﻿using System;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

namespace dbDashboard
{
    public partial class lblMaxTime : Label  
    {
        const string _strMax = "At: ";
        private DateTime _dtMax;
        private Boolean _bChanged;

        public lblMaxTime()
        {
            Label lblMaxTime = new Label();
            this.Text = _strMax + "--:--:--";          
        }

        public DateTime MaxTime
        {
            get { return this._dtMax; }
            set { this._dtMax = value; }
        }

        public Boolean bChanged
        {
            get { return this._bChanged; }
            set { this._bChanged = value; }
        }

        public void SetMax(DateTime dtMax)
        {           
                this.MaxTime = dtMax;
                bChanged = true;
                this.Text = _strMax + this.MaxTime.Hour.ToString("0#") + ":" + this.MaxTime.Minute.ToString("0#") + ":" + this.MaxTime.Second.ToString("0#");           
        }
        public void SetMax()
        {
            SetMax(System.DateTime.Now);            
        }
     }
}
