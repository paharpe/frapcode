﻿namespace dbDashboard
{
    partial class frmDashBoks
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grbBoks = new System.Windows.Forms.GroupBox();
            this.lblVreemd = new System.Windows.Forms.Label();
            this.cmdKankel = new System.Windows.Forms.Button();
            this.cmdOke = new System.Windows.Forms.Button();
            this.grbNewVal = new System.Windows.Forms.GroupBox();
            this.cmdNewUser = new System.Windows.Forms.Button();
            this.cmdApply = new System.Windows.Forms.Button();
            this.lblNewUser = new System.Windows.Forms.Label();
            this.lblNewPassword = new System.Windows.Forms.Label();
            this.lblOldValues = new System.Windows.Forms.Label();
            this.pnlBoks = new System.Windows.Forms.Panel();
            this.grbBoksText = new System.Windows.Forms.GroupBox();
            this.txtBoksText = new System.Windows.Forms.TextBox();
            this.lblBoksText = new System.Windows.Forms.Label();
            this.grbBoksSQL = new System.Windows.Forms.GroupBox();
            this.txtBoksSQLUser = new System.Windows.Forms.TextBox();
            this.lblBoksSQLUser = new System.Windows.Forms.Label();
            this.lblBoksSQLPassword = new System.Windows.Forms.Label();
            this.txtBoksSQLPassword = new System.Windows.Forms.TextBox();
            this.cmdBoksWhere = new System.Windows.Forms.Button();
            this.lblBoksWarn = new System.Windows.Forms.Label();
            this.lblBoksDesc3 = new System.Windows.Forms.Label();
            this.lblBoksDesc2 = new System.Windows.Forms.Label();
            this.lblBoksDesc = new System.Windows.Forms.Label();
            this.txtNewUser = new dbDashboard.txtMaint();
            this.txtNewPassword = new dbDashboard.txtMaint();
            this.grbBoks.SuspendLayout();
            this.grbNewVal.SuspendLayout();
            this.grbBoksText.SuspendLayout();
            this.grbBoksSQL.SuspendLayout();
            this.SuspendLayout();
            // 
            // grbBoks
            // 
            this.grbBoks.Controls.Add(this.lblVreemd);
            this.grbBoks.Controls.Add(this.cmdKankel);
            this.grbBoks.Controls.Add(this.cmdOke);
            this.grbBoks.Controls.Add(this.grbNewVal);
            this.grbBoks.Controls.Add(this.lblOldValues);
            this.grbBoks.Controls.Add(this.pnlBoks);
            this.grbBoks.Controls.Add(this.grbBoksText);
            this.grbBoks.Controls.Add(this.grbBoksSQL);
            this.grbBoks.Controls.Add(this.cmdBoksWhere);
            this.grbBoks.Controls.Add(this.lblBoksWarn);
            this.grbBoks.Controls.Add(this.lblBoksDesc3);
            this.grbBoks.Controls.Add(this.lblBoksDesc2);
            this.grbBoks.Controls.Add(this.lblBoksDesc);
            this.grbBoks.Location = new System.Drawing.Point(9, 13);
            this.grbBoks.Name = "grbBoks";
            this.grbBoks.Size = new System.Drawing.Size(555, 485);
            this.grbBoks.TabIndex = 0;
            this.grbBoks.TabStop = false;
            this.grbBoks.Text = "Boks userid / password";
            // 
            // lblVreemd
            // 
            this.lblVreemd.AutoSize = true;
            this.lblVreemd.Location = new System.Drawing.Point(24, 290);
            this.lblVreemd.Name = "lblVreemd";
            this.lblVreemd.Size = new System.Drawing.Size(506, 13);
            this.lblVreemd.TabIndex = 28;
            this.lblVreemd.Text = "Op dit form is iets vreemds aan de hand: Zolang de OK en Cancel binnen de groepbo" +
                "x bllijven is het goed.";
            this.lblVreemd.Visible = false;
            // 
            // cmdKankel
            // 
            this.cmdKankel.Location = new System.Drawing.Point(91, 336);
            this.cmdKankel.Name = "cmdKankel";
            this.cmdKankel.Size = new System.Drawing.Size(75, 23);
            this.cmdKankel.TabIndex = 26;
            this.cmdKankel.Text = "Cancel";
            this.cmdKankel.UseVisualStyleBackColor = true;
            this.cmdKankel.Click += new System.EventHandler(this.cmdKankel_Click);
            // 
            // cmdOke
            // 
            this.cmdOke.Location = new System.Drawing.Point(7, 336);
            this.cmdOke.Name = "cmdOke";
            this.cmdOke.Size = new System.Drawing.Size(75, 23);
            this.cmdOke.TabIndex = 25;
            this.cmdOke.Text = "Ok";
            this.cmdOke.UseVisualStyleBackColor = true;
            this.cmdOke.Click += new System.EventHandler(this.cmdOke_Click);
            // 
            // grbNewVal
            // 
            this.grbNewVal.Controls.Add(this.cmdNewUser);
            this.grbNewVal.Controls.Add(this.txtNewUser);
            this.grbNewVal.Controls.Add(this.cmdApply);
            this.grbNewVal.Controls.Add(this.txtNewPassword);
            this.grbNewVal.Controls.Add(this.lblNewUser);
            this.grbNewVal.Controls.Add(this.lblNewPassword);
            this.grbNewVal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbNewVal.Location = new System.Drawing.Point(17, 241);
            this.grbNewVal.Name = "grbNewVal";
            this.grbNewVal.Size = new System.Drawing.Size(521, 85);
            this.grbNewVal.TabIndex = 10;
            this.grbNewVal.TabStop = false;
            this.grbNewVal.Text = "New Values";
            // 
            // cmdNewUser
            // 
            this.cmdNewUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdNewUser.Location = new System.Drawing.Point(303, 24);
            this.cmdNewUser.Name = "cmdNewUser";
            this.cmdNewUser.Size = new System.Drawing.Size(52, 23);
            this.cmdNewUser.TabIndex = 2;
            this.cmdNewUser.Text = "Change";
            this.cmdNewUser.UseVisualStyleBackColor = true;
            this.cmdNewUser.Click += new System.EventHandler(this.cmdNewUser_Click);
            // 
            // cmdApply
            // 
            this.cmdApply.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdApply.Location = new System.Drawing.Point(438, 55);
            this.cmdApply.Name = "cmdApply";
            this.cmdApply.Size = new System.Drawing.Size(75, 23);
            this.cmdApply.TabIndex = 5;
            this.cmdApply.Text = "Apply";
            this.cmdApply.UseVisualStyleBackColor = true;
            this.cmdApply.Click += new System.EventHandler(this.cmdApply_Click);
            // 
            // lblNewUser
            // 
            this.lblNewUser.AutoSize = true;
            this.lblNewUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNewUser.Location = new System.Drawing.Point(141, 32);
            this.lblNewUser.Name = "lblNewUser";
            this.lblNewUser.Size = new System.Drawing.Size(40, 13);
            this.lblNewUser.TabIndex = 0;
            this.lblNewUser.Text = "Userid:";
            // 
            // lblNewPassword
            // 
            this.lblNewPassword.AutoSize = true;
            this.lblNewPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNewPassword.Location = new System.Drawing.Point(141, 53);
            this.lblNewPassword.Name = "lblNewPassword";
            this.lblNewPassword.Size = new System.Drawing.Size(56, 13);
            this.lblNewPassword.TabIndex = 3;
            this.lblNewPassword.Text = "Password:";
            // 
            // lblOldValues
            // 
            this.lblOldValues.AutoSize = true;
            this.lblOldValues.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOldValues.Location = new System.Drawing.Point(19, 91);
            this.lblOldValues.Name = "lblOldValues";
            this.lblOldValues.Size = new System.Drawing.Size(94, 13);
            this.lblOldValues.TabIndex = 5;
            this.lblOldValues.Text = "Current Values:";
            // 
            // pnlBoks
            // 
            this.pnlBoks.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlBoks.Location = new System.Drawing.Point(2, 204);
            this.pnlBoks.Name = "pnlBoks";
            this.pnlBoks.Size = new System.Drawing.Size(553, 4);
            this.pnlBoks.TabIndex = 8;
            // 
            // grbBoksText
            // 
            this.grbBoksText.Controls.Add(this.txtBoksText);
            this.grbBoksText.Controls.Add(this.lblBoksText);
            this.grbBoksText.Location = new System.Drawing.Point(234, 111);
            this.grbBoksText.Name = "grbBoksText";
            this.grbBoksText.Size = new System.Drawing.Size(304, 82);
            this.grbBoksText.TabIndex = 7;
            this.grbBoksText.TabStop = false;
            this.grbBoksText.Text = "Textfile";
            // 
            // txtBoksText
            // 
            this.txtBoksText.Location = new System.Drawing.Point(47, 32);
            this.txtBoksText.MaxLength = 8;
            this.txtBoksText.Name = "txtBoksText";
            this.txtBoksText.Size = new System.Drawing.Size(249, 20);
            this.txtBoksText.TabIndex = 1;
            // 
            // lblBoksText
            // 
            this.lblBoksText.AutoSize = true;
            this.lblBoksText.Location = new System.Drawing.Point(6, 35);
            this.lblBoksText.Name = "lblBoksText";
            this.lblBoksText.Size = new System.Drawing.Size(37, 13);
            this.lblBoksText.TabIndex = 0;
            this.lblBoksText.Text = "String:";
            // 
            // grbBoksSQL
            // 
            this.grbBoksSQL.Controls.Add(this.txtBoksSQLUser);
            this.grbBoksSQL.Controls.Add(this.lblBoksSQLUser);
            this.grbBoksSQL.Controls.Add(this.lblBoksSQLPassword);
            this.grbBoksSQL.Controls.Add(this.txtBoksSQLPassword);
            this.grbBoksSQL.Location = new System.Drawing.Point(17, 111);
            this.grbBoksSQL.Name = "grbBoksSQL";
            this.grbBoksSQL.Size = new System.Drawing.Size(202, 82);
            this.grbBoksSQL.TabIndex = 6;
            this.grbBoksSQL.TabStop = false;
            this.grbBoksSQL.Text = "SQL";
            // 
            // txtBoksSQLUser
            // 
            this.txtBoksSQLUser.Location = new System.Drawing.Point(74, 19);
            this.txtBoksSQLUser.MaxLength = 8;
            this.txtBoksSQLUser.Name = "txtBoksSQLUser";
            this.txtBoksSQLUser.Size = new System.Drawing.Size(100, 20);
            this.txtBoksSQLUser.TabIndex = 1;
            // 
            // lblBoksSQLUser
            // 
            this.lblBoksSQLUser.AutoSize = true;
            this.lblBoksSQLUser.Location = new System.Drawing.Point(9, 22);
            this.lblBoksSQLUser.Name = "lblBoksSQLUser";
            this.lblBoksSQLUser.Size = new System.Drawing.Size(40, 13);
            this.lblBoksSQLUser.TabIndex = 0;
            this.lblBoksSQLUser.Text = "Userid:";
            // 
            // lblBoksSQLPassword
            // 
            this.lblBoksSQLPassword.AutoSize = true;
            this.lblBoksSQLPassword.Location = new System.Drawing.Point(9, 48);
            this.lblBoksSQLPassword.Name = "lblBoksSQLPassword";
            this.lblBoksSQLPassword.Size = new System.Drawing.Size(56, 13);
            this.lblBoksSQLPassword.TabIndex = 2;
            this.lblBoksSQLPassword.Text = "Password:";
            // 
            // txtBoksSQLPassword
            // 
            this.txtBoksSQLPassword.Location = new System.Drawing.Point(74, 45);
            this.txtBoksSQLPassword.MaxLength = 10;
            this.txtBoksSQLPassword.Name = "txtBoksSQLPassword";
            this.txtBoksSQLPassword.Size = new System.Drawing.Size(100, 20);
            this.txtBoksSQLPassword.TabIndex = 3;
            // 
            // cmdBoksWhere
            // 
            this.cmdBoksWhere.Location = new System.Drawing.Point(433, 53);
            this.cmdBoksWhere.Name = "cmdBoksWhere";
            this.cmdBoksWhere.Size = new System.Drawing.Size(21, 22);
            this.cmdBoksWhere.TabIndex = 4;
            this.cmdBoksWhere.Text = "?";
            this.cmdBoksWhere.UseVisualStyleBackColor = true;
            this.cmdBoksWhere.Click += new System.EventHandler(this.cmdBoksWhere_Click);
            // 
            // lblBoksWarn
            // 
            this.lblBoksWarn.AutoSize = true;
            this.lblBoksWarn.ForeColor = System.Drawing.Color.Red;
            this.lblBoksWarn.Location = new System.Drawing.Point(20, 218);
            this.lblBoksWarn.Name = "lblBoksWarn";
            this.lblBoksWarn.Size = new System.Drawing.Size(501, 13);
            this.lblBoksWarn.TabIndex = 9;
            this.lblBoksWarn.Text = "Warning: never use the ! sign in your Boks pw. It will  cause trouble while runni" +
                "ng the Windows scripting !";
            // 
            // lblBoksDesc3
            // 
            this.lblBoksDesc3.AutoSize = true;
            this.lblBoksDesc3.Location = new System.Drawing.Point(20, 58);
            this.lblBoksDesc3.Name = "lblBoksDesc3";
            this.lblBoksDesc3.Size = new System.Drawing.Size(409, 13);
            this.lblBoksDesc3.TabIndex = 3;
            this.lblBoksDesc3.Text = "2) The external file being used to authenticate  the execution of the queue info " +
                "scripts";
            // 
            // lblBoksDesc2
            // 
            this.lblBoksDesc2.AutoSize = true;
            this.lblBoksDesc2.Location = new System.Drawing.Point(20, 41);
            this.lblBoksDesc2.Name = "lblBoksDesc2";
            this.lblBoksDesc2.Size = new System.Drawing.Size(172, 13);
            this.lblBoksDesc2.TabIndex = 2;
            this.lblBoksDesc2.Text = "1) The local Access SQL database";
            // 
            // lblBoksDesc
            // 
            this.lblBoksDesc.AutoSize = true;
            this.lblBoksDesc.Location = new System.Drawing.Point(14, 22);
            this.lblBoksDesc.Name = "lblBoksDesc";
            this.lblBoksDesc.Size = new System.Drawing.Size(205, 13);
            this.lblBoksDesc.TabIndex = 1;
            this.lblBoksDesc.Text = "This function updates Boks credentials at:";
            // 
            // txtNewUser
            // 
            this.txtNewUser.bChanged = false;
            this.txtNewUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNewUser.Location = new System.Drawing.Point(203, 25);
            this.txtNewUser.MaxLength = 8;
            this.txtNewUser.Name = "txtNewUser";
            this.txtNewUser.Size = new System.Drawing.Size(100, 20);
            this.txtNewUser.strOldValue = "";
            this.txtNewUser.TabIndex = 1;
            this.txtNewUser.TextChanged += new System.EventHandler(this.txtNewUser_TextChanged);
            // 
            // txtNewPassword
            // 
            this.txtNewPassword.bChanged = false;
            this.txtNewPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNewPassword.Location = new System.Drawing.Point(203, 48);
            this.txtNewPassword.MaxLength = 10;
            this.txtNewPassword.Name = "txtNewPassword";
            this.txtNewPassword.Size = new System.Drawing.Size(100, 20);
            this.txtNewPassword.strOldValue = "";
            this.txtNewPassword.TabIndex = 4;
            this.txtNewPassword.TextChanged += new System.EventHandler(this.txtNewPassword_TextChanged);
            // 
            // frmDashBoks
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoValidate = System.Windows.Forms.AutoValidate.Disable;
            this.ClientSize = new System.Drawing.Size(571, 380);
            this.Controls.Add(this.grbBoks);
            this.Name = "frmDashBoks";
            this.Text = "frmDashBoks";
            this.Load += new System.EventHandler(this.frmDashBoks_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.frmDashBoks_Paint);
            this.grbBoks.ResumeLayout(false);
            this.grbBoks.PerformLayout();
            this.grbNewVal.ResumeLayout(false);
            this.grbNewVal.PerformLayout();
            this.grbBoksText.ResumeLayout(false);
            this.grbBoksText.PerformLayout();
            this.grbBoksSQL.ResumeLayout(false);
            this.grbBoksSQL.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grbBoks;
        private System.Windows.Forms.TextBox txtBoksSQLPassword;
        private System.Windows.Forms.TextBox txtBoksSQLUser;
        private System.Windows.Forms.Label lblBoksSQLPassword;
        private System.Windows.Forms.Label lblBoksSQLUser;
        private System.Windows.Forms.Button cmdBoksWhere;
        private System.Windows.Forms.Label lblBoksWarn;
        private System.Windows.Forms.Label lblBoksDesc3;
        private System.Windows.Forms.Label lblBoksDesc2;
        private System.Windows.Forms.Label lblBoksDesc;
        private System.Windows.Forms.GroupBox grbBoksText;
        private System.Windows.Forms.TextBox txtBoksText;
        private System.Windows.Forms.Label lblBoksText;
        private System.Windows.Forms.GroupBox grbBoksSQL;
        private System.Windows.Forms.Label lblNewPassword;
        private System.Windows.Forms.Label lblNewUser;
        private System.Windows.Forms.Panel pnlBoks;
        private System.Windows.Forms.Label lblOldValues;
        private System.Windows.Forms.GroupBox grbNewVal;
        private System.Windows.Forms.Button cmdApply;
        private txtMaint txtNewPassword;
        private txtMaint txtNewUser;
        private System.Windows.Forms.Button cmdNewUser;
        private System.Windows.Forms.Button cmdKankel;
        private System.Windows.Forms.Button cmdOke;
        private System.Windows.Forms.Label lblVreemd;
    }
}