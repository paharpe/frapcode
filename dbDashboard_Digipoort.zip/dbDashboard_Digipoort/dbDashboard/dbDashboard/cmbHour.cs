﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace dbDashboard
{
    public partial class cmbHour : ComboBox
    {
        private Boolean _bChanged = false;
        private int _intHour = 0;

        public cmbHour()
        {
            ComboBox cmbHour = new ComboBox();
            
            this.Size = new System.Drawing.Size(45, 20);
            this.DropDownStyle = ComboBoxStyle.DropDownList;
            clDashFunction.Melding(this.Items.Count.ToString());
        }

        public Boolean bChanged
        {
            get { return this._bChanged; }
            set { this._bChanged = value; }
        }

        public int intHour
        {
            get { return this._intHour; }
            set { this._intHour = value; }
        }

        public cmbHour(IContainer container)
        {
            container.Add(this);

            InitializeComponent();
        }

        protected override void OnCreateControl()
        {
            int intHour = 0;
            while (intHour < 24)
            {
                this.Items.Add(intHour.ToString("0#"));
                intHour++;
            }
            base.OnCreateControl();
        }

        protected override void OnSelectedIndexChanged(EventArgs e)
        {
            this.bChanged = false;
            if (Convert.ToInt32(this.SelectedItem) != this._intHour)
            {
                this._intHour = Convert.ToInt32(this.SelectedItem);
                this.bChanged = true;
            }            
            base.OnSelectedIndexChanged(e);
        }
    }
}
