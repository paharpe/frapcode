﻿namespace dbDashboard
{
    partial class frmDashIni
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmdOpslaan = new System.Windows.Forms.Button();
            this.grpIni = new System.Windows.Forms.GroupBox();
            this.lblNote = new System.Windows.Forms.Label();
            this.lblTagVal = new System.Windows.Forms.Label();
            this.lblTag = new System.Windows.Forms.Label();
            this.cmdToepassen = new System.Windows.Forms.Button();
            this.grbConnectie.SuspendLayout();
            this.grpIni.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmdAfsluiten
            // 
            this.cmdAfsluiten.Location = new System.Drawing.Point(4, 364);
            // 
            // cmdOpslaan
            // 
            this.cmdOpslaan.Location = new System.Drawing.Point(108, 364);
            this.cmdOpslaan.Name = "cmdOpslaan";
            this.cmdOpslaan.Size = new System.Drawing.Size(75, 23);
            this.cmdOpslaan.TabIndex = 23;
            this.cmdOpslaan.Text = "Opslaan";
            this.cmdOpslaan.UseVisualStyleBackColor = true;
            this.cmdOpslaan.Click += new System.EventHandler(this.cmdOpslaan_Click);
            // 
            // grpIni
            // 
            this.grpIni.Controls.Add(this.lblNote);
            this.grpIni.Controls.Add(this.lblTagVal);
            this.grpIni.Controls.Add(this.lblTag);
            this.grpIni.Location = new System.Drawing.Point(4, 10);
            this.grpIni.Name = "grpIni";
            this.grpIni.Size = new System.Drawing.Size(448, 348);
            this.grpIni.TabIndex = 24;
            this.grpIni.TabStop = false;
            this.grpIni.Text = "Vul de gegevens in";
            // 
            // lblNote
            // 
            this.lblNote.AutoSize = true;
            this.lblNote.Location = new System.Drawing.Point(6, 332);
            this.lblNote.Name = "lblNote";
            this.lblNote.Size = new System.Drawing.Size(163, 13);
            this.lblNote.TabIndex = 2;
            this.lblNote.Text = "*) Tag definitie hardcoded in MDI";
            // 
            // lblTagVal
            // 
            this.lblTagVal.AutoSize = true;
            this.lblTagVal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTagVal.Location = new System.Drawing.Point(102, 23);
            this.lblTagVal.Name = "lblTagVal";
            this.lblTagVal.Size = new System.Drawing.Size(336, 13);
            this.lblTagVal.TabIndex = 1;
            this.lblTagVal.Text = "Waarde                                                                           " +
                "                      ";
            // 
            // lblTag
            // 
            this.lblTag.AutoSize = true;
            this.lblTag.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTag.Location = new System.Drawing.Point(15, 23);
            this.lblTag.Name = "lblTag";
            this.lblTag.Size = new System.Drawing.Size(81, 13);
            this.lblTag.TabIndex = 0;
            this.lblTag.Text = "Tag*                 ";
            // 
            // cmdToepassen
            // 
            this.cmdToepassen.Location = new System.Drawing.Point(189, 364);
            this.cmdToepassen.Name = "cmdToepassen";
            this.cmdToepassen.Size = new System.Drawing.Size(75, 23);
            this.cmdToepassen.TabIndex = 25;
            this.cmdToepassen.Text = "Toepassen";
            this.cmdToepassen.UseVisualStyleBackColor = true;
            this.cmdToepassen.Click += new System.EventHandler(this.cmdToepassen_Click);
            // 
            // frmDashIni
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(460, 390);
            this.Controls.Add(this.cmdToepassen);
            this.Controls.Add(this.grpIni);
            this.Controls.Add(this.cmdOpslaan);
            this.Name = "frmDashIni";
            this.Text = "frmDashIni";
            this.Load += new System.EventHandler(this.frmDashIni_Load);
            this.Controls.SetChildIndex(this.cmdAfsluiten, 0);
            this.Controls.SetChildIndex(this.grbConnectie, 0);
            this.Controls.SetChildIndex(this.lblVoortgang, 0);
            this.Controls.SetChildIndex(this.cmdOpslaan, 0);
            this.Controls.SetChildIndex(this.grpIni, 0);
            this.Controls.SetChildIndex(this.cmdToepassen, 0);
            this.grbConnectie.ResumeLayout(false);
            this.grbConnectie.PerformLayout();
            this.grpIni.ResumeLayout(false);
            this.grpIni.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button cmdOpslaan;
        private System.Windows.Forms.GroupBox grpIni;
        private System.Windows.Forms.Label lblTagVal;
        private System.Windows.Forms.Label lblTag;
        private System.Windows.Forms.Button cmdToepassen;
        private System.Windows.Forms.Label lblNote;
    }
}