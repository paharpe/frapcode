﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.IO;

namespace dbDashboard
{
    public partial class frmDashShell : frmDashBase
    {
        public frmDashShell()
        {
            InitializeComponent();
        }

        private string strTableNr = "15";
       // private int intSeconds;

        private void frmDashShell_Load(object sender, EventArgs e)
        {
            frm_init();
        }
        
        /// <summary>
        /// Initialize form layout, settings and controls
        /// </summary>
        private void frm_init()
        {
            tmrScript.Stop();

            get_online_scripts();

            if (cmbScript.Items.Count < 1)
            {
                cmbScript.Enabled       = false;
                cmbScript.SelectedIndex = -1;               
            }
            else
            {
                cmbScript.SelectedIndex = 0;
                cmbScript.Enabled       = true;                
            }

            // Force the cmdExecute.abled Yes/No
            cmbScript_SelectedIndexChanged(new object(), new EventArgs());

            lbResult.Enabled = false;
            cmdSaveTo.Enabled = false;
        }

        private void cmbScript_SelectedIndexChanged(object sender, EventArgs e)
        {  
            cmdExecute.Enabled = cmbScript.Text.ToString() != "";
            if (cmdExecute.Enabled && cmbScript.Text.ToString() != "")
            {
                cmbServer.SelectedIndex = cmbScript.SelectedIndex;
                cmbCmd.SelectedIndex    = cmbScript.SelectedIndex;
            }
        }


        /// <summary>
        /// Execute selected script and populate lbResult with script result line(s) 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmdExecute_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;

            // tmrScript.Start();
           //  intSeconds = 0;

            execute_script(cmbServer.Text.ToString(), cmbCmd.Text.ToString());
           // tmrScript.Stop();            

            clDashFunction.Melding("Script execution completed",1,"I");

            this.Cursor = Cursors.Default;
        }


        private void execute_script(string strServer, string strCmd)
        {
            lbResult.Items.Clear();
            cmdSaveTo.Enabled = false;

            StreamReader myStreamReader;

            myStreamReader = clDashFunction.get_linux_data(strServer, strCmd,false);
            
            if (myStreamReader != null)
            {
                while (!myStreamReader.EndOfStream)
                {
                    lbResult.Items.Add(myStreamReader.ReadLine());
                }
                myStreamReader.Close();
            }    
        
            if (lbResult.Items.Count > 0)
            {
                cmdSaveTo.Enabled = true;
                lbResult.Enabled = true;
            }
        }


        private void tmrScript_Tick(object sender, EventArgs e)
        {           
           // lbResult.Items.Add( System.DateTime.Now.ToString());
           // lblTimer.Text = System.DateTime.Now.ToString();
           // intSeconds++;
           // lblTimer.Text = intSeconds.ToString();
           // this.Refresh();            
        }

        /// <summary>
        /// Check syntax of scriptline out of table 15. Should have lay-out:
        /// <server>:<location><script> => kslv046:/home/pe029017/scripts/ftps_read_all.scr
        /// </summary>
        /// <param name="strOnlinecmd"></param>
        /// <returns></returns>
        private Boolean check_Onlinecmd(string strOnlinecmd)
        {
            Boolean bReturn = false;

            string[] arOnlinecmd = Regex.Split(strOnlinecmd, ":");
            if (arOnlinecmd.Length == 2)
            {
                bReturn = clDashFunction.validate_server(arOnlinecmd[0].ToString());
            }
            return bReturn;
        }

        /// <summary>
        /// Select all executable scripts out of table #15
        /// Returned (example):
        /// mysql.vul_deze_text1_array(*) mysql.vul_deze_text2_array(*)       mysql.vul_deze_text3_array(*)
        /// FTPS_ALL_READ                 FTPS rapportage capaciteitoverzicht kslv046:/home/pe029017/scripts/ftps_rap_real.scr
        /// </summary>
        private void get_online_scripts()
        {
            string strCmd;

            cmbServer.Items.Clear();
            cmbScript.Items.Clear();
            cmbCmd.Items.Clear();

            DoSql mysql = new DoSql();
            mysql.vul_deze_text1_array[1] = "FTA";
            mysql.DoQuery("SELECT ElemElem, ElemOms1,ElemOms2 " +
                          "FROM   DashElem " +
                          "WHERE  ElemTabn = "+strTableNr);
            if (mysql.affected_rows < 1)
            {
                clDashFunction.Melding("Geen data aangetroffen in tabel "+strTableNr + " !", 1, "I");
            }
            else
            {
                for (int i = 1; i <= mysql.affected_rows; i++)
                {
                    strCmd = mysql.vul_deze_text3_array[i];
                    
                    // Check syntax in cmdstring 
                    if (check_Onlinecmd(strCmd))
                    {
                        cmbScript.Items.Add(mysql.vul_deze_text2_array[i]); // Omschrijving
                        cmbServer.Items.Add(Regex.Split(strCmd, ":")[0]);   // server
                        cmbCmd.Items.Add(Regex.Split(strCmd, ":")[1]);      // path & scriptnaam
                    }
                    else
                    {
                        clDashFunction.Melding("The following entry in table "+strTableNr + " is not valid or the designated server does not exist in table 12 \n\n " + strCmd, 1, "I ");
                    }                 
                }
            }
        }

        private void cmdScripts_Click(object sender, EventArgs e)
        {
            frmDashMaintT frmMaintT = new frmDashMaintT();
                       
            frmMaintT.strBeheer_tabel = "SCRIPTS";
            frmMaintT.strSupplemental_Title = "Execute shell scripts online"; 
            frmMaintT.strUserCode = this.strUserCode;
            frmMaintT.strUserUgro = this.strUserUgro;
            frmMaintT.MdiParent = this.MdiParent;
            frmMaintT.strTabel_nr = strTableNr;
            frmMaintT.Show();           
        }

        private void scriptsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cmdScripts_Click(sender, e);
        }
            
        /// <summary>
        /// Save output to an external txt file
        /// </summary>
        private void save_to()
        {
            string strSaveFileName;
            string strTag = "[GDATAPATH]";
            string strTagValue;
       
            saveFileDialog1.InitialDirectory = clDashFunction.get_TagValue(strTag, true);
            saveFileDialog1.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (saveFileDialog1.ShowDialog(this) == DialogResult.OK)
            {
                strSaveFileName = saveFileDialog1.FileName.ToString();

                strTagValue = clDashFunction.get_dir_file(strSaveFileName)[1].ToString();

                // ******************************************************************************************
                // Als de zojuist, in het dialog gekozen directory anders is dan dan die nu is opgeslagen
                // bij de [GDATAPATH] tagvalue, dan gaan we deze updaten..
                // ******************************************************************************************
                if (saveFileDialog1.InitialDirectory != strTagValue)
                {
                    clDashFunction.update_ini_tag_value(mdiDashboard.strIniFile, strTag, strTagValue);
                }

                // **************************************************************************************
                // Hier wordt de inhoud van de listbox doorgeschreven naar de zojuist gekozen outputfile
                // **************************************************************************************
                StreamWriter sw = clDashFunction.open4write(strSaveFileName);
                int lbIndex = 0;
                while (lbIndex < lbResult.Items.Count)
                {
                    sw.WriteLine(lbResult.Items[lbIndex].ToString());
                    lbIndex++;
                }
                sw.Close();

                // **************************************************************************************
                // Wil u de zojuist geschreven outputfile zien in NotePad ?
                // **************************************************************************************
                if (clDashFunction.Melding("Done, " + lbIndex.ToString() + " listbox rows saved to:\n" + strSaveFileName + "\n\n Would you like to open this file ?", 2, "Q") == DialogResult.OK)
                {
                    clDashFunction.Notepad(strSaveFileName);
                }
            }
        }

        private void cmdSaveTo_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            save_to();
            this.Cursor = Cursors.Default;
        }

        private void cmbServer_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtServer.Text = cmbServer.Text;
        }

        private void cmbCmd_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtCmd.Text = cmbCmd.Text;
        }                    
    }
}