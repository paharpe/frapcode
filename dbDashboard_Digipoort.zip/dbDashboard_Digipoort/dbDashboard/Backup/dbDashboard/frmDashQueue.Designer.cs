﻿namespace dbDashboard
{
    partial class frmDashQueue
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tmrSMTPQ = new System.Windows.Forms.Timer(this.components);
            this.tmrCoreQ = new System.Windows.Forms.Timer(this.components);
            this.tmrX400Q = new System.Windows.Forms.Timer(this.components);
            this.tmrRefresh = new System.Windows.Forms.Timer(this.components);
            this.tmrSeconds = new System.Windows.Forms.Timer(this.components);
            this.lblMsgs_OVH = new System.Windows.Forms.Label();
            this.lblMsgs_BDR = new System.Windows.Forms.Label();
            this.dgSMTPQ_OVH = new System.Windows.Forms.DataGridView();
            this.colSMTP_OVH_Server = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSMTP_OVH_Queue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSMTPQ_OVH_checktime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSMTP_OVH_Domain = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSMTP_OVH_Age = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgSMTPQ_BDR = new System.Windows.Forms.DataGridView();
            this.colSMTPQ_BDR_server = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSMTPQ_BDR_Queue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSMTPQ_BDR_checktime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSMTPQ_BDR_Domain = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSMTP_BDR_Age = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grbCoreQ = new System.Windows.Forms.GroupBox();
            this.pnlCore2 = new System.Windows.Forms.Panel();
            this.lblMsgs_Core_Age2 = new System.Windows.Forms.Label();
            this.lblMsgs_Core_Total2 = new System.Windows.Forms.Label();
            this.lblCoreTotal2 = new System.Windows.Forms.Label();
            this.lblCoreOldest2 = new System.Windows.Forms.Label();
            this.pnlCore1 = new System.Windows.Forms.Panel();
            this.lblCoreTotal1 = new System.Windows.Forms.Label();
            this.lblCoreOldest1 = new System.Windows.Forms.Label();
            this.lblMsgs_Core_Age1 = new System.Windows.Forms.Label();
            this.lblMsgs_Core_Total1 = new System.Windows.Forms.Label();
            this.dgCoreQ = new System.Windows.Forms.DataGridView();
            this.colCoreQ_Server = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCoreQ_Proto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCoreQ_Queue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCoreQ_CheckTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCoreQ_Oldest = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCoreQ_Newest = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grbX400Q = new System.Windows.Forms.GroupBox();
            this.lblSMTP_OVH = new System.Windows.Forms.Label();
            this.dgX400Q_OVH = new System.Windows.Forms.DataGridView();
            this.colX400Q_OVH_Server = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colX400Q_OVH_Queue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colX400Q_OVH_CheckTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colX400Q_OVH_Oldest = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colX400Q_OVH_Newest = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblX400_OVH = new System.Windows.Forms.Label();
            this.grbX400Q_BDR = new System.Windows.Forms.GroupBox();
            this.pnSMTPQ_BDR = new System.Windows.Forms.Panel();
            this.lbSMTPQ_BDR = new System.Windows.Forms.ListBox();
            this.lblSMTP_BDR = new System.Windows.Forms.Label();
            this.lblX400_BDR = new System.Windows.Forms.Label();
            this.dgX400Q_BDR = new System.Windows.Forms.DataGridView();
            this.colX400Q_BDR_Server = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colX400Q_BDR_Queue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colX400Q_BDR_CheckTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colX400Q_BDR_Oldest = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colX400Q_BDR_Newest = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grbAllQueue = new System.Windows.Forms.GroupBox();
            this.lblLog = new System.Windows.Forms.Label();
            this.lblDebugError_val = new System.Windows.Forms.Label();
            this.lblDebugError_text = new System.Windows.Forms.Label();
            this.cmdDebug = new System.Windows.Forms.Button();
            this.lblSettings = new System.Windows.Forms.Label();
            this.lblCore = new System.Windows.Forms.Label();
            this.lbDebug = new System.Windows.Forms.ListBox();
            this.lblOverheden = new System.Windows.Forms.Label();
            this.lblBedrijven = new System.Windows.Forms.Label();
            this.grpSettings = new System.Windows.Forms.GroupBox();
            this.pnlSettings = new System.Windows.Forms.Panel();
            this.lblAutoUpdate = new System.Windows.Forms.Label();
            this.cmdManualUpdate = new System.Windows.Forms.Button();
            this.lblUpdte = new System.Windows.Forms.Label();
            this.lblRefresh_till_refresh = new System.Windows.Forms.Label();
            this.lblRefresh_last_refresh = new System.Windows.Forms.Label();
            this.rbAutoUpdateOn = new System.Windows.Forms.RadioButton();
            this.rbAutoUpdateOff = new System.Windows.Forms.RadioButton();
            this.cmbGroupSMTP = new System.Windows.Forms.ComboBox();
            this.lblGroupSMTP = new System.Windows.Forms.Label();
            this.lblSaveFiile = new System.Windows.Forms.Label();
            this.cmdSaveStop = new System.Windows.Forms.Button();
            this.cmdConfigureSave = new System.Windows.Forms.Button();
            this.lblUpdate_Script_val = new System.Windows.Forms.Label();
            this.lblUpdate_Script_txt = new System.Windows.Forms.Label();
            this.lblSaveFile = new System.Windows.Forms.Label();
            this.rbDGSMTPQ_BEDR = new System.Windows.Forms.RadioButton();
            this.rbPNSMTPQ_BEDR = new System.Windows.Forms.RadioButton();
            this.grbConnectie.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgSMTPQ_OVH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgSMTPQ_BDR)).BeginInit();
            this.grbCoreQ.SuspendLayout();
            this.pnlCore2.SuspendLayout();
            this.pnlCore1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgCoreQ)).BeginInit();
            this.grbX400Q.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgX400Q_OVH)).BeginInit();
            this.grbX400Q_BDR.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgX400Q_BDR)).BeginInit();
            this.grbAllQueue.SuspendLayout();
            this.grpSettings.SuspendLayout();
            this.pnlSettings.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmdAfsluiten
            // 
            this.cmdAfsluiten.Location = new System.Drawing.Point(6, 751);
            this.cmdAfsluiten.Size = new System.Drawing.Size(75, 26);
            this.cmdAfsluiten.Text = "Cancel";
            this.cmdAfsluiten.Click += new System.EventHandler(this.cmdAfsluiten_Click_1);
            // 
            // grbConnectie
            // 
            this.grbConnectie.Location = new System.Drawing.Point(829, 937);
            // 
            // lblVoortgang
            // 
            this.lblVoortgang.Location = new System.Drawing.Point(582, 943);
            // 
            // tmrSMTPQ
            // 
            this.tmrSMTPQ.Interval = 45000;
            this.tmrSMTPQ.Tick += new System.EventHandler(this.tmrSMTPQ_Tick);
            // 
            // tmrCoreQ
            // 
            this.tmrCoreQ.Interval = 55000;
            this.tmrCoreQ.Tick += new System.EventHandler(this.tmrCoreQ_Tick);
            // 
            // tmrX400Q
            // 
            this.tmrX400Q.Interval = 50000;
            this.tmrX400Q.Tick += new System.EventHandler(this.tmrX400Q_Tick);
            // 
            // tmrRefresh
            // 
            this.tmrRefresh.Interval = 59000;
            this.tmrRefresh.Tick += new System.EventHandler(this.tmrRefresh_Tick);
            // 
            // tmrSeconds
            // 
            this.tmrSeconds.Interval = 1000;
            this.tmrSeconds.Tick += new System.EventHandler(this.tmrSeconds_Tick);
            // 
            // lblMsgs_OVH
            // 
            this.lblMsgs_OVH.AutoSize = true;
            this.lblMsgs_OVH.Location = new System.Drawing.Point(6, 182);
            this.lblMsgs_OVH.Name = "lblMsgs_OVH";
            this.lblMsgs_OVH.Size = new System.Drawing.Size(84, 13);
            this.lblMsgs_OVH.TabIndex = 4;
            this.lblMsgs_OVH.Text = "Total messages:";
            // 
            // lblMsgs_BDR
            // 
            this.lblMsgs_BDR.AutoSize = true;
            this.lblMsgs_BDR.Location = new System.Drawing.Point(6, 182);
            this.lblMsgs_BDR.Name = "lblMsgs_BDR";
            this.lblMsgs_BDR.Size = new System.Drawing.Size(84, 13);
            this.lblMsgs_BDR.TabIndex = 3;
            this.lblMsgs_BDR.Text = "Total messages:";
            // 
            // dgSMTPQ_OVH
            // 
            this.dgSMTPQ_OVH.AllowUserToAddRows = false;
            this.dgSMTPQ_OVH.AllowUserToDeleteRows = false;
            this.dgSMTPQ_OVH.AllowUserToResizeColumns = false;
            this.dgSMTPQ_OVH.AllowUserToResizeRows = false;
            this.dgSMTPQ_OVH.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgSMTPQ_OVH.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colSMTP_OVH_Server,
            this.colSMTP_OVH_Queue,
            this.colSMTPQ_OVH_checktime,
            this.colSMTP_OVH_Domain,
            this.colSMTP_OVH_Age});
            this.dgSMTPQ_OVH.Location = new System.Drawing.Point(10, 47);
            this.dgSMTPQ_OVH.MultiSelect = false;
            this.dgSMTPQ_OVH.Name = "dgSMTPQ_OVH";
            this.dgSMTPQ_OVH.ReadOnly = true;
            this.dgSMTPQ_OVH.RowHeadersVisible = false;
            this.dgSMTPQ_OVH.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgSMTPQ_OVH.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgSMTPQ_OVH.Size = new System.Drawing.Size(612, 132);
            this.dgSMTPQ_OVH.TabIndex = 0;
            this.dgSMTPQ_OVH.SelectionChanged += new System.EventHandler(this.dgSMTPQ_OVH_SelectionChanged);
            // 
            // colSMTP_OVH_Server
            // 
            this.colSMTP_OVH_Server.HeaderText = "Server";
            this.colSMTP_OVH_Server.MaxInputLength = 8;
            this.colSMTP_OVH_Server.MinimumWidth = 65;
            this.colSMTP_OVH_Server.Name = "colSMTP_OVH_Server";
            this.colSMTP_OVH_Server.ReadOnly = true;
            this.colSMTP_OVH_Server.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colSMTP_OVH_Server.Width = 65;
            // 
            // colSMTP_OVH_Queue
            // 
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle19.Format = "N0";
            dataGridViewCellStyle19.NullValue = null;
            this.colSMTP_OVH_Queue.DefaultCellStyle = dataGridViewCellStyle19;
            this.colSMTP_OVH_Queue.HeaderText = "Queue";
            this.colSMTP_OVH_Queue.MaxInputLength = 7;
            this.colSMTP_OVH_Queue.MinimumWidth = 50;
            this.colSMTP_OVH_Queue.Name = "colSMTP_OVH_Queue";
            this.colSMTP_OVH_Queue.ReadOnly = true;
            this.colSMTP_OVH_Queue.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colSMTP_OVH_Queue.Width = 50;
            // 
            // colSMTPQ_OVH_checktime
            // 
            this.colSMTPQ_OVH_checktime.HeaderText = "CheckTime";
            this.colSMTPQ_OVH_checktime.Name = "colSMTPQ_OVH_checktime";
            this.colSMTPQ_OVH_checktime.ReadOnly = true;
            this.colSMTPQ_OVH_checktime.Width = 130;
            // 
            // colSMTP_OVH_Domain
            // 
            this.colSMTP_OVH_Domain.HeaderText = "Domain";
            this.colSMTP_OVH_Domain.MaxInputLength = 100;
            this.colSMTP_OVH_Domain.MinimumWidth = 180;
            this.colSMTP_OVH_Domain.Name = "colSMTP_OVH_Domain";
            this.colSMTP_OVH_Domain.ReadOnly = true;
            this.colSMTP_OVH_Domain.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colSMTP_OVH_Domain.Width = 180;
            // 
            // colSMTP_OVH_Age
            // 
            this.colSMTP_OVH_Age.HeaderText = "Age";
            this.colSMTP_OVH_Age.MaxInputLength = 100;
            this.colSMTP_OVH_Age.MinimumWidth = 182;
            this.colSMTP_OVH_Age.Name = "colSMTP_OVH_Age";
            this.colSMTP_OVH_Age.ReadOnly = true;
            this.colSMTP_OVH_Age.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colSMTP_OVH_Age.Width = 182;
            // 
            // dgSMTPQ_BDR
            // 
            this.dgSMTPQ_BDR.AllowUserToAddRows = false;
            this.dgSMTPQ_BDR.AllowUserToDeleteRows = false;
            this.dgSMTPQ_BDR.AllowUserToResizeColumns = false;
            this.dgSMTPQ_BDR.AllowUserToResizeRows = false;
            this.dgSMTPQ_BDR.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgSMTPQ_BDR.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colSMTPQ_BDR_server,
            this.colSMTPQ_BDR_Queue,
            this.colSMTPQ_BDR_checktime,
            this.colSMTPQ_BDR_Domain,
            this.colSMTP_BDR_Age});
            this.dgSMTPQ_BDR.Location = new System.Drawing.Point(10, 47);
            this.dgSMTPQ_BDR.MultiSelect = false;
            this.dgSMTPQ_BDR.Name = "dgSMTPQ_BDR";
            this.dgSMTPQ_BDR.ReadOnly = true;
            this.dgSMTPQ_BDR.RowHeadersVisible = false;
            this.dgSMTPQ_BDR.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgSMTPQ_BDR.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgSMTPQ_BDR.Size = new System.Drawing.Size(563, 132);
            this.dgSMTPQ_BDR.TabIndex = 0;
            this.dgSMTPQ_BDR.SelectionChanged += new System.EventHandler(this.dgSMTPQ_BDR_SelectionChanged);
            // 
            // colSMTPQ_BDR_server
            // 
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.colSMTPQ_BDR_server.DefaultCellStyle = dataGridViewCellStyle20;
            this.colSMTPQ_BDR_server.HeaderText = "Server";
            this.colSMTPQ_BDR_server.MaxInputLength = 8;
            this.colSMTPQ_BDR_server.MinimumWidth = 65;
            this.colSMTPQ_BDR_server.Name = "colSMTPQ_BDR_server";
            this.colSMTPQ_BDR_server.ReadOnly = true;
            this.colSMTPQ_BDR_server.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colSMTPQ_BDR_server.Width = 65;
            // 
            // colSMTPQ_BDR_Queue
            // 
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle21.Format = "N0";
            dataGridViewCellStyle21.NullValue = null;
            this.colSMTPQ_BDR_Queue.DefaultCellStyle = dataGridViewCellStyle21;
            this.colSMTPQ_BDR_Queue.HeaderText = "Queue";
            this.colSMTPQ_BDR_Queue.MaxInputLength = 7;
            this.colSMTPQ_BDR_Queue.MinimumWidth = 50;
            this.colSMTPQ_BDR_Queue.Name = "colSMTPQ_BDR_Queue";
            this.colSMTPQ_BDR_Queue.ReadOnly = true;
            this.colSMTPQ_BDR_Queue.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colSMTPQ_BDR_Queue.Width = 50;
            // 
            // colSMTPQ_BDR_checktime
            // 
            this.colSMTPQ_BDR_checktime.HeaderText = "CheckTime";
            this.colSMTPQ_BDR_checktime.MaxInputLength = 80;
            this.colSMTPQ_BDR_checktime.Name = "colSMTPQ_BDR_checktime";
            this.colSMTPQ_BDR_checktime.ReadOnly = true;
            this.colSMTPQ_BDR_checktime.Width = 130;
            // 
            // colSMTPQ_BDR_Domain
            // 
            this.colSMTPQ_BDR_Domain.HeaderText = "Domain";
            this.colSMTPQ_BDR_Domain.MaxInputLength = 100;
            this.colSMTPQ_BDR_Domain.MinimumWidth = 180;
            this.colSMTPQ_BDR_Domain.Name = "colSMTPQ_BDR_Domain";
            this.colSMTPQ_BDR_Domain.ReadOnly = true;
            this.colSMTPQ_BDR_Domain.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colSMTPQ_BDR_Domain.Width = 180;
            // 
            // colSMTP_BDR_Age
            // 
            this.colSMTP_BDR_Age.FillWeight = 80F;
            this.colSMTP_BDR_Age.HeaderText = "Age";
            this.colSMTP_BDR_Age.MaxInputLength = 80;
            this.colSMTP_BDR_Age.MinimumWidth = 182;
            this.colSMTP_BDR_Age.Name = "colSMTP_BDR_Age";
            this.colSMTP_BDR_Age.ReadOnly = true;
            this.colSMTP_BDR_Age.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colSMTP_BDR_Age.Width = 182;
            // 
            // grbCoreQ
            // 
            this.grbCoreQ.BackColor = System.Drawing.SystemColors.Control;
            this.grbCoreQ.Controls.Add(this.pnlCore2);
            this.grbCoreQ.Controls.Add(this.pnlCore1);
            this.grbCoreQ.Controls.Add(this.dgCoreQ);
            this.grbCoreQ.Location = new System.Drawing.Point(648, 49);
            this.grbCoreQ.Name = "grbCoreQ";
            this.grbCoreQ.Size = new System.Drawing.Size(643, 323);
            this.grbCoreQ.TabIndex = 28;
            this.grbCoreQ.TabStop = false;
            // 
            // pnlCore2
            // 
            this.pnlCore2.BackColor = System.Drawing.Color.DodgerBlue;
            this.pnlCore2.Controls.Add(this.lblMsgs_Core_Age2);
            this.pnlCore2.Controls.Add(this.lblMsgs_Core_Total2);
            this.pnlCore2.Controls.Add(this.lblCoreTotal2);
            this.pnlCore2.Controls.Add(this.lblCoreOldest2);
            this.pnlCore2.Location = new System.Drawing.Point(328, 225);
            this.pnlCore2.Name = "pnlCore2";
            this.pnlCore2.Size = new System.Drawing.Size(302, 38);
            this.pnlCore2.TabIndex = 51;
            // 
            // lblMsgs_Core_Age2
            // 
            this.lblMsgs_Core_Age2.AutoSize = true;
            this.lblMsgs_Core_Age2.ForeColor = System.Drawing.Color.White;
            this.lblMsgs_Core_Age2.Location = new System.Drawing.Point(5, 22);
            this.lblMsgs_Core_Age2.Name = "lblMsgs_Core_Age2";
            this.lblMsgs_Core_Age2.Size = new System.Drawing.Size(40, 13);
            this.lblMsgs_Core_Age2.TabIndex = 51;
            this.lblMsgs_Core_Age2.Text = "Oldest:";
            // 
            // lblMsgs_Core_Total2
            // 
            this.lblMsgs_Core_Total2.AutoSize = true;
            this.lblMsgs_Core_Total2.ForeColor = System.Drawing.Color.White;
            this.lblMsgs_Core_Total2.Location = new System.Drawing.Point(5, 6);
            this.lblMsgs_Core_Total2.Name = "lblMsgs_Core_Total2";
            this.lblMsgs_Core_Total2.Size = new System.Drawing.Size(34, 13);
            this.lblMsgs_Core_Total2.TabIndex = 50;
            this.lblMsgs_Core_Total2.Text = "Total:";
            // 
            // lblCoreTotal2
            // 
            this.lblCoreTotal2.AutoSize = true;
            this.lblCoreTotal2.ForeColor = System.Drawing.Color.White;
            this.lblCoreTotal2.Location = new System.Drawing.Point(43, 6);
            this.lblCoreTotal2.Name = "lblCoreTotal2";
            this.lblCoreTotal2.Size = new System.Drawing.Size(69, 13);
            this.lblCoreTotal2.TabIndex = 45;
            this.lblCoreTotal2.Text = "lblCoreTotal2";
            // 
            // lblCoreOldest2
            // 
            this.lblCoreOldest2.AutoSize = true;
            this.lblCoreOldest2.ForeColor = System.Drawing.Color.White;
            this.lblCoreOldest2.Location = new System.Drawing.Point(43, 22);
            this.lblCoreOldest2.Name = "lblCoreOldest2";
            this.lblCoreOldest2.Size = new System.Drawing.Size(75, 13);
            this.lblCoreOldest2.TabIndex = 47;
            this.lblCoreOldest2.Text = "lblCoreOldest2";
            // 
            // pnlCore1
            // 
            this.pnlCore1.BackColor = System.Drawing.Color.DodgerBlue;
            this.pnlCore1.Controls.Add(this.lblCoreTotal1);
            this.pnlCore1.Controls.Add(this.lblCoreOldest1);
            this.pnlCore1.Controls.Add(this.lblMsgs_Core_Age1);
            this.pnlCore1.Controls.Add(this.lblMsgs_Core_Total1);
            this.pnlCore1.Location = new System.Drawing.Point(10, 225);
            this.pnlCore1.Name = "pnlCore1";
            this.pnlCore1.Size = new System.Drawing.Size(316, 38);
            this.pnlCore1.TabIndex = 50;
            // 
            // lblCoreTotal1
            // 
            this.lblCoreTotal1.AutoSize = true;
            this.lblCoreTotal1.ForeColor = System.Drawing.Color.White;
            this.lblCoreTotal1.Location = new System.Drawing.Point(43, 6);
            this.lblCoreTotal1.Name = "lblCoreTotal1";
            this.lblCoreTotal1.Size = new System.Drawing.Size(69, 13);
            this.lblCoreTotal1.TabIndex = 42;
            this.lblCoreTotal1.Text = "lblCoreTotal1";
            // 
            // lblCoreOldest1
            // 
            this.lblCoreOldest1.AutoSize = true;
            this.lblCoreOldest1.ForeColor = System.Drawing.Color.White;
            this.lblCoreOldest1.Location = new System.Drawing.Point(43, 22);
            this.lblCoreOldest1.Name = "lblCoreOldest1";
            this.lblCoreOldest1.Size = new System.Drawing.Size(75, 13);
            this.lblCoreOldest1.TabIndex = 46;
            this.lblCoreOldest1.Text = "lblCoreOldest1";
            // 
            // lblMsgs_Core_Age1
            // 
            this.lblMsgs_Core_Age1.AutoSize = true;
            this.lblMsgs_Core_Age1.ForeColor = System.Drawing.Color.White;
            this.lblMsgs_Core_Age1.Location = new System.Drawing.Point(5, 22);
            this.lblMsgs_Core_Age1.Name = "lblMsgs_Core_Age1";
            this.lblMsgs_Core_Age1.Size = new System.Drawing.Size(40, 13);
            this.lblMsgs_Core_Age1.TabIndex = 49;
            this.lblMsgs_Core_Age1.Text = "Oldest:";
            // 
            // lblMsgs_Core_Total1
            // 
            this.lblMsgs_Core_Total1.AutoSize = true;
            this.lblMsgs_Core_Total1.ForeColor = System.Drawing.Color.White;
            this.lblMsgs_Core_Total1.Location = new System.Drawing.Point(5, 6);
            this.lblMsgs_Core_Total1.Name = "lblMsgs_Core_Total1";
            this.lblMsgs_Core_Total1.Size = new System.Drawing.Size(34, 13);
            this.lblMsgs_Core_Total1.TabIndex = 48;
            this.lblMsgs_Core_Total1.Text = "Total:";
            // 
            // dgCoreQ
            // 
            this.dgCoreQ.AllowUserToAddRows = false;
            this.dgCoreQ.AllowUserToDeleteRows = false;
            this.dgCoreQ.AllowUserToResizeColumns = false;
            this.dgCoreQ.AllowUserToResizeRows = false;
            this.dgCoreQ.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgCoreQ.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colCoreQ_Server,
            this.colCoreQ_Proto,
            this.colCoreQ_Queue,
            this.colCoreQ_CheckTime,
            this.colCoreQ_Oldest,
            this.colCoreQ_Newest});
            this.dgCoreQ.Location = new System.Drawing.Point(10, 19);
            this.dgCoreQ.MultiSelect = false;
            this.dgCoreQ.Name = "dgCoreQ";
            this.dgCoreQ.ReadOnly = true;
            this.dgCoreQ.RowHeadersVisible = false;
            this.dgCoreQ.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgCoreQ.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgCoreQ.Size = new System.Drawing.Size(618, 200);
            this.dgCoreQ.TabIndex = 0;
            this.dgCoreQ.SelectionChanged += new System.EventHandler(this.dgCoreQ_SelectionChanged);
            // 
            // colCoreQ_Server
            // 
            this.colCoreQ_Server.HeaderText = "Server";
            this.colCoreQ_Server.MaxInputLength = 8;
            this.colCoreQ_Server.MinimumWidth = 50;
            this.colCoreQ_Server.Name = "colCoreQ_Server";
            this.colCoreQ_Server.ReadOnly = true;
            this.colCoreQ_Server.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colCoreQ_Server.Width = 50;
            // 
            // colCoreQ_Proto
            // 
            this.colCoreQ_Proto.HeaderText = "Protocol";
            this.colCoreQ_Proto.MaxInputLength = 4;
            this.colCoreQ_Proto.MinimumWidth = 95;
            this.colCoreQ_Proto.Name = "colCoreQ_Proto";
            this.colCoreQ_Proto.ReadOnly = true;
            this.colCoreQ_Proto.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colCoreQ_Proto.Width = 95;
            // 
            // colCoreQ_Queue
            // 
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle22.Format = "N0";
            dataGridViewCellStyle22.NullValue = null;
            this.colCoreQ_Queue.DefaultCellStyle = dataGridViewCellStyle22;
            this.colCoreQ_Queue.HeaderText = "Queue";
            this.colCoreQ_Queue.MaxInputLength = 7;
            this.colCoreQ_Queue.MinimumWidth = 50;
            this.colCoreQ_Queue.Name = "colCoreQ_Queue";
            this.colCoreQ_Queue.ReadOnly = true;
            this.colCoreQ_Queue.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colCoreQ_Queue.Width = 50;
            // 
            // colCoreQ_CheckTime
            // 
            this.colCoreQ_CheckTime.HeaderText = "Checktime";
            this.colCoreQ_CheckTime.MinimumWidth = 120;
            this.colCoreQ_CheckTime.Name = "colCoreQ_CheckTime";
            this.colCoreQ_CheckTime.ReadOnly = true;
            this.colCoreQ_CheckTime.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colCoreQ_CheckTime.Width = 120;
            // 
            // colCoreQ_Oldest
            // 
            this.colCoreQ_Oldest.HeaderText = "Oldest";
            this.colCoreQ_Oldest.Name = "colCoreQ_Oldest";
            this.colCoreQ_Oldest.ReadOnly = true;
            this.colCoreQ_Oldest.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colCoreQ_Oldest.Width = 150;
            // 
            // colCoreQ_Newest
            // 
            this.colCoreQ_Newest.HeaderText = "Newest";
            this.colCoreQ_Newest.Name = "colCoreQ_Newest";
            this.colCoreQ_Newest.ReadOnly = true;
            this.colCoreQ_Newest.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colCoreQ_Newest.Width = 150;
            // 
            // grbX400Q
            // 
            this.grbX400Q.Controls.Add(this.lblSMTP_OVH);
            this.grbX400Q.Controls.Add(this.dgX400Q_OVH);
            this.grbX400Q.Controls.Add(this.lblX400_OVH);
            this.grbX400Q.Controls.Add(this.dgSMTPQ_OVH);
            this.grbX400Q.Controls.Add(this.lblMsgs_OVH);
            this.grbX400Q.Location = new System.Drawing.Point(658, 383);
            this.grbX400Q.Name = "grbX400Q";
            this.grbX400Q.Size = new System.Drawing.Size(633, 335);
            this.grbX400Q.TabIndex = 33;
            this.grbX400Q.TabStop = false;
            // 
            // lblSMTP_OVH
            // 
            this.lblSMTP_OVH.AutoSize = true;
            this.lblSMTP_OVH.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSMTP_OVH.Location = new System.Drawing.Point(7, 21);
            this.lblSMTP_OVH.Name = "lblSMTP_OVH";
            this.lblSMTP_OVH.Size = new System.Drawing.Size(62, 24);
            this.lblSMTP_OVH.TabIndex = 38;
            this.lblSMTP_OVH.Text = "SMTP";
            // 
            // dgX400Q_OVH
            // 
            this.dgX400Q_OVH.AllowUserToAddRows = false;
            this.dgX400Q_OVH.AllowUserToDeleteRows = false;
            this.dgX400Q_OVH.AllowUserToResizeColumns = false;
            this.dgX400Q_OVH.AllowUserToResizeRows = false;
            this.dgX400Q_OVH.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgX400Q_OVH.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colX400Q_OVH_Server,
            this.colX400Q_OVH_Queue,
            this.colX400Q_OVH_CheckTime,
            this.colX400Q_OVH_Oldest,
            this.colX400Q_OVH_Newest});
            this.dgX400Q_OVH.Location = new System.Drawing.Point(10, 235);
            this.dgX400Q_OVH.MultiSelect = false;
            this.dgX400Q_OVH.Name = "dgX400Q_OVH";
            this.dgX400Q_OVH.ReadOnly = true;
            this.dgX400Q_OVH.RowHeadersVisible = false;
            this.dgX400Q_OVH.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgX400Q_OVH.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgX400Q_OVH.Size = new System.Drawing.Size(612, 67);
            this.dgX400Q_OVH.TabIndex = 1;
            this.dgX400Q_OVH.SelectionChanged += new System.EventHandler(this.dgX400Q_OVH_SelectionChanged);
            // 
            // colX400Q_OVH_Server
            // 
            this.colX400Q_OVH_Server.HeaderText = "Server";
            this.colX400Q_OVH_Server.MaxInputLength = 8;
            this.colX400Q_OVH_Server.MinimumWidth = 65;
            this.colX400Q_OVH_Server.Name = "colX400Q_OVH_Server";
            this.colX400Q_OVH_Server.ReadOnly = true;
            this.colX400Q_OVH_Server.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colX400Q_OVH_Server.Width = 65;
            // 
            // colX400Q_OVH_Queue
            // 
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle23.Format = "N0";
            dataGridViewCellStyle23.NullValue = null;
            this.colX400Q_OVH_Queue.DefaultCellStyle = dataGridViewCellStyle23;
            this.colX400Q_OVH_Queue.HeaderText = "Queue";
            this.colX400Q_OVH_Queue.MaxInputLength = 7;
            this.colX400Q_OVH_Queue.MinimumWidth = 50;
            this.colX400Q_OVH_Queue.Name = "colX400Q_OVH_Queue";
            this.colX400Q_OVH_Queue.ReadOnly = true;
            this.colX400Q_OVH_Queue.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colX400Q_OVH_Queue.Width = 50;
            // 
            // colX400Q_OVH_CheckTime
            // 
            this.colX400Q_OVH_CheckTime.HeaderText = "Checktime";
            this.colX400Q_OVH_CheckTime.MaxInputLength = 100;
            this.colX400Q_OVH_CheckTime.MinimumWidth = 130;
            this.colX400Q_OVH_CheckTime.Name = "colX400Q_OVH_CheckTime";
            this.colX400Q_OVH_CheckTime.ReadOnly = true;
            this.colX400Q_OVH_CheckTime.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colX400Q_OVH_CheckTime.Width = 130;
            // 
            // colX400Q_OVH_Oldest
            // 
            this.colX400Q_OVH_Oldest.HeaderText = "Oldest";
            this.colX400Q_OVH_Oldest.Name = "colX400Q_OVH_Oldest";
            this.colX400Q_OVH_Oldest.ReadOnly = true;
            this.colX400Q_OVH_Oldest.Width = 182;
            // 
            // colX400Q_OVH_Newest
            // 
            this.colX400Q_OVH_Newest.HeaderText = "Newest";
            this.colX400Q_OVH_Newest.Name = "colX400Q_OVH_Newest";
            this.colX400Q_OVH_Newest.ReadOnly = true;
            this.colX400Q_OVH_Newest.Width = 182;
            // 
            // lblX400_OVH
            // 
            this.lblX400_OVH.AutoSize = true;
            this.lblX400_OVH.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblX400_OVH.Location = new System.Drawing.Point(8, 208);
            this.lblX400_OVH.Name = "lblX400_OVH";
            this.lblX400_OVH.Size = new System.Drawing.Size(54, 24);
            this.lblX400_OVH.TabIndex = 21;
            this.lblX400_OVH.Text = "X400";
            // 
            // grbX400Q_BDR
            // 
            this.grbX400Q_BDR.Controls.Add(this.rbPNSMTPQ_BEDR);
            this.grbX400Q_BDR.Controls.Add(this.rbDGSMTPQ_BEDR);
            this.grbX400Q_BDR.Controls.Add(this.pnSMTPQ_BDR);
            this.grbX400Q_BDR.Controls.Add(this.lbSMTPQ_BDR);
            this.grbX400Q_BDR.Controls.Add(this.lblSMTP_BDR);
            this.grbX400Q_BDR.Controls.Add(this.lblX400_BDR);
            this.grbX400Q_BDR.Controls.Add(this.lblMsgs_BDR);
            this.grbX400Q_BDR.Controls.Add(this.dgX400Q_BDR);
            this.grbX400Q_BDR.Controls.Add(this.dgSMTPQ_BDR);
            this.grbX400Q_BDR.Location = new System.Drawing.Point(6, 383);
            this.grbX400Q_BDR.Name = "grbX400Q_BDR";
            this.grbX400Q_BDR.Size = new System.Drawing.Size(633, 335);
            this.grbX400Q_BDR.TabIndex = 34;
            this.grbX400Q_BDR.TabStop = false;
            // 
            // pnSMTPQ_BDR
            // 
            this.pnSMTPQ_BDR.Location = new System.Drawing.Point(12, 48);
            this.pnSMTPQ_BDR.Name = "pnSMTPQ_BDR";
            this.pnSMTPQ_BDR.Size = new System.Drawing.Size(562, 131);
            this.pnSMTPQ_BDR.TabIndex = 62;
            // 
            // lbSMTPQ_BDR
            // 
            this.lbSMTPQ_BDR.FormattingEnabled = true;
            this.lbSMTPQ_BDR.Location = new System.Drawing.Point(576, 46);
            this.lbSMTPQ_BDR.Name = "lbSMTPQ_BDR";
            this.lbSMTPQ_BDR.Size = new System.Drawing.Size(46, 134);
            this.lbSMTPQ_BDR.TabIndex = 38;
            // 
            // lblSMTP_BDR
            // 
            this.lblSMTP_BDR.AutoSize = true;
            this.lblSMTP_BDR.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSMTP_BDR.Location = new System.Drawing.Point(6, 21);
            this.lblSMTP_BDR.Name = "lblSMTP_BDR";
            this.lblSMTP_BDR.Size = new System.Drawing.Size(62, 24);
            this.lblSMTP_BDR.TabIndex = 37;
            this.lblSMTP_BDR.Text = "SMTP";
            // 
            // lblX400_BDR
            // 
            this.lblX400_BDR.AutoSize = true;
            this.lblX400_BDR.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblX400_BDR.Location = new System.Drawing.Point(8, 208);
            this.lblX400_BDR.Name = "lblX400_BDR";
            this.lblX400_BDR.Size = new System.Drawing.Size(54, 24);
            this.lblX400_BDR.TabIndex = 36;
            this.lblX400_BDR.Text = "X400";
            // 
            // dgX400Q_BDR
            // 
            this.dgX400Q_BDR.AllowUserToAddRows = false;
            this.dgX400Q_BDR.AllowUserToDeleteRows = false;
            this.dgX400Q_BDR.AllowUserToResizeColumns = false;
            this.dgX400Q_BDR.AllowUserToResizeRows = false;
            this.dgX400Q_BDR.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgX400Q_BDR.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colX400Q_BDR_Server,
            this.colX400Q_BDR_Queue,
            this.colX400Q_BDR_CheckTime,
            this.colX400Q_BDR_Oldest,
            this.colX400Q_BDR_Newest});
            this.dgX400Q_BDR.Location = new System.Drawing.Point(10, 235);
            this.dgX400Q_BDR.MultiSelect = false;
            this.dgX400Q_BDR.Name = "dgX400Q_BDR";
            this.dgX400Q_BDR.ReadOnly = true;
            this.dgX400Q_BDR.RowHeadersVisible = false;
            this.dgX400Q_BDR.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgX400Q_BDR.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgX400Q_BDR.Size = new System.Drawing.Size(612, 67);
            this.dgX400Q_BDR.TabIndex = 1;
            this.dgX400Q_BDR.SelectionChanged += new System.EventHandler(this.dgX400Q_BDR_SelectionChanged);
            // 
            // colX400Q_BDR_Server
            // 
            this.colX400Q_BDR_Server.FillWeight = 65F;
            this.colX400Q_BDR_Server.HeaderText = "Server";
            this.colX400Q_BDR_Server.MaxInputLength = 8;
            this.colX400Q_BDR_Server.MinimumWidth = 65;
            this.colX400Q_BDR_Server.Name = "colX400Q_BDR_Server";
            this.colX400Q_BDR_Server.ReadOnly = true;
            this.colX400Q_BDR_Server.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colX400Q_BDR_Server.Width = 65;
            // 
            // colX400Q_BDR_Queue
            // 
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle24.Format = "N0";
            dataGridViewCellStyle24.NullValue = null;
            this.colX400Q_BDR_Queue.DefaultCellStyle = dataGridViewCellStyle24;
            this.colX400Q_BDR_Queue.HeaderText = "Queue";
            this.colX400Q_BDR_Queue.MaxInputLength = 7;
            this.colX400Q_BDR_Queue.MinimumWidth = 50;
            this.colX400Q_BDR_Queue.Name = "colX400Q_BDR_Queue";
            this.colX400Q_BDR_Queue.ReadOnly = true;
            this.colX400Q_BDR_Queue.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colX400Q_BDR_Queue.Width = 50;
            // 
            // colX400Q_BDR_CheckTime
            // 
            this.colX400Q_BDR_CheckTime.HeaderText = "Checktime";
            this.colX400Q_BDR_CheckTime.MaxInputLength = 100;
            this.colX400Q_BDR_CheckTime.MinimumWidth = 130;
            this.colX400Q_BDR_CheckTime.Name = "colX400Q_BDR_CheckTime";
            this.colX400Q_BDR_CheckTime.ReadOnly = true;
            this.colX400Q_BDR_CheckTime.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colX400Q_BDR_CheckTime.Width = 130;
            // 
            // colX400Q_BDR_Oldest
            // 
            this.colX400Q_BDR_Oldest.HeaderText = "Oldest";
            this.colX400Q_BDR_Oldest.Name = "colX400Q_BDR_Oldest";
            this.colX400Q_BDR_Oldest.ReadOnly = true;
            this.colX400Q_BDR_Oldest.Width = 182;
            // 
            // colX400Q_BDR_Newest
            // 
            this.colX400Q_BDR_Newest.HeaderText = "Newest";
            this.colX400Q_BDR_Newest.Name = "colX400Q_BDR_Newest";
            this.colX400Q_BDR_Newest.ReadOnly = true;
            this.colX400Q_BDR_Newest.Width = 182;
            // 
            // grbAllQueue
            // 
            this.grbAllQueue.Controls.Add(this.lblLog);
            this.grbAllQueue.Controls.Add(this.lblDebugError_val);
            this.grbAllQueue.Controls.Add(this.lblDebugError_text);
            this.grbAllQueue.Controls.Add(this.cmdDebug);
            this.grbAllQueue.Controls.Add(this.lblSettings);
            this.grbAllQueue.Controls.Add(this.lblCore);
            this.grbAllQueue.Controls.Add(this.grbCoreQ);
            this.grbAllQueue.Controls.Add(this.lbDebug);
            this.grbAllQueue.Controls.Add(this.lblOverheden);
            this.grbAllQueue.Controls.Add(this.lblBedrijven);
            this.grbAllQueue.Controls.Add(this.grbX400Q_BDR);
            this.grbAllQueue.Controls.Add(this.grbX400Q);
            this.grbAllQueue.Controls.Add(this.grpSettings);
            this.grbAllQueue.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.grbAllQueue.Location = new System.Drawing.Point(8, 13);
            this.grbAllQueue.Name = "grbAllQueue";
            this.grbAllQueue.Size = new System.Drawing.Size(1308, 732);
            this.grbAllQueue.TabIndex = 1;
            this.grbAllQueue.TabStop = false;
            // 
            // lblLog
            // 
            this.lblLog.AutoSize = true;
            this.lblLog.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLog.Location = new System.Drawing.Point(318, 32);
            this.lblLog.Name = "lblLog";
            this.lblLog.Size = new System.Drawing.Size(48, 25);
            this.lblLog.TabIndex = 61;
            this.lblLog.Text = "Log";
            // 
            // lblDebugError_val
            // 
            this.lblDebugError_val.AutoSize = true;
            this.lblDebugError_val.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDebugError_val.Location = new System.Drawing.Point(396, 356);
            this.lblDebugError_val.Name = "lblDebugError_val";
            this.lblDebugError_val.Size = new System.Drawing.Size(13, 13);
            this.lblDebugError_val.TabIndex = 60;
            this.lblDebugError_val.Text = "0";
            // 
            // lblDebugError_text
            // 
            this.lblDebugError_text.AutoSize = true;
            this.lblDebugError_text.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDebugError_text.Location = new System.Drawing.Point(320, 356);
            this.lblDebugError_text.Name = "lblDebugError_text";
            this.lblDebugError_text.Size = new System.Drawing.Size(77, 13);
            this.lblDebugError_text.TabIndex = 59;
            this.lblDebugError_text.Text = "# Error events:";
            // 
            // cmdDebug
            // 
            this.cmdDebug.Location = new System.Drawing.Point(564, 352);
            this.cmdDebug.Name = "cmdDebug";
            this.cmdDebug.Size = new System.Drawing.Size(75, 22);
            this.cmdDebug.TabIndex = 58;
            this.cmdDebug.Text = "Clear log";
            this.cmdDebug.UseVisualStyleBackColor = true;
            this.cmdDebug.Click += new System.EventHandler(this.cmdDebug_Click);
            // 
            // lblSettings
            // 
            this.lblSettings.AutoSize = true;
            this.lblSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSettings.Location = new System.Drawing.Point(20, 32);
            this.lblSettings.Name = "lblSettings";
            this.lblSettings.Size = new System.Drawing.Size(90, 25);
            this.lblSettings.TabIndex = 56;
            this.lblSettings.Text = "Settings";
            // 
            // lblCore
            // 
            this.lblCore.AutoSize = true;
            this.lblCore.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCore.Location = new System.Drawing.Point(933, 30);
            this.lblCore.Name = "lblCore";
            this.lblCore.Size = new System.Drawing.Size(78, 33);
            this.lblCore.TabIndex = 57;
            this.lblCore.Text = "Core";
            // 
            // lbDebug
            // 
            this.lbDebug.FormattingEnabled = true;
            this.lbDebug.HorizontalScrollbar = true;
            this.lbDebug.Location = new System.Drawing.Point(322, 58);
            this.lbDebug.Name = "lbDebug";
            this.lbDebug.ScrollAlwaysVisible = true;
            this.lbDebug.Size = new System.Drawing.Size(316, 277);
            this.lbDebug.TabIndex = 54;
            // 
            // lblOverheden
            // 
            this.lblOverheden.AutoSize = true;
            this.lblOverheden.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOverheden.Location = new System.Drawing.Point(899, 376);
            this.lblOverheden.Name = "lblOverheden";
            this.lblOverheden.Size = new System.Drawing.Size(159, 33);
            this.lblOverheden.TabIndex = 53;
            this.lblOverheden.Text = "Overheden";
            // 
            // lblBedrijven
            // 
            this.lblBedrijven.AutoSize = true;
            this.lblBedrijven.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBedrijven.Location = new System.Drawing.Point(248, 376);
            this.lblBedrijven.Name = "lblBedrijven";
            this.lblBedrijven.Size = new System.Drawing.Size(137, 33);
            this.lblBedrijven.TabIndex = 38;
            this.lblBedrijven.Text = "Bedrijven";
            // 
            // grpSettings
            // 
            this.grpSettings.BackColor = System.Drawing.SystemColors.Control;
            this.grpSettings.Controls.Add(this.pnlSettings);
            this.grpSettings.Controls.Add(this.cmbGroupSMTP);
            this.grpSettings.Controls.Add(this.lblGroupSMTP);
            this.grpSettings.Controls.Add(this.lblSaveFiile);
            this.grpSettings.Controls.Add(this.cmdSaveStop);
            this.grpSettings.Controls.Add(this.cmdConfigureSave);
            this.grpSettings.Controls.Add(this.lblUpdate_Script_val);
            this.grpSettings.Controls.Add(this.lblUpdate_Script_txt);
            this.grpSettings.Controls.Add(this.lblSaveFile);
            this.grpSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpSettings.Location = new System.Drawing.Point(16, 42);
            this.grpSettings.Name = "grpSettings";
            this.grpSettings.Size = new System.Drawing.Size(298, 323);
            this.grpSettings.TabIndex = 52;
            this.grpSettings.TabStop = false;
            // 
            // pnlSettings
            // 
            this.pnlSettings.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlSettings.Controls.Add(this.lblAutoUpdate);
            this.pnlSettings.Controls.Add(this.cmdManualUpdate);
            this.pnlSettings.Controls.Add(this.lblUpdte);
            this.pnlSettings.Controls.Add(this.lblRefresh_till_refresh);
            this.pnlSettings.Controls.Add(this.lblRefresh_last_refresh);
            this.pnlSettings.Controls.Add(this.rbAutoUpdateOn);
            this.pnlSettings.Controls.Add(this.rbAutoUpdateOff);
            this.pnlSettings.Location = new System.Drawing.Point(11, 18);
            this.pnlSettings.Name = "pnlSettings";
            this.pnlSettings.Size = new System.Drawing.Size(278, 135);
            this.pnlSettings.TabIndex = 62;
            // 
            // lblAutoUpdate
            // 
            this.lblAutoUpdate.AutoSize = true;
            this.lblAutoUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAutoUpdate.Location = new System.Drawing.Point(2, 57);
            this.lblAutoUpdate.Name = "lblAutoUpdate";
            this.lblAutoUpdate.Size = new System.Drawing.Size(174, 13);
            this.lblAutoUpdate.TabIndex = 58;
            this.lblAutoUpdate.Text = "Automatic                                        ";
            // 
            // cmdManualUpdate
            // 
            this.cmdManualUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdManualUpdate.Location = new System.Drawing.Point(2, 24);
            this.cmdManualUpdate.Name = "cmdManualUpdate";
            this.cmdManualUpdate.Size = new System.Drawing.Size(75, 23);
            this.cmdManualUpdate.TabIndex = 57;
            this.cmdManualUpdate.Text = "Update now";
            this.cmdManualUpdate.UseVisualStyleBackColor = true;
            this.cmdManualUpdate.Click += new System.EventHandler(this.cmdManualUpdate_Click);
            // 
            // lblUpdte
            // 
            this.lblUpdte.AutoSize = true;
            this.lblUpdte.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUpdte.Location = new System.Drawing.Point(-1, 0);
            this.lblUpdte.Name = "lblUpdte";
            this.lblUpdte.Size = new System.Drawing.Size(59, 16);
            this.lblUpdte.TabIndex = 56;
            this.lblUpdte.Text = "Update";
            // 
            // lblRefresh_till_refresh
            // 
            this.lblRefresh_till_refresh.AutoSize = true;
            this.lblRefresh_till_refresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRefresh_till_refresh.Location = new System.Drawing.Point(55, 73);
            this.lblRefresh_till_refresh.Name = "lblRefresh_till_refresh";
            this.lblRefresh_till_refresh.Size = new System.Drawing.Size(107, 13);
            this.lblRefresh_till_refresh.TabIndex = 6;
            this.lblRefresh_till_refresh.Text = "lblRefresh_till_refresh";
            this.lblRefresh_till_refresh.Visible = false;
            // 
            // lblRefresh_last_refresh
            // 
            this.lblRefresh_last_refresh.AutoSize = true;
            this.lblRefresh_last_refresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRefresh_last_refresh.Location = new System.Drawing.Point(55, 91);
            this.lblRefresh_last_refresh.Name = "lblRefresh_last_refresh";
            this.lblRefresh_last_refresh.Size = new System.Drawing.Size(114, 13);
            this.lblRefresh_last_refresh.TabIndex = 9;
            this.lblRefresh_last_refresh.Text = "lblRefresh_last_refresh";
            this.lblRefresh_last_refresh.Visible = false;
            // 
            // rbAutoUpdateOn
            // 
            this.rbAutoUpdateOn.AutoSize = true;
            this.rbAutoUpdateOn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbAutoUpdateOn.Location = new System.Drawing.Point(6, 74);
            this.rbAutoUpdateOn.Name = "rbAutoUpdateOn";
            this.rbAutoUpdateOn.Size = new System.Drawing.Size(39, 17);
            this.rbAutoUpdateOn.TabIndex = 53;
            this.rbAutoUpdateOn.TabStop = true;
            this.rbAutoUpdateOn.Text = "On";
            this.rbAutoUpdateOn.UseVisualStyleBackColor = true;
            this.rbAutoUpdateOn.CheckedChanged += new System.EventHandler(this.rbAutoUpdateOn_CheckedChanged);
            // 
            // rbAutoUpdateOff
            // 
            this.rbAutoUpdateOff.AutoSize = true;
            this.rbAutoUpdateOff.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbAutoUpdateOff.Location = new System.Drawing.Point(6, 108);
            this.rbAutoUpdateOff.Name = "rbAutoUpdateOff";
            this.rbAutoUpdateOff.Size = new System.Drawing.Size(39, 17);
            this.rbAutoUpdateOff.TabIndex = 52;
            this.rbAutoUpdateOff.TabStop = true;
            this.rbAutoUpdateOff.Text = "Off";
            this.rbAutoUpdateOff.UseVisualStyleBackColor = true;
            this.rbAutoUpdateOff.CheckedChanged += new System.EventHandler(this.rbAutoUpdateOff_CheckedChanged);
            // 
            // cmbGroupSMTP
            // 
            this.cmbGroupSMTP.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbGroupSMTP.FormattingEnabled = true;
            this.cmbGroupSMTP.Items.AddRange(new object[] {
            "Domain",
            "Server"});
            this.cmbGroupSMTP.Location = new System.Drawing.Point(11, 207);
            this.cmbGroupSMTP.Name = "cmbGroupSMTP";
            this.cmbGroupSMTP.Size = new System.Drawing.Size(160, 21);
            this.cmbGroupSMTP.TabIndex = 61;
            this.cmbGroupSMTP.SelectedIndexChanged += new System.EventHandler(this.cmbGroupSMTP_SelectedIndexChanged);
            // 
            // lblGroupSMTP
            // 
            this.lblGroupSMTP.AutoSize = true;
            this.lblGroupSMTP.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGroupSMTP.Location = new System.Drawing.Point(8, 186);
            this.lblGroupSMTP.Name = "lblGroupSMTP";
            this.lblGroupSMTP.Size = new System.Drawing.Size(176, 16);
            this.lblGroupSMTP.TabIndex = 60;
            this.lblGroupSMTP.Text = "Group SMTP queues by:";
            // 
            // lblSaveFiile
            // 
            this.lblSaveFiile.AutoSize = true;
            this.lblSaveFiile.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaveFiile.Location = new System.Drawing.Point(4, 248);
            this.lblSaveFiile.Name = "lblSaveFiile";
            this.lblSaveFiile.Size = new System.Drawing.Size(224, 16);
            this.lblSaveFiile.TabIndex = 59;
            this.lblSaveFiile.Text = "Save queue info to external csv";
            // 
            // cmdSaveStop
            // 
            this.cmdSaveStop.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdSaveStop.Location = new System.Drawing.Point(126, 267);
            this.cmdSaveStop.Name = "cmdSaveStop";
            this.cmdSaveStop.Size = new System.Drawing.Size(115, 23);
            this.cmdSaveStop.TabIndex = 11;
            this.cmdSaveStop.Text = "Stop";
            this.cmdSaveStop.UseVisualStyleBackColor = true;
            this.cmdSaveStop.Click += new System.EventHandler(this.cmdSaveStop_Click);
            // 
            // cmdConfigureSave
            // 
            this.cmdConfigureSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdConfigureSave.Location = new System.Drawing.Point(5, 267);
            this.cmdConfigureSave.Name = "cmdConfigureSave";
            this.cmdConfigureSave.Size = new System.Drawing.Size(115, 23);
            this.cmdConfigureSave.TabIndex = 8;
            this.cmdConfigureSave.Text = "Configure && Start...";
            this.cmdConfigureSave.UseVisualStyleBackColor = true;
            this.cmdConfigureSave.Click += new System.EventHandler(this.cmdConfigureSave_Click);
            // 
            // lblUpdate_Script_val
            // 
            this.lblUpdate_Script_val.AutoSize = true;
            this.lblUpdate_Script_val.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUpdate_Script_val.Location = new System.Drawing.Point(134, 162);
            this.lblUpdate_Script_val.Name = "lblUpdate_Script_val";
            this.lblUpdate_Script_val.Size = new System.Drawing.Size(105, 13);
            this.lblUpdate_Script_val.TabIndex = 58;
            this.lblUpdate_Script_val.Text = "lblUpdate_Script_val";
            this.lblUpdate_Script_val.Visible = false;
            // 
            // lblUpdate_Script_txt
            // 
            this.lblUpdate_Script_txt.AutoSize = true;
            this.lblUpdate_Script_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUpdate_Script_txt.Location = new System.Drawing.Point(8, 162);
            this.lblUpdate_Script_txt.Name = "lblUpdate_Script_txt";
            this.lblUpdate_Script_txt.Size = new System.Drawing.Size(127, 13);
            this.lblUpdate_Script_txt.TabIndex = 57;
            this.lblUpdate_Script_txt.Text = "Update scripts trigged by:";
            this.lblUpdate_Script_txt.Visible = false;
            // 
            // lblSaveFile
            // 
            this.lblSaveFile.AutoSize = true;
            this.lblSaveFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaveFile.Location = new System.Drawing.Point(7, 295);
            this.lblSaveFile.Name = "lblSaveFile";
            this.lblSaveFile.Size = new System.Drawing.Size(58, 13);
            this.lblSaveFile.TabIndex = 13;
            this.lblSaveFile.Text = "lblSaveFile";
            // 
            // rbDGSMTPQ_BEDR
            // 
            this.rbDGSMTPQ_BEDR.AutoSize = true;
            this.rbDGSMTPQ_BEDR.Location = new System.Drawing.Point(74, 27);
            this.rbDGSMTPQ_BEDR.Name = "rbDGSMTPQ_BEDR";
            this.rbDGSMTPQ_BEDR.Size = new System.Drawing.Size(52, 17);
            this.rbDGSMTPQ_BEDR.TabIndex = 63;
            this.rbDGSMTPQ_BEDR.TabStop = true;
            this.rbDGSMTPQ_BEDR.Text = "Table";
            this.rbDGSMTPQ_BEDR.UseVisualStyleBackColor = true;
            this.rbDGSMTPQ_BEDR.CheckedChanged += new System.EventHandler(this.rbDGSMTPQ_BEDR_CheckedChanged);
            // 
            // rbPNSMTPQ_BEDR
            // 
            this.rbPNSMTPQ_BEDR.AutoSize = true;
            this.rbPNSMTPQ_BEDR.Location = new System.Drawing.Point(128, 27);
            this.rbPNSMTPQ_BEDR.Name = "rbPNSMTPQ_BEDR";
            this.rbPNSMTPQ_BEDR.Size = new System.Drawing.Size(53, 17);
            this.rbPNSMTPQ_BEDR.TabIndex = 64;
            this.rbPNSMTPQ_BEDR.TabStop = true;
            this.rbPNSMTPQ_BEDR.Text = "Trend";
            this.rbPNSMTPQ_BEDR.UseVisualStyleBackColor = true;
            this.rbPNSMTPQ_BEDR.CheckedChanged += new System.EventHandler(this.rbPNSMTPQ_BEDR_CheckedChanged);
            // 
            // frmDashQueue
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1324, 780);
            this.Controls.Add(this.grbAllQueue);
            this.Name = "frmDashQueue";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmDashQueue - Digipoort overview Messagequeues";
            this.Load += new System.EventHandler(this.frmDashQueue_Load);
            this.Controls.SetChildIndex(this.cmdAfsluiten, 0);
            this.Controls.SetChildIndex(this.grbAllQueue, 0);
            this.Controls.SetChildIndex(this.lblVoortgang, 0);
            this.Controls.SetChildIndex(this.grbConnectie, 0);
            this.grbConnectie.ResumeLayout(false);
            this.grbConnectie.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgSMTPQ_OVH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgSMTPQ_BDR)).EndInit();
            this.grbCoreQ.ResumeLayout(false);
            this.pnlCore2.ResumeLayout(false);
            this.pnlCore2.PerformLayout();
            this.pnlCore1.ResumeLayout(false);
            this.pnlCore1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgCoreQ)).EndInit();
            this.grbX400Q.ResumeLayout(false);
            this.grbX400Q.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgX400Q_OVH)).EndInit();
            this.grbX400Q_BDR.ResumeLayout(false);
            this.grbX400Q_BDR.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgX400Q_BDR)).EndInit();
            this.grbAllQueue.ResumeLayout(false);
            this.grbAllQueue.PerformLayout();
            this.grpSettings.ResumeLayout(false);
            this.grpSettings.PerformLayout();
            this.pnlSettings.ResumeLayout(false);
            this.pnlSettings.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer tmrSMTPQ;
        private System.Windows.Forms.Timer tmrCoreQ;
        private System.Windows.Forms.Timer tmrX400Q;
        private System.Windows.Forms.Timer tmrRefresh;
        private System.Windows.Forms.Timer tmrSeconds;
        private System.Windows.Forms.Label lblMsgs_BDR;
        private System.Windows.Forms.DataGridView dgSMTPQ_BDR;
        private System.Windows.Forms.GroupBox grbCoreQ;
        private System.Windows.Forms.Label lblCoreTotal2;
        private System.Windows.Forms.Label lblCoreTotal1;
        private System.Windows.Forms.DataGridView dgCoreQ;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCoreQ_Server;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCoreQ_Proto;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCoreQ_Queue;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCoreQ_CheckTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCoreQ_Oldest;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCoreQ_Newest;
        private System.Windows.Forms.Label lblMsgs_OVH;
        private System.Windows.Forms.DataGridView dgSMTPQ_OVH;
        private System.Windows.Forms.GroupBox grbX400Q;
        private System.Windows.Forms.DataGridView dgX400Q_OVH;
        private System.Windows.Forms.DataGridViewTextBoxColumn colX400Q_OVH_Server;
        private System.Windows.Forms.DataGridViewTextBoxColumn colX400Q_OVH_Queue;
        private System.Windows.Forms.DataGridViewTextBoxColumn colX400Q_OVH_CheckTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn colX400Q_OVH_Oldest;
        private System.Windows.Forms.DataGridViewTextBoxColumn colX400Q_OVH_Newest;
        private System.Windows.Forms.GroupBox grbX400Q_BDR;
        private System.Windows.Forms.DataGridView dgX400Q_BDR;
        private System.Windows.Forms.GroupBox grbAllQueue;
        private System.Windows.Forms.Label lblCoreOldest1;
        private System.Windows.Forms.Label lblCoreOldest2;
        private System.Windows.Forms.Label lblMsgs_Core_Total1;
        private System.Windows.Forms.Label lblMsgs_Core_Age1;
        private System.Windows.Forms.Panel pnlCore2;
        private System.Windows.Forms.Panel pnlCore1;
        private System.Windows.Forms.Label lblMsgs_Core_Age2;
        private System.Windows.Forms.Label lblMsgs_Core_Total2;
        private System.Windows.Forms.GroupBox grpSettings;
        private System.Windows.Forms.RadioButton rbAutoUpdateOn;
        private System.Windows.Forms.RadioButton rbAutoUpdateOff;
        private System.Windows.Forms.Label lblRefresh_last_refresh;
        private System.Windows.Forms.Label lblRefresh_till_refresh;
        private System.Windows.Forms.Label lblUpdte;
        private System.Windows.Forms.Label lblUpdate_Script_val;
        private System.Windows.Forms.Label lblUpdate_Script_txt;
        private System.Windows.Forms.Button cmdSaveStop;
        private System.Windows.Forms.Button cmdConfigureSave;
        private System.Windows.Forms.Label lblSaveFile;
        private System.Windows.Forms.Label lblSaveFiile;
        private System.Windows.Forms.Label lblGroupSMTP;
        private System.Windows.Forms.ComboBox cmbGroupSMTP;
        private System.Windows.Forms.Label lblX400_OVH;
        private System.Windows.Forms.Label lblX400_BDR;
        private System.Windows.Forms.Label lblSMTP_OVH;
        private System.Windows.Forms.Label lblSMTP_BDR;
        private System.Windows.Forms.Label lblOverheden;
        private System.Windows.Forms.Label lblBedrijven;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSMTP_OVH_Server;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSMTP_OVH_Queue;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSMTPQ_OVH_checktime;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSMTP_OVH_Domain;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSMTP_OVH_Age;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSMTPQ_BDR_server;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSMTPQ_BDR_Queue;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSMTPQ_BDR_checktime;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSMTPQ_BDR_Domain;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSMTP_BDR_Age;
        private System.Windows.Forms.ListBox lbDebug;
        private System.Windows.Forms.Label lblSettings;
        private System.Windows.Forms.Panel pnlSettings;
        private System.Windows.Forms.Label lblCore;
        private System.Windows.Forms.Button cmdDebug;
        private System.Windows.Forms.DataGridViewTextBoxColumn colX400Q_BDR_Server;
        private System.Windows.Forms.DataGridViewTextBoxColumn colX400Q_BDR_Queue;
        private System.Windows.Forms.DataGridViewTextBoxColumn colX400Q_BDR_CheckTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn colX400Q_BDR_Oldest;
        private System.Windows.Forms.DataGridViewTextBoxColumn colX400Q_BDR_Newest;
        private System.Windows.Forms.Button cmdManualUpdate;
        private System.Windows.Forms.Label lblAutoUpdate;
        private System.Windows.Forms.Label lblDebugError_val;
        private System.Windows.Forms.Label lblDebugError_text;
        private System.Windows.Forms.Label lblLog;
        private System.Windows.Forms.ListBox lbSMTPQ_BDR;
        private System.Windows.Forms.Panel pnSMTPQ_BDR;
        private System.Windows.Forms.RadioButton rbPNSMTPQ_BEDR;
        private System.Windows.Forms.RadioButton rbDGSMTPQ_BEDR;
    }
}