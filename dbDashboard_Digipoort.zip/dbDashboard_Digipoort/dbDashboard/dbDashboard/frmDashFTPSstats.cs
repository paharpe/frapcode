﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Xml;

namespace dbDashboard
{
    public partial class frmDashFTPSstats : frmDashBase
    {
        public frmDashFTPSstats()
        {
            InitializeComponent();
        }

        private int intNumberOfAccounts = 0;
        private int intDaysSinceLastLogin = 0;
        private int intLongerThan3Months = 0;
        private int intNeverLoggedOn = 0;
        private int intRecentLoggedOn = 0;
        private string strLoginName;
        private string strLastLogin_Raw;
        private string strLastLogin_TS;

        private void frmDashFTPSstats_Load(object sender, EventArgs e)
        {
            frm_init();                     
        }

        /// <summary>
        /// Initial form settings
        /// </summary>
        private void frm_init()
        {
            able_data(false);
            grbSTAccounter.Enabled = true;
        }


        /// <summary>
        /// Show the openfile dialog in order to select an XML
        /// file to process
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmdChooseFile_Click(object sender, EventArgs e)
        {

            openFileDlg.InitialDirectory = clDashFunction.get_path("FTPS_DIN_PATH", true, false);
            openFileDlg.FileName = txtInputFile.Text;
            openFileDlg.Filter = "XML files (*.xml)|*.xml|All files (*.*)|*.*";
            openFileDlg.DefaultExt = "xml";
            if (openFileDlg.ShowDialog() == DialogResult.OK)
            {
                txtInputFile.Text = openFileDlg.FileName;
                if (File.Exists(txtInputFile.Text))
                    try
                    {
                        {
                            ProcessFile();
                        }
                    }
                    catch (Exception ex)
                    {
                        clDashFunction.Melding("Unable to open " + txtInputFile.Text + "\n\n" + ex.Message);
                    }
                else
                {
                    clDashFunction.Melding("Inputfile " + txtInputFile.Text + " suddenly seems to be disappeared ", 1, "E");
                }
            }
        }

        /// <summary>
        /// Read XML file, do some counting and display in datagrid
        /// </summary>
        private void ProcessFile()
        {
            dgSTAccounter.Rows.Clear();

            intNumberOfAccounts = 0;

            able_data(false);

            if (!File.Exists(txtInputFile.Text))
            {
                clDashFunction.Melding("Inputfile " + txtInputFile.Text + " does not exist ", 1, "E");
                return;
            }
            string xmlText = File.ReadAllText(txtInputFile.Text);
            XmlDocument doc = new XmlDocument();
            try
            {
                doc.LoadXml(xmlText);
            }
            catch (Exception e)
            {
                clDashFunction.Melding("The following error has occurred while parsing the inputfile: \n" + e.Message, 1, "E");
                return;
            }

            XmlNodeList parentNode = doc.GetElementsByTagName("exportData");
            IEnumerator parentSubNodes = parentNode[0].ChildNodes.GetEnumerator();

            strLoginName = "";
            strLastLogin_Raw = "";
            strLastLogin_TS = "";
            intDaysSinceLastLogin = -1;

            intLongerThan3Months = 0;
            intNeverLoggedOn = 0;
            intRecentLoggedOn = 0;

            while (parentSubNodes.MoveNext())
            {

                XmlNode parentSubSubNodes = (XmlNode)parentSubNodes.Current;

                if (parentSubSubNodes.Name.Trim().ToUpper() == "completeAccount".Trim().ToUpper())
                {
                    IEnumerator completeAccount_nodes = parentSubSubNodes.ChildNodes.GetEnumerator();

                    while (completeAccount_nodes.MoveNext())
                    {

                        strLoginName = "Nobody";
                        strLastLogin_Raw = "Never";
                        strLastLogin_TS = "Never";
                        intDaysSinceLastLogin = -1;

                        XmlNode AccountSubNode = (XmlNode)completeAccount_nodes.Current;

                        if (AccountSubNode.Name.Trim().ToUpper() == "virtualUser".Trim().ToUpper())
                        {
                            IEnumerator VirtualUser = AccountSubNode.ChildNodes.GetEnumerator();
                            while (VirtualUser.MoveNext())
                            {
                                XmlNode VirtualUserSubNode = (XmlNode)VirtualUser.Current;
                                if (VirtualUserSubNode.Name.Trim().ToUpper() == "loginName".Trim().ToUpper())
                                {
                                    strLoginName = VirtualUserSubNode.InnerText;
                                }
                                if (VirtualUserSubNode.Name.Trim().ToUpper() == "lastLogin".Trim().ToUpper())
                                {
                                    strLastLogin_Raw = VirtualUserSubNode.InnerText;
                                }
                            }

                            // Afhandelen van lastlogin
                            if (strLastLogin_Raw.ToUpper().Trim() != "nEVER".ToUpper().Trim())
                            {
                                strLastLogin_TS = strLastLogin_Raw.Replace("T", " ");
                                strLastLogin_TS = strLastLogin_TS.Substring(0, strLastLogin_TS.IndexOf("+"));
                                DateTime dtLastLogin = Convert.ToDateTime(strLastLogin_TS);

                                TimeSpan ts = (System.DateTime.Now - dtLastLogin);
                                intDaysSinceLastLogin = Convert.ToInt16(ts.TotalDays);
                                if (intDaysSinceLastLogin > Convert.ToInt16(txtDaysIdle.Text))
                                {
                                    intLongerThan3Months++;
                                }
                                else
                                {
                                    intRecentLoggedOn++;
                                }
                            }
                            else
                            {
                                if (intDaysSinceLastLogin == -1)
                                {
                                    intNeverLoggedOn++;
                                }
                            }

                            int intRowNo = dgSTAccounter.Rows.Add();

                            dgSTAccounter[0, intRowNo].Value = strLoginName;
                            dgSTAccounter[1, intRowNo].Value = strLastLogin_TS;
                            dgSTAccounter[2, intRowNo].Value = intDaysSinceLastLogin;

                            intNumberOfAccounts++;
                        }
                    }
                }
            }
            SetNumbers(intNumberOfAccounts, intLongerThan3Months, intNeverLoggedOn, intRecentLoggedOn);
            if (intNumberOfAccounts > 0)
            {
                able_data(true);
            }
        }

        /// <summary>
        /// Enable of disable the search(box) controls
        /// </summary>
        /// <param name="bEnable"></param>
        private void able_data(Boolean bEnable)
        {
            grbSTAData.Enabled = bEnable;
            txtIDXText.Enabled = bEnable;
            if (bEnable)
            {
                if (txtIDXText.Text.Trim() != "")
                {
                    cmdIDXText.Enabled = bEnable;
                }
                else
                {
                    cmdIDXText.Enabled = false;
                }
            }

        }

        /// <summary>
        /// Show a brief instruction
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmdHowFile_Click(object sender, EventArgs e)
        {
            clDashFunction.Melding("An inputfile can be obtained by performing an XML export\n" +
           "of all FTPs accounts in the SecureTransport webconsole:\n\n ( https://kslv046.esn.kpn.com:8444/admin/ )\n\n" +
           "from one of the Digipoort steppingstone servers", 1, "I");
        }

        /// <summary>
        /// Put the numeric counters into form label controls
        /// </summary>
        /// <param name="intRowsSelected_Count"></param>
        /// <param name="intRowsMoreThanMaxIdleCount"></param>
        /// <param name="intRowsNeverLoggedOn_Count"></param>
        /// <param name="intRowsRecentLoggedOn_Count"></param>
        private void SetNumbers(int intRowsSelected_Count, int intRowsMoreThanMaxIdleCount, int intRowsNeverLoggedOn_Count, int intRowsRecentLoggedOn_Count)
        {
            lblRowsSelected_Count.Text = intRowsSelected_Count.ToString();
            lblRowsMoreThanMaxIdleCount.Text = intRowsMoreThanMaxIdleCount.ToString();
            lblRowsNeverLoggedOn_Count.Text = intRowsNeverLoggedOn_Count.ToString();
            lblRowsRecentLoggedOn_Count.Text = intRowsRecentLoggedOn_Count.ToString();
        }

        /// <summary>
        /// Enable/disable searchbutton depenable on presence of entered searchtext
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtIDXText_TextChanged(object sender, EventArgs e)
        {
            cmdIDXText.Enabled = (txtIDXText.Text.Trim() != "");
        } 


        private void save_to_file()
        {
            saveFileDlg.InitialDirectory = clDashFunction.get_path("FTPS_DOUT_PATH", true, false);

            saveFileDlg.FileName = "ftps_acCount" + System.DateTime.Now.Year.ToString() + System.DateTime.Now.Month.ToString("0#") + System.DateTime.Now.Day.ToString("0#") + "_" + System.DateTime.Now.Hour.ToString("0#") + System.DateTime.Now.Minute.ToString("0#") + System.DateTime.Now.Second.ToString("0#") + ".txt";
            saveFileDlg.AddExtension = false;
            saveFileDlg.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
            saveFileDlg.DefaultExt = "txt";
            if (saveFileDlg.ShowDialog() == DialogResult.OK)
            {
                if (!File.Exists(saveFileDlg.FileName))
                {
                    StreamWriter sw = clDashFunction.open4write(saveFileDlg.FileName);
                    if (sw != null)
                    {
                        sw.WriteLine("***************************************************");
                        sw.WriteLine("* Output Start");
                        sw.WriteLine("* Written by: " + this.Name);
                        sw.WriteLine("* Timestamp : " + System.DateTime.Now);
                        sw.WriteLine("***************************************************");
                        sw.WriteLine(lblRowsSelected_Count.Text.ToString() + " total translations selected");
                        sw.WriteLine(" ");
                        sw.WriteLine(lblRowsRecentLoggedOn_Count.Text.ToString() + " translations recently logged on (" + txtDaysIdle.Text.ToString() + " days ago or less)");
                        sw.WriteLine(lblRowsMoreThanMaxIdleCount.Text.ToString() + " translations idle for more than " + txtDaysIdle.Text.ToString() + " days");
                        sw.WriteLine(lblRowsNeverLoggedOn_Count.Text.ToString() + " translations never logged on ");
                        sw.WriteLine(" ");
                        sw.WriteLine("***************************************************");
                        sw.WriteLine("* Output End");
                        sw.WriteLine("***************************************************");
                        sw.Close();

                        clDashFunction.Melding("Done, results successfully written to: \n " + saveFileDlg.FileName, 1, "I");
                    }
                }
            }
        }

        private void cmdSave_Click(object sender, EventArgs e)
        {
            save_to_file();
        }

        /// <summary>
        /// Only select and count the datagrid rows who's translation.text value
        /// matches the value in the search textbox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmdIDXText_Click(object sender, EventArgs e)
        {            
            do_idx_selection(false);
        }

        /// <summary>
        /// Select and count all rows within the datagrid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmdIDXAll_Click(object sender, EventArgs e)
        {
            txtIDXText.Text = "";
            do_idx_selection(true);
        }

        private void do_idx_selection(Boolean bReset)
        {
            intNumberOfAccounts = 0;
            intLongerThan3Months = 0;
            intNeverLoggedOn = 0;
            intRecentLoggedOn = 0;
            int intDGRowCount = 0;
            Boolean bPassed = false;
            while (intDGRowCount < dgSTAccounter.Rows.Count)
            {
                bPassed = false;

                if (!bReset && dgSTAccounter[0, intDGRowCount].Value.ToString().ToUpper().Trim().Contains(txtIDXText.Text.ToUpper().ToString()))
                {
                    bPassed = true;
                }
                if (bReset)
                {
                    bPassed = true;
                }

                if (bPassed)
                {

                    intNumberOfAccounts++;

                    if (Convert.ToInt16(dgSTAccounter[2, intDGRowCount].Value) < 0)
                    {
                        intNeverLoggedOn++;
                    }
                    else
                    {
                        if (Convert.ToInt16(dgSTAccounter[2, intDGRowCount].Value) > Convert.ToInt16(txtDaysIdle.Text))
                        {
                            intLongerThan3Months++;
                        }
                        else
                        {
                            intRecentLoggedOn++;
                        }
                    }
                }

                dgSTAccounter.Rows[intDGRowCount].Visible = bPassed;

                intDGRowCount++;
            }
            SetNumbers(intNumberOfAccounts, intLongerThan3Months, intNeverLoggedOn, intRecentLoggedOn);
        }      
    }
}
