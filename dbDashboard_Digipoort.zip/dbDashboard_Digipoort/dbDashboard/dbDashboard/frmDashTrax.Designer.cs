﻿namespace dbDashboard
{
    partial class frmDashTrax
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDashTrax));
            this.grpTraxCriteria = new System.Windows.Forms.GroupBox();
            this.pbDigipoort = new System.Windows.Forms.PictureBox();
            this.grbWho = new System.Windows.Forms.GroupBox();
            this.lblSubject = new System.Windows.Forms.Label();
            this.txtSubject = new System.Windows.Forms.TextBox();
            this.cmdTrans = new System.Windows.Forms.Button();
            this.grbServerDate = new System.Windows.Forms.GroupBox();
            this.cmdDate_reset = new System.Windows.Forms.Button();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.txtSubjectType = new System.Windows.Forms.TextBox();
            this.lbDates = new System.Windows.Forms.ListBox();
            this.lblDatesMax = new System.Windows.Forms.Label();
            this.lbServer = new System.Windows.Forms.ListBox();
            this.lblServer = new System.Windows.Forms.Label();
            this.cmdSelect = new System.Windows.Forms.Button();
            this.lblTraxStatus = new System.Windows.Forms.Label();
            this.grpTraxResult = new System.Windows.Forms.GroupBox();
            this.lblMsgId = new System.Windows.Forms.Label();
            this.grbMsgId = new System.Windows.Forms.GroupBox();
            this.cmdNotePad = new System.Windows.Forms.Button();
            this.cmdMsgId_Close = new System.Windows.Forms.Button();
            this.lbMsgId = new System.Windows.Forms.ListBox();
            this.grpTraxSearch = new System.Windows.Forms.GroupBox();
            this.lblTraxSearchField = new System.Windows.Forms.Label();
            this.lblTraxSearchHelp = new System.Windows.Forms.Label();
            this.cmbTraxSearch = new System.Windows.Forms.ComboBox();
            this.cmdTraxReset = new System.Windows.Forms.Button();
            this.txtTraxSearch = new System.Windows.Forms.TextBox();
            this.cmdTraxSearch = new System.Windows.Forms.Button();
            this.lblTraxCount = new System.Windows.Forms.Label();
            this.dgTrax = new System.Windows.Forms.DataGridView();
            this.colTrax = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDatum = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTijd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMsgId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMsg = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.grbTrax = new System.Windows.Forms.GroupBox();
            this.bgw1 = new System.ComponentModel.BackgroundWorker();
            this.grbConnect.SuspendLayout();
            this.grpTraxCriteria.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbDigipoort)).BeginInit();
            this.grbWho.SuspendLayout();
            this.grbServerDate.SuspendLayout();
            this.grpTraxResult.SuspendLayout();
            this.grbMsgId.SuspendLayout();
            this.grpTraxSearch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgTrax)).BeginInit();
            this.grbTrax.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmdAfsluiten
            // 
            this.cmdAfsluiten.Location = new System.Drawing.Point(8, 789);
            this.cmdAfsluiten.TabIndex = 1;
            // 
            // grbConnect
            // 
            this.grbConnect.Location = new System.Drawing.Point(756, 836);
            // 
            // lblHostName
            // 
            this.lblHostName.Location = new System.Drawing.Point(1103, 803);
            this.lblHostName.Size = new System.Drawing.Size(145, 13);
            this.lblHostName.TabIndex = 2;
            this.lblHostName.Text = "KPNNL\\WLD4BED923B63C";
            // 
            // grpTraxCriteria
            // 
            this.grpTraxCriteria.Controls.Add(this.pbDigipoort);
            this.grpTraxCriteria.Controls.Add(this.grbWho);
            this.grpTraxCriteria.Controls.Add(this.grbServerDate);
            this.grpTraxCriteria.Controls.Add(this.cmdSelect);
            this.grpTraxCriteria.Controls.Add(this.lblTraxStatus);
            this.grpTraxCriteria.Location = new System.Drawing.Point(12, 27);
            this.grpTraxCriteria.Name = "grpTraxCriteria";
            this.grpTraxCriteria.Size = new System.Drawing.Size(1215, 275);
            this.grpTraxCriteria.TabIndex = 1;
            this.grpTraxCriteria.TabStop = false;
            this.grpTraxCriteria.Text = "Criteria";
            // 
            // pbDigipoort
            // 
            this.pbDigipoort.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pbDigipoort.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pbDigipoort.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbDigipoort.Image = ((System.Drawing.Image)(resources.GetObject("pbDigipoort.Image")));
            this.pbDigipoort.Location = new System.Drawing.Point(938, 26);
            this.pbDigipoort.Name = "pbDigipoort";
            this.pbDigipoort.Size = new System.Drawing.Size(256, 235);
            this.pbDigipoort.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbDigipoort.TabIndex = 66;
            this.pbDigipoort.TabStop = false;
            // 
            // grbWho
            // 
            this.grbWho.Controls.Add(this.lblSubject);
            this.grbWho.Controls.Add(this.txtSubject);
            this.grbWho.Controls.Add(this.cmdTrans);
            this.grbWho.Location = new System.Drawing.Point(8, 19);
            this.grbWho.Name = "grbWho";
            this.grbWho.Size = new System.Drawing.Size(349, 202);
            this.grbWho.TabIndex = 0;
            this.grbWho.TabStop = false;
            this.grbWho.Text = "Who";
            // 
            // lblSubject
            // 
            this.lblSubject.AutoSize = true;
            this.lblSubject.Location = new System.Drawing.Point(5, 25);
            this.lblSubject.Name = "lblSubject";
            this.lblSubject.Size = new System.Drawing.Size(300, 13);
            this.lblSubject.TabIndex = 0;
            this.lblSubject.Text = "Enter at least 3 characters of a Subject, Sender or a Recipient";
            // 
            // txtSubject
            // 
            this.txtSubject.Location = new System.Drawing.Point(8, 41);
            this.txtSubject.MaxLength = 75;
            this.txtSubject.Name = "txtSubject";
            this.txtSubject.Size = new System.Drawing.Size(309, 20);
            this.txtSubject.TabIndex = 1;
            this.txtSubject.TextChanged += new System.EventHandler(this.txtSubject_TextChanged);
            this.txtSubject.Enter += new System.EventHandler(this.txtSubject_Enter);
            // 
            // cmdTrans
            // 
            this.cmdTrans.Location = new System.Drawing.Point(316, 39);
            this.cmdTrans.Name = "cmdTrans";
            this.cmdTrans.Size = new System.Drawing.Size(25, 23);
            this.cmdTrans.TabIndex = 2;
            this.cmdTrans.Text = "...";
            this.cmdTrans.UseVisualStyleBackColor = true;
            this.cmdTrans.Click += new System.EventHandler(this.cmdTrans_Click);
            // 
            // grbServerDate
            // 
            this.grbServerDate.Controls.Add(this.cmdDate_reset);
            this.grbServerDate.Controls.Add(this.monthCalendar1);
            this.grbServerDate.Controls.Add(this.txtSubjectType);
            this.grbServerDate.Controls.Add(this.lbDates);
            this.grbServerDate.Controls.Add(this.lblDatesMax);
            this.grbServerDate.Controls.Add(this.lbServer);
            this.grbServerDate.Controls.Add(this.lblServer);
            this.grbServerDate.Location = new System.Drawing.Point(458, 20);
            this.grbServerDate.Name = "grbServerDate";
            this.grbServerDate.Size = new System.Drawing.Size(395, 242);
            this.grbServerDate.TabIndex = 2;
            this.grbServerDate.TabStop = false;
            this.grbServerDate.Text = "Where and when";
            // 
            // cmdDate_reset
            // 
            this.cmdDate_reset.Location = new System.Drawing.Point(12, 208);
            this.cmdDate_reset.Name = "cmdDate_reset";
            this.cmdDate_reset.Size = new System.Drawing.Size(58, 23);
            this.cmdDate_reset.TabIndex = 2;
            this.cmdDate_reset.Text = "Reset";
            this.cmdDate_reset.UseVisualStyleBackColor = true;
            this.cmdDate_reset.Click += new System.EventHandler(this.cmdDate_reset_Click);
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Location = new System.Drawing.Point(12, 41);
            this.monthCalendar1.MaxDate = new System.DateTime(2020, 12, 31, 0, 0, 0, 0);
            this.monthCalendar1.MaxSelectionCount = 1;
            this.monthCalendar1.MinDate = new System.DateTime(2010, 1, 1, 0, 0, 0, 0);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.ShowTodayCircle = false;
            this.monthCalendar1.ShowWeekNumbers = true;
            this.monthCalendar1.TabIndex = 1;
            this.monthCalendar1.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.monthCalendar1_DateSelected);
            // 
            // txtSubjectType
            // 
            this.txtSubjectType.Location = new System.Drawing.Point(181, 18);
            this.txtSubjectType.Name = "txtSubjectType";
            this.txtSubjectType.Size = new System.Drawing.Size(23, 20);
            this.txtSubjectType.TabIndex = 3;
            this.txtSubjectType.Visible = false;
            // 
            // lbDates
            // 
            this.lbDates.FormattingEnabled = true;
            this.lbDates.Location = new System.Drawing.Point(312, 41);
            this.lbDates.Name = "lbDates";
            this.lbDates.Size = new System.Drawing.Size(34, 173);
            this.lbDates.Sorted = true;
            this.lbDates.TabIndex = 6;
            this.lbDates.Visible = false;
            this.lbDates.SelectedIndexChanged += new System.EventHandler(this.lbDates_SelectedIndexChanged);
            this.lbDates.DoubleClick += new System.EventHandler(this.lbDates_DoubleClick);
            // 
            // lblDatesMax
            // 
            this.lblDatesMax.AutoSize = true;
            this.lblDatesMax.Location = new System.Drawing.Point(11, 25);
            this.lblDatesMax.Name = "lblDatesMax";
            this.lblDatesMax.Size = new System.Drawing.Size(118, 13);
            this.lblDatesMax.TabIndex = 0;
            this.lblDatesMax.Text = "Select dates ( max. 10 )";
            // 
            // lbServer
            // 
            this.lbServer.FormattingEnabled = true;
            this.lbServer.Location = new System.Drawing.Point(242, 41);
            this.lbServer.Name = "lbServer";
            this.lbServer.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.lbServer.Size = new System.Drawing.Size(77, 186);
            this.lbServer.TabIndex = 5;
            this.lbServer.SelectedIndexChanged += new System.EventHandler(this.lbServer_SelectedIndexChanged);
            // 
            // lblServer
            // 
            this.lblServer.AutoSize = true;
            this.lblServer.Location = new System.Drawing.Point(239, 25);
            this.lblServer.Name = "lblServer";
            this.lblServer.Size = new System.Drawing.Size(80, 13);
            this.lblServer.TabIndex = 4;
            this.lblServer.Text = "Select server(s)";
            // 
            // cmdSelect
            // 
            this.cmdSelect.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.cmdSelect.Location = new System.Drawing.Point(209, 241);
            this.cmdSelect.Name = "cmdSelect";
            this.cmdSelect.Size = new System.Drawing.Size(148, 25);
            this.cmdSelect.TabIndex = 1;
            this.cmdSelect.Text = "Select SMTP logrows";
            this.cmdSelect.UseVisualStyleBackColor = true;
            this.cmdSelect.Click += new System.EventHandler(this.cmdSelect_Click);
            // 
            // lblTraxStatus
            // 
            this.lblTraxStatus.AutoSize = true;
            this.lblTraxStatus.Location = new System.Drawing.Point(9, 225);
            this.lblTraxStatus.Name = "lblTraxStatus";
            this.lblTraxStatus.Size = new System.Drawing.Size(37, 13);
            this.lblTraxStatus.TabIndex = 9;
            this.lblTraxStatus.Text = "Status";
            // 
            // grpTraxResult
            // 
            this.grpTraxResult.Controls.Add(this.lblMsgId);
            this.grpTraxResult.Controls.Add(this.grbMsgId);
            this.grpTraxResult.Controls.Add(this.grpTraxSearch);
            this.grpTraxResult.Controls.Add(this.lblTraxCount);
            this.grpTraxResult.Controls.Add(this.dgTrax);
            this.grpTraxResult.Location = new System.Drawing.Point(12, 321);
            this.grpTraxResult.Name = "grpTraxResult";
            this.grpTraxResult.Size = new System.Drawing.Size(1215, 422);
            this.grpTraxResult.TabIndex = 0;
            this.grpTraxResult.TabStop = false;
            this.grpTraxResult.Text = "Result";
            // 
            // lblMsgId
            // 
            this.lblMsgId.AutoSize = true;
            this.lblMsgId.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMsgId.Location = new System.Drawing.Point(14, 26);
            this.lblMsgId.Name = "lblMsgId";
            this.lblMsgId.Size = new System.Drawing.Size(426, 13);
            this.lblMsgId.TabIndex = 0;
            this.lblMsgId.Text = "Double click on the MsgId column to view the message processing details";
            // 
            // grbMsgId
            // 
            this.grbMsgId.Controls.Add(this.cmdNotePad);
            this.grbMsgId.Controls.Add(this.cmdMsgId_Close);
            this.grbMsgId.Controls.Add(this.lbMsgId);
            this.grbMsgId.Location = new System.Drawing.Point(295, 41);
            this.grbMsgId.Name = "grbMsgId";
            this.grbMsgId.Size = new System.Drawing.Size(900, 293);
            this.grbMsgId.TabIndex = 2;
            this.grbMsgId.TabStop = false;
            this.grbMsgId.Text = "Detail information";
            // 
            // cmdNotePad
            // 
            this.cmdNotePad.Location = new System.Drawing.Point(92, 264);
            this.cmdNotePad.Name = "cmdNotePad";
            this.cmdNotePad.Size = new System.Drawing.Size(75, 23);
            this.cmdNotePad.TabIndex = 2;
            this.cmdNotePad.Text = "Save...";
            this.cmdNotePad.UseVisualStyleBackColor = true;
            this.cmdNotePad.Click += new System.EventHandler(this.cmdNotePad_Click);
            // 
            // cmdMsgId_Close
            // 
            this.cmdMsgId_Close.Location = new System.Drawing.Point(11, 264);
            this.cmdMsgId_Close.Name = "cmdMsgId_Close";
            this.cmdMsgId_Close.Size = new System.Drawing.Size(75, 23);
            this.cmdMsgId_Close.TabIndex = 1;
            this.cmdMsgId_Close.Text = "Close";
            this.cmdMsgId_Close.UseVisualStyleBackColor = true;
            this.cmdMsgId_Close.Click += new System.EventHandler(this.cmdMsgId_Close_Click);
            // 
            // lbMsgId
            // 
            this.lbMsgId.FormattingEnabled = true;
            this.lbMsgId.HorizontalScrollbar = true;
            this.lbMsgId.Location = new System.Drawing.Point(12, 19);
            this.lbMsgId.Name = "lbMsgId";
            this.lbMsgId.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lbMsgId.Size = new System.Drawing.Size(879, 238);
            this.lbMsgId.TabIndex = 0;
            // 
            // grpTraxSearch
            // 
            this.grpTraxSearch.Controls.Add(this.lblTraxSearchField);
            this.grpTraxSearch.Controls.Add(this.lblTraxSearchHelp);
            this.grpTraxSearch.Controls.Add(this.cmbTraxSearch);
            this.grpTraxSearch.Controls.Add(this.cmdTraxReset);
            this.grpTraxSearch.Controls.Add(this.txtTraxSearch);
            this.grpTraxSearch.Controls.Add(this.cmdTraxSearch);
            this.grpTraxSearch.Location = new System.Drawing.Point(649, 341);
            this.grpTraxSearch.Name = "grpTraxSearch";
            this.grpTraxSearch.Size = new System.Drawing.Size(546, 70);
            this.grpTraxSearch.TabIndex = 4;
            this.grpTraxSearch.TabStop = false;
            this.grpTraxSearch.Text = "Table search";
            // 
            // lblTraxSearchField
            // 
            this.lblTraxSearchField.AutoSize = true;
            this.lblTraxSearchField.Location = new System.Drawing.Point(8, 26);
            this.lblTraxSearchField.Name = "lblTraxSearchField";
            this.lblTraxSearchField.Size = new System.Drawing.Size(42, 13);
            this.lblTraxSearchField.TabIndex = 0;
            this.lblTraxSearchField.Text = "Column";
            // 
            // lblTraxSearchHelp
            // 
            this.lblTraxSearchHelp.AutoSize = true;
            this.lblTraxSearchHelp.Location = new System.Drawing.Point(130, 26);
            this.lblTraxSearchHelp.Name = "lblTraxSearchHelp";
            this.lblTraxSearchHelp.Size = new System.Drawing.Size(202, 13);
            this.lblTraxSearchHelp.TabIndex = 2;
            this.lblTraxSearchHelp.Text = "Use string or timerange: UU:MM~UU:MM";
            // 
            // cmbTraxSearch
            // 
            this.cmbTraxSearch.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTraxSearch.FormattingEnabled = true;
            this.cmbTraxSearch.Location = new System.Drawing.Point(8, 42);
            this.cmbTraxSearch.Name = "cmbTraxSearch";
            this.cmbTraxSearch.Size = new System.Drawing.Size(121, 21);
            this.cmbTraxSearch.TabIndex = 1;
            this.cmbTraxSearch.SelectedIndexChanged += new System.EventHandler(this.cmbTraxSearch_SelectedIndexChanged);
            // 
            // cmdTraxReset
            // 
            this.cmdTraxReset.Location = new System.Drawing.Point(444, 41);
            this.cmdTraxReset.Name = "cmdTraxReset";
            this.cmdTraxReset.Size = new System.Drawing.Size(75, 23);
            this.cmdTraxReset.TabIndex = 5;
            this.cmdTraxReset.Text = "Show all";
            this.cmdTraxReset.UseVisualStyleBackColor = true;
            this.cmdTraxReset.Click += new System.EventHandler(this.cmdTraxReset_Click);
            // 
            // txtTraxSearch
            // 
            this.txtTraxSearch.Location = new System.Drawing.Point(133, 43);
            this.txtTraxSearch.Name = "txtTraxSearch";
            this.txtTraxSearch.Size = new System.Drawing.Size(199, 20);
            this.txtTraxSearch.TabIndex = 3;
            this.txtTraxSearch.TextChanged += new System.EventHandler(this.txtTraxSearch_TextChanged);
            // 
            // cmdTraxSearch
            // 
            this.cmdTraxSearch.Location = new System.Drawing.Point(334, 41);
            this.cmdTraxSearch.Name = "cmdTraxSearch";
            this.cmdTraxSearch.Size = new System.Drawing.Size(73, 23);
            this.cmdTraxSearch.TabIndex = 4;
            this.cmdTraxSearch.Text = "Search";
            this.cmdTraxSearch.UseVisualStyleBackColor = true;
            this.cmdTraxSearch.Click += new System.EventHandler(this.cmdTraxSearch_Click);
            // 
            // lblTraxCount
            // 
            this.lblTraxCount.AutoSize = true;
            this.lblTraxCount.Location = new System.Drawing.Point(9, 398);
            this.lblTraxCount.Name = "lblTraxCount";
            this.lblTraxCount.Size = new System.Drawing.Size(60, 13);
            this.lblTraxCount.TabIndex = 3;
            this.lblTraxCount.Text = "Item count:";
            // 
            // dgTrax
            // 
            this.dgTrax.AllowUserToAddRows = false;
            this.dgTrax.AllowUserToDeleteRows = false;
            this.dgTrax.AllowUserToOrderColumns = true;
            this.dgTrax.AllowUserToResizeColumns = false;
            this.dgTrax.AllowUserToResizeRows = false;
            this.dgTrax.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgTrax.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colTrax,
            this.colDatum,
            this.colTijd,
            this.colMsgId,
            this.colMsg});
            this.dgTrax.Location = new System.Drawing.Point(13, 47);
            this.dgTrax.Name = "dgTrax";
            this.dgTrax.RowHeadersVisible = false;
            this.dgTrax.Size = new System.Drawing.Size(1183, 286);
            this.dgTrax.TabIndex = 1;
            this.dgTrax.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgTrax_CellDoubleClick);
            // 
            // colTrax
            // 
            this.colTrax.FillWeight = 50F;
            this.colTrax.HeaderText = "Server";
            this.colTrax.MaxInputLength = 50;
            this.colTrax.MinimumWidth = 50;
            this.colTrax.Name = "colTrax";
            this.colTrax.ReadOnly = true;
            this.colTrax.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colTrax.Width = 50;
            // 
            // colDatum
            // 
            this.colDatum.HeaderText = "Date";
            this.colDatum.MaxInputLength = 60;
            this.colDatum.MinimumWidth = 60;
            this.colDatum.Name = "colDatum";
            this.colDatum.Width = 60;
            // 
            // colTijd
            // 
            this.colTijd.FillWeight = 50F;
            this.colTijd.HeaderText = "Time";
            this.colTijd.MaxInputLength = 100;
            this.colTijd.MinimumWidth = 50;
            this.colTijd.Name = "colTijd";
            this.colTijd.Width = 50;
            // 
            // colMsgId
            // 
            this.colMsgId.FillWeight = 120F;
            this.colMsgId.HeaderText = "MsgId";
            this.colMsgId.MaxInputLength = 100;
            this.colMsgId.MinimumWidth = 120;
            this.colMsgId.Name = "colMsgId";
            this.colMsgId.Width = 120;
            // 
            // colMsg
            // 
            this.colMsg.HeaderText = "Message";
            this.colMsg.MaxInputLength = 100;
            this.colMsg.MinimumWidth = 900;
            this.colMsg.Name = "colMsg";
            this.colMsg.Width = 900;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // grbTrax
            // 
            this.grbTrax.Controls.Add(this.grpTraxCriteria);
            this.grbTrax.Controls.Add(this.grpTraxResult);
            this.grbTrax.Location = new System.Drawing.Point(8, 22);
            this.grbTrax.Name = "grbTrax";
            this.grbTrax.Size = new System.Drawing.Size(1240, 758);
            this.grbTrax.TabIndex = 0;
            this.grbTrax.TabStop = false;
            this.grbTrax.Text = "Track && Trace";
            // 
            // frmDashTrax
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1255, 820);
            this.Controls.Add(this.grbTrax);
            this.Name = "frmDashTrax";
            this.Text = "frmDashTrax - Digipoort Track en Trace  in SMTP logging";
            this.Activated += new System.EventHandler(this.frmDashTrax_Activated);
            this.Load += new System.EventHandler(this.frmDashTrax_Load);
            this.Controls.SetChildIndex(this.grbConnect, 0);
            this.Controls.SetChildIndex(this.lblHostName, 0);
            this.Controls.SetChildIndex(this.cmdAfsluiten, 0);
            this.Controls.SetChildIndex(this.grbTrax, 0);
            this.grbConnect.ResumeLayout(false);
            this.grbConnect.PerformLayout();
            this.grpTraxCriteria.ResumeLayout(false);
            this.grpTraxCriteria.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbDigipoort)).EndInit();
            this.grbWho.ResumeLayout(false);
            this.grbWho.PerformLayout();
            this.grbServerDate.ResumeLayout(false);
            this.grbServerDate.PerformLayout();
            this.grpTraxResult.ResumeLayout(false);
            this.grpTraxResult.PerformLayout();
            this.grbMsgId.ResumeLayout(false);
            this.grpTraxSearch.ResumeLayout(false);
            this.grpTraxSearch.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgTrax)).EndInit();
            this.grbTrax.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpTraxCriteria;
        private System.Windows.Forms.Button cmdSelect;
        private System.Windows.Forms.ListBox lbDates;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private System.Windows.Forms.TextBox txtSubject;
        private System.Windows.Forms.Label lblSubject;
        private System.Windows.Forms.GroupBox grpTraxResult;
        private System.Windows.Forms.DataGridView dgTrax;
        private System.Windows.Forms.Label lblDatesMax;
        private System.Windows.Forms.Label lblServer;
        private System.Windows.Forms.ListBox lbServer;
        private System.Windows.Forms.Label lblTraxCount;
        private System.Windows.Forms.Button cmdTraxSearch;
        private System.Windows.Forms.TextBox txtTraxSearch;
        private System.Windows.Forms.Button cmdTraxReset;
        private System.Windows.Forms.Label lblTraxStatus;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.ComboBox cmbTraxSearch;
        private System.Windows.Forms.GroupBox grpTraxSearch;
        private System.Windows.Forms.Label lblTraxSearchHelp;
        private System.Windows.Forms.Label lblTraxSearchField;
        private System.Windows.Forms.GroupBox grbTrax;
        private System.Windows.Forms.Button cmdTrans;
        private System.Windows.Forms.TextBox txtSubjectType;
        private System.ComponentModel.BackgroundWorker bgw1;
        private System.Windows.Forms.GroupBox grbMsgId;
        private System.Windows.Forms.Button cmdMsgId_Close;
        private System.Windows.Forms.ListBox lbMsgId;
        private System.Windows.Forms.GroupBox grbServerDate;
        private System.Windows.Forms.Button cmdDate_reset;
        private System.Windows.Forms.GroupBox grbWho;
        private System.Windows.Forms.Label lblMsgId;
        private System.Windows.Forms.PictureBox pbDigipoort;
        private System.Windows.Forms.Button cmdNotePad;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTrax;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDatum;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTijd;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMsgId;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMsg;
    }
}