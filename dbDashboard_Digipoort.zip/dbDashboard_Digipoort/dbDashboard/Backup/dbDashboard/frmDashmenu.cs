using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Collections;
using System.IO;
using System.Diagnostics;

namespace dbDashboard
{
    
    public partial class frmDashMenu : frmDashBase
    {

        string[]         strQueryArgs        = new string[] { "[0]", "[1] ", "[2] ", "[4]", "[5]" };
        string[]         strFunctie_array    = new string[50];
        public string    strUserNaam;
        public ArrayList arrSubs;
      
        Label[] lblFunktie = new Label[50];
        
        public frmDashMenu()
        {
            InitializeComponent();           
        }

        private void frmDashMenu_Load(object sender, EventArgs e)
        {
            this.Location = new System.Drawing.Point(1, 20);
            this.Cursor = Cursors.WaitCursor;
            frm_init();
            this.Cursor = Cursors.Default;
        }               

        public void DoSqlQuery(string strFunctie, string[] strValue)
        {
            DoSql mysql = new DoSql();
            
            switch (strFunctie)
            {
                case "MENU":
                    {                        
                        mysql.vul_deze_treeview = this.tvMenu;
                       
                        mysql.DoQuery(  " SELECT DISTINCT E.SubsVolg, E.SubsLevl, E.SubsNaam "+
                                        " FROM DashUser A,DashUgro B, DashSfug C, DashSufu D, DashSubs E "+
                                        " WHERE  A.UserCode = '"+ strUserCode + "'"+
                                        " AND    B.UgroCode = A.UserUgro "+
                                        " AND    C.SfugUgvo = B.UgroVolg "+
                                        " AND    D.SufuVolg = C.SfugSfvo "+
                                        " AND (  E.SubsVolg = D.SufuSuvo OR E.SubsLevl = 0 ) ");
                       
                        break;                       
                    }
                case "GETFUNCTIE":
                    {
                        
                        {
                            /*
                             * NIEUW INTERFACE
                            */
                            // Functies binnen het in geselecteerde Menuysteem ophalen... 
                            this.strFunctie_array[1] = "FTA";
                            mysql.vul_deze_text1_array = this.strFunctie_array;
                            mysql.DoQuery("SELECT   B.FuncText, B.FuncProg + '/' + FuncParm , B.FuncFuns  " +
                                // mysql.DoQuery("SELECT   B.FuncParm, B.FuncProg, B.FuncFuns  " +
                                         "FROM     DashGsfu A,DashFunc B               " +
                                         "WHERE    A.GsFuUgro = '" + strValue[1] + "' " +
                                         "AND      A.GsFuSubs = '" + strValue[0] + "' " +
                                         "AND      B.FuncProg = A.GsFuFunc " +
                                         "AND      B.FuncParm = A.GsFuParm " +
                                         "ORDER BY B.FuncText" );
                            if (mysql.affected_rows < 1)
                            {
                                clDashFunction.Melding("Geen functies binnen subsysteem!", 1, "I");
                                return;
                            }

                            // Dynamisch nieuwe "pushbuttons" maken....
                            for (int i = 1; i <= mysql.affected_rows; i++)
                            {
                                lblFunktie[i] = new Label();

                                lblFunktie[i].BackColor = Color.White;
                                lblFunktie[i].Text      = mysql.vul_deze_text1_array[i];
                                lblFunktie[i].Tag       = mysql.vul_deze_text2_array[i];
                                lblFunktie[i].Height    = 46;
                                // Dirty hack:  moet nog size in points of pixels uitzoeken
                                // om dit echt mooi te laten werken...
                                if (lblFunktie[i].Text.Length > 20)
                                {
                                    lblFunktie[i].Height = 60 - (25 - lblFunktie[i].Text.Length);
                                    // lblFunktie[i].Height = 65 - (25 - lblFunktie[i].Text.Length);
                                }
                                 
                                lblFunktie[i].Width     = 110;
                                lblFunktie[i].ImageList = tvMenu.ImageList;

                                // Executables krijgen blauwe bitmap variant, "formloaders" de zwarte...
                                if (mysql.vul_deze_text3_array[i] == "I")
                                {
                                    lblFunktie[i].ImageIndex = 0;
                                }
                                else
                                {
                                    lblFunktie[i].ImageIndex = 1;
                                }

                                lblFunktie[i].FlatStyle  = FlatStyle.Standard;
                                lblFunktie[i].ImageAlign = ContentAlignment.TopCenter;
                                lblFunktie[i].TextAlign  = ContentAlignment.BottomCenter;
                                
                                lblFunktie[i].MouseHover  += new System.EventHandler(lblFunktie_MouseHover);
                                lblFunktie[i].DoubleClick += new System.EventHandler(lblFunktie_DoubleClick);
                                lblFunktie[i].LostFocus   += new System.EventHandler(lblFunktie_LostFocus);

                                // Toevoegen op panel
                                flwPanel.Controls.Add(lblFunktie[i]);
                            }
                        }
                        break;                       
                    }
                default:
                    {
                        clDashFunction.Melding("Param error ("+strFunctie+") in DoSqlQuery()",1,"E");
                        break;
                    }
            }
        }

        private void afsluitenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void lblFunktie_LostFocus(object sender, EventArgs e)
        {
            Label lbl_FocusLost = (Label)sender;
            lbl_FocusLost.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));

        }
        // private void lblFunktie_Click(object sender, EventArgs e)
        private void lblFunktie_DoubleClick(object sender, EventArgs e)
        {
            string strProgramma = "";
            string strArguments = "";

            // Button cmdClicked = (Button)sender;
            Label cmdClicked = (Label)sender;

            this.Cursor = Cursors.WaitCursor;
            // cmdClicked.Enabled = false;
            // Eerst splitsen op programmanaam en evt parameter
            // Daarna kijken of we een EXE moeten starten of een intern form moeten gaan laden.
            // Dit wordt gedaan door te kijken of er ".exe" in de tag van de geklikte button
            // voorkomt EN of het imageindex 0 is, exe's worden immers met het default icon
            // getoond....

            // tbv doorgeven functietekst voor title in algemeen beheerform
            string strSupplemental_title = cmdClicked.Text;

            // Splits in formname en argument....
            string[] strForm_narg = Regex.Split(cmdClicked.Tag.ToString(), "/");
            strProgramma = strForm_narg[0].ToString(); 
            if (strForm_narg.Length == 2) 
            {
                strArguments = strForm_narg[1].ToString();
            }           
            
            if (strProgramma.ToString().ToUpper().IndexOf(".EXE") > 0 &&
                cmdClicked.ImageIndex == 1)
            {

                start_selected_program(strProgramma, strArguments); // Dus een EXE
            }
            else
            {
                start_selected_form(strProgramma, strArguments, strSupplemental_title);  // Dus een Form binnen deze solution           
            }
           // cmdClicked.Enabled = true;
            this.Cursor = Cursors.Default;
        }                  
        
        private void lblFunktie_MouseHover(object sender, EventArgs e)
        {
            Label lbl_Clicked = (Label)sender;
            reset_lblFunktie_font();
            lblToolTip.Text = lbl_Clicked.Text;
            lbl_Clicked.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        }

        private void MenuItemsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmDashMaintT DashMaintT = new frmDashMaintT();            
            DashMaintT.ShowDialog();
        }  
        
        private void frm_init()
        {
            // Reset van schermattributen
            lblUser_data.Text = strUserNaam;
            lblToolTip.Text = null;
            lblPad.Visible = false;
            txtPad.Visible = false;

            TreeNode tnSysteem = null;

            tvMenu.Nodes.Clear();
            DoSql mysql = new DoSql();
            mysql.vul_deze_text1_array[1] = "FTA";
            mysql.DoQuery("SELECT UgssVolg, UgssSubs, UgssUgro " +
                          "FROM DashUgss " +
                          "WHERE UgssUgro = '" + strUserUgro + "' " +
                          "ORDER BY UgssVolg ");
            if (mysql.affected_rows == 0)
            {
                clDashFunction.Melding("Geen menustructuur gedefinieerd voor groep: " + strUserUgro + "!", 1, "E");
                return;
            }
            // Alle geselecteerde menuitems doorlopen van ( occ 0 = altijd null )
            for (int i = 1; i <= mysql.affected_rows; i++)
            {
                string strNodeVolg = mysql.vul_deze_text1_array[i];
                string strNodeNaam = mysql.vul_deze_text2_array[i];
                string strUgssPkey = mysql.vul_deze_text3_array[i];

                // Nodevolgnummer ( 1,0,0,0 ) in array[0-3] zetten
                string[] arNodeLvl = Regex.Split(strNodeVolg, ",");

                // Alle geselecteerde menuitems doorlopen van N naar 1 ( occ 0 = altijd null )
                for (int j = arNodeLvl.Length - 1; j >= 0; j--)
                {
                    int intNodeNivoMin1 = Convert.ToInt16(arNodeLvl[j]);
                    // ***************************
                    // AFHANDELING SUBSUBSUB NODES
                    // ***************************
                    // Als op de NIET 1e positie van het volgnummer een "getal" staat dat
                    // groter is dan 0, dan hebben we een te maken met een sub(sub(sub))
                    // We moeten nu zijn "parent" zoeken:
                    // Bijvoorbeeld volgnr = 5,1,0,0, dan gaan we zoeken naar 5,0,0,0 Dit nummer wordt
                    // gecomponeerd in strSearchNode
                    if (j > 0 && arNodeLvl[j] != "0")
                    {
                        arNodeLvl[j] = "0";
                        string strSearchNode = arNodeLvl[0] + "," +
                                               arNodeLvl[1] + "," +
                                               arNodeLvl[2] + "," +
                                               arNodeLvl[3];

                        // Doorzoek de hele boom, hij MOET gevonden worden, anders klopt de menutabel
                        // in de database niet.....
                        TreeNode[] tnFound = tvMenu.Nodes.Find(strSearchNode, true);
                        // Omdat we bij een gevonden geval de hele "tak" meekrijgen is dit een 
                        // array. De nieuwe node moet als subnode worden toegevoegd aan het laatste
                        // item uit de "tak" (de search was immers naar de "vader" die 1 niveau hoger
                        // in de boom zit) vandaar onderstaande index constructie.
                        TreeNode tnNew = tnFound[tnFound.Length - 1].
                                         Nodes.Add(strNodeVolg, strNodeNaam);
                        tnNew.Tag = strUgssPkey;
                        break;
                    }

                    // ***************************************
                    // afhandeling rootnode SYSTEEM (0,0,0,0)
                    // EN DE NODES DAAR direct onders
                    // ****************************************
                    else
                    {
                        if (j == 0)
                        {
                            if (tnSysteem == null)
                            {
                                TreeNode tnNew = tvMenu.Nodes.Add(strNodeVolg, strNodeNaam);                                
                                tnNew.Tag = strUgssPkey;
                                if (strNodeVolg == "0,0,0,0")
                                {
                                    tnSysteem = tnNew;
                                }
                            }
                            else
                            {

                                TreeNode tnNew = tnSysteem.Nodes.Add(strNodeVolg, strNodeNaam);
                                tnNew.Tag = strUgssPkey;
                            }
                        }
                    }
                }
            }
            tnSysteem.Expand();      
        }        
        
        private void tvMenu_AfterSelect(object sender, TreeViewEventArgs e)
        {
            // Oude pushbutton controls op panel opruimen...          
            flwPanel.Controls.Clear();

            // Opnieuw vullen....
            if (e.Node.Text != null && e.Node.Tag != null && e.Node.Text != "Systeem")
            {
                strQueryArgs[0] = e.Node.Text;
                strQueryArgs[1] = e.Node.Tag.ToString();
                DoSqlQuery("GETFUNCTIE", strQueryArgs);
            }
        }       

        private void afsluitenToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void start_selected_program(string strProgramma, string strArguments)
        {
            DoSql mysql = new DoSql();
            mysql.vul_deze_string = " ";
            mysql.DoQuery(" SELECT FuncProg " +
                            "FROM   DashFunc " +
                            "WHERE  FuncProg = '" + strProgramma + "'");

            if (!File.Exists(strProgramma))
            {
                clDashFunction.Melding("Programma(locatie) " +
                                      strProgramma + " " + "ongeldig !", 1, "I");
            }
            else
            {
                // Programmanaam bijv. abc.exe destilleren uit "mysql.vul_deze_string" om verderop
                // te kunnen controleren of proces "abc.exe" al aanwezig is.
                int inStart = 0;
                int i_old = 0;
                for (int i = 1; i > 0; i++)
                {
                    i_old = i;
                    i = strProgramma.IndexOf("\\", inStart); //Na de laatste slashes staat de exe file
                    inStart = i + 1;
                }

                string[] strTarget = Regex.Split(strProgramma.Substring(i_old - 0,
                                                 strProgramma.Length - (i_old + 0)),
                                                 ".exe");
                
                // Indien proces al bekend is, dan opnieuw starten niet toegestaan
                if (Process.GetProcessesByName(strTarget[0]).Length > 0)
                {
                    clDashFunction.Melding("Programma '" + strProgramma +
                                           "' is reeds actief, dubbel opstarten niet toegestaan !", 1, "I");                   
                }
                else
                {
                    try
                    {
                        System.Diagnostics.Process.Start(strProgramma, strArguments);
                    }
                    catch
                    {
                        clDashFunction.Melding("Er is een fout opgetreden bij het opstarten van: " + strProgramma, 1, "E");
                        return;
                    }
                }
            }           
        }

        private void start_selected_form(string strForm_name, string strArguments, string strSupplemental_title)
        {
            if (!clDashFunction.block_form(mdiDashboard.alForms_loaded, strForm_name))
            {                
                clDashFunction.Melding("Functie '"+strForm_name+ "' is reeds actief, dubbel opstarten niet toegestaan !", 1, "I");
                // Form opzoeken in de collectie en vervolgens tonen.....
                foreach (Form mdiChild in MdiParent.MdiChildren)
                {
                    if (mdiChild.Name == strForm_name)
                    {
                        mdiChild.Location = new Point(100, 1);
                        mdiChild.WindowState = FormWindowState.Normal;
                        mdiChild.Activate();
                        break;
                    }                        
                }
                return;
            }  

            switch (strForm_name)
            {
                   
                case "frmDashMaintT":
                    {                        
                        frmDashMaintT DashMaintT         = new frmDashMaintT();
                        DashMaintT.strBeheer_tabel       = strArguments;
                        DashMaintT.strSupplemental_Title = strSupplemental_title;
                        DashMaintT.strUserCode           = this.strUserCode;                        
                        DashMaintT.MdiParent             = this.MdiParent;
                        DashMaintT.Show();
                    }
                    break;                
                case "frmDashRelMenu":
                    {
                        frmDashRelMenu DashRelMenu  = new frmDashRelMenu();
                        DashRelMenu.MdiParent       = this.MdiParent;
                        DashRelMenu.strUserCode     = this.strUserCode;  
                        DashRelMenu.Show();
                    }
                    break;

                case "frmDashSettings":
                    {
                        frmDashSettings DashSettings = new frmDashSettings();
                        DashSettings.MdiParent   = this.MdiParent;
                        DashSettings.strUserUgro = this.strUserUgro;
                        DashSettings.strUserCode = this.strUserCode;
                        DashSettings.Show();
                    }
                    break;

                   case "frmDashEnvir":
                    {
                        frmDashEnvir DashEnvir        = new frmDashEnvir();
                        DashEnvir.MdiParent           = this.MdiParent;
                        DashEnvir.strUserCode         = strUserCode;
                        DashEnvir.strUserUgro         = strUserUgro;
                        DashEnvir.alBericht           = new ArrayList();
                        // DashEnvir.Owner               = this;
                        DashEnvir.strDownload_functie = "CRONTAB";
                        DashEnvir.Show();                        
                    }
                    break;
                    
                case "frmDashQueue":
                    {
                        frmDashQueue Queue = new frmDashQueue();
                        Queue.MdiParent = this.MdiParent;
                        Queue.strUserCode = strUserCode;
                        Queue.strUserUgro = strUserUgro;
                        Queue.Show();
                    }
                    break;

                case "frmDashQueueView":
                    {
                        frmDashQueueView Queue = new frmDashQueueView();
                        Queue.MdiParent = this.MdiParent;
                        Queue.strUserCode = strUserCode;
                        Queue.strUserUgro = strUserUgro;
                        Queue.Show();
                    }
                    break;    
                default:
                    {
                        clDashFunction.Melding("Het opgegeven formulier ("+strForm_name+") kan niet worden geladen !", 1, "I");
                        break;
                    }
            }

        }      

        private void flwPanel_MouseHover(object sender, EventArgs e)
        {
            reset_lblFunktie_font();
        }

        private void flwPanel_MouseLeave(object sender, EventArgs e)
        {
            reset_lblFunktie_font();
        }
        private void reset_lblFunktie_font()
        {
            int i = 1;
            while (lblFunktie[i] != null)
            {
                this.lblFunktie[i].Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                i++;
            }
        }

        private void MeasureStringMin(PaintEventArgs e)
        {

            // Set up string.
            string measureString = "Measure String";
            Font stringFont = new Font("Arial", 16);

            // Measure string.
            SizeF stringSize = new SizeF();
            stringSize = e.Graphics.MeasureString(measureString, stringFont);

            // Draw rectangle representing size of string.
            e.Graphics.DrawRectangle(new Pen(Color.Red, 1), 0.0F, 0.0F, stringSize.Width, stringSize.Height);

            // Draw string to screen.
            e.Graphics.DrawString(measureString, stringFont, Brushes.Black, new PointF(0, 0));
        }

    }
}
   
