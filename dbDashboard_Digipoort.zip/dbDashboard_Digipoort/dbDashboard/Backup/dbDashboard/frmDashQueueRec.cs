﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace dbDashboard
{
    public partial class frmDashQueueRec : frmDashBase
    {
        public string strQueueData_Path;
        public string strRecordFile_val;
        public Boolean bRecordQueueOnly;
        public Boolean bRecordErrors;
        public Boolean bLog_X400Q_OVH;
        public Boolean bLog_X400Q_BDR;
        public Boolean bLog_SMTPQ_BDR;
        public Boolean bLog_SMTPQ_OVH;
        public Boolean bLog_CoreQ; 
        public Boolean bCancelled;

        public frmDashQueueRec()
        {
            InitializeComponent();
        }
       
        private void frmDashQueueRec_Load(object sender, EventArgs e)
        {
            frm_init();
        }


        private void frm_init()
        {
            txtRecord2File.Text = null;

            if (!Directory.Exists(strQueueData_Path))
            {
                clDashFunction.Melding("Error while generating 'SaveTo' filename, " +
                                       System.Environment.NewLine +
                                       System.Environment.NewLine +
                                       "Path: " + strQueueData_Path +
                                       System.Environment.NewLine +
                                       "does not exist !" +
                                       System.Environment.NewLine +
                                       System.Environment.NewLine +
                                       "check settings in INI file ");
                cmdAfsluiten_Click_1(new object(), new EventArgs());
            }
            else
            {
                cmdOK.Enabled = false;
                cbSMTPQ_BDR.Checked = bLog_SMTPQ_BDR;
                cbSMTPQ_OVH.Checked = bLog_SMTPQ_OVH;
                cbX400Q_OVH.Checked = bLog_X400Q_OVH;
                cbX400Q_BDR.Checked = bLog_X400Q_BDR;
                cbCoreQ.Checked = bLog_CoreQ;
                cbRecordQueueOnly.Checked = bRecordQueueOnly;
                cbRecordErrors.Checked = bRecordErrors;
                txtRecord2File.Text = strRecordFile_val;
                if ( File.Exists(txtRecord2File.Text) )
                {
                    cmdViewLogfile.Enabled=true;
                }
                else
	{
                    cmdViewLogfile.Enabled=false;
                    cmdGenerate_logfile_name_Click(new object(), new EventArgs());
	}
            }
        }

        private void cmdAfsluiten_Click_1(object sender, EventArgs e)
        {
            bCancelled = true;
            this.Close();
        }

        private void cmdOK_Click(object sender, EventArgs e)
        {
            strRecordFile_val = txtRecord2File.Text;
            bCancelled = false;
            this.Close();
        }

        private void cbRecordQueueOnly_CheckedChanged(object sender, EventArgs e)
        {
            bRecordQueueOnly = cbRecordQueueOnly.Checked;
        }
        
        private void cbRecordErrors_CheckedChanged(object sender, EventArgs e)
        {
            bRecordErrors = cbRecordErrors.Checked;
        }   

        private void cbCoreQ_CheckedChanged(object sender, EventArgs e)
        {
            bLog_CoreQ = cbCoreQ.Checked;
            cbValidate();
        }

        private void cbSMTPQ_OVH_CheckedChanged(object sender, EventArgs e)
        {
            bLog_SMTPQ_OVH = cbSMTPQ_OVH.Checked;
            cbValidate();
        }

        private void cbSMTPQ_BDR_CheckedChanged(object sender, EventArgs e)
        {
            bLog_SMTPQ_BDR = cbSMTPQ_BDR.Checked;
            cbValidate();
        }

        private void cbX400Q_BDR_CheckedChanged(object sender, EventArgs e)
        {
            bLog_X400Q_BDR = cbX400Q_BDR.Checked;
            cbValidate();
        }   

        private void cbX400Q_OVH_CheckedChanged(object sender, EventArgs e)
        {
            bLog_X400Q_OVH = cbX400Q_OVH.Checked;
            
            cbValidate();
        }
        
        private void cbValidate()
        {
            Boolean bOK = false;

            if ((bLog_CoreQ || bLog_X400Q_BDR || bLog_X400Q_OVH || bLog_SMTPQ_BDR || bLog_SMTPQ_OVH)  
                && txtRecord2File.Text != null
                && txtRecord2File.Text != "")
            {
                bOK = true;
            }
            cmdOK.Enabled =  bOK;
        }

        private string generate_logfile_name()
        {
            // (1) Filenaam componeren op basis van timestamp
            if (Directory.Exists(strQueueData_Path))
            {
                // (1) Filenaam componeren op basis van timestamp
                return strQueueData_Path +
                       "dpQ"+
                       System.DateTime.Now.Year.ToString() +
                       System.DateTime.Now.Month.ToString().PadLeft(2, '0') +
                       System.DateTime.Now.Day.ToString().PadLeft(2, '0') +
                       "_" +
                       System.DateTime.Now.Hour.ToString().PadLeft(2, '0') +
                       System.DateTime.Now.Minute.ToString().PadLeft(2, '0') +
                       System.DateTime.Now.Second.ToString().PadLeft(2, '0') +
                       ".csv";               
            }
            else
            {
                return null;
            }       
        }

        private void cmdGenerate_logfile_name_Click(object sender, EventArgs e)
        {
            txtRecord2File.Text = generate_logfile_name();
            cmdViewLogfile.Enabled = false;
        }

        private void txtRecord2File_TextChanged(object sender, EventArgs e)
        {
            cbValidate();
        }

        private void cmdViewLogfile_Click(object sender, EventArgs e)
        {
            clDashFunction.Notepad(txtRecord2File.Text);
        }            
    }
}
