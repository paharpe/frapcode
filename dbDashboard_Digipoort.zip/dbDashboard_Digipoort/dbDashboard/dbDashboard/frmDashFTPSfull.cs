﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.IO;

namespace dbDashboard
{
    public partial class frmDashFTPSfull : frmDashBase
    {
        public string strEnvironment;
        public System.Drawing.Size sdsdgTransfer;
        public System.Drawing.Size sdsgrbTransfer;
        public Point pntpnlSearch_transfer;

        public System.Drawing.Size sdsdgCommand;
        public System.Drawing.Size sdsgrbCommand;
        public Point pntpnlSearch;

        public frmDashFTPSfull()
        {
            InitializeComponent();
        }

        private void cbTimeFrame_CheckedChanged(object sender, EventArgs e)
        {
            grbTimeFrame.Enabled = cbTime.Checked;
            if (!grbTimeFrame.Enabled)
            {
                cmbFromHour.SelectedIndex   = -1;
                cmbFromMinute.SelectedIndex = -1;
                cmbToHour.SelectedIndex = -1;
                cmbToMinute.SelectedIndex = -1;    
            }
        }

        private void frmDashFTPSfull_Load(object sender, EventArgs e)
        {
            frm_init();
        }

        /// <summary>
        /// Initialisation form and controls
        /// </summary>
        private void frm_init()
        {
            cbTime.Checked       = false;
            grbTimeFrame.Enabled = false;

            rbProduction.Checked = true;

            lblDebug.Visible = mdiDashboard.bDebug;

            sdsdgTransfer = dgTransferLog.Size;
            sdsgrbTransfer = grbTransferLog.Size;
            pntpnlSearch_transfer = pnlSearch_transfer.Location;

            sdsdgCommand = dgCommandLog.Size;
            sdsgrbCommand = grbCommandLog.Size;
            pntpnlSearch = pnlSearch.Location;
        }
              
        /*
        private void Select_date()
        {
            lbDates.Items.Clear();

            // From 1-7-2014 
            //   To 20140701
            string strFormattedDate = mtcDate.SelectionRange.Start.Year.ToString() + mtcDate.SelectionRange.Start.Month.ToString("0#") + mtcDate.SelectionRange.Start.Day.ToString("0#");

            if (mtcDate.SelectionRange.Start > System.DateTime.Now)
            {
                clDashFunction.Melding("Future events do not yet exist !");
            }
            else
            {
                if (lbDates.Items.IndexOf(strFormattedDate) < 0)
                {
                    if (lbDates.Items.Count > 9)
                    {
                        clDashFunction.Melding("Number of selected dates has reached its limit !", 1, "I");
                    }
                    else
                    {
                        lbDates.Items.Add(strFormattedDate);
                    }
                }
                else
                {
                    lbDates.Items.Remove(strFormattedDate);
                }
               //  Do_Dates_Bold();                
            }
        }
         */

        private void rbProduction_CheckedChanged(object sender, EventArgs e)
        {
            strEnvironment = "Productie"; //roduction
            is_selection_ok(txtLogical.Text,strEnvironment);
        }

        private void rbPreProduction_CheckedChanged(object sender, EventArgs e)
        {
            strEnvironment = "PreProductie"; // pReproduction
            is_selection_ok(txtLogical.Text, strEnvironment);
        }

        private void cmdSelect_Click(object sender, EventArgs e)
        {
            if (check_TimeFrame())
            {
                do_selection();
            }
        }

        private Boolean check_TimeFrame()
        {
            Boolean bReturn = false;
            if (cbTime.Checked)
            {
                if (((cmbFromHour.intHour * 100) + cmbFromMinute.intMinute) > ((cmbToHour.intHour * 100) + cmbToMinute.intMinute))
                {
                    clDashFunction.Melding("'Time from' value should be less than 'time to' value", 1, "I");
                    cmbFromHour.Focus();
                }
                else
                {
                    bReturn = true;
                }
            }                        
            return bReturn;
        }

        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        // OVER DEBUG
        // Note bij het uitvoeren van de diverse selecties.......
        // Als mdiDashboard.bDebug aanstaat, dan wordt geen 'echte' query/selectie uitgevoerd op de Linux server(s),
        // maar wordt de inhoud van een  bestaand test bestand ingelezen -althans dat wordt geprobeerd, 
        // want dat bestand moet er natuurlijk (nog) wel zijn-
        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void do_selection()
        {
                   

            //***********************
            // Variabelen componeren
            // **********************
            string strCommandLogFile_indication;
 
            string strTransferLogServer = "kslv000";
            string strTransferLogDate = dtPicker.Value.Year.ToString() +
                                        "-" +
                                        dtPicker.Value.Month.ToString("0#") +
                                        "-" +
                                        dtPicker.Value.Day.ToString("0#");


            // ********************************************
            // Ophalen path en bestandsnaam van TransferLog
            // ********************************************
            string strTransferLogFile = clDashFunction.get_path("FTPS_TRANS_PATH");
            /*
                if (strTransferLogFile.Trim() == "")
                {
                     clDashFunction.Melding("Geen FTPs Transfer logfile(path) gedefinieerd in tabel nr:10 - elm:FTPS_TRANS_PATH", 1, "I");
                }
            */
            
            string[] strCommandLogServer = new string[2];
            strCommandLogServer[0]   = "kslv039";
            string strCommandLogDate = dtPicker.Value.Year.ToString() +
                                       dtPicker.Value.Month.ToString("0#") +
                                       dtPicker.Value.Day.ToString("0#");

            // ***************************************************************************
            // Ophalen path en scriptnaam van het script om de ST CommandLog uit te vragen
            // ***************************************************************************
            string strCommandScriptFile;
            strCommandScriptFile = clDashFunction.get_path("FTPS_COMMAND_SCRIPT");
            if (strCommandScriptFile == "")
            {
                clDashFunction.Melding("FTPS commandlog queryscript gegevens niet gevonden in tabel 10 !");
            }

            /*
                if (strCommandLogFile.Trim() == "")
                {
                    clDashFunction.Melding("Geen FTPs Command logfile(path) gedefinieerd in tabel nr:10 - elm:FTPS_COMMAND_PATH", 1, "I");
                }
            */

            // ********************************************
            // Ophalen path en bestandsnaam van CommandLog
            // ********************************************
            if (System.DateTime.Now.Date == dtPicker.Value.Date)
            {
                // Als de selectiedatum die van vandaag is => N(ow), 
                strCommandLogFile_indication = "N";
            }
            else
            {
                // anders => H(istory)
                strCommandLogFile_indication = "H";
            }

            // **********************************
            // Ophalen (basis)pad waar de 
            // in en out directory 
            // en de bestanden van de betreffende
            // klant staan.
            // **********************************
            string strIOPath = clDashFunction.get_path("FTPS_IO_PATH");


            // *************************
            // Time selection as well ?
            // *************************
            string strLogTimeFrom = "*";
            string strLogTimeUpTo = "*";
            if ( grbTimeFrame.Enabled )
            {
               strLogTimeFrom = cmbFromHour.intHour.ToString("0#") + ":" + cmbFromMinute.intMinute.ToString("0#");
               strLogTimeUpTo = cmbToHour.intHour.ToString("0#") + ":" + cmbToMinute.intMinute.ToString("0#");              
            }

            // ********************************************************************
            // Ophalen FTPS Core en Proxy(s) behorend bij de betreffende omgeving 
            // ********************************************************************
            DoSql mySql = new DoSql();
            mySql.vul_deze_text1_array[1] = "FTA";
            mySql.DoQuery("SELECT ElemElem, ElemOms1, ElemOms2 " +
                          "FROM DashElem " +
                          "WHERE ElemTabn = 12 " +
                          "AND ElemOms2 = '" + strEnvironment + "'" +
                          "AND ElemOms1 LIKE '%FTPS%'");

            if (mySql.affected_rows < 1)
            {
                clDashFunction.Melding("No FTPs Core and Proxy server(s) selected ! \n\n " +
                                       "You may check upon table 12 !", 1, "E");
                return;
            }
            else
            {
                int intmySql_array_index = 1;
                int intCommandLogServer_index = 0;
                while (intmySql_array_index <= mySql.affected_rows)
                {
                    // ********************
                    // FTPS Proxy gevonden => strCommandLogServer[<index>]
                    // ********************
                    if (mySql.vul_deze_text2_array[intmySql_array_index].ToString().ToUpper().Trim().Contains("PROXY"))
                    {
                        strCommandLogServer[intCommandLogServer_index] = mySql.vul_deze_text1_array[intmySql_array_index].ToString();
                        intCommandLogServer_index++;
                    }

                    // *********************
                    // FTPS Core gevonden strTransferLogServer
                    // *********************
                    if (mySql.vul_deze_text2_array[intmySql_array_index].ToString().ToUpper().Trim().Contains("CORE"))
                    {
                        strTransferLogServer = mySql.vul_deze_text1_array[intmySql_array_index].ToString();
                    }

                    intmySql_array_index++;
                }
            }

            //////////////////////////
            // Variabelen compleet ?
            //////////////////////////
            if (txtLogical.Text.Trim().Length > 3)
            {
                if (strTransferLogServer.Trim() != "")
                {
                    // ***********************
                    // First check Transferlog
                    // ***********************
                    if (strTransferLogDate.Trim() != "")
                    {                       
                        select_transferlog(strTransferLogFile, txtLogical.Text, strTransferLogServer, strTransferLogDate, strLogTimeFrom, strLogTimeUpTo);                        
                    }
                    else
                    {
                        clDashFunction.Melding("TransferLogDate is faulty");
                    }

                    // ***********************
                    // Then, check Commandlog
                    // ***********************      
                    if (strCommandLogDate != "")
                    {
                        //                  kslv039 / 071      /home/pe029017...scr            N/H                 20150505          10:59           11:15 
                        select_commandlog(strCommandLogServer, strCommandScriptFile,strCommandLogFile_indication, strCommandLogDate, strLogTimeFrom, strLogTimeUpTo);                               
                    }
                    else
                    {
                        clDashFunction.Melding("CommandDate is faulty");
                    }

                    // **************************
                    // Then, check files in inbox
                    // **********************
                    get_inbox(strTransferLogServer, strIOPath);
                   

                    // *******************************
                    // Finally, check files in outbox
                    // *******************************
                    get_outbox(strTransferLogServer, strIOPath);
                                                          
                }
                else
                {
                    clDashFunction.Melding("LogServer is faulty");
                }

                
            }
            else
            {
                clDashFunction.Melding("LogicalAddress is faulty");
            }         

        }

        //----------------------------------------------------------------------------------------------------------------------------------------
        
        

        private void txtLogical_TextChanged(object sender, EventArgs e)
        {
            is_selection_ok(txtLogical.Text, strEnvironment);
        }


        private void is_selection_ok(string strLogical, string strEnvironment)
        {
            Boolean bReturn = false;

            if (strLogical.Trim().Length >= 4 && (strEnvironment == "Productie" || strEnvironment == "PreProductie"))
            {
                bReturn = true;
            }
            cmdSelect.Enabled = bReturn;
        }

        // ***********
        // TRANSFERLOG
        // ************
        // Als mdiDashboard.bDebug aanstaat, dan wordt geen 'echte' query gedaan op Linux, maar wordt een bestaand test bestand ingelezen. 
        // Maar..... die moet er dan wel zijn natuurlijk
        private void select_transferlog(string strTransferLogFile, string strTransferLogUser, string strTransferLogServer, string strTransferLogDate, string strTransferLogTimeFrom, string strTransferLogTimeUpto)
        {
             //----------------------------------------------------------------------------------------------------------------------------------------
            string strGrep = "";
            string strTranferLogRecord;
            int intRowNo = 0;
            StreamReader myStreamReader;
            
            dgTransferLog.Rows.Clear();
            this.Refresh();

            strGrep = "grep "  + txtLogical.Text + "  " + strTransferLogFile + " " +
                    "| grep ^" + strTransferLogDate + " | grep -v dpkb";
                

            if (mdiDashboard.Talk)
            {
                clDashFunction.Melding("QueryParms: strServer: " + strTransferLogServer + "\n strTrans:" + strGrep, 1, "I");
            }      

            if (mdiDashboard.bDebug)
            {
                 myStreamReader = clDashFunction.open4read("C:\\harpe\\C#Solutions\\dbDashboard_Digipoort\\dbDashboard\\TempData\\Transfer.txt"); 
            }
            else
            {

                 myStreamReader = clDashFunction.get_linux_data(strTransferLogServer, strGrep);
            }
                     
            if (myStreamReader != null)
            {                
                while (!myStreamReader.EndOfStream)
                {        
                    strTranferLogRecord = myStreamReader.ReadLine();
                    
                    intRowNo = dgTransferLog.Rows.Add();
                    dgTransferLog[0, intRowNo].Value = strTransferLogServer;
                    dgTransferLog[1, intRowNo].Value = strTranferLogRecord;
                   
                }
            }
            else
            {
                clDashFunction.Melding("StreamReader is NULL !!");
            }
            if (intRowNo < 0)
            {
                dgTransferLog.Enabled = false;
                clDashFunction.Melding("No Transferlog records selected", 1, "I");
            }
            else
            {
                dgTransferLog.Enabled = true;
            }

            // nul = nul, maar anders komt de telling steevast 1 te laag uit.
            //            we beginnen immers te tellen bij rij 0 en die bevat record 1
            if (intRowNo > 0)
            { intRowNo++; }

            lblTransferLog.Text = dgTransferLog.Rows.Count.ToString() + " row(s)";
        }


        // **********
        // COMMANDLOG
        // **********
        private void select_commandlog(string[] strCommandLogServer, string strCommandScriptFile, string strCommandLogFile_indication, string strCommandLogDate, string strLogTimeFrom, string strLogTimeUpTo)                           
        {
            //----------------------------------------------------------------------------------------------------------------------------------------
            string strGrep = "";
            string strCommandLogRecord;
            int intRowNo = 0;
            StreamReader myStreamReader;
            dgCommandLog.Rows.Clear();
            this.Refresh();

            strGrep = strCommandScriptFile + " " + strCommandLogFile_indication +  " " + "'" + strCommandLogDate.Trim() + "'" + " " +  "'"+txtLogical.Text + "'" + " " + strLogTimeFrom + " " + strLogTimeUpTo;
            
            int intCommandLogServer_index = 0;
            while (intCommandLogServer_index < 2) // Max. 2 proxies per omgeving nu; start met index 0
            {
                if (mdiDashboard.Talk)
                {
                    clDashFunction.Melding("QueryParms: strServer: " + strCommandLogServer[intCommandLogServer_index] + "\n strGrep:" + strGrep, 1, "I");
                }
               
                if (mdiDashboard.bDebug)
                {
                    myStreamReader = clDashFunction.open4read("C:\\harpe\\C#Solutions\\dbDashboard_Digipoort\\dbDashboard\\TempData\\Command.txt");
                }
                else
                {                  
                  myStreamReader = clDashFunction.get_linux_boksu_data(strCommandLogServer[intCommandLogServer_index], strGrep);                       
                }

                if (myStreamReader != null)
                {
                    while (!myStreamReader.EndOfStream)
                    {
                        strCommandLogRecord = myStreamReader.ReadLine();

                        intRowNo = dgCommandLog.Rows.Add();
                        dgCommandLog[0, intRowNo].Value = strCommandLogServer[intCommandLogServer_index];
                        dgCommandLog[1, intRowNo].Value = strCommandLogRecord;

                    }
                }
                else
                {
                    if (mdiDashboard.Talk)
                    {
                        clDashFunction.Melding("myStreamreader van de get_linux_boksu_data is leeg!");
                    }
                }
                intCommandLogServer_index++;
            }
            if (intRowNo < 0)
            {
                dgCommandLog.Enabled = false;
                clDashFunction.Melding("No Commandlog records selected", 1, "I");
            }
            else
            {
                dgCommandLog.Enabled = true;
            }

            // nul = nul, maar anders komt de telling steevast 1 te laag uit.
            //            we beginnen immers te tellen bij rij 0 en die bevat record 1
            if (intRowNo > 0)
            { intRowNo++; }


            lblCommandLog.Text = dgCommandLog.Rows.Count.ToString() + " row(s)";           
        }

        // ***************
        // File INBOX
        // ***************
        private void get_inbox(string strCommandlogServer, string strIOPath)
        {

            // --> ls --full-time /data/opt/TMWD/data/BU/*/amro2412@ftp


            string strGetFiles = "ls --full-time " + strIOPath + "/*/" + txtLogical.Text + "/in/*";
            string strFileInRecord;
            int intRowNo = 0;
            StreamReader myStreamReader;

            dgFilesIn.Rows.Clear();

            if (mdiDashboard.Talk)
            {
                clDashFunction.Melding("QueryParms: strServer: " + strCommandlogServer + "\n strTrans:" + strGetFiles, 1, "I");
            }

            if (mdiDashboard.bDebug)
            {
                myStreamReader = clDashFunction.open4read("C:\\harpe\\C#Solutions\\dbDashboard_Digipoort\\dbDashboard\\TempData\\GetIn.txt");
            }
            else
            {
                myStreamReader = clDashFunction.get_linux_data(strCommandlogServer, strGetFiles);
            }

            if (myStreamReader != null)
            {
                while (!myStreamReader.EndOfStream)
                {
                    strFileInRecord = myStreamReader.ReadLine();
                    strFileInRecord = clDashFunction.remove_multiple_spaces(strFileInRecord);                  
                    string[] strarFileInRecord = Regex.Split(strFileInRecord, " ");
                    if (strarFileInRecord.Length >= 8)
                    {
                        intRowNo = dgFilesIn.Rows.Add();
                        // Filename
                        dgFilesIn[0, intRowNo].Value = strarFileInRecord[8];
                        // Timestamp
                        dgFilesIn[1, intRowNo].Value = strarFileInRecord[5] + " "+ strarFileInRecord[6] + strarFileInRecord[7];
                        // Filesize
                        dgFilesIn[2, intRowNo].Value = strarFileInRecord[4];
                    }
                }
            }

            lblFilesIn.Text = dgFilesIn.Rows.Count.ToString() + " row(s)";
        }

        // ***************
        // File OUTBOX
        // ***************
        private void get_outbox(string strCommandlogServer, string strIOPath)
        {

            // --> ls --full-time /data/opt/TMWD/data/BU/*/amro2412@ftp


            string strGetFiles = "ls --full-time " + strIOPath + "/*/" + txtLogical.Text + "/out/*";
            string strFileOutRecord;
            int intRowNo = 0;
            StreamReader myStreamReader;
            dgFilesOut.Rows.Clear();

            if (mdiDashboard.Talk)
            {
                clDashFunction.Melding("QueryParms: strServer: " + strCommandlogServer + "\n strTrans:" + strGetFiles, 1, "I");
            }

            if (mdiDashboard.bDebug)
            {
                myStreamReader = clDashFunction.open4read("C:\\harpe\\C#Solutions\\dbDashboard_Digipoort\\dbDashboard\\TempData\\GetOut.txt");
            }
            else
            {
                myStreamReader = clDashFunction.get_linux_data(strCommandlogServer, strGetFiles);
            }
           
            if (myStreamReader != null)
            {
                while (!myStreamReader.EndOfStream)
                {
                    strFileOutRecord = myStreamReader.ReadLine();
                    strFileOutRecord = clDashFunction.remove_multiple_spaces(strFileOutRecord);
                    string[] strarFileOutRecord = Regex.Split(strFileOutRecord, " ");
                    //
                    if (strarFileOutRecord.Length >= 8)
                    {
                        intRowNo = dgFilesOut.Rows.Add();
                        // Filename
                        dgFilesOut[0, intRowNo].Value = strarFileOutRecord[8];
                        // Timestamp
                        dgFilesOut[1, intRowNo].Value = strarFileOutRecord[5] + " " + strarFileOutRecord[6] + strarFileOutRecord[7];
                        // Filesize
                        dgFilesOut[2, intRowNo].Value = strarFileOutRecord[4];
                    }                    
                }
            }

            lblFilesOut.Text = dgFilesOut.Rows.Count.ToString() + " row(s)";
        }

        private void cmdSearch_Click(object sender, EventArgs e)
        {
            Button cmdSearch = (Button)sender;
            switch (cmdSearch.Tag.ToString().ToUpper())
            {
                case "DGCOMMANDLOG":
                    select_datagrid_rows(dgCommandLog, false, txtSearch.Text);
                    break;
                case "DGTRANSFERLOG":
                    select_datagrid_rows(dgTransferLog, false, txtSearch_transfer.Text);
                    break;
                default:
                    clDashFunction.Melding("An unknown cmdSearch.tag value ("+ cmdSearch.Tag.ToString().ToUpper() + ") has been passed !", 1, "E");
                    break;
            }
            select_datagrid_rows(dgCommandLog, false, txtSearch.Text);
        }
        
        private void cmdSall_Click(object sender, EventArgs e)
        {

            Button cmdSearch = (Button)sender;
            switch (cmdSearch.Tag.ToString().ToUpper())
            {
                case "DGCOMMANDLOG":
                    txtSearch.Text = "";
                    select_datagrid_rows(dgCommandLog, true, txtSearch.Text);
                    break;
                case "DGTRANSFERLOG":
                    txtSearch_transfer.Text = "";
                    select_datagrid_rows(dgTransferLog, true, txtSearch_transfer.Text);
                    break;
                default:
                    clDashFunction.Melding("An unknown cmdSearch.tag value (" + cmdSearch.Tag.ToString().ToUpper() + ") has been passed !", 1, "E");
                    break;
            }      
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            cmdSearch.Enabled = false;

            if (txtSearch.Text.Trim() != "")
            {
                cmdSearch.Enabled = true;
            }
        }

        private void txtSearch_transfer_TextChanged(object sender, EventArgs e)
        {
            cmdSearch_transfer.Enabled = false;

            if (txtSearch_transfer.Text.Trim() != "")
            {
                cmdSearch_transfer.Enabled = true;
            }
        }

        private void select_datagrid_rows(DataGridView dgGrid, Boolean bReset, string strSearch_Value)
        {
            int intDataGridRow_index = 0;
            int intSaveFirstSelectedRow_number = -1;
            while (intDataGridRow_index < dgGrid.Rows.Count)
            {
                dgGrid.Rows[intDataGridRow_index].Visible = false;
                if (dgGrid[1, intDataGridRow_index].Value.ToString().Trim().ToUpper().Contains(strSearch_Value.ToUpper().Trim()) ||
                    bReset)
                {
                    dgGrid.Rows[intDataGridRow_index].Visible = true;
                    if (intSaveFirstSelectedRow_number == -1)
                    {
                        intSaveFirstSelectedRow_number = intDataGridRow_index;
                    }
                }
                intDataGridRow_index++;
            }
            if (intSaveFirstSelectedRow_number > -1)
            {
                dgGrid.FirstDisplayedScrollingRowIndex = intSaveFirstSelectedRow_number;
            }
        }

        private void dgTransferLog_Click(object sender, EventArgs e)
        {
            clDashFunction.Melding("Hiero");
        }

        

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            System.Drawing.Size xx = new System.Drawing.Size();
            xx.Width = sdsgrbTransfer.Width;
            xx.Height = sdsgrbTransfer.Height - (10 * trackBar1.Value);
            grbTransferLog.Size = xx;

            System.Drawing.Size yy = new System.Drawing.Size();
            yy.Width = sdsdgTransfer.Width;
            yy.Height = sdsdgTransfer.Height - (10 * trackBar1.Value);
            dgTransferLog.Size = yy;

            Point zz = new Point();
            zz.X = pntpnlSearch_transfer.X;
            zz.Y = pntpnlSearch_transfer.Y - (10 * trackBar1.Value);
            pnlSearch_transfer.Location = zz;

            if (sdsdgTransfer.Height < yy.Height ||
                sdsgrbTransfer.Height < xx.Height)
            {
                grbFilesIn.Visible = false;
                grbFilesOut.Visible = false;
            }
            else
            {
                grbFilesIn.Visible = true;
                grbFilesOut.Visible = true;  
            }
            grbTransferLog.Refresh();
        }
            

        private void trackBar2_Scroll(object sender, EventArgs e)
        {
            System.Drawing.Size xx = new System.Drawing.Size();
            xx.Width = sdsgrbCommand.Width;
            xx.Height = sdsgrbCommand.Height - (10 * trackBar2.Value);
            grbCommandLog.Size = xx;

            System.Drawing.Size yy = new System.Drawing.Size();
            yy.Width = sdsdgCommand.Width;
            yy.Height = sdsdgCommand.Height - (10 * trackBar2.Value);
            dgCommandLog.Size = yy;

            Point zz = new Point();
            zz.X = pntpnlSearch.X;
            zz.Y = pntpnlSearch.Y - (10 * trackBar2.Value);
            pnlSearch.Location = zz;

            if (sdsdgCommand.Height  < yy.Height ||
                sdsgrbCommand.Height < xx.Height)
            {
                grbTransferLog.Visible = false;
                trackBar1.Visible = false;                
            }
            else
            {
                grbTransferLog.Visible = true;
                trackBar1.Visible = true;
            }
            grbCommandLog.Refresh();
        }

        private void cmdReset_Click(object sender, EventArgs e)
        {
            trackBar1.Value = 0;
            trackBar1_Scroll(new object(), new EventArgs());
           
            trackBar2.Value = 0;
            trackBar2_Scroll(new object(), new EventArgs());
        }

        private void dgFilesIn_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0)
            {
                // strIOPath
                clDashFunction.Melding(clDashFunction.get_path("FTPS_IO_PATH")+dgFilesIn[e.ColumnIndex,e.RowIndex].Value.ToString());
            }            
        }                             
    }
}
