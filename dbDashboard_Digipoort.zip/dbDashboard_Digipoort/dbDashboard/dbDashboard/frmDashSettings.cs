﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace dbDashboard
{
    public partial class frmDashSettings : frmDashBase
    {
        
        // private string  strAuthFunctie;
       
        private ArrayList   alSaveGeg1 = new ArrayList();
        private ArrayList   alSaveGeg2 = new ArrayList();
        private ArrayList   alSaveGeg3 = new ArrayList();
        private ArrayList   alSaveGeg4 = new ArrayList();
        private ArrayList   alSaveGeg5 = new ArrayList();
        private string      strUpdateMode = "NEW";

        private int intDefaultWidth  = 685;
        private int intDefaultHeigth = 280;
        private int intExpandWidth   = 685;
        private int intExpandHeigth  = 610;

        public frmDashSettings()
        {
            InitializeComponent();
        }
        private void frmDashSettings_Load(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            frm_init();
            this.Cursor = Cursors.Default;
        }

        private void frm_init()
        {
            setAuth_Buttons(false);
            set_screen("DEFAULT");
            lblWarn.Visible      = false;
            rbGebruiker.Enabled  = true;
            rbGroep.Enabled      = true;
            lbGebrGroep.Enabled  = true;
            grpAutab.Visible     = false;
            cmdToepassen.Enabled = false;
            cmdOk.Enabled        = false;
            rbGebruiker.Checked  = true;
            for (int intGebruiker = 0; intGebruiker < lbGebrGroep.Items.Count; intGebruiker++)
            {
                lbGebrGroep.SelectedIndex = intGebruiker;
                if (lbGebrGroep.Text.ToUpper().Trim() == strUserCode.ToUpper().Trim())
                {
                    break;
                }
            }
        }

        private void rbGebruiker_CheckedChanged(object sender, EventArgs e)
        {
            DoSql mysql = new DoSql();
            mysql.vul_deze_listbox = lbGebrGroep;
            mysql.DoQuery("SELECT UserCode " +
                          "FROM   DashUser ");
        }

        private void rbGroep_CheckedChanged(object sender, EventArgs e)
        {
            DoSql mysql = new DoSql();
            mysql.vul_deze_listbox = lbGebrGroep;
            mysql.DoQuery("SELECT UgroCode " +
                          "FROM   DashUgro ");
        }

        private void cmdCancel_Click(object sender, EventArgs e)
        {
            if (bChanged)
            {
                if (clDashFunction.Melding("Gegevens zijn gewijzigd, wilt u stoppen zonder opslaan ?", 4, "Q") != DialogResult.Yes)
                {
                    return;
                }
            }
            set_screen("DEFAULT");
            bChanged = false;
            setAuth_Buttons(true);           
        }       

        private void Doe_Conn_Init()
        {
            rbGebruiker.Enabled = false;
            rbGroep.Enabled     = false;
            lbGebrGroep.Enabled = false;
            grpAutab.Visible    = true;

            string strDefaultConn = null;
            string strDefaultDir  = null;
            
            int dgAuth_RowNr = 0;           
            
            ArrayList alConnectie_query = new ArrayList(2);
            Boolean[] bChecked          = new Boolean[2];
            dgAuth.Columns.Clear();
            DataGridViewCheckBoxColumn colCBGekoppeld  = new DataGridViewCheckBoxColumn();
            DataGridViewTextBoxColumn  colTBGroepGebr  = new DataGridViewTextBoxColumn();
            DataGridViewTextBoxColumn  colTBGroepConn  = new DataGridViewTextBoxColumn();
            DataGridViewTextBoxColumn  colTBDefaultDir = new DataGridViewTextBoxColumn();
            DataGridViewCheckBoxColumn colCBDefaultCon = new DataGridViewCheckBoxColumn();
           
            dgAuth.Columns.Add(colCBGekoppeld);
            dgAuth.Columns.Add(colTBGroepGebr);
            dgAuth.Columns.Add(colTBGroepConn);
            dgAuth.Columns.Add(colTBDefaultDir);
            dgAuth.Columns.Add(colCBDefaultCon);
            dgAuth.Columns[0].Width = 75;
            dgAuth.Columns[1].Width = 100;
            dgAuth.Columns[2].Width = 150;
            dgAuth.Columns[3].Width = 200;
            dgAuth.Columns[4].Width = 100;
            dgAuth.Columns[0].HeaderText = "Gekoppeld";
            dgAuth.Columns[1].HeaderText = "Groep/Gebruiker";
            dgAuth.Columns[2].HeaderText = "Connectie";
            dgAuth.Columns[3].HeaderText = "Def.Dir";
            dgAuth.Columns[4].HeaderText = "Def.Conn";
            dgAuth.Columns[1].ReadOnly = true;
            dgAuth.Columns[2].ReadOnly = true;
            
            bChecked[0] = true;
            bChecked[1] = false;

            // Eerst de reeds toegewezen connecties vullen...
            alConnectie_query.Add("SELECT UgcoUgro, UgcoSnam, UgcoDftD + '@' + UgcoDftC " +
                                    "FROM   DashUgco " +
                                    "WHERE  UgcoUgro = '" + lbGebrGroep.Text + "'");
            
            // Daarna de nog niet toegewezen...
            alConnectie_query.Add("SELECT '" + lbGebrGroep.Text + "' , ConnSnam, ' ', ' ' " +
                                    "FROM   DashConn AS L " +
                                    "WHERE NOT EXISTS ( " +
                                    " SELECT 1 FROM DashUgCo AS  M " +
                                    " WHERE M.UgCoUgro = '" + lbGebrGroep.Text + "'" +
                                    " AND   M.UgCoSnam   = L.ConnSnam )");
            alSaveGeg1.Clear();
            alSaveGeg2.Clear();
            alSaveGeg3.Clear();
            alSaveGeg4.Clear();
            alSaveGeg5.Clear();

            dgAuth.Rows.Clear();

            DoSql mysql = new DoSql();
            for (int q = 0; q < 2; q++)
            {
               
                mysql.vul_deze_text1_array[1] = "FTA";
                           
                mysql.DoQuery(alConnectie_query[q].ToString());

                for (int i = 1; i <= mysql.affected_rows; i++)
                {
                    dgAuth.Rows.Add();
                    dgAuth[0, dgAuth_RowNr].Value = bChecked[q];

                    // Connectie niet gekoppeld ? Dan niet edited ook !
                    if (!bChecked[q])
                    {
                        dgAuth[3, dgAuth_RowNr].ReadOnly = true;
                        dgAuth[4, dgAuth_RowNr].ReadOnly = true;
                        dgAuth[0, dgAuth_RowNr].Style.BackColor = Color.LightGray;
                        dgAuth[1, dgAuth_RowNr].Style.BackColor = Color.LightGray;
                        dgAuth[2, dgAuth_RowNr].Style.BackColor = Color.LightGray;
                        dgAuth[3, dgAuth_RowNr].Style.BackColor = Color.LightGray;
                        dgAuth[4, dgAuth_RowNr].Style.BackColor = Color.LightGray;
                    }

                    dgAuth[1, dgAuth_RowNr].Value = mysql.vul_deze_text1_array[i];
                    dgAuth[2, dgAuth_RowNr].Value = mysql.vul_deze_text2_array[i];
                    

                    string[] strDefaults = Regex.Split(mysql.vul_deze_text3_array[i], "@");
                    strDefaultDir  = strDefaults[0];
                    strDefaultConn = "";
                    dgAuth[3, dgAuth_RowNr].Value = strDefaultDir;

                    if (strDefaults.Length > 1)
                    {
                        strDefaultConn = strDefaults[1];                        
                    }
                    if (strDefaultConn == "D")
                    {
                        dgAuth[4, dgAuth_RowNr].Value = bChecked[0];
                    }
                   
                    // Bewaar oorspronkelijke waarden om later selectief te kunnen INSERTEN, UPDATEN, DELETEN....
                    alSaveGeg1.Add(bChecked[q]);
                    alSaveGeg2.Add(mysql.vul_deze_text1_array[i]);
                    alSaveGeg3.Add(mysql.vul_deze_text2_array[i]);
                    alSaveGeg4.Add(strDefaultDir);
                    if (strDefaultConn == "D")
                    {
                        alSaveGeg5.Add(bChecked[0]);
                    }
                    else
                    {
                        alSaveGeg5.Add(bChecked[1]);
                    }
                    dgAuth_RowNr++;
                }
                mysql.vul_deze_text1_array = new string[50];
                mysql.vul_deze_text2_array = new string[50];
                mysql.vul_deze_text3_array = new string[50];
                mysql.affected_rows = 0;

                bChanged             = false;
                cmdOk.Enabled        = false;
                cmdToepassen.Enabled = false;   
            }

            foreach (DataGridViewColumn column in dgAuth.Columns)
            {
                column.SortMode = DataGridViewColumnSortMode.NotSortable;
            }           
        }

        private void Doe_Ftpp_Init()
        {
            rbGebruiker.Enabled = false;
            rbGroep.Enabled     = false;
            lbGebrGroep.Enabled = false;
            grpAutab.Visible    = true;

            int dgAuth_RowNr = 0;

            dgAuth.Columns.Clear();

            DataGridViewTextBoxColumn colTBGroepGebr = new DataGridViewTextBoxColumn();
            DataGridViewTextBoxColumn colTBFtppValue = new DataGridViewTextBoxColumn();
            DataGridViewButtonColumn colBTNKiesDir = new DataGridViewButtonColumn();

            dgAuth.Columns.Add(colTBGroepGebr);
            dgAuth.Columns.Add(colTBFtppValue);
            dgAuth.Columns.Add(colBTNKiesDir);

            dgAuth.Columns[0].Width = 100;
            dgAuth.Columns[1].Width = 490;
            dgAuth.Columns[2].Width = 35;

            dgAuth.Columns[0].HeaderText = "Groep/Gebruiker";
            dgAuth.Columns[1].HeaderText = "Huidige instelling";
         
            alSaveGeg1.Clear();
            alSaveGeg2.Clear();
            alSaveGeg3.Clear();
            alSaveGeg4.Clear();
            alSaveGeg5.Clear();

            dgAuth.Rows.Clear();

            DoSql mysql = new DoSql();
            mysql.vul_deze_text1_array[1] = "FTA";
            mysql.DoQuery("SELECT UgFPUgro,UgFPFtpV, '...' " +
                          "FROM   DashUgFP " +
                          "WHERE  UgFPUgro = '" + lbGebrGroep.Text + "'");
            if (mysql.affected_rows == 0)
            {
                dgAuth_RowNr = dgAuth.Rows.Add();
                strUpdateMode = "NEW";
                dgAuth[0, dgAuth_RowNr].Value = lbGebrGroep.Text;
                dgAuth[1, dgAuth_RowNr].Value = " ";
                dgAuth[2, dgAuth_RowNr].Value = "...";                
            }
            else
            {
                strUpdateMode = "UPD";
                for (dgAuth_RowNr = 0; dgAuth_RowNr < mysql.affected_rows; dgAuth_RowNr++)
                {
                    dgAuth_RowNr = dgAuth.Rows.Add();
                    dgAuth[0, dgAuth_RowNr].Value = mysql.vul_deze_text1_array[dgAuth_RowNr + 1];
                    dgAuth[1, dgAuth_RowNr].Value = mysql.vul_deze_text2_array[dgAuth_RowNr + 1];
                    dgAuth[2, dgAuth_RowNr].Value = mysql.vul_deze_text3_array[dgAuth_RowNr + 1];
                    
                    // Bewaar oorspronkelijke waarden om later selectief te kunnen INSERTEN, UPDATEN, DELETEN....
                    alSaveGeg1.Add(mysql.vul_deze_text1_array[dgAuth_RowNr + 1]);
                    alSaveGeg2.Add(mysql.vul_deze_text2_array[dgAuth_RowNr + 1]);                   
                }
            }
            // Toch maar een rij (0) te behandelen hier....
            dgAuth[0, 0 ].ReadOnly = true;
            dgAuth[1, 0].ReadOnly = true;
            
            bChanged             = false;
            cmdToepassen.Enabled = false;
            cmdOk.Enabled        = false;

            foreach (DataGridViewColumn column in dgAuth.Columns)
            {
                column.SortMode = DataGridViewColumnSortMode.NotSortable;
            }
        }

        private void dgAuth_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            Verwerk_dgTextFields(e.ColumnIndex, e.RowIndex);
        }

        private void dgAuth_CurrentCellDirtyStateChanged(object sender, EventArgs e)
        {
            if (dgAuth.IsCurrentCellDirty)
            {
                dgAuth.CommitEdit(DataGridViewDataErrorContexts.Commit);
            }
        }      
        private void cmdOk_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            set_screen("DEFAULT");
            setAuth_Buttons(true);    
            this.Cursor = Cursors.Default;
        }

        private void cmdToepassen_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            
            this.Cursor = Cursors.Default;
        }  
        
        private void Verwerk_dgTextFields(int intColInd, int intRowInd)
        {
            if (intRowInd > -1 && intColInd < dgAuth.Columns.Count)
            {
                if (intColInd == 3 && alSaveGeg4.Count > intRowInd && dgAuth[intColInd, intRowInd].Value != null)
                {
                    if (dgAuth[intColInd, intRowInd].Value.ToString() != alSaveGeg4[intRowInd].ToString())
                    {
                        bChanged = true;
                        cmdToepassen.Enabled = true;
                        cmdOk.Enabled        = true;
                    }
                }
            }
        }

        private void Doe_Conn_Update()
        {
            string strDefaultDir = null;
            string strDefaultCon = null;
            string strGrus;
            if (rbGebruiker.Checked)
            {
                strGrus = "U";
            }
            else
            {
                strGrus = "G";
            }
            for (int i = 0; i < dgAuth.RowCount; i++)
            {
                // Gekoppelde checkbox is gewijzigd.....
                if (Convert.ToBoolean(dgAuth[0, i].Value) != Convert.ToBoolean(alSaveGeg1[i]))                                    
                {
                    // Hij is aangezet ( was uit ). Wordt insert
                    if (Convert.ToBoolean(dgAuth[0, i].Value) == true)
                    {
                        if (Convert.ToBoolean(dgAuth[4, i].Value) == true)
                        {
                            strDefaultCon = "D";
                        }
                        else
                        {
                            strDefaultCon = "";
                        }
                        DoSql mysql = new DoSql();
                        mysql.vul_deze_string = "";
                        mysql.DoQuery("SELECT 1 " +
                                      "FROM   DashUgco " +
                                      "WHERE  UgcoUgro = '" + dgAuth[1, i].Value.ToString() + "'" +
                                      "  AND  UgcoSnam = '" + dgAuth[2, i].Value.ToString() + "'");
                        if (mysql.affected_rows == 0)
                        {
                            mysql.vul_deze_string = null;
                            mysql.DoUpdate("INSERT INTO DashUgco ( UgcoUgro, UgcoSnam, UgcoGrus, UgcoDftd, " +
                                            "                      UgcoDftC, UgcoCdat, UgcoCtyd, UgcoCUsr, " +
                                            "                      UgcoMdat, UgcoMtyd, UgcoMUsr )" +
                                            " VALUES('" + dgAuth[1, i].Value.ToString() + "'" +
                                                  ",'" + dgAuth[2, i].Value.ToString() + "'" +
                                                  ",'" + strGrus + "'" +
                                                  ",'" + strDefaultDir + "'" +
                                                  ",'" + strDefaultCon + "'" +
                                                  ",'" + clDashFunction.get_mutdatum() + "'" +
                                                  ",'" + clDashFunction.get_muttijd() + "'" +
                                                  ",'" + strUserCode + "'" +
                                                  ",'" + clDashFunction.get_mutdatum() + "'" +
                                                  ",'" + clDashFunction.get_muttijd() + "'" +
                                                  ",'" + strUserCode + "')");
                        }
                    }
                    // Hij is uit en was aan. Wordt dus delete
                    else
                    {
                        DoSql mysql = new DoSql();
                        mysql.DoUpdate("DELETE FROM DashUgco " +
                                        "WHERE UgcoUgro = '" + dgAuth[1, i].Value.ToString() + "' " +
                                        "AND   UgcoSnam = '" + dgAuth[2, i].Value.ToString() + "'");
                    }
                }
                // Er is niet aan de "gekoppeld" checkbox gerommeld.. Mogelijk updaten ???
                else
                {
                    if (Convert.ToBoolean(dgAuth[4, i].Value) != Convert.ToBoolean(alSaveGeg5[i]) |
                                dgAuth[3, i].Value.ToString() != alSaveGeg4[i].ToString())
                    {
                        if (Convert.ToBoolean(dgAuth[4, i].Value) == true)
                        {
                            strDefaultCon = "D";
                        }
                        else
                        {
                            strDefaultCon = "";
                        }
                        DoSql mysql = new DoSql();
                        mysql.DoUpdate("UPDATE  DashUgco " +
                                       " SET    UgcoDftC = '" + strDefaultCon + "' "+
                                       "       ,UgcoDftD = '" + dgAuth[3, i].Value.ToString() + "' " +
                                       "       ,UgcoMdat = '" + clDashFunction.get_mutdatum() + "'" +
                                       "       ,UgcoMtyd = '" + clDashFunction.get_muttijd() + "'" +
                                       "       ,UgcoMusr = '" + strUserCode + "' " +
                                       " WHERE  UgcoUgro = '" + dgAuth[1, i].Value.ToString() + "' " +
                                       " AND    UgcoSnam = '" + dgAuth[2, i].Value.ToString() + "'");
                    }
                }
            }
            bChanged = false;
        }

        private void Doe_Ftpp_Update()
        {
            string strGrus;
            if (rbGebruiker.Checked)
            {
                strGrus = "U";
            }
            else
            {
                strGrus = "G";
            }
            for (int i = 0; i < dgAuth.RowCount; i++)
            {
                if (strUpdateMode == "UPD")
                {
                    // Gekoppelde checkbox is gewijzigd.....
                    if (dgAuth[1, i].Value != alSaveGeg1[i])
                    {
                    }
                }
                switch (strUpdateMode)
                {
                    case "NEW":
                    {
                        DoSql mysql = new DoSql();
                        mysql.DoUpdate(" INSERT INTO DashUgFP " +
                                     " ( UgFpUgro, UgFPFtpK, UgFPGrus, UgFPFtpV, "+
                                     "   UgFPCdat, UgFPCtyd, UgFPCusr, "+
                                     "   UgFPMdat, UgFPMtyd, UgFPMusr )" +
                                     " VALUES('" + dgAuth[0, i].Value.ToString() + "'" +
                                                ",'FP'" +
                                                ",'" + strGrus + "'" +
                                                ",'" + dgAuth[1, i].Value.ToString() + "'" + 
                                                ",'" + clDashFunction.get_mutdatum() + "'" +
                                                ",'" + clDashFunction.get_muttijd() + "'" +
                                                ",'" + strUserCode + "'" +
                                                ",'" + clDashFunction.get_mutdatum() + "'" +
                                                ",'" + clDashFunction.get_muttijd() + "'" +
                                                ",'" + strUserCode + "')");
                    }
                    break;
                 
                    case "UPD":
                    {
                        DoSql mysql = new DoSql();
                        mysql.DoUpdate(" UPDATE DashUgFp " +
                                        " SET   UgFpFtpV = '" + dgAuth[1, i].Value.ToString() + "' " +
                                         "     ,UgFpMdat = '" + clDashFunction.get_mutdatum() + "'" +
                                       "       ,UgFpMtyd = '" + clDashFunction.get_muttijd() + "'" +
                                       "       ,UgFpMusr = '" + strUserCode + "' " +
                                       " WHERE  UgFpUgro = '" + dgAuth[0, i].Value.ToString() + "' ");
                    }
                    break;
                    default:
                    {
                        clDashFunction.Melding("Onbekende parameter (" + strUpdateMode + ") bij aanroep Doe_FtppUpdate", 1, "E");
                    }
                    break;
                 }
            }
            bChanged = false;
        }

        private void lbGebrGroep_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lbGebrGroep.SelectedIndex != -1)
            {
                setAuth_Buttons(true);
            }
        }

        private void setAuth_Buttons(Boolean bOnOff)
        {
           cmdPref.Enabled      = bOnOff;                      
        }

        private void cmdReset_Click(object sender, EventArgs e)
        {
            setAuth_Buttons(false);
            rbGebruiker.Enabled = true;
            rbGroep.Enabled     = true;
            lbGebrGroep.Enabled = true;
            grpAutab.Visible    = false;
        }       

        private void set_screen(string strMode)
        {
            switch (strMode)
            {
                case "DEFAULT":
                    setAuth_Buttons(false);
                    rbGebruiker.Enabled = true;
                    rbGroep.Enabled     = true;
                    lbGebrGroep.Enabled = true;
                    grpAutab.Visible    = false;
                    grpAuthType.Enabled = true;
                    this.Width  = intDefaultWidth;
                    this.Height = intDefaultHeigth;
                    cmdAfsluiten.Visible = true;
                    break;
                case "EXPAND":
                    this.Width  = intExpandWidth;
                    this.Height = intExpandHeigth;
                    grpAuthType.Enabled = false;
                    cmdAfsluiten.Visible  = false;
                    break;
                default:
                    clDashFunction.Melding("Onbekende parameter in functie set_screen", 1, "E");
                    break;
            }
        }

        private void cmdLocal_Click(object sender, EventArgs e)
        {
            clDashFunction.Melding("Keuze nog niet geimplementeerd", 1, "I");
        }

        private void cmdServServ_Click(object sender, EventArgs e)
        {
            clDashFunction.Melding("Keuze nog niet geimplementeerd", 1, "I");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Refresh();
        }

        private void dgAuth_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            return;
        }          
    }
}
