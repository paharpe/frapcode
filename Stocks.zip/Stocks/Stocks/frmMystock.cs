﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Stocks
{
    public partial class frmMystock : Form
    {
        public frmMystock()
        {
            InitializeComponent();
        }

        private void grbStock_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DoSql mysql = new DoSql();
            mysql.vul_dit_datagrid = dgStock;
            mysql.DoQuery("SELECT KoursFonds as Fonds, '0' as Aantal, Max(KoursKoers) as MaxKoers, '0' as Totaal,'KOURS' as ID "
                        + "FROM KoursKours "
                        + "WHERE (((KoursFonds) IN (select MystFonds from KoursMyst )) "
                        + "AND    ((KoursIndex) IN( select MystIndex from KoursMyst))) "
                        + "GROUP BY KoursFonds"
                        + " UNION "
                        + "SELECT MystFonds,format(MystBaant,'General Number'), MystBkoers, MystBaant*MystBkoers,'MYST' "
                        + "FROM KoursMyst "
                        + "ORDER BY Fonds, ID");
        }
    }
}
