﻿namespace dbDashboard
{
    partial class frmDashlogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDashlogin));
            this.cmdOK = new System.Windows.Forms.Button();
            this.cmdCancel = new System.Windows.Forms.Button();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtUser = new System.Windows.Forms.TextBox();
            this.lblpassword = new System.Windows.Forms.Label();
            this.lbluser = new System.Windows.Forms.Label();
            this.lblsvp = new System.Windows.Forms.Label();
            this.lbldbDashboard = new System.Windows.Forms.Label();
            this.cmdDatabase = new System.Windows.Forms.Button();
            this.grbConnectie.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmdOK
            // 
            this.cmdOK.BackColor = System.Drawing.SystemColors.Control;
            this.cmdOK.Location = new System.Drawing.Point(323, 92);
            this.cmdOK.Name = "cmdOK";
            this.cmdOK.Size = new System.Drawing.Size(75, 23);
            this.cmdOK.TabIndex = 3;
            this.cmdOK.Text = "Aanmelden";
            this.cmdOK.UseVisualStyleBackColor = true;
            this.cmdOK.Click += new System.EventHandler(this.cmdOK_Click);
            // 
            // cmdCancel
            // 
            this.cmdCancel.BackColor = System.Drawing.SystemColors.Control;
            this.cmdCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cmdCancel.Location = new System.Drawing.Point(401, 92);
            this.cmdCancel.Name = "cmdCancel";
            this.cmdCancel.Size = new System.Drawing.Size(75, 23);
            this.cmdCancel.TabIndex = 4;
            this.cmdCancel.Text = "Afsluiten";
            this.cmdCancel.UseVisualStyleBackColor = true;
            this.cmdCancel.Click += new System.EventHandler(this.cmdCancel_Click);
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(250, 64);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(226, 20);
            this.txtPassword.TabIndex = 2;
            this.txtPassword.Text = "Lpuus01$";
            this.txtPassword.TextChanged += new System.EventHandler(this.txtPassword_TextChanged);
            // 
            // txtUser
            // 
            this.txtUser.Location = new System.Drawing.Point(250, 40);
            this.txtUser.MaxLength = 10;
            this.txtUser.Name = "txtUser";
            this.txtUser.Size = new System.Drawing.Size(226, 20);
            this.txtUser.TabIndex = 1;
            this.txtUser.Text = "pe029017";
            this.txtUser.TextChanged += new System.EventHandler(this.txtUser_TextChanged);
            // 
            // lblpassword
            // 
            this.lblpassword.AutoSize = true;
            this.lblpassword.BackColor = System.Drawing.Color.Transparent;
            this.lblpassword.Location = new System.Drawing.Point(178, 68);
            this.lblpassword.Name = "lblpassword";
            this.lblpassword.Size = new System.Drawing.Size(71, 13);
            this.lblpassword.TabIndex = 13;
            this.lblpassword.Text = "Wachtwoord:";
            // 
            // lbluser
            // 
            this.lbluser.AutoSize = true;
            this.lbluser.BackColor = System.Drawing.Color.Transparent;
            this.lbluser.Location = new System.Drawing.Point(178, 44);
            this.lbluser.Name = "lbluser";
            this.lbluser.Size = new System.Drawing.Size(38, 13);
            this.lbluser.TabIndex = 11;
            this.lbluser.Text = "Naam:";
            // 
            // lblsvp
            // 
            this.lblsvp.AutoSize = true;
            this.lblsvp.BackColor = System.Drawing.Color.Transparent;
            this.lblsvp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsvp.Location = new System.Drawing.Point(13, 15);
            this.lblsvp.Name = "lblsvp";
            this.lblsvp.Size = new System.Drawing.Size(276, 15);
            this.lblsvp.TabIndex = 14;
            this.lblsvp.Text = "Vul gebruikersnaam en wachtwoord in svp";
            // 
            // lbldbDashboard
            // 
            this.lbldbDashboard.AutoSize = true;
            this.lbldbDashboard.BackColor = System.Drawing.Color.Transparent;
            this.lbldbDashboard.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldbDashboard.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbldbDashboard.Location = new System.Drawing.Point(7, 92);
            this.lbldbDashboard.Name = "lbldbDashboard";
            this.lbldbDashboard.Size = new System.Drawing.Size(161, 20);
            this.lbldbDashboard.TabIndex = 15;
            this.lbldbDashboard.Text = "DB Dashboard versie 1.0";
            // 
            // cmdDatabase
            // 
            this.cmdDatabase.FlatAppearance.BorderSize = 0;
            this.cmdDatabase.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdDatabase.Image = ((System.Drawing.Image)(resources.GetObject("cmdDatabase.Image")));
            this.cmdDatabase.Location = new System.Drawing.Point(13, 36);
            this.cmdDatabase.Name = "cmdDatabase";
            this.cmdDatabase.Size = new System.Drawing.Size(148, 48);
            this.cmdDatabase.TabIndex = 5;
            this.cmdDatabase.UseVisualStyleBackColor = true;
            this.cmdDatabase.Click += new System.EventHandler(this.cmdDatabase_Click);
            // 
            // frmDashlogin
            // 
            this.AcceptButton = this.cmdOK;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.CancelButton = this.cmdCancel;
            this.ClientSize = new System.Drawing.Size(487, 126);
            this.Controls.Add(this.cmdDatabase);
            this.Controls.Add(this.lbldbDashboard);
            this.Controls.Add(this.lblsvp);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.txtUser);
            this.Controls.Add(this.lblpassword);
            this.Controls.Add(this.lbluser);
            this.Controls.Add(this.cmdCancel);
            this.Controls.Add(this.cmdOK);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimizeBox = false;
            this.Name = "frmDashlogin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "DB Dashboard; aanmelden";
            this.Load += new System.EventHandler(this.frmDashlogin_Load);
            this.Controls.SetChildIndex(this.cmdOK, 0);
            this.Controls.SetChildIndex(this.cmdCancel, 0);
            this.Controls.SetChildIndex(this.lbluser, 0);
            this.Controls.SetChildIndex(this.lblpassword, 0);
            this.Controls.SetChildIndex(this.txtUser, 0);
            this.Controls.SetChildIndex(this.txtPassword, 0);
            this.Controls.SetChildIndex(this.lblsvp, 0);
            this.Controls.SetChildIndex(this.lbldbDashboard, 0);
            this.Controls.SetChildIndex(this.cmdDatabase, 0);
            this.Controls.SetChildIndex(this.cmdAfsluiten, 0);
            this.Controls.SetChildIndex(this.grbConnectie, 0);
            this.Controls.SetChildIndex(this.lblVoortgang, 0);
            this.grbConnectie.ResumeLayout(false);
            this.grbConnectie.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button cmdOK;
        private System.Windows.Forms.Button cmdCancel;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.TextBox txtUser;
        private System.Windows.Forms.Label lblpassword;
        private System.Windows.Forms.Label lbluser;
        private System.Windows.Forms.Label lblsvp;
        private System.Windows.Forms.Label lbldbDashboard;
        private System.Windows.Forms.Button cmdDatabase;
    }
}