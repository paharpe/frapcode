﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace dbDashboard
{
    public partial class txtMaint : TextBox
    {
        private Boolean _bChanged = false;
        private string _strOldValue = "";
        
        public txtMaint()
        {
            TextBox txtMaint = new TextBox();            
        }

        public Boolean bChanged
        {
            get { return this._bChanged; }
            set { this._bChanged = value; }
        }

        public string strOldValue
        {
            get { return this._strOldValue; }
            set { this._strOldValue = value; }
        }

        protected override void OnTextChanged(EventArgs e)
        {
            this.bChanged = false;
            if (this.Text != this.strOldValue)
            {
                this.bChanged = true;             
            }            
            base.OnTextChanged(e);           
        }         
    }
}
