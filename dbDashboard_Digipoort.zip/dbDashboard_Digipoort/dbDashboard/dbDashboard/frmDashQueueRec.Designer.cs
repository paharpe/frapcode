﻿namespace dbDashboard
{
    partial class frmDashQueueRec
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDashQueueRec));
            this.grpRecord = new System.Windows.Forms.GroupBox();
            this.cmdStartLog = new System.Windows.Forms.Button();
            this.pbQueueRec = new System.Windows.Forms.PictureBox();
            this.grbRecordOptions = new System.Windows.Forms.GroupBox();
            this.cmdStopLog = new System.Windows.Forms.Button();
            this.txtRecord2File = new System.Windows.Forms.TextBox();
            this.lblRecord2File = new System.Windows.Forms.Label();
            this.cbRecordErrors = new System.Windows.Forms.CheckBox();
            this.cbX400Q = new System.Windows.Forms.CheckBox();
            this.cbRecordQueueOnly = new System.Windows.Forms.CheckBox();
            this.cbCoreQ = new System.Windows.Forms.CheckBox();
            this.cbSMTPQ = new System.Windows.Forms.CheckBox();
            this.cmdOK = new System.Windows.Forms.Button();
            this.grbConnect.SuspendLayout();
            this.grpRecord.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbQueueRec)).BeginInit();
            this.grbRecordOptions.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmdAfsluiten
            // 
            this.cmdAfsluiten.Location = new System.Drawing.Point(86, 393);
            this.cmdAfsluiten.TabIndex = 3;
            this.cmdAfsluiten.Click += new System.EventHandler(this.cmdAfsluiten_Click_1);
            // 
            // grbConnect
            // 
            this.grbConnect.Location = new System.Drawing.Point(304, 492);
            // 
            // lblHostName
            // 
            this.lblHostName.Location = new System.Drawing.Point(508, 407);
            this.lblHostName.Size = new System.Drawing.Size(145, 13);
            this.lblHostName.Text = "KPNNL\\WLD4BED923B63C";
            // 
            // grpRecord
            // 
            this.grpRecord.Controls.Add(this.cmdStartLog);
            this.grpRecord.Controls.Add(this.pbQueueRec);
            this.grpRecord.Controls.Add(this.grbRecordOptions);
            this.grpRecord.Location = new System.Drawing.Point(6, 26);
            this.grpRecord.Name = "grpRecord";
            this.grpRecord.Size = new System.Drawing.Size(635, 354);
            this.grpRecord.TabIndex = 1;
            this.grpRecord.TabStop = false;
            this.grpRecord.Text = "Save queue info";
            // 
            // cmdStartLog
            // 
            this.cmdStartLog.Location = new System.Drawing.Point(536, 37);
            this.cmdStartLog.Name = "cmdStartLog";
            this.cmdStartLog.Size = new System.Drawing.Size(75, 70);
            this.cmdStartLog.TabIndex = 0;
            this.cmdStartLog.Text = "Start saving";
            this.cmdStartLog.UseVisualStyleBackColor = true;
            this.cmdStartLog.Click += new System.EventHandler(this.cmdStartLog_Click);
            // 
            // pbQueueRec
            // 
            this.pbQueueRec.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pbQueueRec.ErrorImage")));
            this.pbQueueRec.Image = ((System.Drawing.Image)(resources.GetObject("pbQueueRec.Image")));
            this.pbQueueRec.Location = new System.Drawing.Point(15, 20);
            this.pbQueueRec.Name = "pbQueueRec";
            this.pbQueueRec.Size = new System.Drawing.Size(101, 90);
            this.pbQueueRec.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbQueueRec.TabIndex = 3;
            this.pbQueueRec.TabStop = false;
            // 
            // grbRecordOptions
            // 
            this.grbRecordOptions.Controls.Add(this.cmdStopLog);
            this.grbRecordOptions.Controls.Add(this.txtRecord2File);
            this.grbRecordOptions.Controls.Add(this.lblRecord2File);
            this.grbRecordOptions.Controls.Add(this.cbRecordErrors);
            this.grbRecordOptions.Controls.Add(this.cbX400Q);
            this.grbRecordOptions.Controls.Add(this.cbRecordQueueOnly);
            this.grbRecordOptions.Controls.Add(this.cbCoreQ);
            this.grbRecordOptions.Controls.Add(this.cbSMTPQ);
            this.grbRecordOptions.Location = new System.Drawing.Point(12, 115);
            this.grbRecordOptions.Name = "grbRecordOptions";
            this.grbRecordOptions.Size = new System.Drawing.Size(604, 206);
            this.grbRecordOptions.TabIndex = 1;
            this.grbRecordOptions.TabStop = false;
            this.grbRecordOptions.Text = "Options";
            // 
            // cmdStopLog
            // 
            this.cmdStopLog.Location = new System.Drawing.Point(522, 127);
            this.cmdStopLog.Name = "cmdStopLog";
            this.cmdStopLog.Size = new System.Drawing.Size(75, 67);
            this.cmdStopLog.TabIndex = 9;
            this.cmdStopLog.Text = "Stop saving";
            this.cmdStopLog.UseVisualStyleBackColor = true;
            this.cmdStopLog.Click += new System.EventHandler(this.cmdStopLog_Click);
            // 
            // txtRecord2File
            // 
            this.txtRecord2File.BackColor = System.Drawing.SystemColors.MenuBar;
            this.txtRecord2File.Enabled = false;
            this.txtRecord2File.Location = new System.Drawing.Point(10, 172);
            this.txtRecord2File.Name = "txtRecord2File";
            this.txtRecord2File.Size = new System.Drawing.Size(490, 20);
            this.txtRecord2File.TabIndex = 8;
            // 
            // lblRecord2File
            // 
            this.lblRecord2File.AutoSize = true;
            this.lblRecord2File.Location = new System.Drawing.Point(7, 156);
            this.lblRecord2File.Name = "lblRecord2File";
            this.lblRecord2File.Size = new System.Drawing.Size(47, 13);
            this.lblRecord2File.TabIndex = 7;
            this.lblRecord2File.Text = "Save to:";
            // 
            // cbRecordErrors
            // 
            this.cbRecordErrors.AutoSize = true;
            this.cbRecordErrors.Location = new System.Drawing.Point(12, 132);
            this.cbRecordErrors.Name = "cbRecordErrors";
            this.cbRecordErrors.Size = new System.Drawing.Size(297, 17);
            this.cbRecordErrors.TabIndex = 6;
            this.cbRecordErrors.Text = "Error lines ( in cases queue size could not be determined )";
            this.cbRecordErrors.UseVisualStyleBackColor = true;
            this.cbRecordErrors.CheckedChanged += new System.EventHandler(this.cbRecordErrors_CheckedChanged);
            // 
            // cbX400Q
            // 
            this.cbX400Q.AutoSize = true;
            this.cbX400Q.Location = new System.Drawing.Point(12, 70);
            this.cbX400Q.Name = "cbX400Q";
            this.cbX400Q.Size = new System.Drawing.Size(188, 17);
            this.cbX400Q.TabIndex = 3;
            this.cbX400Q.Text = "X400 waiting Bedrijven / Overheid";
            this.cbX400Q.UseVisualStyleBackColor = true;
            this.cbX400Q.CheckedChanged += new System.EventHandler(this.cbX400Q_CheckedChanged);
            // 
            // cbRecordQueueOnly
            // 
            this.cbRecordQueueOnly.AutoSize = true;
            this.cbRecordQueueOnly.Location = new System.Drawing.Point(12, 109);
            this.cbRecordQueueOnly.Name = "cbRecordQueueOnly";
            this.cbRecordQueueOnly.Size = new System.Drawing.Size(265, 17);
            this.cbRecordQueueOnly.TabIndex = 4;
            this.cbRecordQueueOnly.Text = "Only save queue records containing queuesize > 0";
            this.cbRecordQueueOnly.UseVisualStyleBackColor = true;
            this.cbRecordQueueOnly.CheckedChanged += new System.EventHandler(this.cbRecordQueueOnly_CheckedChanged);
            // 
            // cbCoreQ
            // 
            this.cbCoreQ.AutoSize = true;
            this.cbCoreQ.Location = new System.Drawing.Point(12, 47);
            this.cbCoreQ.Name = "cbCoreQ";
            this.cbCoreQ.Size = new System.Drawing.Size(131, 17);
            this.cbCoreQ.TabIndex = 2;
            this.cbCoreQ.Text = "Incomming Core traffic";
            this.cbCoreQ.UseVisualStyleBackColor = true;
            this.cbCoreQ.CheckedChanged += new System.EventHandler(this.cbCoreQ_CheckedChanged);
            // 
            // cbSMTPQ
            // 
            this.cbSMTPQ.AutoSize = true;
            this.cbSMTPQ.Location = new System.Drawing.Point(12, 24);
            this.cbSMTPQ.Name = "cbSMTPQ";
            this.cbSMTPQ.Size = new System.Drawing.Size(202, 17);
            this.cbSMTPQ.TabIndex = 1;
            this.cbSMTPQ.Text = "SMTP queue to Bedrijven / Overheid";
            this.cbSMTPQ.UseVisualStyleBackColor = true;
            this.cbSMTPQ.CheckedChanged += new System.EventHandler(this.cbSMTPQ_CheckedChanged);
            // 
            // cmdOK
            // 
            this.cmdOK.Location = new System.Drawing.Point(5, 393);
            this.cmdOK.Name = "cmdOK";
            this.cmdOK.Size = new System.Drawing.Size(75, 23);
            this.cmdOK.TabIndex = 2;
            this.cmdOK.Text = "OK";
            this.cmdOK.UseVisualStyleBackColor = true;
            this.cmdOK.Click += new System.EventHandler(this.cmdOK_Click);
            // 
            // frmDashQueueRec
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(653, 420);
            this.Controls.Add(this.grpRecord);
            this.Controls.Add(this.cmdOK);
            this.Name = "frmDashQueueRec";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "frmDashQueueRec; Save queue info to external file";
            this.Load += new System.EventHandler(this.frmDashQueueRec_Load);
            this.Controls.SetChildIndex(this.cmdAfsluiten, 0);
            this.Controls.SetChildIndex(this.cmdOK, 0);
            this.Controls.SetChildIndex(this.lblHostName, 0);
            this.Controls.SetChildIndex(this.grpRecord, 0);
            this.Controls.SetChildIndex(this.grbConnect, 0);
            this.grbConnect.ResumeLayout(false);
            this.grbConnect.PerformLayout();
            this.grpRecord.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbQueueRec)).EndInit();
            this.grbRecordOptions.ResumeLayout(false);
            this.grbRecordOptions.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpRecord;
        private System.Windows.Forms.GroupBox grbRecordOptions;
        private System.Windows.Forms.Button cmdOK;
        private System.Windows.Forms.PictureBox pbQueueRec;
        private System.Windows.Forms.CheckBox cbSMTPQ;
        private System.Windows.Forms.CheckBox cbCoreQ;
        private System.Windows.Forms.CheckBox cbX400Q;
        private System.Windows.Forms.Button cmdStopLog;
        private System.Windows.Forms.Button cmdStartLog;
        private System.Windows.Forms.CheckBox cbRecordErrors;
        private System.Windows.Forms.CheckBox cbRecordQueueOnly;
        private System.Windows.Forms.TextBox txtRecord2File;
        private System.Windows.Forms.Label lblRecord2File;
    }
}