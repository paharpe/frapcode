﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Text;

namespace dbDashboard
{
    public partial class dgX400 : DataGridView
    {
        public dgX400()
        {
            InitializeComponent();
          //  init();
        }

        private void init()
        {
            DataGridViewColumn colServer = new DataGridViewColumn();
            // DataGridTextBoxColumn colServer = new DataGridTextBoxColumn();
            colServer.HeaderText = "Server";
            colServer.Width = 80;

            this.RowHeadersVisible = false;
            this.Columns.Add(colServer);
        }
       
       
    }
}
