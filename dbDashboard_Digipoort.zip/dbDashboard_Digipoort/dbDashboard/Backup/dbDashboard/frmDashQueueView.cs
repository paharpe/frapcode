﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.IO;
using System.Windows.Forms.DataVisualization.Charting;

namespace dbDashboard
{
    public partial class frmDashQueueView : frmDashBase
    {
        private string strQueueData_Path;
        private ArrayList alQueueColsIn = new ArrayList();
        private ArrayList alQueueColsIn2 = new ArrayList();
        private ArrayList alQueuColsOut = new ArrayList();

        const string strViewAlles = "Alles";
        const string strViewQueueDataOnly = "Queue data only";
        const string strViewErrors = "Errors";
       
        public frmDashQueueView()
        {
            InitializeComponent();
        }

        private void cmdOpenLogFile_Click(object sender, EventArgs e)
        {
            ofdOpenLogFile.InitialDirectory = strQueueData_Path;
            if (ofdOpenLogFile.ShowDialog() == DialogResult.OK)
            {           
                dgQueue.Rows.Clear();

                foreach (string strQueueLogFile in ofdOpenLogFile.FileNames)
                {
                    StreamReader srQueue=clDashFunction.open4read(strQueueLogFile);
                    if (srQueue != null)
                    {
                        while (!srQueue.EndOfStream)
                        {
                            string strQueue = srQueue.ReadLine();
                            int intRowno = dgQueue.Rows.Add();
                            // dgQueue[0, intNewRow].Value = strQueue;
                            String[] strarQueue = Regex.Split(strQueue, "~");
                            int intColno = 0;
                            foreach (string strQueueCell in strarQueue)
                            {
                                int ikol;
                                if (strarQueue.Length > 2)
                                {
                                    if (strarQueue[2] == "SMTP_OUT_BDR" || strarQueue[2] == "SMTP_OUT_OVH")
                                    {
                                        ikol = Convert.ToInt32(alQueueColsIn[intColno]);
                                    }
                                    else
                                    {
                                        ikol = Convert.ToInt32(alQueueColsIn2[intColno]);
                                    }
                                    switch (ikol)
                                    {
                                        case 4:
                                            //Aantal
                                            dgQueue[ikol, intRowno].Value = Convert.ToInt32(strQueueCell);
                                            break;
                                        case 5:
                                            //Oldest
                                            dgQueue[ikol, intRowno].Value = clDashFunction.fromS2DHMS(Convert.ToDouble(strQueueCell), false);
                                            break;
                                        case 6:
                                            //Newest
                                            dgQueue[ikol, intRowno].Value = clDashFunction.fromS2DHMS(Convert.ToDouble(strQueueCell), false);
                                            break;
                                        default:
                                            dgQueue[ikol, intRowno].Value = strQueueCell;
                                            break;
                                    }
                                    
                                }
                                intColno++;                               
                            }
                        }
                    }
                }
                cmbView.SelectedIndex = 0;
                grpFilter.Enabled = true;
            }
            else
            {
                MessageBox.Show("Cancel");
            }
        }

        private void frmDashQueueView_Load(object sender, EventArgs e)
        {
            init_form();
        }

        private void init_form()
        {
            alQueueColsIn.Add(0);  // 1=0 RESPONSE
            alQueueColsIn.Add(2);  // 2=3 SERVER
            alQueueColsIn.Add(1);  // 3=1 SOORT
            alQueueColsIn.Add(7);  // 4=7 CHECKTIME
            alQueueColsIn.Add(3);  // 5=3 DOMAIN
            alQueueColsIn.Add(4);  // 6=4 QUEUESIZE
            alQueueColsIn.Add(5);  // 7=8 QUEUEAGE OLD DATE
            alQueueColsIn.Add(8);  // 8=5 QUEUEAGE OLD SECS
            alQueueColsIn.Add(9);  // 9=9 QUEUEAGE NEW DATE
            alQueueColsIn.Add(6);  // 9=9 QUEUEAGE NEW SECS

            alQueueColsIn2.Add(0);  // 1=0 RESPONSE
            alQueueColsIn2.Add(2);  // 2=3 SERVER
            alQueueColsIn2.Add(1);  // 3=1 SOORT
            alQueueColsIn2.Add(7);  // 4=7 CHECKTIME
            alQueueColsIn2.Add(4);  // 5=3 QUEUESIZE
            alQueueColsIn2.Add(8);  // 6=4 QUEUEAGE OLD DATE / of 0 Messages
            alQueueColsIn2.Add(5);  // 7=8 QUEUEAGE OLD SECS / of ""
            alQueueColsIn2.Add(9);  // 8=5 QUEUEAGE NEW DATE / of "" 
            alQueueColsIn2.Add(6);  // 9=9 QUEUEAGE NEW SECS / of ""
            alQueueColsIn2.Add(3);  // NOP
            

            cmbView.Items.Add(strViewAlles);
            cmbView.Items.Add(strViewQueueDataOnly);
            cmbView.Items.Add(strViewErrors);


            grpFilter.Enabled = false;

            // private ArrayList alQueuColsOut;
            // directory en filenamen om nieuwe data vandaag te halen.
            strQueueData_Path = clDashFunction.get_TagValue("[QDATAPATH]", true);
                        

            // Alles aanwezig ?
            if ( strQueueData_Path != "")
            {
                // MessageBox.Show(strQueueData_Path);
                // refresh_queuedata();
            }
            else
            {               
                clDashFunction.Melding("Unable to obtain queuedata due to INI file issues");
            }
        }

       
        private void cmbView_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch ( cmbView.Text )
            {
                case strViewAlles:
                    doView(strViewAlles);
                    break;
                case strViewQueueDataOnly:
                    doView(strViewQueueDataOnly);
                    break;
                case strViewErrors:
                    doView(strViewErrors);
                    break;
                default:
                    clDashFunction.Melding("Unknown Combobox value: "+ cmbView.Text,1,"I"); 
                    break;
            }           
        }

        private void doView(string strView)
        {
            // Hier gaan we opnieuw alle aanwezige rows langs en deze
            // op basis van de gemaakte combobox keuze SHOW'en of HIDE'n
            int intRow = 0;
            int intShown = 0;
            int intHidden = 0;

            // =====================================
            // Loop thru DataGrid
            // =====================================
            while (intRow < dgQueue.Rows.Count )
            {
                dgQueue.Rows[intRow].Visible = false;
                // ===========================
                // Alles
                // ===========================
                if (strView == strViewAlles)
                { 
                    if ( Convert.ToInt32(dgQueue[4, intRow].Value) < 0 || Convert.ToInt32(dgQueue[4, intRow].Value) >= Convert.ToInt16(cbZeroes.Checked))
                    {
                    dgQueue.Rows[intRow].Visible = true;
                    intShown++;
                    }
                }
                else
                {
                    // ==================================
                    // Niet Alles.. maar....
                    // ==================================
                    // regel met NULL in het aantal zijn leeg en die willen we nu niet
                    if (dgQueue[4, intRow].Value != null)
                    {
                        // ===========================
                        // Doe dan de ERROR lines maar 
                        // ===========================
                        if (strView == strViewErrors && Convert.ToInt32(dgQueue[4, intRow].Value) < 0)
                        {
                            dgQueue.Rows[intRow].Visible = true;
                            intShown++;
                        }
                        else
                        {
                            // ===================================================================
                            // Doe dan maar alles, behalve de errors en die met NULL in het aantal
                            // ===================================================================
                            if (strView != strViewErrors && Convert.ToInt32(dgQueue[4, intRow].Value) >= Convert.ToInt16(cbZeroes.Checked))
                            {
                                dgQueue.Rows[intRow].Visible = true;
                                intShown++;
                            }
                        }
                    }
                }
                intRow++;
            }
            intHidden = dgQueue.Rows.Count - intShown;
            lblQueueRecCount.Text = "Shown: " + intShown + " Hidden: " + intHidden;
        }

        private void cbZeroes_CheckedChanged(object sender, EventArgs e)
        {
            cmbView_SelectedIndexChanged(new object(), new EventArgs());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Chart xd = new Chart();

            xd.BackColor = Color.Yellow;
            xd.Show();
        }  
    }
}
