﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace dbDashboard
{
    public partial class frmDashQueueRec : frmDashBase
    {
        public Boolean bActive;
        public string strQueueData_Path;
        public string strRecordFile_val;
        public Boolean bRecordQueueOnly;
        public Boolean bRecordErrors;
        public Boolean bLog_X400Q;
        public Boolean bLog_SMTPQ;
        public Boolean bLog_CoreQ; 
        public Boolean bCancelled;

        public frmDashQueueRec()
        {
            InitializeComponent();
        }
       
        private void frmDashQueueRec_Load(object sender, EventArgs e)
        {
            frm_init();
        }


        private void frm_init()
        {
            cbRecordQueueOnly.Checked = bRecordQueueOnly;
            cbRecordErrors.Checked = bRecordErrors;
            cbX400Q.Checked = bLog_X400Q;
            cbSMTPQ.Checked = bLog_SMTPQ;
            cbCoreQ.Checked = bLog_CoreQ;

            if (!cbRecordQueueOnly.Checked &&
                  !cbRecordErrors.Checked &&
                  !cbX400Q.Checked &&
                  !cbSMTPQ.Checked &&
                  !cbCoreQ.Checked)
            {                
                DoControls(false);
            }
            else
            {
                // Save al geactiveerd
                cmdStartLog.Enabled = false;
                txtRecord2File.Text = strRecordFile_val;
            }
        }
        
        private void cmdAfsluiten_Click_1(object sender, EventArgs e)
        {       
            if (base.DialogResult == DialogResult.Cancel)
            {
                bCancelled = true;               
            }
        }

        private void cmdOK_Click(object sender, EventArgs e)
        {
            strRecordFile_val = txtRecord2File.Text;
            bCancelled = false;
            this.Close();
        }

        private void cbRecordQueueOnly_CheckedChanged(object sender, EventArgs e)
        {
            bRecordQueueOnly = cbRecordQueueOnly.Checked;
        }
        
        private void cbRecordErrors_CheckedChanged(object sender, EventArgs e)
        {
            bRecordErrors = cbRecordErrors.Checked;
        }   

        private void cbCoreQ_CheckedChanged(object sender, EventArgs e)
        {
            bLog_CoreQ = cbCoreQ.Checked;
            cbValidate();
        }
          

        private void cbSMTPQ_CheckedChanged(object sender, EventArgs e)
        {
            bLog_SMTPQ = cbSMTPQ.Checked;
            cbValidate();
        }
            

        private void cbX400Q_CheckedChanged(object sender, EventArgs e)
        {
            bLog_X400Q = cbX400Q.Checked;
            cbValidate();
        }
        
        private void cbValidate()
        {
            Boolean bOK = true;

            if ((bLog_CoreQ || bLog_X400Q || bLog_SMTPQ)  
                && txtRecord2File.Text != null
                && txtRecord2File.Text != "")
            {
                bOK = true;
            }
            cmdOK.Enabled =  bOK;
        }

        private string generate_logfile_name()
        {
            // (1) Filenaam componeren op basis van timestamp
            if (Directory.Exists(strQueueData_Path))
            {
                // (1) Filenaam componeren op basis van timestamp
                return strQueueData_Path +
                       "dpQ"+
                       System.DateTime.Now.Year.ToString() +
                       System.DateTime.Now.Month.ToString().PadLeft(2, '0') +
                       System.DateTime.Now.Day.ToString().PadLeft(2, '0') +
                       "_" +
                       System.DateTime.Now.Hour.ToString().PadLeft(2, '0') +
                       System.DateTime.Now.Minute.ToString().PadLeft(2, '0') +
                       System.DateTime.Now.Second.ToString().PadLeft(2, '0') +
                       ".csv";               
            }
            else
            {
                return null;
            }       
        }

        private void cmdGenerate_logfile_name_Click(object sender, EventArgs e)
        {
            txtRecord2File.Text = generate_logfile_name();           
        }

        private void txtRecord2File_TextChanged(object sender, EventArgs e)
        {
            cbValidate();
        }

        private void cmdViewLog_Click(object sender, EventArgs e)
        {
            clDashFunction.Notepad(txtRecord2File.Text);
        }

        private void cmdStartLog_Click(object sender, EventArgs e)
        {
            bActive = true;
            
            DoControls(bActive);
            
            txtRecord2File.Text = generate_logfile_name();
            
            bChanged = true;
        }

        private void cmdStopLog_Click(object sender, EventArgs e)
        {
            if (File.Exists(txtRecord2File.Text))
            {
                if (clDashFunction.Melding("Er is reeds logdata geschreven.\nWeet u zeker dat u wilt stoppen met het opslaan van logdata ? ", 4, "Q") != DialogResult.Yes)
                {
                    return;
                }               
            }

            bActive = false;

            DoControls(bActive);
            
            txtRecord2File.Text = "";
            
            bChanged = true;
        }
              

        private void DoControls(Boolean bLogActive)
        {
            cbSMTPQ.Enabled = cbSMTPQ.Checked = bLogActive;
            cbX400Q.Enabled = cbX400Q.Checked = bLogActive;
            cbCoreQ.Enabled = cbCoreQ.Checked = bLogActive;
            cbRecordQueueOnly.Enabled = cbRecordQueueOnly.Checked = bLogActive;
            cbRecordErrors.Enabled = cbRecordErrors.Checked = bLogActive;
            cmdStopLog.Enabled = bLogActive;
            cmdStartLog.Enabled = !bLogActive;
        }            
    }
}
