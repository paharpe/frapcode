﻿using System;
using System.Text;
using System.Windows.Forms;
using System.Drawing;

namespace DBDashboard
{
    public partial class cbMaint : CheckBox
    {
        private Boolean _bChanged = false;
        private Boolean _bOldValue = false;
        private Int16 _bBitValue = 0;

        public cbMaint()
        {
            CheckBox cbMaint = new CheckBox();
            this.Width = 200;
            this.Height = 40;
            this.Checked = false;
        }

        public Boolean bChanged
        {
            get { return this._bChanged; }
            set { this._bChanged = value; }
        }
        public Boolean OldValue
        {
            get { return this._bOldValue; }
            set { this._bOldValue = value; }
        }

        public Int16 BitValue
        {
            get { return this._bBitValue; }
            set { this._bBitValue = value; }
        }
        protected override void  OnCheckedChanged(EventArgs e)
        {
            this.bChanged = false;
            if (this.Checked != this.OldValue)
            {
                this.bChanged = true;               
            }
            if (this.Checked)
            {
                this.BitValue = 1;
            }
            else
            {
                this.BitValue = 0;
            }
            base.OnCheckedChanged(e);           
        }
    }
}