﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.IO;
using System.Threading;
using System.Diagnostics.CodeAnalysis;
// using System.Windows.Forms.DataVisualization.Charting;

// using System.Windows.Forms.
// 2015-03-17 using Excel = Microsoft.Office.Interop.Excel.Chart;

namespace dbDashboard
{
    public partial class frmDashQueue : frmDashBase
    {
        const string strNoMessages = "No messages";

        // Identifiers in de diverse inputbestanden
        // SMTP
        const string strSMTP2Bedrijven = "SMTP_OUT_BDR";
        const string strSMTP2Overheden = "SMTP_OUT_OVH";
        // Cores
        const string strSMTP_from_bedrijven = "SMTP_IN_BDR";
        const string strX400_from_overheden = "X400_IN_OVH";
        const string strALARM_OTPtransfer = "CORE_ALARM";
        // X400
        const string strX4002Bedrijven = "X400_OUT_BDR";
        const string strX4002Overheden = "X400_OUT_OVH";
        // NAGIOS
        const string strNagios1 = "SMTP_OUT_NAGIOS1";
        const string strNagios2 = "SMTP_OUT_NAGIOS2";
        // Reponse is an important landmark in the processing;
        const string strResponse = "RESPONSE";

        private Color clQueue_yes = Color.Orange;
        private Color clQueue_no = Color.White;
        private Color clQueue_error = Color.YellowGreen;

        private string strUpdateScript;

        private string strQueueCMD_Path;
        private string strQueueCMD_SMTP;
        private string strQueueCMD_X400;
        private string strQueueCMD_Core;
        private string strQueueCMD_Nagios;

        private string strQueueData_Path;
        private string strQueueData_SMTP;
        private string strQueueData_X400;
        private string strQueueData_Core;
        private string strQueueData_Nagios;

        private Boolean b_tmrCoreq_started;
        private Boolean b_tmrX400q_started;

        private Boolean b_SMTPq_SaveStarted;
        private Boolean b_Coreq_SaveStarted;
        private Boolean b_X400q_SaveStarted;

        private string  strNagios;

        private Boolean bSaveStarted;

        private string strSaveFile_Name;
        private StreamWriter swSaveFile;
        private Boolean bRecordErrors;
        private Boolean bRecordQueueOnly;

        private ArrayList alDigipoort_Server = new ArrayList();
        private ArrayList alDigipoort_Env = new ArrayList();

        private ArrayList alSMTP_Shadow_Tab_Current = new ArrayList();
        private ArrayList alSMTP_Shadow_Tab_Previous = new ArrayList();

        private ArrayList alCore_Shadow_Tab_Current = new ArrayList(8);
        private ArrayList alCore_Shadow_Tab_Previous = new ArrayList(8);

        private ArrayList alX400_Shadow_Tab_Current = new ArrayList(6);
        private ArrayList alX400_Shadow_Tab_Previous = new ArrayList(6);

        // Deze moeten in Sync blijven en gehouden worden
        private ArrayList alEnvironment_Omschrijving = new ArrayList(3);
        private ArrayList alEnvironment_Code = new ArrayList(3);

        private Boolean bDo_cmbGroupSMTP_SelectedIndexChanged;

        int intDebugErrors = 0;

        public frmDashQueue()
        {
            InitializeComponent();
        }

        private void frmDashQueue_Load(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            init_form();
            this.Cursor = Cursors.Default;
        }

        private void init_form()
        {
            // bInitForm = true;
           

            // path en cmd namen uit INI file ophalen
            strQueueCMD_Path = clDashFunction.get_TagValue("[QCMDPATH]", true);
            strQueueCMD_Core = strQueueCMD_Path + clDashFunction.get_TagValue("[QCMDCORE]", true);
            strQueueCMD_SMTP = strQueueCMD_Path + clDashFunction.get_TagValue("[QCMDSMTP]", true);
            strQueueCMD_X400 = strQueueCMD_Path + clDashFunction.get_TagValue("[QCMDX400]", true);
            strQueueCMD_Nagios = strQueueCMD_Path + clDashFunction.get_TagValue("[QCMDNAGIOS]", true);

            // directory en filenamen om nieuwe data vandaag te halen.
            strQueueData_Path = clDashFunction.get_TagValue("[QDATAPATH]", true);
            strQueueData_Core = strQueueData_Path + clDashFunction.get_TagValue("[QDATACORE]", true);
            strQueueData_SMTP = strQueueData_Path + clDashFunction.get_TagValue("[QDATASMTP]", true);
            strQueueData_X400 = strQueueData_Path + clDashFunction.get_TagValue("[QDATAX400]", true);
            strQueueData_Nagios = strQueueData_Path + clDashFunction.get_TagValue("[QDATANAGIOS]", true);

            // Default keuze maken voor SMTP overzichten: per domein
            bDo_cmbGroupSMTP_SelectedIndexChanged = false;
            cmbGroupSMTP.SelectedIndex = 0;
            bDo_cmbGroupSMTP_SelectedIndexChanged = true;


            alEnvironment_Omschrijving.Add("Productie"); alEnvironment_Code.Add("P");
            alEnvironment_Omschrijving.Add("Preproductie"); alEnvironment_Code.Add("R");
            alEnvironment_Omschrijving.Add("Alles"); alEnvironment_Code.Add("A");
            int i = 0;
            while (i < alEnvironment_Code.Count)
            {
                cmbEnv.Items.Add(alEnvironment_Omschrijving[i]);
                i++;
            }

            // Environment instellen op basis van wat in het externe config. filetje is aangetroffen:
            // Alles ANDERS dan de waarde P zorgt voor instellen op PREPRODUCTIE
            // Aangezien 'Productie' op occurence 0 wordt verondersteld, en PreProductie op 1
            // kunnen we truuken met een geconverteerde Boolean waarde 
            cmbEnv.Tag = "NO_UPDATE_IN_INIT";
            cmbEnv.SelectedIndex = Convert.ToInt16(Convert.ToBoolean(mdiDashboard.strEnv != "P"));
            cmbEnv.Tag = "";


            // Alles aanwezig ?
            if (strQueueCMD_Core   == "" || strQueueCMD_SMTP    == "" || strQueueCMD_X400  == "" ||
                strQueueData_Core  == "" || strQueueData_SMTP   == "" || strQueueData_X400 == "" ||
                strQueueCMD_Nagios == "" || strQueueData_Nagios == "")
            {
                clDashFunction.Melding("Unable to obtain queuedata due to INI file issues");
            }

            // Default keuzes invullen voor in DialogBox QueueRec, waar wordt aangegeven of, welke en waar
            // recoding van de queuelog data plaatsvindt. 
            // Hier doen we gemakshalve NIET AAN voor NAGIOS deze variabelen ontbreken dan ook bewust. 
            b_SMTPq_SaveStarted = false; // SMTPqueues naar Bedrijven en Overheden      ( kslv037/45 en 042 en 092 )
            b_Coreq_SaveStarted = false; // Queue(s) op de Cores                        ( kslv048/kslv095/096 )
            b_X400q_SaveStarted = false; // Queue(s) naar X400 Bedrijven en Overheden   ( kslv038 / kslv58 en 043 en 093 ) 
            bRecordQueueOnly = false;
            bRecordErrors = false;

            // Array vullen met server / namen / koppelvlakken / omgevingen
            get_Digipoort_Servers();

            // Variabele strUpdateScript kan "SERVER" of "LOCAL" bevatten
            // via deze waarde wordt bepaalt of de update scripts via deze
            // code moeten worden getriggered of niet.
            // LOCAL: script uitvoeren en resultaat inlezen
            // SERVER:  alleen resultaat inlezen, script draait dan elders
            // Voor gebruik in code
            strUpdateScript = clDashFunction.get_update_script();
            // Voor tonen op scherm
            ////////////////////////////////////////////// lblUpdate_Script_val.Text = strUpdateScript;
            rbAutoUpdateOff.Checked = true;
            rbAutoUpdateOn.Checked = true;

            // Op basis van waarde stuurvariable
            // SQL tabel 10 de
            // Debug controls laten zien 
            //          OFWEL
            // een dummy stukkie tekst als we niet 
            // mogen debuggen
            cbDebug.Visible = cmdDebugLog_Toggle.Visible = cmdDebugLog_Clear.Visible = mdiDashboard.bDebug;
            lblNoDebug.Visible = pnlNoDebug.Visible = !cbDebug.Visible;

            // Initieel forceren dat het Digipoort logo of de LOG listbox verschijnt.
            cmdDebugLog_Toggle_Click(new object(), new EventArgs());

            // Initieel de variabelen die hebben te maken met het saven van logdata naar
            // een extern bestand gereedzetten
            Reset_Save_Vars(strSaveFile_Name);           
        }


        private void refresh_queuedata()
        {
            // MessageBox.Show("1");
            debug("Start refresh_queuedata() ", false);
            // MessageBox.Show("2");
            check_SMTP_OUT(strQueueData_SMTP);
            // MessageBox.Show("3");
            get_SMTP_OUT_queues(strQueueData_SMTP);
            // MessageBox.Show("4");
            get_Core_queues(strQueueData_Core);
            // MessageBox.Show("5");
            get_X400_queues(strQueueData_X400);
            // MessageBox.Show("6");
            get_Nagios_OUT_queues(strQueueData_Nagios);
            // MessageBox.Show("7");
            debug("End refresh_queuedata() ", false);
            // MessageBox.Show("8");
            debug(" ", false);

        }

        private void check_SMTP_OUT(string strQueueData)
        {
            // Deze functie zorgt ervoor dat de radiobutten rbDomain niet kan worden
            // geklikt als er een "No messages" record voorkomt hetzij in de "BDR" of "OVH" 
            // SMTP output.
            // Het gaf namelijk een vreemd beeld om bijvoorbeeld
            //   "All   No messages" 
            //   "All   Wissekerke Unions   393" 
            // te zien staan. Daarom, bij (ook al is er maar 1) "No messages" record,
            // ALTIJD ALLEEN op SERVER groeperen

            // We moeten dus een hybride situatie met NO MESSAGES binnen OFWEL OVERHEID ofwel BEDRIJVEN herkennen..

            lblGroupSMTP.Enabled = true;
            cmbGroupSMTP.Enabled = true;
            if (cmbGroupSMTP.SelectedIndex < 0)
            {
                bDo_cmbGroupSMTP_SelectedIndexChanged = false;
                cmbGroupSMTP.SelectedIndex = 1;
                bDo_cmbGroupSMTP_SelectedIndexChanged = true;
            }

            int intNoMsg_BDR = 0;
            int intNoMsg_OVH = 0;
            
            StreamReader srQueue = clDashFunction.open4read(strQueueData);

            string strQueue_record;

            if (srQueue != null)
            {
                while (!srQueue.EndOfStream)
                {
                    strQueue_record = srQueue.ReadLine();
                    
                    // Staat er "no messages" in het inputrecord ??
                    if (!strQueue_record.ToUpper().Contains(strNoMessages.ToUpper()))
                    {

                        if (strQueue_record.ToUpper().Contains(strSMTP2Bedrijven))
                        {
                            intNoMsg_BDR++;
                        }
                        if (strQueue_record.ToUpper().Contains(strSMTP2Overheden))
                        {
                            intNoMsg_OVH++;
                        }
                    }                 

                }
                srQueue.Close();
                /* *And now.... op basis van de bevindingen:
                de combobox moet disabled worden:
                 - Als er binnen OVerHeid een combinatie voorkomt van No Messages en Wel Messages
                 *                                 OF
                 - Als er binnen BeDRrijven een combinatie voorkomt van No Messages en Wel Messages
                 * */

                // if ((bNoMsg_BDR && bYesMsg_BDR) || (bNoMsg_OVH && bYesMsg_OVH))
                if ( intNoMsg_BDR == 1 || intNoMsg_OVH == 1 )
                {
                    bDo_cmbGroupSMTP_SelectedIndexChanged = false;
                    //cmbGroupSMTP.SelectedIndex = -1;
                    cmbGroupSMTP.SelectedIndex = 1;
                    bDo_cmbGroupSMTP_SelectedIndexChanged = true;

                    //Gewoon "per Server" dan toch maar doen ???
                    // Dit gaf waarschijnlijk loopgezeur
                   //cmbGroupSMTP.SelectedIndex = 1;

                    lblGroupSMTP.Enabled = false;
                    cmbGroupSMTP.Enabled = false;
                }
            }
            else
            {
                // Als het goed is kan deze 'else' tak een keer worden weggegooid, zolang dat niet zo is:
                // Experimenteel einde ingebouwd om te voorkomen dat er 100 dezelfde 
                // foutboxes staan als een bestand niet in 10 keer kan worden geopend.
                debug("Fout bij openen: " + strQueueData + " (>10 tries?)", true);
                // clDashFunction.Melding("Er is een fout opgetreden bij het openen van "+strQueueData +" (>10 tries nodig ?)",1,"I"); 
                // this.Close();
            }
        }

        private void get_SMTP_OUT_queues(string strQueueData)
        {
            int intAL_BDR;
            int intAL_OVH;

            string strSMTP_OUT_rec;
            int intSMTPRowNo = 0;

            ArrayList alServer_BDR = new ArrayList();
            ArrayList alBedrijf_BDR = new ArrayList();
            ArrayList alQueue_BDR = new ArrayList();
            ArrayList alCheckTime_BDR = new ArrayList();
            ArrayList alAge_BDR = new ArrayList();
            Boolean bFound_BDR = false;

            ArrayList alServer_OVH = new ArrayList();
            ArrayList alBedrijf_OVH = new ArrayList();
            ArrayList alQueue_OVH = new ArrayList();
            ArrayList alCheckTime_OVH = new ArrayList();
            ArrayList alAge_OVH = new ArrayList();
            Boolean bFound_OVH = false;

            // (Her)initialiseren van Shadowtabel
            ArrayList alSMTP_Shadow_Tab_Current = new ArrayList();

            int intQueue_BDR = 0;
            int intQueue_OVH = 0;

            StreamReader srQueue = clDashFunction.open4read(strQueueData);

            if (srQueue != null)
            {
                // Inputfile met QUEUE info doorfietsen
                while (!srQueue.EndOfStream)
                {
                    strSMTP_OUT_rec = srQueue.ReadLine();

                    /////////////////////
                    //Shadowtabel prutsel 
                    ////////////////////
                    // Deze tabel is dynamic, dus elementen toevoegen indien nodig
                    if (alSMTP_Shadow_Tab_Current.Count <= intSMTPRowNo)
                    {
                        alSMTP_Shadow_Tab_Current.Add("");
                    }

                    alSMTP_Shadow_Tab_Current[intSMTPRowNo] = strSMTP_OUT_rec;
                    intSMTPRowNo++;
                    //////////////////////////
                    // End Shadowtabel prutsel
                    //////////////////////////

                    string[] alSMTP_OUT = Regex.Split(strSMTP_OUT_rec, "~");

                    if (alSMTP_OUT.Length > 4)
                    {
                        // Voldoet de herkomst van dit record qua omgeving aan de geselecteerde ?
                    // Dit gaan we zien door de servernaam te houden tegen de array met alle
                    // Digipoort servers, waarbij tevens staat aangegeven wat de bijbehorende
                    // omgeving is.

                       if (isServerInChoosenEnv(alSMTP_OUT[1]))
                       {
                        ///////////////////////////
                        // BEDRIJVEN
                        ///////////////////////////
                        if (alSMTP_OUT[2] == strSMTP2Bedrijven)
                        {
                            if (cmbGroupSMTP.Text.ToUpper() == "DOMAIN".ToUpper())
                            {
                                bFound_BDR = false;
                                intAL_BDR = 0;
                                while (intAL_BDR < alBedrijf_BDR.Count) // had ook intMAX_BDR kunnen zijn
                                {
                                    // Bestaand bedrijf/domain
                                    if (alBedrijf_BDR[intAL_BDR].ToString() == alSMTP_OUT[4])
                                    {
                                        if (alSMTP_OUT.Length > 5)
                                        {
                                            alQueue_BDR[intAL_BDR] = Convert.ToString(Convert.ToInt32(alQueue_BDR[intAL_BDR]) + Convert.ToInt32(alSMTP_OUT[5]));
                                            if (Convert.ToInt32(alAge_BDR[intAL_BDR]) < Convert.ToInt32(alSMTP_OUT[6]))
                                            {
                                                alAge_BDR[intAL_BDR] = alSMTP_OUT[6];
                                            }
                                            alCheckTime_BDR[intAL_BDR] = alSMTP_OUT[3];
                                        }
                                        bFound_BDR = true;
                                    }
                                    intAL_BDR++;
                                }
                                // Nieuw bedrijf/domain
                                if (!bFound_BDR)
                                {
                                    alServer_BDR.Add("All");
                                    alCheckTime_BDR.Add(alSMTP_OUT[3]);
                                    alBedrijf_BDR.Add(alSMTP_OUT[4]);
                                    if (alSMTP_OUT.Length > 5)
                                    {
                                        alQueue_BDR.Add(alSMTP_OUT[5]);
                                        alAge_BDR.Add(alSMTP_OUT[6]);
                                    }
                                    else
                                    {
                                        // Nullen toevoegen om array's in sync te houden
                                        alQueue_BDR.Add(0);
                                        alAge_BDR.Add(0);
                                    }
                                }
                            }
                            else // de "gewone" recht op en neer weergave
                            {
                                alServer_BDR.Add(alSMTP_OUT[1]);
                                alCheckTime_BDR.Add(alSMTP_OUT[3]);
                                alBedrijf_BDR.Add(alSMTP_OUT[4]);
                                if (alSMTP_OUT.Length > 5)
                                {
                                    alQueue_BDR.Add(alSMTP_OUT[5]);
                                    alAge_BDR.Add(alSMTP_OUT[6]);
                                }
                                else
                                {
                                    // Nullen toevoegen om array's in sync te houden
                                    alQueue_BDR.Add(0);
                                    alAge_BDR.Add(0);
                                }
                            }
                        }

                        ///////////////////////////
                        // OVERHEDEN
                        ///////////////////////////
                        if (alSMTP_OUT[2] == strSMTP2Overheden)
                        {
                            if (cmbGroupSMTP.Text.ToUpper() == "DOMAIN".ToUpper())
                            {
                                bFound_OVH = false;
                                intAL_OVH = 0;
                                while (intAL_OVH < alBedrijf_OVH.Count) // had ook intMAX_OVH kunnen zijn
                                {
                                    // Bestaand bedrijf/domain
                                    if (alBedrijf_OVH[intAL_OVH].ToString() == alSMTP_OUT[4])
                                    {
                                        if (alSMTP_OUT.Length > 5)
                                        {
                                            alQueue_OVH[intAL_OVH] = Convert.ToString(Convert.ToInt32(alQueue_OVH[intAL_OVH]) + Convert.ToInt32(alSMTP_OUT[5]));
                                            if (Convert.ToInt32(alAge_OVH[intAL_OVH]) < Convert.ToInt32(alSMTP_OUT[6]))
                                            {
                                                alAge_OVH[intAL_OVH] = alSMTP_OUT[6];
                                            }
                                            alCheckTime_OVH[intAL_OVH] = alSMTP_OUT[3];
                                        }
                                        bFound_OVH = true;
                                    }
                                    intAL_OVH++;
                                }
                                // Nieuw bedrijf/domain
                                if (!bFound_OVH)
                                {
                                    alServer_OVH.Add("All");
                                    alCheckTime_OVH.Add(alSMTP_OUT[3]);
                                    alBedrijf_OVH.Add(alSMTP_OUT[4]);
                                    if (alSMTP_OUT.Length == 7)
                                    {
                                        alQueue_OVH.Add(alSMTP_OUT[5]);
                                        alAge_OVH.Add(alSMTP_OUT[6]);
                                    }
                                    else
                                    {
                                        // Nullen toevoegen om array's in sync te houden
                                        alQueue_OVH.Add(0);
                                        alAge_OVH.Add(0);
                                    }
                                }
                            }
                            else // de "gewone" recht op en neer weergave
                            {
                                alServer_OVH.Add(alSMTP_OUT[1]);
                                alCheckTime_OVH.Add(alSMTP_OUT[3]);
                                alBedrijf_OVH.Add(alSMTP_OUT[4]);
                                if (alSMTP_OUT.Length == 7)
                                {
                                    alQueue_OVH.Add(alSMTP_OUT[5]);
                                    alAge_OVH.Add(alSMTP_OUT[6]);
                                }
                                else
                                {
                                    // Nullen toevoegen om array's in sync te houden
                                    alQueue_OVH.Add(0);
                                    alAge_OVH.Add(0);
                                }
                            }
                        }
                    }
                }
                    else
                    {
                        show_data_columns_error("SMTPQ", strQueueData);
                        return;
                    }
                }
                srQueue.Close();

                /////////////////////////
                // < QUEUEDATA LOGGING />
                /////////////////////////
                if (b_SMTPq_SaveStarted)
                {
                    alSMTP_Shadow_Tab_Previous = Save_Log_Record("SMTP", alSMTP_Shadow_Tab_Current, alSMTP_Shadow_Tab_Previous);
                }


                /////////////////////////////////////////////////////////////////////////////////
                // Datagrids vullen
                ////////////////////////////////////////////////////////////////////////////////

                // *********
                // BEDRIJVEN
                // *********
                intAL_BDR = 0;

                dgSMTPQ_BDR.Rows.Clear();
                while (intAL_BDR < alBedrijf_BDR.Count)
                {
                    int intNewRow = dgSMTPQ_BDR.Rows.Add();
                    dgSMTPQ_BDR[0, intNewRow].Value = alServer_BDR[intAL_BDR];
                    dgSMTPQ_BDR[3, intNewRow].Value = alBedrijf_BDR[intAL_BDR];
                    if (Convert.ToInt32(alQueue_BDR[intAL_BDR]) > 0)
                    {
                        dgSMTPQ_BDR[1, intNewRow].Value = Convert.ToInt32(alQueue_BDR[intAL_BDR]);
                        dgSMTPQ_BDR[2, intNewRow].Value = alCheckTime_BDR[intAL_BDR];
                        dgSMTPQ_BDR[4, intNewRow].Value = clDashFunction.fromS2DHMS(Convert.ToDouble(alAge_BDR[intAL_BDR]), false);
                    }
                    else
                    {
                        dgSMTPQ_BDR[1, intNewRow].Value = 0;
                        dgSMTPQ_BDR[2, intNewRow].Value = alCheckTime_BDR[intAL_BDR];
                        dgSMTPQ_BDR[4, intNewRow].Value = "";
                    }
                    intQueue_BDR = intQueue_BDR + Convert.ToInt32(dgSMTPQ_BDR[1, intNewRow].Value);

                    intAL_BDR++;
                }

                /////////////////////////////
                // TREND
                /////////////////////////////
                debug("Gemiddeld SMTP BDR: " + lbSMTPQ_BDR.AddValue(intQueue_BDR), false);
                if (lblSMTPQ_BDR_MAX.SetMax(intQueue_BDR))
                {
                    lblSMTPQ_BDR_MAXTime.SetMax();
                }

                // Als er geen messages gequeued zijn, dan de "aantal domains" variabele ook naar 0
                // anders worden de "No messages" regels wel als zodanig geteld.
                if (intQueue_BDR == 0)
                {
                    intAL_BDR = 0;
                }

                lblMsgs_BDR.Text = intQueue_BDR + " message(s), " + intAL_BDR + " domain(s)";

                // Trendgrafiek bijwerken
                // pnSMTPQ_BDR.Controls.Add(Get_SMTPQ_BDR_Chart());

                // *********
                // OVERHEDEN
                // *********
                intAL_OVH = 0;

                dgSMTPQ_OVH.Rows.Clear();
                while (intAL_OVH < alBedrijf_OVH.Count)
                {
                    int intNewRow = dgSMTPQ_OVH.Rows.Add();
                    dgSMTPQ_OVH[0, intNewRow].Value = alServer_OVH[intAL_OVH];
                    dgSMTPQ_OVH[3, intNewRow].Value = alBedrijf_OVH[intAL_OVH];
                    if (Convert.ToInt32(alQueue_OVH[intAL_OVH]) > 0)
                    {
                        dgSMTPQ_OVH[1, intNewRow].Value = Convert.ToInt32(alQueue_OVH[intAL_OVH]);
                        dgSMTPQ_OVH[2, intNewRow].Value = alCheckTime_OVH[intAL_OVH];
                        dgSMTPQ_OVH[4, intNewRow].Value = clDashFunction.fromS2DHMS(Convert.ToDouble(alAge_OVH[intAL_OVH]), false);
                    }
                    else
                    {
                        dgSMTPQ_OVH[1, intNewRow].Value = 0;
                        dgSMTPQ_OVH[2, intNewRow].Value = alCheckTime_OVH[intAL_OVH];
                        dgSMTPQ_OVH[4, intNewRow].Value = "";
                    }
                    intQueue_OVH = intQueue_OVH + Convert.ToInt32(dgSMTPQ_OVH[1, intNewRow].Value);

                    intAL_OVH++;
                }

                /////////////////////////////
                // TREND
                /////////////////////////////
                debug("Gemiddeld SMTP OVH: " + lbSMTPQ_OVH.AddValue(intQueue_OVH), false);
                if (lblSMTPQ_OVH_MAX.SetMax(intQueue_OVH))
                {
                    lblSMTPQ_OVH_MAXTime.SetMax();
                }

                //Als er geen messages gequeued zijn, dan de "aantal domains" variabele ook naar 0
                //anders worden de "No messages" regels wel als zodanig geteld.
                if (intQueue_OVH == 0)
                {
                    intAL_OVH = 0;
                }

                lblMsgs_OVH.Text = intQueue_OVH + " message(s), " + intAL_OVH + " domain(s)";
            }
            else
            {
                debug("No update: fout bij openen SMTP inputfile", true);
                // clDashFunction.Melding("File " + strQueueData + " does not exist ");
            }
        }

        private void get_Core_queues(string strQueueData)
        {
            string strCore_OUT_rec;
            int intCoreRowNo = 0;
            int intNewRow = 0;
            int[] intCoreTotals = new int[2];
            int[] intCoreOldestRowNo = new int[2];
            string[] strCoreOldest = new string[2];

            pnlCore1.Visible = false;
            pnlCore2.Visible = false;

            intCoreOldestRowNo[0] = -1;
            intCoreOldestRowNo[1] = -1;
            strCoreOldest[0] = "9999-99-9999:99:99.999999999";
            strCoreOldest[1] = "9999-99-9999:99:99.999999999";

            Label[] lblCore_Alarm = new Label[4]; // Want 4 coreservers ( op dit moment !! )
            flpCoreAlarm.Controls.Clear();
            int intCore_Alarm_index = 1;             

            string  strCore_Alarm_Image_Spacing="       ";


            System.Drawing.Size sdCore_Alarm = new System.Drawing.Size(240,20);

            StreamReader srQueue = clDashFunction.open4read(strQueueData);
            if (srQueue != null)
            {
                // Herinitialiseren
                alCore_Shadow_Tab_Current = new ArrayList();

                // Alleen datagrid opschonen als suc6 vol een file is geopend om het opnieuw
                // te vullen, anders zitten we misschien tegen een zwart datagrid aan te kijken
                dgCoreQ.Rows.Clear();

                while (!srQueue.EndOfStream)
                {
                    strCore_OUT_rec = srQueue.ReadLine();

                    /////////////////////
                    //Shadowtabel prutsel 
                    ////////////////////
                    if (alCore_Shadow_Tab_Current.Count <= intCoreRowNo)
                    {
                        alCore_Shadow_Tab_Current.Add("");
                    }

                    alCore_Shadow_Tab_Current[intCoreRowNo] = strCore_OUT_rec;

                    intCoreRowNo++;
                    //////////////////////////
                    // End Shadowtabel prutsel
                    //////////////////////////

                    // Split inputrecord into separate fields
                    string[] alCore = Regex.Split(strCore_OUT_rec, "~");

                    if (alCore.Length > 3)
                    {
                        // De 'show' alarm controls worden dynamisch aangemaakt 
                        // en dan alleen voor die core(s) waarop alarms te betreuren zijn
                        if (isServerInChoosenEnv(alCore[1])) // CORE_ALARM
                        {
                            if (alCore[2] == strALARM_OTPtransfer)
                            {                               
                                if (Convert.ToInt16(alCore[4]) > 0 ) // Aantal
                                {
                                    lblCore_Alarm[intCore_Alarm_index] = new Label();
                                    lblCore_Alarm[intCore_Alarm_index].Text = strCore_Alarm_Image_Spacing + alCore[4].ToString() + " otptrans alarm(s) on "+alCore[1].ToString() ;
                                    lblCore_Alarm[intCore_Alarm_index].Visible = true;
                                    lblCore_Alarm[intCore_Alarm_index].Size = sdCore_Alarm;
                                    lblCore_Alarm[intCore_Alarm_index].Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
                                    lblCore_Alarm[intCore_Alarm_index].ForeColor = Color.Maroon;
                                    lblCore_Alarm[intCore_Alarm_index].Image = imageList1.Images[0];
                                    lblCore_Alarm[intCore_Alarm_index].ImageAlign = ContentAlignment.MiddleLeft;
                                    //
                                    // Toevoegen aan flowpanel
                                    flpCoreAlarm.Controls.Add(lblCore_Alarm[intCore_Alarm_index]);                                    
                                }                                  
                            }                            

                            if (alCore[2] == strSMTP_from_bedrijven || alCore[2] == strX400_from_overheden)
                            {
                                intNewRow = dgCoreQ.Rows.Add();
                                dgCoreQ[0, intNewRow].Value = alCore[1]; // Server
                                dgCoreQ[1, intNewRow].Value = alCore[2]; // Protocol

                                // Als Queue aantal groter of gelijk is aan 0 handel dan 'normaal' af en
                                // ga dan het aantal in het grid zetten en kleuren
                                if (Convert.ToInt32(alCore[4]) >= 0)
                                {
                                    dgCoreQ[2, intNewRow].Value = Convert.ToInt32(alCore[4]); // # Queue

                                    if (Convert.ToInt32(alCore[4]) == 0)
                                    {
                                        dgCoreQ.Rows[intNewRow].DefaultCellStyle.BackColor = clQueue_no;
                                    }

                                    if (Convert.ToInt32(alCore[4]) > 0)
                                    {
                                        dgCoreQ.Rows[intNewRow].DefaultCellStyle.BackColor = clQueue_yes;
                                    }

                                }
                                // Als het Queue aantal kleiner is dan 0 dan is er een fout opgetreden in het
                                // onderliggende script op Linux bij het bepalen van grootte en ouderdom
                                // berichten in de queue ( ik heb wel ???'kens gezien in het resultaat van een ls
                                else
                                {
                                    dgCoreQ[2, intNewRow].Value = "Error";
                                    dgCoreQ.Rows[intNewRow].DefaultCellStyle.BackColor = clQueue_error;
                                    debug("Error in Core inputdata", true);
                                }

                                dgCoreQ[3, intNewRow].Value = alCore[3]; // Age
                                if (alCore.Length > 7)
                                {
                                    dgCoreQ[4, intNewRow].Value = clDashFunction.fromS2DHMS(Convert.ToDouble(alCore[6]), true); // Oldest
                                    dgCoreQ[5, intNewRow].Value = clDashFunction.fromS2DHMS(Convert.ToDouble(alCore[8]), true); // Newest
                                }

                                switch (alCore[2])
                                {
                                    case strSMTP_from_bedrijven:

                                        intCoreTotals[0] = intCoreTotals[0] + Convert.ToInt32(alCore[4]);

                                        if (alCore[5].CompareTo(strCoreOldest[0]) < 0)
                                        {
                                            strCoreOldest[0] = alCore[5];
                                            intCoreOldestRowNo[0] = intNewRow;
                                        }
                                        break;

                                    case strX400_from_overheden:
                                        intCoreTotals[1] = intCoreTotals[1] + Convert.ToInt32(alCore[4]);
                                        if (alCore[5].CompareTo(strCoreOldest[1]) < 0)
                                        {
                                            strCoreOldest[1] = alCore[5];
                                            intCoreOldestRowNo[1] = intNewRow;
                                        }
                                        break;

                                    default:
                                        clDashFunction.Melding("Unknown protocol type: " + alCore[2] + " in function: get_Core_queues", 1, "I");
                                        break;
                                }
                            }
                        }

                        if (intCoreTotals[0] > 0)
                        {
                            lblMsgs_Core_Age1.Text = "[" + strSMTP_from_bedrijven + "], oldest: ";
                            lblCoreTotal1.Text = intCoreTotals[0].ToString("#,#");
                            lblCoreOldest1.Text = dgCoreQ[4, intCoreOldestRowNo[0]].Value.ToString();
                            pnlCore1.Visible = true;
                        }

                        if (intCoreTotals[1] > 0)
                        {
                            lblMsgs_Core_Age2.Text = "[" + strX400_from_overheden + "], oldest: ";
                            lblCoreTotal2.Text = intCoreTotals[1].ToString("#,#");
                            lblCoreOldest2.Text = dgCoreQ[4, intCoreOldestRowNo[1]].Value.ToString();
                            pnlCore2.Visible = true;
                        }

                    }
                    else
                    {
                        show_data_columns_error("CoreQ", strQueueData);
                        return;
                    }
                }
                srQueue.Close();

                if (flpCoreAlarm.Controls.Count == 0)
                {
                    Label lblNoAlarm = new Label();
                    lblNoAlarm.Text = "OK; no alarm(s)";
                    lblNoAlarm.Enabled = false;
                    flpCoreAlarm.Controls.Add(lblNoAlarm);
                }

                //////////////////
                // TREND Core SMTP
                //////////////////
                debug("Gemiddeld SMTP Core: " + lbCoreQ_SMTP.AddValue(intCoreTotals[0]), false);
                if (lblCore_SMTP_MAX.SetMax(intCoreTotals[0]))
                {
                    lblCore_SMTP_MaxTime.SetMax();
                }

                ///////////////////
                // TREND Core X400
                //////////////////
                debug("Gemiddeld X400 Core: " + lbCoreQ_X400.AddValue(intCoreTotals[1]), false);
                if (lblCore_X400_MAX.SetMax(intCoreTotals[1]))
                {
                    lblCore_X400_MaxTime.SetMax();
                }

                // Trendgrafiek bijwerken
                // pnCoreQ.Controls.Add(Get_CoreQ_Chart());

                /////////////////////////
                // < QUEUEDATA LOGGING />
                /////////////////////////
                if (b_Coreq_SaveStarted)
                {
                    alCore_Shadow_Tab_Previous = Save_Log_Record("CORE", alCore_Shadow_Tab_Current, alCore_Shadow_Tab_Previous);
                }

            }
            else
            {
                debug("No update: fout bij openen Core inputfile", true);
            }
        }

        private void get_X400_queues(string strQueueData)
        {
            string strX400_OUT_rec;
            int intX400RowNo = 0;
            int intX400Q_OVH = 0;
            int intX400Q_BDR = 0;

            StreamReader srQueue = clDashFunction.open4read(strQueueData);
            if (srQueue != null)
            {
                // (Her)initialisatie
                alX400_Shadow_Tab_Current = new ArrayList(6);

                // Alleen datagrid opschonen als suc6 vol een file is geopend om het opnieuw
                // te vullen, anders zitten we misschien tegen een zwart datagrid aan te kijken
                dgX400Q_OVH.Rows.Clear();
                dgX400Q_BDR.Rows.Clear();

                while (!srQueue.EndOfStream)
                {

                    strX400_OUT_rec = srQueue.ReadLine();

                    /////////////////////
                    //Shadowtabel prutsel 
                    ////////////////////
                    // Deze tabel is dynamic, dus elementen toevoegen indien nodig
                    if (alX400_Shadow_Tab_Current.Count <= intX400RowNo)
                    {
                        alX400_Shadow_Tab_Current.Add("");
                    }

                    alX400_Shadow_Tab_Current[intX400RowNo] = strX400_OUT_rec;
                    intX400RowNo++;
                    //////////////////////////
                    // End Shadowtabel prutsel
                    //////////////////////////

                    string[] alX400Q = Regex.Split(strX400_OUT_rec, "~");

                    if (alX400Q.Length > 3)
                    {
                        if (isServerInChoosenEnv(alX400Q[1]))
                        {


                            //////////////////
                            // Bedrijven X400
                            //////////////////
                            if (alX400Q[2] == strX4002Bedrijven)
                            {
                                int intNewRow = dgX400Q_BDR.Rows.Add();
                                dgX400Q_BDR[0, intNewRow].Value = alX400Q[1]; // Server
                                dgX400Q_BDR[1, intNewRow].Value = Convert.ToInt32(alX400Q[4]); // # Queue
                                if (Convert.ToInt32(alX400Q[4]) > 0)
                                {
                                    dgX400Q_BDR.Rows[intNewRow].DefaultCellStyle.BackColor = clQueue_yes;
                                }
                                else
                                {
                                    dgX400Q_BDR.Rows[intNewRow].DefaultCellStyle.BackColor = clQueue_no;
                                }
                                dgX400Q_BDR[2, intNewRow].Value = alX400Q[3]; // Time
                                if (alX400Q.Length > 6)
                                {
                                    dgX400Q_BDR[3, intNewRow].Value = clDashFunction.fromS2DHMS(Convert.ToDouble(alX400Q[6]), true); // Oldest
                                    dgX400Q_BDR[4, intNewRow].Value = clDashFunction.fromS2DHMS(Convert.ToDouble(alX400Q[8]), true); // Newest
                                }

                                intX400Q_BDR = intX400Q_BDR + Convert.ToInt32(dgX400Q_BDR[1, intNewRow].Value);
                            }

                            //////////////////
                            // Overheden X400
                            //////////////////
                            if (alX400Q[2] == strX4002Overheden)
                            {
                                int intNewRow = dgX400Q_OVH.Rows.Add();
                                dgX400Q_OVH[0, intNewRow].Value = alX400Q[1]; // Server
                                dgX400Q_OVH[1, intNewRow].Value = Convert.ToInt32(alX400Q[4]); // # Queue

                                if (Convert.ToInt32(alX400Q[4]) > 0)
                                {
                                    dgX400Q_OVH.Rows[intNewRow].DefaultCellStyle.BackColor = clQueue_yes;
                                }
                                else
                                {
                                    dgX400Q_OVH.Rows[intNewRow].DefaultCellStyle.BackColor = clQueue_no;
                                }
                                dgX400Q_OVH[2, intNewRow].Value = alX400Q[3]; // Time
                                if (alX400Q.Length > 6)
                                {
                                    dgX400Q_OVH[3, intNewRow].Value = clDashFunction.fromS2DHMS(Convert.ToDouble(alX400Q[6]), true); // Oldest
                                    dgX400Q_OVH[4, intNewRow].Value = clDashFunction.fromS2DHMS(Convert.ToDouble(alX400Q[8]), true); // Newest
                                }

                                intX400Q_OVH = intX400Q_OVH + Convert.ToInt32(dgX400Q_OVH[1, intNewRow].Value);
                            }
                        }
                    }
                    else
                    {
                        show_data_columns_error("X400Q", strQueueData);
                        return;
                    }
                }
                srQueue.Close();

                /////////////////////////////
                // TREND
                /////////////////////////////
                debug("Gemiddeld X400-BDR: " + lbX400Q_BDR.AddValue(intX400Q_BDR), false);
                if (lblX400Q_BDR_MAX.SetMax(intX400Q_BDR))
                {
                    lblX400Q_BDR_MAXTime.SetMax();
                }

                debug("Gemiddeld X400-OVH: " + lbX400Q_OVH.AddValue(intX400Q_OVH), false);
                if (lblX400Q_OVH_MAX.SetMax(intX400Q_OVH))
                {
                    lblX400Q_OVH_MAXTime.SetMax();
                }

                ////////////////////////
                // < QUEUEDATA LOGGING />
                ////////////////////////
                if (b_X400q_SaveStarted)
                {
                    alX400_Shadow_Tab_Previous = Save_Log_Record("X400", alX400_Shadow_Tab_Current, alX400_Shadow_Tab_Previous);
                }

            }
            else
            {
                debug("No update: fout bij openen X400 inputfile", true);
            }
        }

        /// <summary>
        /// Het resultaat ophalen van de test of er op de Nagios machines misschien nog
        /// alarm berichten in de queue staan. In dat geval worden er geen alarms
        /// naar de mailbox van ServiceDesk.Overheid gestuurd, en is de monitoring dus
        /// eigenlijk niet compleet, en moet er actie naar Midrange of Connecitivy volgen
        /// </summary>
        /// <param name="strQueueData"></param>
        private void get_Nagios_OUT_queues(string strQueueData)
        {
            string strNagios_OUT_rec;

            ArrayList alServerNagios1 = new ArrayList();
            ArrayList alBedrijfNagios1 = new ArrayList();
            ArrayList alQueueNagios1 = new ArrayList();
            ArrayList alCheckTimeNagios1 = new ArrayList();
            ArrayList alAgeNagios1 = new ArrayList();

            ArrayList alServerNagios2 = new ArrayList();
            ArrayList alBedrijfNagios2 = new ArrayList();
            ArrayList alQueueNagios2 = new ArrayList();
            ArrayList alCheckTimeNagios2 = new ArrayList();
            ArrayList alAgeNagios2 = new ArrayList();

            ///string strNagiosServer1 = "kslv114";
            ///string strNagiosServer2 = "kslv115";
            int intNagios1Queue = 0;
            int intNagios2Queue = 0;

            StreamReader srQueue = clDashFunction.open4read(strQueueData);

            if (srQueue != null)
            {
                // Inputfile met QUEUE info doorfietsen
                while (!srQueue.EndOfStream)
                {
                    strNagios_OUT_rec = srQueue.ReadLine();

                    string[] alNagios_OUT = Regex.Split(strNagios_OUT_rec, "~");

                    if (alNagios_OUT.Length > 4)
                    {
                        ////////////////////
                        // Nagios1 / kslv114
                        ////////////////////
                        if (alNagios_OUT[2] == strNagios1)
                        {
                            alServerNagios1.Add(alNagios_OUT[1]);
                            alCheckTimeNagios1.Add(alNagios_OUT[3]);
                            alBedrijfNagios1.Add(alNagios_OUT[4]);
                            if (alNagios_OUT.Length == 7)
                            {
                                alQueueNagios1.Add(alNagios_OUT[5]);
                                alAgeNagios1.Add(alNagios_OUT[6]);
                            }
                            else
                            {
                                // Nullen toevoegen om array's in sync te houden
                                alQueueNagios1.Add(0);
                                alAgeNagios1.Add(0);
                            }
                        }

                        ////////////////////
                        // Nagios2 / kslv115
                        ////////////////////
                        if (alNagios_OUT[2] == strNagios2)
                        {
                            alServerNagios2.Add(alNagios_OUT[1]);
                            alCheckTimeNagios2.Add(alNagios_OUT[3]);
                            alBedrijfNagios2.Add(alNagios_OUT[4]);
                            if (alNagios_OUT.Length == 7)
                            {
                                alQueueNagios2.Add(alNagios_OUT[5]);
                                alAgeNagios2.Add(alNagios_OUT[6]);
                            }
                            else
                            {
                                // Nullen toevoegen om array's in sync te houden
                                alQueueNagios2.Add(0);
                                alAgeNagios2.Add(0);
                            }
                        }
                    }
                    else
                    {
                        show_data_columns_error("NagiosQ", strQueueData);
                        return;
                    }

                }
                srQueue.Close();

                intNagios1Queue = alBedrijfNagios1.Count;
                intNagios2Queue = alBedrijfNagios2.Count;
                if (intNagios1Queue == 1 && alBedrijfNagios1[0].ToString() == strNoMessages)
                {
                    intNagios1Queue = 0;
                }
                if (intNagios2Queue == 1 && alBedrijfNagios2[0].ToString() == strNoMessages)
                {
                    intNagios2Queue = 0;
                }

                if (intNagios1Queue == 0 && intNagios2Queue == 0)
                {
                    txtNagios_Queue.BackColor = SystemColors.Window;
                    txtNagios_Queue.Text = "OK: no queue(s) on server(s): " + strNagios;

                }
                else
                {
                    txtNagios_Queue.BackColor = Color.Orange;
                    txtNagios_Queue.Text = "Warning: message queue(s) on server(s): "+strNagios;
                }
            }
            else
            {
                debug("No update: fout bij openen Nagios inputfile", true);
            }
        }

        private void show_data_columns_error(string strKind, string strQueueData)
        {
            clDashFunction.Melding(strKind + " data record does not have the appropriate number of columns !" +
                      "\n" + "\n" +
                      "( " + strQueueData + ")" +
                       "\n" + "\n" +
                      "This file will NOT be processed !", 1, "E");
        }

        private void auto_update_start()
        {

            // lblRefresh_till_refresh.Text = "(Started)";
            lblRefresh_till_refresh.Visible = true;
            lblRefresh_last_refresh.Visible = true;
            ///////////////////////////// lblUpdate_Script_txt.Visible = true;
            ///////////////////////////// lblUpdate_Script_val.Visible = true;

            cmdSaveToOptions.Enabled = true;

            // Eerst alles éénmalig uitvoeren om direct actuele data te zien..
            tmrSMTPQ_Tick(new object(), new EventArgs());
            tmrCoreQ_Tick(new object(), new EventArgs());
            tmrX400Q_Tick(new object(), new EventArgs());
            tmrRefresh_Tick(new object(), new EventArgs());

            // En daarna op het ritme van de timers      
            start_timers();
        }

        private void auto_update_stop()
        {
            Boolean bStopSave = false;

            if (bSaveStarted)
            {
                if (swSaveFile != null)
                {
                    if (clDashFunction.Melding("Queuedata recording is currently active and will be cancelled, Are you sure ?", 4, "Q") == DialogResult.Yes)
                    {
                        bStopSave = true;
                    }
                    else
                    {
                        // Toch maar niet..
                        rbAutoUpdateOn.Checked = true;
                    }
                }
            }
            else
            {
                bStopSave = true;
            }
            if (bStopSave)
            {
                stop_timers();
                // lblRefresh.Text = "(Stopped)";
                lblRefresh_till_refresh.Text = "";
                lblRefresh_last_refresh.Text = "";
                //lblUpdate_Script_txt.Text = "";
                //lblUpdate_Script_val.Text = "";

                lblRefresh_till_refresh.Visible = false;
                lblRefresh_last_refresh.Visible = false;
                ///////////////////// lblUpdate_Script_txt.Visible = false;
                ///////////////////// lblUpdate_Script_val.Visible = false;
            }
        }

        private void start_timers()
        {
            tmrSeconds.Start();
            /////////////////////////////////////////////////////////////////////
            // LET OP:
            // de CoreQ 
            //    en
            // de X400 
            // timers worden "getrapt" gestart vanuit de SMTPQ timer !!!
            //////////////////////////////////////////////////////////////////////
            tmrSMTPQ.Start();

            tmrRefresh.Start();
        }

        private void stop_timers()
        {
            tmrSeconds.Stop();
            tmrSMTPQ.Stop();

            tmrCoreQ.Stop();
            b_tmrCoreq_started = false;
            tmrX400Q.Stop();
            b_tmrX400q_started = false;
            tmrRefresh.Stop();
            // cbAutoUpdateOff.Enabled = false;
            cmdSaveToOptions.Enabled = false;
            // grbSaveData.Enabled = false;
            // cbAutoUpdateOn.Enabled = !cbAutoUpdateOff.Enabled;
            // cbAutoUpdateOn.Checked = !cbAutoUpdateOff.Checked;
        }

        private void tmrSMTPQ_Tick(object sender, EventArgs e)
        {
            // alleen script vanaf deze app zelf triggeren als strUpdateScript <> "SERVER"
            // Anders wordt verondersteld dat er wel ergens anders op een server een script draait
            // en hoeven we alleen daar de output van op te halen
            if (strUpdateScript.ToUpper() != mdiDashboard.strServer.ToUpper())
            {
                clDashFunction.do_wincmd(strQueueCMD_SMTP, "", true);
            }
            if (!b_tmrCoreq_started) { tmrCoreQ.Start(); b_tmrCoreq_started = true; }
        }

        private void tmrCoreQ_Tick(object sender, EventArgs e)
        {
            // alleen script vanaf deze app zelf triggeren als strUpdateScript <> "SERVER"
            // Anders wordt verondersteld dat er wel ergens anders op een server een script draait
            // en hoeven we alleen daar de output van op te halen
            if (strUpdateScript.ToUpper() != "ServeR".ToUpper())
            {
                clDashFunction.do_wincmd(strQueueCMD_Core, "", true);
            }
            if (!b_tmrX400q_started) { tmrX400Q.Start(); b_tmrX400q_started = true; }
        }

        private void tmrX400Q_Tick(object sender, EventArgs e)
        {
            // alleen script vanaf deze app zelf triggeren als strUpdateScript <> "SERVER"
            // Anders wordt verondersteld dat er wel ergens anders op een server een script draait
            // en hoeven we alleen daar de output van op te halen
            if (strUpdateScript.ToUpper() != "ServeR".ToUpper())
            {
                clDashFunction.do_wincmd(strQueueCMD_X400, "", true);
            }
        }

        private void tmrRefresh_Tick(object sender, EventArgs e)
        {
            lblRefresh_last_refresh.Text = LastRefresh();
            lblRefresh_till_refresh.Tag = (tmrRefresh.Interval / 1000).ToString();
            lblRefresh_till_refresh.Text = NextRefresh(lblRefresh_till_refresh, 0);

            debug("Timer triggered: " + System.DateTime.Now, false);
            refresh_queuedata();
        }

        private void tmrSeconds_Tick(object sender, EventArgs e)
        {
            lblRefresh_till_refresh.Text = NextRefresh(lblRefresh_till_refresh);
        }
               
        private void cmdSaveToOptions_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;

            frmDashQueueRec frmQueueRec = new frmDashQueueRec();

            // *****************************************************
            // Instellen Dialog schermvariablen
            // *****************************************************
            // "Logging al actief" indicatie
            frmQueueRec.bActive = bSaveStarted;

            // Path en naam "To" logfile
            frmQueueRec.strQueueData_Path = strQueueData_Path;
            frmQueueRec.strRecordFile_val = strSaveFile_Name;

            // Log queue bitjes
            frmQueueRec.bLog_SMTPQ = b_SMTPq_SaveStarted;
            frmQueueRec.bLog_CoreQ = b_Coreq_SaveStarted;
            frmQueueRec.bLog_X400Q = b_X400q_SaveStarted;

            // Log option bitjes
            frmQueueRec.bRecordQueueOnly = bRecordQueueOnly;
            frmQueueRec.bRecordErrors = bRecordErrors;

            // ****************************************************
            // Tonen Dialog scherm
            // ****************************************************
            frmQueueRec.ShowDialog();

            // Als er niet is geannuleerd ( want dan verandert er nix )....
            if (!frmQueueRec.bCancelled)
            {
                // *************************************************************
                // Terug inlezen van de (evt gewijzigde) dialog schermvariabelen
                // *************************************************************

                // Log option bitjes
                bRecordErrors = frmQueueRec.bRecordErrors;
                bRecordQueueOnly = frmQueueRec.bRecordQueueOnly;

                // Log queue bitjes
                b_X400q_SaveStarted = frmQueueRec.bLog_X400Q;
                b_Coreq_SaveStarted = frmQueueRec.bLog_CoreQ;
                b_SMTPq_SaveStarted = frmQueueRec.bLog_SMTPQ;

                // Beetje aparte constructie hier ten aanzien van de "save file naam"
                // Bij het AANzetten gebruiken we de variabele van het dialoog form.
                // en bij het UITzetten de 'oude' variabele strSaveFile_Name. Dit omdat
                // de variabele uit het dialoog form dan al is gereset. We willen echter
                // nog wel even een "** STOP Logging" schrijven

                // Logging WAS uit en IS aan
                if (!bSaveStarted && frmQueueRec.bActive)
                {
                    if (frmQueueRec.strRecordFile_val == null)
                    {
                        clDashFunction.Melding("No 'SaveTo' filename has been issued\nExternal save will NOT be initiated !", 1, "E");
                        this.Cursor = Cursors.Default;
                        return;
                    }
                    else
                    {
                        Start_save(frmQueueRec.strRecordFile_val, true);
                    }
                }
                // Logging WAS aan en IS uit
                if (bSaveStarted && !frmQueueRec.bActive)
                {
                    Reset_Save_Vars(strSaveFile_Name);
                }

                // En terugschrijven van de 'overkoepelende' vars
                strSaveFile_Name = frmQueueRec.strRecordFile_val;
                bSaveStarted = frmQueueRec.bActive;
            }
            this.Cursor = Cursors.Default;
        }


        private void Start_save(string strSaveFile_Name, Boolean bOpenNewSaveFile)
        {
            // Hier alleen de filename met wat punten ervoor. Als het path eraan is
            // vastgeplakt past de gehele waarde mogelijk niet op het form(deel)
            lblSaveFile.Text = "busy: ../" + System.IO.Path.GetFileName(strSaveFile_Name);

            // Er moet een nieuwe file worden geopend
            if (bOpenNewSaveFile)
            {
                // Bestaande eerst sluiten
                if (swSaveFile != null)
                {
                    swSaveFile.Close();
                }

                // Open nieuwe

                swSaveFile = clDashFunction.open4write(strSaveFile_Name);
                swSaveFile.WriteLine("*** Start logging (" + System.DateTime.Now + ") ***");
            }
            else
            {
                if (swSaveFile != null)
                {
                    swSaveFile.WriteLine("*** Resume logging (" + System.DateTime.Now + ") ***");
                }
            }

            // Reset de shadow tabs, anders zou het schrijven naar
            // de externe file mogelijk niet gebeuren omdat de Previous tabs
            // al gelijk kunnen zijn aan de Current shadow tabs.
            //
            // Immers: we hoeven niet direct al na het starten 
            // van deze exe de "SaveTo" actief te hebben gemaakt,
            // maar dit kan (veel) later worden gedaan
            alX400_Shadow_Tab_Previous = new ArrayList(6);
            alCore_Shadow_Tab_Previous = new ArrayList(8);
            alSMTP_Shadow_Tab_Previous = new ArrayList();

        }

        private void Reset_Save_Vars(string strSaveFile_Name)
        {
            lblSaveFile.Text = "not active";

            if (File.Exists(strSaveFile_Name))
            {
                if (swSaveFile != null)
                {
                    swSaveFile.WriteLine("*** Stop logging (" + System.DateTime.Now + ") ***");
                    swSaveFile.Close();
                    swSaveFile = null;
                }
            }
        }


        // Aftellen van het aantal seconden voordat een
        // volgende refresh gaat plaatsvinden. Het control
        // waarover het gaat wordt als Parm meegegeven.
        // Note: we ge/mis/bruiken het Tag attribute om te tellen
        private string NextRefresh(Control cLabel, Int16 intSubtractSecs)
        {
            cLabel.Tag = Convert.ToInt32(cLabel.Tag) - intSubtractSecs;
            return "Next refresh within: " + cLabel.Tag + " seconds";
        }
        // Effe overloaden voor de default keuze ( = -1 seconden )
        private string NextRefresh(Control cLabel)
        {
            return NextRefresh(cLabel, 1);
        }

        // Teruggeven van een (STD) tekst string met daarin een timestamp
        private string LastRefresh()
        {
            return "Last refreshed at: " + System.DateTime.Now.ToLongTimeString();
        }

        private void dgSMTPQ_BDR_SelectionChanged(object sender, EventArgs e)
        {
            dgSMTPQ_BDR.CurrentRow.Selected = false;
        }

        private void dgSMTPQ_OVH_SelectionChanged(object sender, EventArgs e)
        {
            dgSMTPQ_OVH.CurrentRow.Selected = false;
        }

        private void dgCoreQ_SelectionChanged(object sender, EventArgs e)
        {
            dgCoreQ.CurrentRow.Selected = false;
        }

        private void dgX400Q_OVH_SelectionChanged(object sender, EventArgs e)
        {
            dgX400Q_OVH.CurrentRow.Selected = false;
        }

        private void cmdAfsluiten_Click_1(object sender, EventArgs e)
        {
            // Als de Queuedata recording nog actief is, dan deze beëindigen.
            if (bSaveStarted)
            {
                Reset_Save_Vars(strSaveFile_Name);
            }
        }
        
        private void Write_Log_Record(string strLogRecord, int intFields)
        {
            int intQueueSizeGE0 = 0;
            int intQueueSizeGT0 = 0;
            int intQueueSizeLT0 = 0;

            // Let hier wordt gebruik gemaakt van de 'global' write filehandle "swSaveFile"
            if (swSaveFile != null)
            {

                int intQueueIndex = intFields + 1;
                if ((strLogRecord.Split('~').Length - 1) > intFields)
                {
                    int intQueueSize = Convert.ToInt32(strLogRecord.Split('~')[intQueueIndex]);

                    if (bRecordErrors == false && bRecordQueueOnly == false)
                    {
                        if (intQueueSize >= 0)
                        {
                            intQueueSizeGE0++;
                            swSaveFile.WriteLine(strLogRecord);
                        }
                    }

                    if (bRecordErrors == true && bRecordQueueOnly == false)
                    {
                        if (intQueueSize >= -1)
                        {
                            if (intQueueSize == -1)
                            {
                                intQueueSizeLT0++;
                                swSaveFile.WriteLine(strLogRecord + "Error");
                            }
                            else
                            {
                                intQueueSizeGE0++;
                                swSaveFile.WriteLine(strLogRecord);
                            }
                        }
                    }

                    if (bRecordErrors == false && bRecordQueueOnly == true)
                    {
                        if (intQueueSize >= 1)
                        {
                            intQueueSizeGT0++;
                            swSaveFile.WriteLine(strLogRecord);
                        }
                    }

                    if (bRecordErrors == true && bRecordQueueOnly == true)
                    {
                        if (intQueueSize != 0)
                        {
                            if (intQueueSize == -1)
                            {
                                intQueueSizeLT0++;
                                swSaveFile.WriteLine(strLogRecord + "Error");
                            }
                            else
                            {
                                intQueueSizeGT0++;
                                swSaveFile.WriteLine(strLogRecord);
                            }
                        }
                    }
                }
            }

            else
            {
                clDashFunction.Melding("Error: no opened (swSaveFile)filehandle to Preserve queue info !", 1, "E");
            }
        }

        private Boolean isDataChanged(string strAgeFirstRow, string strAgeLastRow, ArrayList alAge_BDR)
        {
            // Om overbodig werk en dubbele logrecords te voorkomen:
            // Controle of er wel refreshed en naar de externe logfile moet worden geschreven.
            // Dit wordt gedaan door te zien of 
            // - het aantal bestaande rijen gelijk is aan het aantal rows in de (nieuwe)Age array
            // - EN of de AGE van het eerste EN laatste record gelijk is tussen het datagrid en de Age array
            Boolean bRefresh = true;

            if (dgSMTPQ_BDR.Rows.Count == alAge_BDR.Count)
            {
                if (dgSMTPQ_BDR[4, 0].Value.ToString() == clDashFunction.fromS2DHMS(Convert.ToDouble(alAge_BDR[0]), false).ToString())
                {
                    if (dgSMTPQ_BDR[4, alAge_BDR.Count - 1].Value.ToString() == clDashFunction.fromS2DHMS(Convert.ToDouble(alAge_BDR[alAge_BDR.Count - 1]), false).ToString())
                    {
                        bRefresh = false;
                    }
                }
            }
            return bRefresh;
        }

        private void dgX400Q_BDR_SelectionChanged(object sender, EventArgs e)
        {
            dgX400Q_BDR.CurrentRow.Selected = false;
        }

        private void rbAutoUpdateOff_CheckedChanged(object sender, EventArgs e)
        {
            if (rbAutoUpdateOff.Checked)
            {
                auto_update_stop();
            }
        }

        private void rbAutoUpdateOn_CheckedChanged(object sender, EventArgs e)
        {
            if (rbAutoUpdateOn.Checked)
            {
                auto_update_start();
            }
        }

        private void cmbGroupSMTP_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Niet uitvoeren wanneer het form voor het eerst wordt geladen
            // andes wordt ( met name - get_SMTP_OUT_queues - ) dubbel uitgevoerd
            // en dat staat lelijk
            if (bDo_cmbGroupSMTP_SelectedIndexChanged)
            {
                if (cmbGroupSMTP.SelectedIndex != -1)
                {
                    check_SMTP_OUT(strQueueData_SMTP);
                    get_SMTP_OUT_queues(strQueueData_SMTP);
                }
            }
        }

        private void cmdDebug_Click(object sender, EventArgs e)
        {
            debug("RESET", false);
        }

        private void cmdManualUpdate_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;

            debug("Triggered: Manual refresh", false);
            refresh_queuedata();

            this.Cursor = Cursors.Default;
        }

        private void debug(string strMessage, Boolean bError)
        {
            if (cbDebug.Checked)
            {
                if (strMessage.ToUpper() == "RESET".ToUpper())
                {
                    lbDebug.Items.Clear();
                    debug_error(true);
                }
                else
                {
                    lbDebug.Items.Insert(0, System.DateTime.Now + " - " + strMessage);
                    if (bError)
                    {
                        debug_error(false);
                    }
                }
            }
        }

        private void debug_error(Boolean bReset)
        {
            if (bReset)
            {
                intDebugErrors = 0;
            }
            else
            {
                intDebugErrors++;
            }
            lblDebugError_val.Text = Convert.ToString(intDebugErrors);
        }

        private void cmdDebugLog_Toggle_Click(object sender, EventArgs e)
        {
            String[] strLogText = new String[2];

            strLogText[0] = "Show logwindow";
            strLogText[1] = "Hide logwindow";

            grbLog.Visible = !grbLog.Visible;
            grbDigipoort.Visible = !grbLog.Visible;
            cbDebug.Visible = !cbDebug.Visible;
            cmdDebugLog_Toggle.Text = strLogText[Convert.ToInt64(grbLog.Visible)];
        }

        private void frmDashQueue_Resize(object sender, EventArgs e)
        {

            // Control control = (Control)sender;

            // Ensure the Form remains square (Height = Width). 
            // if (control.Size.Height != control.Size.Width)
            // {
            //     control.Size = new Size(control.Size.Width, control.Size.Width);
            // }
        }

        /*
        private Chart Get_SMTPQ_BDR_Chart()
        {
            Chart chart = null;
            
            try
            {
                pnSMTPQ_BDR.Controls.Clear();

                DataTable dt = new DataTable();
                dt.Columns.Add("Queuesize", typeof(int));
                                
                int i = 0;
                while (i < lbSMTPQ_BDR.Items.Count)
                {
                    lbSMTPQ_BDR.SelectedIndex = i;

                    dt.Rows.Add(Convert.ToInt32(lbSMTPQ_BDR.Text));
                    i++;
                }
                WindowsCharting charting = new WindowsCharting();
                chart = charting.GenerateChart(dt, pnSMTPQ_BDR.Width, pnSMTPQ_BDR.Height, "FloralWhite", 3);
            }
            catch (Exception exp)
            {
                throw exp;
            }
            finally
            {
                //do nothing
            }
            return chart;
        }

        private Chart Get_CoreQ_Chart()
        {
            Chart chart = null;

            try
            {
                pnCoreQ.Controls.Clear();

                DataTable dt = new DataTable();
                dt.Columns.Add("QueuesizeS", typeof(int));
                dt.Columns.Add("QueuesizeX", typeof(int));
                int i = 0;
                while (i < lbCoreQ.Items.Count)
                {
                    lbCoreQ.SelectedIndex = i;
                    // hier de string uit de listbox weer splitsen in occ[0] = SMTP, en occ[1] = X400
                    string[] alCoreq = Regex.Split(lbCoreQ.Text, "~");
                    dt.Rows.Add(Convert.ToInt32(alCoreq[0]),Convert.ToInt32(alCoreq[1]));
                    i++;
                }
                WindowsCharting charting = new WindowsCharting();
                chart = charting.GenerateChart(dt, pnCoreQ.Width, pnCoreQ.Height, "FloralWhite", 3);
            }
            catch (Exception exp)
            {
                throw exp;
            }
            finally
            {
                //do nothing
            }
            return chart;
        }

       */

        private ArrayList Save_Log_Record(string strKoppelvlak, ArrayList alCurrent, ArrayList alPrevious)
        {
            /////////////////////////////////////////////////////////////////////////////
            // Als de "Queuedata recording" aanstaat, dan worden alleen de wijzigingen
            // ten opzichte van de vorige refresh weggeschreven. Dit gebeurt door de 
            // entries in de CURRENT tab te vergelijken met die in de PREVIOUS
            //
            // Voor ELKE entry in de CURRENT tab worden
            //      ALLE entries in de PREVIOUS tab doorlopen
            //
            /////////////////////////////////////////////////////////////////////////////

            Boolean bFoundInPrevious = false;
            int intRecs2bWritten = 0;
            int intRecs2bIgnored = 0;

            int int_Tab_Current_Count = 0;
            string strLogRecord;
            while (int_Tab_Current_Count < alCurrent.Count)
            {

                int int_Tab_Previous_Count = 0;
                while (int_Tab_Previous_Count < alPrevious.Count)
                {

                    if (alCurrent[int_Tab_Current_Count].ToString() == alPrevious[int_Tab_Previous_Count].ToString())
                    {
                        bFoundInPrevious = true;
                        break;
                    }

                    int_Tab_Previous_Count++;
                }

                if (!bFoundInPrevious)
                {
                    strLogRecord = alCurrent[int_Tab_Current_Count].ToString();

                    string strId = strLogRecord.Split('~')[2];

                    switch (strId.ToUpper())
                    {
                        case "SMTP_OUT_BDR":
                            Write_Log_Record(strLogRecord, 4);
                            break;
                        case "SMTP_OUT_OVH":
                            Write_Log_Record(strLogRecord, 4);
                            break;
                        default:
                            Write_Log_Record(strLogRecord, 3);
                            break;
                    }
                    intRecs2bWritten++;
                    debug("External write (" + strId + ") logrecord", false);
                }
                else
                {
                    intRecs2bIgnored++;
                }
                int_Tab_Current_Count++;
                bFoundInPrevious = false;
            }

            debug("Totals for -" + strKoppelvlak + "- in RTN Save_Log_Record. Written: " + intRecs2bWritten.ToString() + " Ignored: " + intRecs2bIgnored.ToString(), false);
            return alCurrent;
        }

        private void cmbEnv_SelectedIndexChanged(object sender, EventArgs e)
        {
            mdiDashboard.strEnv = alEnvironment_Code[cmbEnv.SelectedIndex].ToString();
            Change_Env(mdiDashboard.strEnv);
            if (cmbEnv.Tag.ToString().Trim() == "")
            {
                cmdManualUpdate_Click(new Object(), new EventArgs());
            }
        }

        /// <summary>
        /// Als -via de combobox- voor een andere environment wordt gekozen, dan wordt dat
        /// technisch vertaald door de inhoud van het bestandje env.env te wijzigen, en 
        /// dat gebeurt met behulp van de Write2File functie
        /// </summary>
        private void Change_Env(string strEnv_Parm)
        {
            clDashFunction.Write2File(strEnv_Parm, mdiDashboard.strEnv_Loc, false);
        }

        private void frmDashQueue_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Mocht er nog een actieve SAVE to logfile lopen, dan deze 'netjes' afsluiten
            // anders lopen we het risico dat we alle logrecords kwijt zijn die nog in memory staan.
            // Had dit liever wat generieker opgelost.....
            Reset_Save_Vars(strSaveFile_Name);
        }

        /// <summary>
        /// Vul 2 arrays op basis van Digipoort server tabel 12 in DashElem:
        /// array 1: servernamen
        /// array 2: omgeving waar de server uit 1: bij hoort.
        /// </summary>
        private void get_Digipoort_Servers()
        {
            
            int intIndexOfAddedServer;

            strNagios = "";

            DoSql mySql = new DoSql();
            mySql.vul_deze_text1_array[1] = "FTA";

            mySql.DoQuery("SELECT   ElemElem, ElemOms1, ElemOms2 " +
                          "FROM     DashElem " +
                          "WHERE    ElemTabn = 12 " +
                          "ORDER BY ElemOms2, ElemElem");

            if (mySql.affected_rows < 1)
            {
                clDashFunction.Melding("Geen Digipoort servers gedefinieerd in tabel 12", 1, "I");
            }

            for (int intServersVerwerkt = 1; intServersVerwerkt < mySql.vul_deze_text1_array.Length; intServersVerwerkt++)
            {
                if (mySql.vul_deze_text1_array[intServersVerwerkt] == null)
                {
                    break;
                }

                // Afhandeling 'gewone' servers
                intIndexOfAddedServer = alDigipoort_Server.Add(mySql.vul_deze_text1_array[intServersVerwerkt].Trim().ToUpper());
                intIndexOfAddedServer = alDigipoort_Env.Add(mySql.vul_deze_text3_array[intServersVerwerkt].Trim().ToUpper());

                // en dit stukje is in feite alleen maar om de strNagios te vullen met:
                // 1e loop: "kslv114"
                // 2e loop: "kslv114;kslv115" 
                if (alDigipoort_Env[intIndexOfAddedServer].ToString().ToUpper().Trim().IndexOf("nagios".ToUpper().Trim()) != -1)
                {
                    if (strNagios == "")
                    {
                        strNagios = alDigipoort_Server[intIndexOfAddedServer].ToString();
                    }
                    else
                    {
                        strNagios = strNagios + ";" + alDigipoort_Server[intIndexOfAddedServer].ToString();
                    }
                }
            }
        }

        /// <summary>
        /// Returns TRUE als ALL(es) is gekozen als omgeving
        /// // Of
        /// Returns FALSE of TRUE als strServer in de gekozen omgeving zit
        /// 1: Zoek index van strServer op in alDigipoort_Server
        /// 2: Vergelijk de gekozen omgeving volgens cmbENV met de corresponderende omgeving in alDigipoort_Env[index uit 1:]
        /// </summary>
        /// <param name="strServer"></param>
        /// <returns></returns>
        private Boolean isServerInChoosenEnv(string strServer)
        {
            Boolean bResult = false;

            if (cmbEnv.Text.ToUpper().Trim().IndexOf("ALL") != -1)
            {
                bResult = true;
            }
           
            int intIndexVanServerInArray = alDigipoort_Server.IndexOf(strServer.Trim().ToUpper());
            if (intIndexVanServerInArray != -1)
            {
                if (alDigipoort_Env[intIndexVanServerInArray].ToString() == cmbEnv.Text.Trim().ToUpper())
                {
                    bResult = true;
                }
            }

            return bResult;
        }           
    }
}


