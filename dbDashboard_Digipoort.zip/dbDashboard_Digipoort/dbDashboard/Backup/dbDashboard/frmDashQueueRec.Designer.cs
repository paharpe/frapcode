﻿namespace dbDashboard
{
    partial class frmDashQueueRec
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDashQueueRec));
            this.grpRecord = new System.Windows.Forms.GroupBox();
            this.grbRecord2File = new System.Windows.Forms.GroupBox();
            this.cmdViewLogfile = new System.Windows.Forms.Button();
            this.cmdGenerate_logfile_name = new System.Windows.Forms.Button();
            this.txtRecord2File = new System.Windows.Forms.TextBox();
            this.lblRecord2File = new System.Windows.Forms.Label();
            this.pbQueueRec = new System.Windows.Forms.PictureBox();
            this.grbRecordOptions = new System.Windows.Forms.GroupBox();
            this.cbX400Q_BDR = new System.Windows.Forms.CheckBox();
            this.cbX400Q_OVH = new System.Windows.Forms.CheckBox();
            this.cbCoreQ = new System.Windows.Forms.CheckBox();
            this.cbSMTPQ_OVH = new System.Windows.Forms.CheckBox();
            this.cbSMTPQ_BDR = new System.Windows.Forms.CheckBox();
            this.cbRecordQueueOnly = new System.Windows.Forms.CheckBox();
            this.cmdOK = new System.Windows.Forms.Button();
            this.cbRecordErrors = new System.Windows.Forms.CheckBox();
            this.grbConnectie.SuspendLayout();
            this.grpRecord.SuspendLayout();
            this.grbRecord2File.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbQueueRec)).BeginInit();
            this.grbRecordOptions.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmdAfsluiten
            // 
            this.cmdAfsluiten.Location = new System.Drawing.Point(84, 320);
            this.cmdAfsluiten.Text = "Cancel";
            this.cmdAfsluiten.Click += new System.EventHandler(this.cmdAfsluiten_Click_1);
            // 
            // grpRecord
            // 
            this.grpRecord.Controls.Add(this.cbRecordErrors);
            this.grpRecord.Controls.Add(this.grbRecord2File);
            this.grpRecord.Controls.Add(this.pbQueueRec);
            this.grpRecord.Controls.Add(this.grbRecordOptions);
            this.grpRecord.Controls.Add(this.cbRecordQueueOnly);
            this.grpRecord.Location = new System.Drawing.Point(6, 12);
            this.grpRecord.Name = "grpRecord";
            this.grpRecord.Size = new System.Drawing.Size(706, 302);
            this.grpRecord.TabIndex = 21;
            this.grpRecord.TabStop = false;
            this.grpRecord.Text = "Queue data recording";
            // 
            // grbRecord2File
            // 
            this.grbRecord2File.Controls.Add(this.cmdViewLogfile);
            this.grbRecord2File.Controls.Add(this.cmdGenerate_logfile_name);
            this.grbRecord2File.Controls.Add(this.txtRecord2File);
            this.grbRecord2File.Controls.Add(this.lblRecord2File);
            this.grbRecord2File.Location = new System.Drawing.Point(21, 189);
            this.grbRecord2File.Name = "grbRecord2File";
            this.grbRecord2File.Size = new System.Drawing.Size(676, 102);
            this.grbRecord2File.TabIndex = 6;
            this.grbRecord2File.TabStop = false;
            this.grbRecord2File.Text = "Logfile";
            // 
            // cmdViewLogfile
            // 
            this.cmdViewLogfile.Location = new System.Drawing.Point(9, 76);
            this.cmdViewLogfile.Name = "cmdViewLogfile";
            this.cmdViewLogfile.Size = new System.Drawing.Size(126, 23);
            this.cmdViewLogfile.TabIndex = 6;
            this.cmdViewLogfile.Text = "View logfile";
            this.cmdViewLogfile.UseVisualStyleBackColor = true;
            this.cmdViewLogfile.Click += new System.EventHandler(this.cmdViewLogfile_Click);
            // 
            // cmdGenerate_logfile_name
            // 
            this.cmdGenerate_logfile_name.Location = new System.Drawing.Point(9, 47);
            this.cmdGenerate_logfile_name.Name = "cmdGenerate_logfile_name";
            this.cmdGenerate_logfile_name.Size = new System.Drawing.Size(126, 23);
            this.cmdGenerate_logfile_name.TabIndex = 4;
            this.cmdGenerate_logfile_name.Text = "Generate logfilename";
            this.cmdGenerate_logfile_name.UseVisualStyleBackColor = true;
            this.cmdGenerate_logfile_name.Click += new System.EventHandler(this.cmdGenerate_logfile_name_Click);
            // 
            // txtRecord2File
            // 
            this.txtRecord2File.BackColor = System.Drawing.SystemColors.MenuBar;
            this.txtRecord2File.Enabled = false;
            this.txtRecord2File.Location = new System.Drawing.Point(65, 19);
            this.txtRecord2File.Name = "txtRecord2File";
            this.txtRecord2File.Size = new System.Drawing.Size(601, 20);
            this.txtRecord2File.TabIndex = 5;
            this.txtRecord2File.TextChanged += new System.EventHandler(this.txtRecord2File_TextChanged);
            // 
            // lblRecord2File
            // 
            this.lblRecord2File.AutoSize = true;
            this.lblRecord2File.Location = new System.Drawing.Point(6, 22);
            this.lblRecord2File.Name = "lblRecord2File";
            this.lblRecord2File.Size = new System.Drawing.Size(57, 13);
            this.lblRecord2File.TabIndex = 0;
            this.lblRecord2File.Text = "Record to:";
            // 
            // pbQueueRec
            // 
            this.pbQueueRec.Image = ((System.Drawing.Image)(resources.GetObject("pbQueueRec.Image")));
            this.pbQueueRec.Location = new System.Drawing.Point(610, 19);
            this.pbQueueRec.Name = "pbQueueRec";
            this.pbQueueRec.Size = new System.Drawing.Size(87, 87);
            this.pbQueueRec.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbQueueRec.TabIndex = 3;
            this.pbQueueRec.TabStop = false;
            // 
            // grbRecordOptions
            // 
            this.grbRecordOptions.Controls.Add(this.cbX400Q_BDR);
            this.grbRecordOptions.Controls.Add(this.cbX400Q_OVH);
            this.grbRecordOptions.Controls.Add(this.cbCoreQ);
            this.grbRecordOptions.Controls.Add(this.cbSMTPQ_OVH);
            this.grbRecordOptions.Controls.Add(this.cbSMTPQ_BDR);
            this.grbRecordOptions.Location = new System.Drawing.Point(15, 28);
            this.grbRecordOptions.Name = "grbRecordOptions";
            this.grbRecordOptions.Size = new System.Drawing.Size(195, 155);
            this.grbRecordOptions.TabIndex = 2;
            this.grbRecordOptions.TabStop = false;
            this.grbRecordOptions.Text = "Options";
            // 
            // cbX400Q_BDR
            // 
            this.cbX400Q_BDR.AutoSize = true;
            this.cbX400Q_BDR.Location = new System.Drawing.Point(17, 93);
            this.cbX400Q_BDR.Name = "cbX400Q_BDR";
            this.cbX400Q_BDR.Size = new System.Drawing.Size(134, 17);
            this.cbX400Q_BDR.TabIndex = 4;
            this.cbX400Q_BDR.Text = "X400 waiting Bedrijven";
            this.cbX400Q_BDR.UseVisualStyleBackColor = true;
            this.cbX400Q_BDR.CheckedChanged += new System.EventHandler(this.cbX400Q_BDR_CheckedChanged);
            // 
            // cbX400Q_OVH
            // 
            this.cbX400Q_OVH.AutoSize = true;
            this.cbX400Q_OVH.Location = new System.Drawing.Point(17, 116);
            this.cbX400Q_OVH.Name = "cbX400Q_OVH";
            this.cbX400Q_OVH.Size = new System.Drawing.Size(133, 17);
            this.cbX400Q_OVH.TabIndex = 0;
            this.cbX400Q_OVH.Text = "X400 waiting Overheid";
            this.cbX400Q_OVH.UseVisualStyleBackColor = true;
            this.cbX400Q_OVH.CheckedChanged += new System.EventHandler(this.cbX400Q_OVH_CheckedChanged);
            // 
            // cbCoreQ
            // 
            this.cbCoreQ.AutoSize = true;
            this.cbCoreQ.Location = new System.Drawing.Point(17, 70);
            this.cbCoreQ.Name = "cbCoreQ";
            this.cbCoreQ.Size = new System.Drawing.Size(131, 17);
            this.cbCoreQ.TabIndex = 3;
            this.cbCoreQ.Text = "Incomming Core traffic";
            this.cbCoreQ.UseVisualStyleBackColor = true;
            this.cbCoreQ.CheckedChanged += new System.EventHandler(this.cbCoreQ_CheckedChanged);
            // 
            // cbSMTPQ_OVH
            // 
            this.cbSMTPQ_OVH.AutoSize = true;
            this.cbSMTPQ_OVH.Location = new System.Drawing.Point(17, 47);
            this.cbSMTPQ_OVH.Name = "cbSMTPQ_OVH";
            this.cbSMTPQ_OVH.Size = new System.Drawing.Size(147, 17);
            this.cbSMTPQ_OVH.TabIndex = 2;
            this.cbSMTPQ_OVH.Text = "SMTP queue to Overheid";
            this.cbSMTPQ_OVH.UseVisualStyleBackColor = true;
            this.cbSMTPQ_OVH.CheckedChanged += new System.EventHandler(this.cbSMTPQ_OVH_CheckedChanged);
            // 
            // cbSMTPQ_BDR
            // 
            this.cbSMTPQ_BDR.AutoSize = true;
            this.cbSMTPQ_BDR.Location = new System.Drawing.Point(17, 24);
            this.cbSMTPQ_BDR.Name = "cbSMTPQ_BDR";
            this.cbSMTPQ_BDR.Size = new System.Drawing.Size(151, 17);
            this.cbSMTPQ_BDR.TabIndex = 1;
            this.cbSMTPQ_BDR.Text = "SMTP queue to  Bedrijven";
            this.cbSMTPQ_BDR.UseVisualStyleBackColor = true;
            this.cbSMTPQ_BDR.CheckedChanged += new System.EventHandler(this.cbSMTPQ_BDR_CheckedChanged);
            // 
            // cbRecordQueueOnly
            // 
            this.cbRecordQueueOnly.AutoSize = true;
            this.cbRecordQueueOnly.Location = new System.Drawing.Point(216, 134);
            this.cbRecordQueueOnly.Name = "cbRecordQueueOnly";
            this.cbRecordQueueOnly.Size = new System.Drawing.Size(265, 17);
            this.cbRecordQueueOnly.TabIndex = 0;
            this.cbRecordQueueOnly.Text = "Only save queue records containing queuesize > 0";
            this.cbRecordQueueOnly.UseVisualStyleBackColor = true;
            this.cbRecordQueueOnly.CheckedChanged += new System.EventHandler(this.cbRecordQueueOnly_CheckedChanged);
            // 
            // cmdOK
            // 
            this.cmdOK.Location = new System.Drawing.Point(6, 320);
            this.cmdOK.Name = "cmdOK";
            this.cmdOK.Size = new System.Drawing.Size(75, 23);
            this.cmdOK.TabIndex = 22;
            this.cmdOK.Text = "OK";
            this.cmdOK.UseVisualStyleBackColor = true;
            this.cmdOK.Click += new System.EventHandler(this.cmdOK_Click);
            // 
            // cbRecordErrors
            // 
            this.cbRecordErrors.AutoSize = true;
            this.cbRecordErrors.Location = new System.Drawing.Point(216, 166);
            this.cbRecordErrors.Name = "cbRecordErrors";
            this.cbRecordErrors.Size = new System.Drawing.Size(297, 17);
            this.cbRecordErrors.TabIndex = 7;
            this.cbRecordErrors.Text = "Error lines ( in cases queue size could not be determined )";
            this.cbRecordErrors.UseVisualStyleBackColor = true;
            this.cbRecordErrors.CheckedChanged += new System.EventHandler(this.cbRecordErrors_CheckedChanged);
            // 
            // frmDashQueueRec
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(720, 355);
            this.Controls.Add(this.grpRecord);
            this.Controls.Add(this.cmdOK);
            this.Name = "frmDashQueueRec";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "frmDashQueueRec";
            this.Load += new System.EventHandler(this.frmDashQueueRec_Load);
            this.Controls.SetChildIndex(this.cmdAfsluiten, 0);
            this.Controls.SetChildIndex(this.cmdOK, 0);
            this.Controls.SetChildIndex(this.grpRecord, 0);
            this.Controls.SetChildIndex(this.grbConnectie, 0);
            this.Controls.SetChildIndex(this.lblVoortgang, 0);
            this.grbConnectie.ResumeLayout(false);
            this.grbConnectie.PerformLayout();
            this.grpRecord.ResumeLayout(false);
            this.grpRecord.PerformLayout();
            this.grbRecord2File.ResumeLayout(false);
            this.grbRecord2File.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbQueueRec)).EndInit();
            this.grbRecordOptions.ResumeLayout(false);
            this.grbRecordOptions.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpRecord;
        private System.Windows.Forms.GroupBox grbRecordOptions;
        private System.Windows.Forms.CheckBox cbRecordQueueOnly;
        private System.Windows.Forms.Label lblRecord2File;
        private System.Windows.Forms.Button cmdOK;
        private System.Windows.Forms.PictureBox pbQueueRec;
        private System.Windows.Forms.CheckBox cbSMTPQ_OVH;
        private System.Windows.Forms.CheckBox cbSMTPQ_BDR;
        private System.Windows.Forms.CheckBox cbX400Q_OVH;
        private System.Windows.Forms.CheckBox cbCoreQ;
        private System.Windows.Forms.Button cmdGenerate_logfile_name;
        private System.Windows.Forms.GroupBox grbRecord2File;
        private System.Windows.Forms.TextBox txtRecord2File;
        private System.Windows.Forms.Button cmdViewLogfile;
        private System.Windows.Forms.CheckBox cbX400Q_BDR;
        private System.Windows.Forms.CheckBox cbRecordErrors;
    }
}