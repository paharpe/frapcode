﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text.RegularExpressions;
using System.Text; // Voor de stringbuilder
using System.Windows.Forms;
using System.Collections;
using System.IO;

namespace dbDashboard
{
    public partial class frmDashRelMenu : frmDashBase
    {       
        private Boolean     bItemIsDropped       = false;       
        private int[]       intMenu_level        = new int[4];
        private TreeNode    tnHover_node         = null;
        private Boolean     btvMenustrip_shown   = false;
        private string      strRootNode_name     = "Systeem";
        private string      strRootNode_key      = "0,0,0,0";
        private int         intlbUgro_save_Index = -1;
        private ArrayList   alTreeNodes          = new ArrayList();
    
        public frmDashRelMenu()
        {
            InitializeComponent();
        }

        private void DashRelMenu_Load(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            init_form();
            this.Cursor = Cursors.Default;
        }

        private void init_form()
        {         
            // **********************************************
            // Remove bepaalde controls vanuit het base form
            // **********************************************
            clDashFunction.remove_inherited_control(this, "toolstrip1");
            
            DoSql mysql = new DoSql();
            mysql.vul_deze_text1_array[1] = "FTA";
            mysql.DoQuery(  "SELECT ElemOms1, ElemOms2,'DUMMY' "+
                            "FROM   DashElem "+
                            "WHERE  ElemTabn = 10 "+
                            "AND    ElemElem = 'ROOTNODE'");
            if (mysql.affected_rows == 0)
            {
                clDashFunction.Melding("Rootnode NAME en KEY ( Systeem 0,0,0,0 ) ontbreken !", 1, "E");
                return;
            }
            else
            {
                strRootNode_name = mysql.vul_deze_text1_array[1];
                strRootNode_key = mysql.vul_deze_text2_array[1];
            }

            mysql.vul_deze_text1_array[1] = null;
            mysql.vul_deze_listbox = lbUgro;
            mysql.DoQuery(" SELECT  UgroCode " +
                            "FROM   DashUgro " +
                            "ORDER BY UgroCode ");
            if (mysql.affected_rows == 0)
            {
                clDashFunction.Melding("Geen usergroepen geselecteerd", 1, "E");
                return;
            }
            
            this.tvMenu.ItemDrag  += new System.Windows.Forms.ItemDragEventHandler(this.tvMenu_ItemDrag);
            this.tvMenu.DragEnter += new System.Windows.Forms.DragEventHandler(this.tvMenu_DragEnter);
            this.tvMenu.DragDrop  += new System.Windows.Forms.DragEventHandler(this.tvMenu_DragDrop);

            bChanged        = false;
            grpMenu.Enabled = false;
            GrpSubs.Enabled = false;
            setLb2TvButtons();
        }           
        #region Mousezooi
        private void lbSubs_MouseDown(object sender, MouseEventArgs e)
        {         
            int indexOfItem = lbSubs.IndexFromPoint(e.X, e.Y);
            if(indexOfItem >= 0 && indexOfItem < lbSubs.Items.Count)  // check we clicked down on a string
            {
                // Set allowed DragDropEffect to Copy selected 
                // from DragDropEffects enumberation of None, Move, All etc.
                lbSubs.DoDragDrop(lbSubs.Items[indexOfItem], DragDropEffects.Copy );
            }           
        }

        private void tvMenu_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Move;            
		}

        private void tvMenu_DragOver(object sender, DragEventArgs e)
        {
            bItemIsDropped = false;
        }       

        private void tvMenu_DragDrop(object sender, DragEventArgs e)
        {
            // Deze constructie om te voorkomen dat het DragDrop event zichzelf
            // weer aanroept.
            if (bItemIsDropped)
            {
                return;
            }
            bItemIsDropped = true;
            
            TreeNode NewNode;

            if (e.Data.GetDataPresent("System.Windows.Forms.TreeNode", false))
            {
                Point pt = ((TreeView)sender).PointToClient(new Point(e.X, e.Y));
                TreeNode DestinationNode = ((TreeView)sender).GetNodeAt(pt);
              
                if (DestinationNode.Level == 4)
                {
                    clDashFunction.Melding("Maximaal 4 menu niveaus toegestaan !");
                    return;
                }
                NewNode = (TreeNode)e.Data.GetData("System.Windows.Forms.TreeNode");
                if (NewNode.Text == strRootNode_name)
                {
                    clDashFunction.Melding("Rootnode kan niet worden verplaatst", 1, "I");
                    return;
                }
                // Als we dit niet doen verdwijnt de node ins blauwe hinein.....
                if (DestinationNode.Text == NewNode.Text)
                {
                    bChanged = true;
                    setLb2TvButtons();
                    return;
                }
                // MessageBox.Show(DestinationNode.Text);
                DestinationNode.Nodes.Add((TreeNode)NewNode.Clone());
               
                DestinationNode.Expand();
                
                NewNode.Remove();
                
                bChanged = true;
                
                setLb2TvButtons();
            }
        }  
        
        private void tvMenu_ItemDrag(object sender, System.Windows.Forms.ItemDragEventArgs e)
        {
            DoDragDrop(e.Item, DragDropEffects.Move);
        }
     
        private void tvMenu_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right && tnHover_node != null)
            {
                tvMenu.SelectedNode = tnHover_node;
            }
        }
        
        #endregion

        private void cmdReset_Click(object sender, EventArgs e)
        {           
            if (bChanged)
            {
                if (clDashFunction.Melding("Deze menu-indeling is gewijzigd ! Doorgaan met reset ?", 4, "Q") == DialogResult.Yes)
                {
                    tvMenu.Nodes.Clear();
                    init_form();
                    lbSubs.Items.Clear();
                    lbUgro.SelectedIndex = intlbUgro_save_Index;
                }
            }           
        }

        private void cmdOpslaan_Click(object sender, EventArgs e)
        {
            Opslaan();
        }
               
        private void Opslaan()
        {
            this.Cursor = Cursors.WaitCursor;

            string strUgss_verwijderd = null;
            // string strUgss_geschreven = null;

            // Eerst bestaande records verwijderen alvorens geheel nieuwe
            // menu indeling te gaan schrijven..

            DoSql mysql = new DoSql();

            // Het opslaan is nogal een gelazer...
            // Eerst gaan we de NIET geselecteerde items ( die dus in de listbox staan )
            // weggooien uit DashGsfu; voorzover die bestaan. Eerst een select om de DELETE niet te 
            // laten crashen als er geen entry is.
            for (int i = 0; i < lbSubs.Items.Count; i++)
            {
                mysql.vul_deze_string = "";
                mysql.DoQuery("SELECT 1 " +
                              "FROM DashGsFu " +
                              "WHERE GsFuSubs ='" + lbSubs.Items[i].ToString() + "' " +
                              "AND   GsFuUgro ='" + lblUgro_value.Text + "'");
                if (mysql.affected_rows > 0)
                {   
                    mysql.DoUpdate("DELETE FROM DashGsfu " +
                                   "WHERE  GsFuUgro = '" + lblUgro_value.Text + "' " +
                                   "AND    GsFuSubs = '" + lbSubs.Items[i].ToString()+"'");
                }
            }
            // Daarna ALLES weggooien uit DashUgss, en vervolgens alles weer toevoegen wat
            // nog in de treeview staat....
            mysql.DoUpdate(" DELETE FROM DashUgss " +
                           " WHERE UgssUgro = '" + lblUgro_value.Text + "'");
            strUgss_verwijderd = mysql.affected_rows.ToString();


            intMenu_level[0] = -1;
            for (int i = 1; i <= 3; i++)
            {
                intMenu_level[i] = 0;
            }

            foreach (TreeNode rootNode in tvMenu.Nodes)
            {
                ParseNode(rootNode);
            }

            bChanged = false;
            tvMenu.SelectedNode = null;
            setLb2TvButtons();
            this.Cursor  = Cursors.Default;
        }

        private void ParseNode(TreeNode node)
        {
            if (node.Level == 0)
            {
                intMenu_level[0] = 0;
                intMenu_level[1] = 0;
                intMenu_level[2] = 0;
                intMenu_level[3] = 0;
            }

            else
            {
                for (int i = node.Level - 1; i < 4; i++)
                {
                    if (i==node.Level-1)
                    {
                        intMenu_level[i]++;
                    }
                    else
                    {
                        intMenu_level[i] = 0;
                    }
                }
            }
            DoSql mysql = new DoSql();

            // Sleutel voor DashUgss samenstellen....
            string strUgssUgro = lblUgro_value.Text;
            string strUgssSubs = node.Text;
            string strUgssVolg = intMenu_level[0].ToString() + "," +
                                 intMenu_level[1].ToString() + "," +
                                 intMenu_level[2].ToString() + "," +
                                 intMenu_level[3].ToString();            

            mysql.DoUpdate("INSERT INTO DashUgss "+
                "( UgssUgro, UgssSubs, UgssVolg, UgssCdat, UgssCtyd, UgssCusr, "+
                "  UgssMdat, UgssMtyd, UgssMusr ) " +
                " VALUES( '" + strUgssUgro + "'"+
                        ",'" + strUgssSubs + "'"+
                        ",'" + strUgssVolg + "'"+
                        ",'" + clDashFunction.get_mutdatum() + "'" +
                        ",'" + clDashFunction.get_muttijd()  + "'" +
                        ",'" + strUserCode + "'" +
                        ",'" + clDashFunction.get_mutdatum() + "'" +
                        ",'" + clDashFunction.get_muttijd()  + "'" +
                        ",'" + strUserCode + "')");
            // MessageBox.Show(strUgssUgro + "-" + strUgssSubs + "-" + strUgssVolg);
            
            foreach (TreeNode child in node.Nodes)
            {                
                ParseNode(child);
            }
        }

        private void lbUgro_SelectedIndexChanged(object sender, EventArgs e)
        {   
            if (lbUgro.SelectedItem != null)
            {
                intlbUgro_save_Index = lbUgro.SelectedIndex; // Bewaren voor eventuele reset actie
                lblUgro_value.Text = lbUgro.SelectedItem.ToString();
                bouw_treeview(lbUgro.SelectedItem.ToString());
                setLb2TvButtons();
                grpMenu.Enabled = true;
                GrpSubs.Enabled = true;
            }
        }

        private void bouw_treeview(string strUserUgro)
        {
            DoSql mysql = new DoSql();

            mysql.vul_deze_listbox = lbSubs;
            mysql.DoQuery(" SELECT L.* "+ 
                          " FROM DashSubs AS L "+ 
                          " WHERE NOT EXISTS ( "+ 
                              " SELECT 1 "+ 
                              " FROM  DashUgss M "+
                              " WHERE M.UgssUgro = '"+strUserUgro + "'" + 
                              " AND   M.UgssSubs = L.SubsNaam )" +
                          " AND SubsNaam <> '"+strRootNode_name+"'" );
            lblUgro_text.Visible     = true;
            lblUgro_value.Visible    = true;
            lblUgro_label.Visible    = true;
            lblFunc_Instruct.Visible = true;
                
            TreeNode tnSysteem = null;
            tvMenu.Nodes.Clear();
            mysql.vul_deze_listbox  = null;
            mysql.affected_rows     = 0;
            mysql.vul_deze_text1_array[1] = "FTA";
            mysql.DoQuery("SELECT   UgssVolg, UgssSubs, 'DUMMY'" +
                          "FROM     DashUgss " +
                          "WHERE    UgssUgro = '" + strUserUgro + "' " +
                          "ORDER BY UgssVolg ");
            
            // Alle geselecteerde menuitems doorlopen van ( occ 0 = altijd null )
            for (int i = 1; i <= mysql.affected_rows; i++)
            {
                string strNodeVolg = mysql.vul_deze_text1_array[i];
                string strNodeNaam = mysql.vul_deze_text2_array[i];
                // string strUgssPkey = mysql.vul_deze_text3_array[i];

                int intlbItem_found=lbSubs.FindStringExact(strNodeNaam);
                if (intlbItem_found >= 0)
                {                    
                    lbSubs.Items.RemoveAt(intlbItem_found);
                }

                // Nodevolgnummer ( 1,0,0,0 ) in array[0-3] zetten
                string[] arNodeLvl = Regex.Split(strNodeVolg, ",");

                // Alle geselecteerde menuitems doorlopen van N naar 1 ( occ 0 = altijd null )
                for (int j = arNodeLvl.Length - 1; j >= 0; j--)
                {
                    int intNodeNivoMin1 = Convert.ToInt16(arNodeLvl[j]);
                    // ***************************
                    // AFHANDELING SUBSUBSUB NODES
                    // ***************************
                    // Als op de NIET 1e positie van het volgnummer een "getal" staat dat
                    // groter is dan 0, dan hebben we een te maken met een sub(sub(sub))
                    // We moeten nu zijn "parent" zoeken:
                    // Bijvoorbeeld volgnr = 5,1,0,0, dan gaan we zoeken naar 5,0,0,0 Dit nummer wordt
                    // gecomponeerd in strSearchNode
                    if (j > 0 && arNodeLvl[j] != "0")
                    {
                        arNodeLvl[j] = "0";
                        string strSearchNode = arNodeLvl[0] + "," +
                                               arNodeLvl[1] + "," +
                                               arNodeLvl[2] + "," +
                                               arNodeLvl[3];

                        // Doorzoek de hele boom, hij MOET gevonden worden, anders klopt de menutabel
                        // in de database niet.....
                        TreeNode[] tnFound = tvMenu.Nodes.Find(strSearchNode, true);
                        // Omdat we bij een gevonden geval de hele "tak" meekrijgen is dit een 
                        // array. De nieuwe node moet als subnode worden toegevoegd aan het laatste
                        // item uit de "tak" (de search was immers naar de "vader" die 1 niveau hoger
                        // in de boom zit) vandaar onderstaande index constructie.
                        TreeNode tnNew = tnFound[tnFound.Length - 1].
                                         Nodes.Add(strNodeVolg, strNodeNaam);                      
                        tnNew.Tag = lblUgro_value.Text + "@" + strNodeNaam;
                        break;
                    }

                    // ***************************************
                    // afhandeling rootnode SYSTEEM (0,0,0,0)
                    // EN DE NODES DAAR direct onder
                    // ****************************************
                    else
                    {
                        if (j == 0)
                        {
                            if (tnSysteem == null)
                            {
                                TreeNode tnNew = tvMenu.Nodes.Add(strNodeVolg, strNodeNaam);
                                tnNew.Tag = lblUgro_value.Text + "@" + strNodeNaam;
                                if (strNodeVolg == strRootNode_key)
                                {
                                    tnSysteem = tnNew;
                                }
                            }
                            else
                            {
                                TreeNode tnNew = tnSysteem.Nodes.Add(strNodeVolg, strNodeNaam);
                                tnNew.Tag = lblUgro_value.Text + "@" + strNodeNaam;
                            }
                        }
                    }
                }
            }
            if (tnSysteem != null)
            {
                tnSysteem.Expand();
            }
        }    

        private void Verwijder_Click(object sender, EventArgs e)
        {
            Verwijder_vanaf_node(tvMenu.SelectedNode);
            setLb2TvButtons();
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {
            btvMenustrip_shown = true;
        }

        private void contextMenuStrip1_Closed(object sender, ToolStripDropDownClosedEventArgs e)
        {
            btvMenustrip_shown = false;
        }

        private void tvMenu_MouseMove(object sender, MouseEventArgs e)
        {
            if (!btvMenustrip_shown)
            {
                // Bewaren (laatste) node waar overheen is gemoved....
                TreeView tvTemp = ((TreeView)sender);
                Point clientPos = tvTemp.PointToClient(Control.MousePosition);

                TreeViewHitTestInfo hitInfo = tvTemp.HitTest(clientPos.X, clientPos.Y);
                if (hitInfo.Node != null)
                {
                    tnHover_node = hitInfo.Node;                    
                }
            }
        }

        private void Verwijder_vanaf_node(TreeNode tnVvn)
        {
            if (tnVvn != null)
            {
                bChanged = true;

                foreach (TreeNode rootNode in tnVvn.Nodes)
                {
                    if (rootNode.Text != strRootNode_name)
                    {
                        lbSubs.Items.Add(rootNode.Text);
                    }
                    Verwijder_recur_node(rootNode);
                }
                if (tnVvn.Text != strRootNode_name)
                {
                    lbSubs.Items.Add(tnVvn.Text);
                }
              
                tvMenu.Nodes.Remove(tnVvn);
            }
        }

        private void Verwijder_recur_node(TreeNode tnVrn)
        {           
            foreach (TreeNode tnVrnc in tnVrn.Nodes)
            {
                if (tnVrn.Text != strRootNode_name)
                {
                    lbSubs.Items.Add(tnVrnc.Text);
                }
                Verwijder_recur_node(tnVrnc);
            }
        }

        private void cmd1toTV_Click(object sender, EventArgs e)
        {            
            subs2menutree(lbSubs.SelectedIndex,"1");
            setLb2TvButtons();
        }

        private void cmdAlltoTV_Click(object sender, EventArgs e)
        {
            subs2menutree(0,"*");
            setLb2TvButtons();
        }

        private void subs2menutree(int intSelected_index, string strAantal_ind)
        {
            if (intSelected_index != -1)
            {
                bChanged        = true;
                
                TreeNode tnRootnode = null;
                TreeNode[] tnTemp   = null;
                tnTemp = tvMenu.Nodes.Find(strRootNode_key, true);
                // Als rootnode SYSTEEM er nog niet is, dan eerst vullen van deze.....
                if (tnTemp.Length == 0)
                {
                    tnRootnode = tvMenu.Nodes.Add(strRootNode_key, strRootNode_name);
                    tnRootnode.Tag = lblUgro_value.Text + "@" + strRootNode_name;
                }
                else
                {
                    tnRootnode = tnTemp[0];
                }

                //
                // Dubbele pijl << gedrukt: Hier wordt de GEHELE inhoud van de Subsysteem 
                //                          listbox toegevoegd aan de menutree..
                // Ze krijgen allemaal een volgnummer ala: n.0.0.0 we moeten alleen wel eerst het
                // hoogst aanwezige nummer bepalen voordat we kunnen gaan nummeren.....
                // Later = strAantal_ind toegevoegd; omdat wanneer de eerste entry met de 
                // "single button (<) werd gemoved dit resulteerde in het verplaatsen van ALLE subsys'
                // Dit omdat dit ook ging op "selected_index 0"
                // 
                if (intSelected_index == 0 && strAantal_ind == "*")
                {                 
                    for (int i = 0; i < lbSubs.Items.Count; i++)
                    {
                        TreeNode tnNew = tnRootnode.Nodes.Add(lbSubs.Items[i].ToString(), lbSubs.Items[i].ToString());
                        tnNew.Tag = lblUgro_value.Text + "@" + lbSubs.Items[i].ToString();
                    }
                    lbSubs.Items.Clear();
                }

                //
                // Er wordt één geselecteer item van de Subsysteem listbox toegevoegd aan de menutree
                //
                else
                {
                    TreeNode tnAdded = tnRootnode.Nodes.Add( lbSubs.Items[intSelected_index].ToString(),
                                                             lbSubs.Items[intSelected_index].ToString());
                    tnAdded.Tag = lblUgro_value.Text + "@" + tnAdded.Text;
                    lbSubs.Items.RemoveAt(intSelected_index);
                }
                tvMenu.ExpandAll();
            }
        }         

        private void setLb2TvButtons()
        {
            cmdOpslaan.Enabled       = false;
            cmdReset.Enabled         = false;
            cmd1fromTV.Enabled       = false;
            cmd1toTV.Enabled         = false;
            cmdAllfromTV.Enabled     = false;
            cmdAlltoTV.Enabled       = false;
            cmdFuncties.Enabled      = false;
            lbUgro.Enabled           = true;
            lblUgro_text.Visible     = false;
            lblUgro_value.Visible    = false;
            lblUgro_label.Visible    = false;
            lblFunc_Instruct.Visible = false;
            contextMenuStrip1.Items[0].Enabled = false;

            if (lbSubs.Items.Count > 0)
            {
                cmdAlltoTV.Enabled = true;
                if (lbSubs.SelectedIndex >= 0)
                {
                    cmd1toTV.Enabled = true;
                }
            }

            if (tvMenu.Nodes.Count > 0)
            {
                if (tvMenu.Nodes[0].Nodes.Count > 0)
                {
                    cmdAllfromTV.Enabled = true;


                    if (tvMenu.SelectedNode != null)
                    {
                        if (tvMenu.SelectedNode.Text != strRootNode_name)
                        {
                            cmd1fromTV.Enabled = true;
                        }
                    }
                    if (!bChanged & tvMenu.SelectedNode != null)
                    {
                        cmdFuncties.Enabled = true;
                        contextMenuStrip1.Items[0].Enabled = true;
                    }
                }
            }
            
            if (bChanged)
            {
                cmdOpslaan.Enabled       = true;
                cmdReset.Enabled         = true;
                cmdFuncties.Enabled      = false;
                lbUgro.SelectedIndex     = -1;
                lbUgro.Enabled           = false;
                lblUgro_text.Visible     = true;
                lblUgro_value.Visible    = true;
                lblUgro_label.Visible    = true;
                lblFunc_Instruct.Visible = true;

                contextMenuStrip1.Items[0].Enabled = false;
            }
        }

        private void lbSubs_SelectedIndexChanged(object sender, EventArgs e)
        {
            setLb2TvButtons();
        }

        private void tvMenu_AfterSelect(object sender, TreeViewEventArgs e)
        {
            setLb2TvButtons();
        }

        private void cmdAllfromTV_Click(object sender, EventArgs e)
        {
            TreeNode[] tnTemp = tvMenu.Nodes.Find(strRootNode_key, true);
            if (tnTemp == null)
            {
                clDashFunction.Melding("Sleutelwaarde van Systeem-item niet gevonden !", 1, "E");
                     
                return;
            }
            Verwijder_vanaf_node(tnTemp[0]);
            setLb2TvButtons();
        }

        private void cmd1fromTV_Click(object sender, EventArgs e)
        {
            Verwijder_vanaf_node(tvMenu.SelectedNode);
            setLb2TvButtons();
            tvMenu.Focus();
        }

        private void lbSubs_DoubleClick(object sender, EventArgs e)
        {
            cmd1toTV_Click(sender, e);
        }

        private void tvMenu_DoubleClick(object sender, EventArgs e)
        {
            if (cmd1fromTV.Enabled)
            {
                cmd1fromTV_Click(sender, e);
            }
        }

        private void functiesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmDashRelFunc RelFunc = new frmDashRelFunc();
            string[] strFunctie_args = Regex.Split(tvMenu.SelectedNode.Tag.ToString(), "@");
            
            RelFunc.strUserUgro = strFunctie_args[0];
            RelFunc.strSubs     = strFunctie_args[1];
            RelFunc.strUserCode = strUserCode;
            RelFunc.ShowDialog();
           
            tvMenu.Focus();
        }      

        private void cmdFuncties_Click(object sender, EventArgs e)
        {
            functiesToolStripMenuItem_Click(sender, e);
        }

        private void lbSubs_Click(object sender, EventArgs e)
        {
            setLb2TvButtons();
        }
    }
}
