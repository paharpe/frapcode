﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;

namespace dbDashboard
{
    public partial class mdiDashboard : Form
    {
        private int               childFormNumber   = 0;
        public  string            strUserCode       = "UserCode";
        public  string            strUserUgro       = "";
        public  static  ArrayList alForms_loaded    = new ArrayList();
        public  static  string    access_connection = null;
        public  static  string    access_database   = null;
        public  static  string    dbinterface_unix  = null;
        public  static  string    ftpget_env        = null;
        public  static  string    ftpget_temp       = null;
        public  static  ArrayList alIniTags         = new ArrayList();
        public  static  ArrayList alIniVals         = new ArrayList();
        public  static  string    strIniFile        = null;
        public  static  string    strServer         = "SERVER";
        public  static  string    strDomain         = "DOMAIN";

        public mdiDashboard( string [] strStartup_parms)
        {            
            Boolean bInit_ok=false;

            this.Cursor = Cursors.WaitCursor;
            // **************************************************************************************
            // Access database KAN als parameter aan de shortcut van de 'exe' file worden meegegeven.
            // in alle andere gevallen wordt de hier hard-coded default gebruikt
            // **************************************************************************************
            if (strStartup_parms.Length > 0)
            {
               access_database = strStartup_parms[0].ToString();
            }
            else
            {
                // Thuis
                // access_database = "C:\\Harpe\\C#\\dbDashboard_1024\\dbDashboard\\dbDashboard.mdb";
                // Zaak
                access_database = "C:\\harpe\\C#Solutions\\dbDashboard_Digipoort\\dbDashboard\\dbDashboard.mdb";               
            }

            if (!File.Exists(access_database))
            {
                clDashFunction.Melding("Database(path): " + access_database + " bestaat niet of is ongeldig ", 1, "E");
                // Zonder databeesje heeft het leven geen zin meer...
                // veroorzaak een error die via "catch" wordt opgevangen in Program.cs
                this.Close();
            }
            else
            {
                access_connection = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" +
                                    access_database +
                                    ";Persist Security Info=False;Jet OLEDB:Database Password=drrvs";

                //Naam en locatie inifile ophalen
                DoSql mysql = new DoSql();
                      mysql.vul_deze_string = "";
                      mysql.DoQuery("SELECT ElemOms1 " +
                                    "FROM   DashElem " +
                                    "WHERE  ElemTabn = 10 " +
                                    " AND   ElemElem = 'INIFILE'");                                    
                      if (mysql.affected_rows == 0)
                      {
                          clDashFunction.Melding("Geen INI file entry gevonden in tabel 10", 1, "I");
                      }
                      else
                      {
                          strIniFile = mysql.vul_deze_string;
                      }

                // Inifile checken en/of maken en vervolgens ook de waarden inlezen
                alIniTags.Add("[QDATAPATH]");
                alIniTags.Add("[QCMDPATH]");
                alIniTags.Add("[QDATACORE]");
                alIniTags.Add("[QDATASMTP]");
                alIniTags.Add("[QDATAX400]");
                alIniTags.Add("[QCMDCORE]");
                alIniTags.Add("[QCMDSMTP]");
                alIniTags.Add("[QCMDX400]");
                bInit_ok = clDashFunction.check_ini(strIniFile, alIniTags, alIniVals);                      
                
                InitializeComponent();

                // Het "bewerk INI bestand" menu-item krijgt de "abled" status van de resultaat
                // van bovenstaande controle. Als er issues zijn, dan is bewerken ook niet mogelijk/zinvol
                lokaleInsntellingenToolStripMenuItem.Enabled = bInit_ok;                
            }
            this.Cursor = Cursors.Default;
        }

        private void ShowNewForm(object sender, EventArgs e)
        {
            Form childForm      = new Form();
            childForm.MdiParent = this;
            childForm.Text      = "Window " + childFormNumber++;
            childForm.Show();
        }
        
        private void OpenFile(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            openFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (openFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = openFileDialog.FileName;
            }
        }

        private void SaveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            saveFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (saveFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = saveFileDialog.FileName;
            }
        }

        private void ExitToolsStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CutToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void CopyToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void PasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void ToolBarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            toolStrip.Visible = toolBarToolStripMenuItem.Checked;
        }

        private void StatusBarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            statusStrip.Visible = statusBarToolStripMenuItem.Checked;
        }

        private void CascadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.Cascade);
        }
        
        private void TileVerticalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileVertical);
        }

        private void TileHorizontalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void ArrangeIconsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.ArrangeIcons);
        }

        private void CloseAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            close_children();            
        }

        private void mdidbDashboard_Load(object sender, EventArgs e)
        {
            /* -------------->
            // Dit doen we even niet meer omdat dit onder Citrix ook maar één instance toestaat.
            // Nog onderzoeken of de owner van het proces kan worden bepaald zodat we hierop ook
            // kunnen checken....

            // Indien proces al bekend is, dan opnieuw starten niet toegestaan
            if (Process.GetProcessesByName("dbDashboard").Length>1)
            {
                clDashFunction.Melding("Programma is reeds actief !", 1, "I");
                this.Close();
            }
            < ------------------------ */
            this.toolStripStatusLabel1.Text = "DB Dashboard hoofdpagina"; 
            this.WindowState = FormWindowState.Maximized;
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutBox1 about = new AboutBox1();
            about.ShowDialog();
        }

        private void mdiDashboard_Shown(object sender, EventArgs e)
        {
            /*
            if (lokaleInsntellingenToolStripMenuItem.Enabled == false)
            {
                this.Close();
            }
            */

            aanmelden();
        }

        private void aanmeldenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.MdiChildren.Length > 0)
            {
                if (clDashFunction.Melding("Bij opnieuw aanmelden worden alle openstaande schermen gesloten. Doorgaan ?", 4, "Q") == DialogResult.Yes)
                {
                    this.Cursor = Cursors.WaitCursor;
                    close_children();
                }
                else
                {
                    return;
                }
            }           
            aanmelden();
        }

        private void aanmelden()
        {
            this.Cursor = Cursors.WaitCursor;
            // Eventuele child forms afsluiten+subsysteem dropdown slopen...
            close_children();
            // Reset de 'onthoud' tabel met alle open forms...
            alForms_loaded.Clear();
            this.Cursor = Cursors.Default;

            frmDashlogin Dashlogin = new frmDashlogin();
            Dashlogin.ShowDialog();
            if (!Dashlogin.bLogin_cancelled)
            {
                this.strUserCode = Dashlogin.strUsercode;
                this.strUserUgro = Dashlogin.strUserugro;

                check_verplichte_workfiles();

                if (this.strUserUgro != "")
                {
                    beheerToolStripMenuItem.Enabled = true;
                }
                else
                {
                    beheerToolStripMenuItem.Enabled = false;
                }

                afmeldenToolStripMenuItem.Enabled = true;
                frmDashMenu DashMenu = new frmDashMenu();
                DashMenu.MdiParent   = this;
                DashMenu.strUserCode = Dashlogin.strUsercode;
                DashMenu.strUserNaam = Dashlogin.strUsernaam;
                DashMenu.strUserUgro = Dashlogin.strUserugro;
                DashMenu.Show();
            }
        }
        
        private void eindeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();           
        }
           

        private void afmeldenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.MdiChildren.Length > 0)
            {
                if (clDashFunction.Melding("Bij afmelden worden alle openstaande schermen gesloten. Doorgaan ?", 4, "Q") == DialogResult.Yes)
                {
                    this.Cursor = Cursors.WaitCursor;
                    close_children();
                }                
            }
            beheerToolStripMenuItem.Enabled = false;
            this.Cursor = Cursors.Default;
        }

        private void close_children()
        {
            foreach (Form mdiChild in this.MdiChildren)
            {              
                mdiChild.Close();
            }            
        }

        private void check_verplichte_workfiles()
        {   // Bevat HARDCODED zaken !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            // Controleer bestanden en directories op basis van
            // de verplichte entries in tabel 250...
            // Crontab   = positie 0 // Niet meer !
            // Uitgevers = positie 1
            // Waarschijnlijk nog uit te breiden.....

            ArrayList alInit_fouten = new ArrayList();

            int intFouten = 0;

            Boolean[] bWorkfiles_present = new Boolean[2];

            DoSql mysql = new DoSql();
            mysql.vul_deze_text1_array = new string[20];
            mysql.vul_deze_text2_array = new string[20];
            mysql.vul_deze_text3_array = new string[20];
            mysql.vul_deze_text1_array[1] = "FTA";
            mysql.affected_rows = 0;
            mysql.DoQuery("SELECT ElemTabn, ElemElem, ElemOms1 + ElemOms2 " +
                          "FROM   DashElem " +
                          "WHERE  ElemTabn = 250");

            for (int i = 1; i < mysql.vul_deze_text2_array.Length; i++)
            {
                if (mysql.vul_deze_text2_array[i] == null)
                {
                    break;
                }
                if (File.Exists(mysql.vul_deze_text3_array[i]))
                {
                    switch (mysql.vul_deze_text2_array[i])
                    {
                        default:
                            {
                                break;
                            }
                    }
                }
            }

            for (int i = 1; i < bWorkfiles_present.Length; i++)
            {
                switch (bWorkfiles_present[i])
                {
                    case true:
                        {
                            break;
                        }
                    case false:
                        {
                            //               intFouten++;
                            //               alInit_fouten.Add(mysql.vul_deze_text3_array[i ] +
                            //                           " ontbreekt !");                           
                            break;
                        }
                    default:
                        {
                            break;
                        }
                }
            }

            // Unix directory info samenstellen           
            mysql.affected_rows = 0;
            mysql.vul_deze_string = "";
            mysql.DoQuery(" SELECT ElemOms2 " +
                          " FROM DashElem " +
                          " WHERE ElemTabn = 10 " +
                          " AND   ElemElem = 'DBINTERFACE'");
            if (mysql.affected_rows == 0)
            {
                intFouten++;
                alInit_fouten.Add("DBINTERFACE verwijzing in tabel 10 ontbreekt !");
            }
            else
            {
                dbinterface_unix = mysql.vul_deze_string;
            }
        }

        private void lokaleInsntellingenToolStripMenuItem_Click(object sender, EventArgs e)
        {

            clDashFunction.showInit(strIniFile, alIniTags);
            // Opnieuw inlezen van de (zojuist gewijzigde) waarden in (mdi)aliniVals
            clDashFunction.lees_ini(strIniFile, alIniTags, alIniVals);
           
        }
        
        private void mdiDashboard_MdiChildActivate(object sender, EventArgs e)
        {
            // Alle childforms gesloten ? Dan ook toolbarmenu(s)....
            if (alForms_loaded.Count < 1)
            {
                beheerToolStripMenuItem.Enabled = false;
            }            
        }                             
    }
}
