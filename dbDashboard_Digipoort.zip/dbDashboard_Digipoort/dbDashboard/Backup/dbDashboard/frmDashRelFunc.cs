﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace dbDashboard
{
    
    public partial class frmDashRelFunc : frmDashBase
    {
        // Onderstaande 2 waarden worden vanuit calling programma gevuld...
        public string strSubs;
        private ArrayList alFuncProg_selY = new ArrayList();
        private ArrayList alFuncName_selY = new ArrayList();
        private ArrayList alFuncParm_selY = new ArrayList();

        private ArrayList alFuncProg_selN = new ArrayList();
        private ArrayList alFuncName_selN = new ArrayList();
        private ArrayList alFuncParm_selN = new ArrayList();

        public frmDashRelFunc()
        {            
            InitializeComponent();
        }

        private void frmDashRelFunc_Load(object sender, EventArgs e)
        {
           this.Cursor = Cursors.WaitCursor;
           init_form();
           this.Cursor = Cursors.Default;
        }

        private void init_form()
        {
            alFuncProg_selN.Clear();
            alFuncName_selN.Clear();
            alFuncParm_selN.Clear();
            alFuncName_selY.Clear();
            alFuncProg_selY.Clear();
            alFuncParm_selY.Clear();
            clbFunc.Items.Clear();
            cbFilter.SelectedIndex = 1;

            DoSql mysql = new DoSql();
            
            // Eerst de reeds gekoppelde functies selecteren
            mysql.vul_deze_text1_array[1] = "FTA";
            mysql.DoQuery(  "SELECT A.FuncProg, A.FuncText, A.FuncParm "+
                            "FROM   DashFunc A, DashGsfu B "+
                            "WHERE  B.GsFuSubs = '"+ strSubs + "'" +
                            "AND    B.GsFuUgro = '"+ strUserUgro + "'" +
                            "AND    B.GsfuFunc = A.FuncProg " + 
                            "AND    B.GsfuParm = A.FuncParm "  );            

            for (int i = 1; i < mysql.vul_deze_text1_array.Length-1; i++)
            {
                if (mysql.vul_deze_text1_array[i] == null)
                {
                    break;
                }
                if (mysql.vul_deze_text1_array[i] != "FTA")
                {
                    alFuncProg_selY.Add(mysql.vul_deze_text1_array[i]);
                    alFuncName_selY.Add(mysql.vul_deze_text2_array[i]);
                    alFuncParm_selY.Add(mysql.vul_deze_text3_array[i]);
                }
            }          

            // Vervolgens de (nog) niet gekoppelde...
            mysql.affected_rows     = 0;
            mysql.vul_deze_text1_array = new string [50];
            mysql.vul_deze_text1_array = new string [50];
            mysql.vul_deze_text2_array = new string [50];
            mysql.vul_deze_text3_array = new string [50];

            mysql.vul_deze_text1_array[1] = "FTA";
            mysql.DoQuery("SELECT   A.FuncProg, A.FuncText, A.FuncParm " +
                          "FROM     DashFunc A " +
                          "WHERE NOT EXISTS (  SELECT 1         " +
                                             " FROM DashGsfu B  " +
                                             " WHERE B.GsFuSubs = '" + strSubs + "'" +
                                             " AND   B.GsFuUgro = '" + strUserUgro + "'" +
                                             " AND   B.GsFuFunc = A.FuncProg " +
                                             " AND   B.GsFuParm = A.FuncParm )" ); 

            for (int i = 1;i< mysql.vul_deze_text1_array.Length - 1; i++)
            {
                if (mysql.vul_deze_text1_array[i] == null)
                {
                    break;
                }

                if (mysql.vul_deze_text1_array[i] != "FTA")
                {
                    alFuncProg_selN.Add(mysql.vul_deze_text1_array[i]);
                    alFuncName_selN.Add(mysql.vul_deze_text2_array[i]);
                    alFuncParm_selN.Add(mysql.vul_deze_text3_array[i]);
                }
            }

            cbFilter.SelectedIndex = 0;
            cmdReset.Enabled = false;
            lblUgro.Text     = this.strUserUgro;
            lblSubs.Text     = this.strSubs;
            lblSelectedN_cnt.Text = alFuncProg_selN.Count.ToString();
            lblSelectedY_cnt.Text = alFuncProg_selY.Count.ToString();     
        
        }

        private void cmdOk_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            Opslaan();
            this.Cursor = Cursors.Default;            

            this.Close();
        }

        private void Opslaan()
        {
            DoSql mysql = new DoSql();
            mysql.DoUpdate("DELETE FROM DashGsfu " +
                "WHERE GsfuUgro = '" + strUserUgro + "'" +
                "AND   gsfuSubs = '" + strSubs + "'");
            //
            for (int i=0;i<alFuncProg_selY.Count;i++)
            if (alFuncName_selY[i] != null)
            {
                // MessageBox.Show(clbFunc.CheckedItems[i].ToString());
                mysql.DoUpdate("INSERT INTO DashGsfu " +
                "( GsfuUgro, GsfuSubs, GsfuFunc, GsFuParm, GsfuCdat, GsfuCtyd, " +
                "  GsfuCusr, GsfuMdat, GsfuMtyd, GsfuMusr ) " +
                " VALUES( '" + strUserUgro + "'" +
                        ",'" + strSubs + "'" +
                        ",'" + alFuncProg_selY[i] + "'" +
                        ",'" + alFuncParm_selY[i] + "'" +
                        ",'" + clDashFunction.get_mutdatum() + "'" +
                        ",'" + clDashFunction.get_muttijd() + "'" +
                        ",'" + strUserCode + "'" +
                        ",'" + clDashFunction.get_mutdatum() + "'" +
                        ",'" + clDashFunction.get_muttijd() + "'" +
                        ",'" + strUserCode + "')");
            }
        }
        /*
        private void cmdAnnuleren_Click(object sender, EventArgs e)
        {
            if (!bFormChanged)
            {
                this.Close();
            }
            else
            {
                if (clDashFunction.Melding("Geselecteerde functies gewijzigd, wilt u stoppen zonder opslaan ?", 4, "Q") == DialogResult.Yes)
                {
                    this.Close();
                }
            }
        }
        */

        private void clbFunc_SelectedIndexChanged(object sender, EventArgs e)
        {
            bChanged = true;
            cmdReset.Enabled = true;            
        }

        private void cbFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch(cbFilter.SelectedItem.ToString().ToUpper())
            {
                case "ALLES":
                    clbFunc.Items.Clear();
                    vul_selectedY();
                    vul_selectedN();
                    break;

                case "ALLEEN GESELECTEERD":
                    clbFunc.Items.Clear();
                    vul_selectedY();
                    break;

                case "ALLEEN NIET GESELECTEERD":
                    clbFunc.Items.Clear();
                    vul_selectedN();                   
                    break;

                default:
                    clDashFunction.Melding("Onbekend filteritem :"+cbFilter.SelectedText,1,"E");
                    break;
            }
        }

        private void vul_selectedY()
        {
            for (int i = 0; i < alFuncName_selY.Count; i++)
            {
                if (alFuncName_selY[i] != null)
                {
                    int indexY = clbFunc.Items.Add(alFuncName_selY[i]);
                    clbFunc.SetItemChecked(indexY, true);
                }
            }
        }
        
        private void vul_selectedN()
        {
            for (int i = 0; i < alFuncName_selN.Count; i++)
            {
                if (alFuncName_selN[i] != null)
                {
                    clbFunc.Items.Add(alFuncName_selN[i]);
                }
            }
        }

        private void clbFunc_ItemCheck(object sender, ItemCheckEventArgs e)
        {             
            if (e.NewValue == CheckState.Checked & clbFunc.SelectedItem != null)
            {
              int intDexN = alFuncName_selN.IndexOf(clbFunc.SelectedItem.ToString());
              if (intDexN >= 0)
              {
                  alFuncName_selY.Add(alFuncName_selN[intDexN]);
                  alFuncProg_selY.Add(alFuncProg_selN[intDexN]);
                  alFuncParm_selY.Add(alFuncParm_selN[intDexN]);
                  alFuncName_selN.RemoveAt(intDexN);
                  alFuncProg_selN.RemoveAt(intDexN);
                  alFuncParm_selN.RemoveAt(intDexN);
              }
            }
            if (e.NewValue == CheckState.Unchecked & clbFunc.SelectedItem != null)
            {
              int intDexY = alFuncName_selY.IndexOf(clbFunc.SelectedItem.ToString());
              if (intDexY >= 0)
              {
                  alFuncName_selN.Add(alFuncName_selY[intDexY]);
                  alFuncProg_selN.Add(alFuncProg_selY[intDexY]);
                  alFuncParm_selN.Add(alFuncParm_selY[intDexY]);
                  alFuncName_selY.RemoveAt(intDexY);
                  alFuncProg_selY.RemoveAt(intDexY);
                  alFuncParm_selY.RemoveAt(intDexY);
              }
            }
            lblSelectedN_cnt.Text = alFuncProg_selN.Count.ToString();
            lblSelectedY_cnt.Text = alFuncProg_selY.Count.ToString();           
        }

        private void cmdReset_Click(object sender, EventArgs e)
        {
            if (!bChanged)
            {
                init_form();
                cmdReset.Enabled = false;
            }
            else
            {
                if (clDashFunction.Melding("Geselecteerde functies gewijzigd ! Doorgaan met reset ?", 4, "Q") == DialogResult.Yes)
                {
                    init_form();
                    cmdReset.Enabled = false;
                }
            }
        }                  
    }
}
