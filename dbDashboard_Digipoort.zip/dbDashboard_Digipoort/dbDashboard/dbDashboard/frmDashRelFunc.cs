﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace dbDashboard
{
    
    public partial class frmDashRelFunc : frmDashBase
    {
        // Onderstaande 2 waarden worden vanuit calling programma gevuld...
        public string      strSubs;
        private ArrayList alFuncProg_selY = new ArrayList();
        private ArrayList alFuncName_selY = new ArrayList();
        private ArrayList alFuncParm_selY = new ArrayList();

        private ArrayList alFuncProg_selN = new ArrayList();
        private ArrayList alFuncName_selN = new ArrayList();
        private ArrayList alFuncParm_selN = new ArrayList();

        private ArrayList alEmbedFunc_selY = new ArrayList();
        private ArrayList alEmbedFunc_selN = new ArrayList();

        private Boolean   bNoCheck_Change = false;
        private Boolean   bEmbed_changed  = false;

        public frmDashRelFunc()
        {            
            InitializeComponent();
        }

        private void frmDashRelFunc_Load(object sender, EventArgs e)
        {
           this.Cursor = Cursors.WaitCursor;
           init_form();
           this.Cursor = Cursors.Default;
        }

        private void init_form()
        {          
            alFuncProg_selN.Clear();
            alFuncName_selN.Clear();
            alFuncParm_selN.Clear();
            alFuncName_selY.Clear();
            alFuncProg_selY.Clear();
            alFuncParm_selY.Clear();
            clbFunc.Items.Clear();
                       
            cbFilter.Enabled          = true;
            bNoCheck_Change           = false;
            cmdUp.Enabled             = false;
            cmdDown.Enabled           = false;
            cbVolgorde.Enabled        = false;
            cbVolgorde.Checked        = false;
            pcbembed_notavail.Visible = true;
            cbFilter.SelectedIndex    = 1;

            DoSql mysql = new DoSql();
            
            // Eerst de reeds gekoppelde functies selecteren
            mysql.vul_deze_text1_array[1] = "FTA";
            mysql.DoQuery(  "SELECT A.FuncProg, A.FuncText, A.FuncParm "+
                            "FROM   DashFunc A, DashGsfu B "+
                            "WHERE  B.GsFuSubs = '"+ strSubs + "'" +
                            "AND    B.GsFuUgro = '"+ strUserUgro + "'" +
                            "AND    B.GsfuFunc = A.FuncProg " + 
                            "AND    B.GsfuParm = A.FuncParm "  );            

            for (int i = 1; i < mysql.vul_deze_text1_array.Length-1; i++)
            {
                if (mysql.vul_deze_text1_array[i] == null)
                {
                    break;
                }
                if (mysql.vul_deze_text1_array[i] != "FTA")
                {
                    alFuncProg_selY.Add(mysql.vul_deze_text1_array[i]);
                    alFuncName_selY.Add(mysql.vul_deze_text2_array[i]);
                    alFuncParm_selY.Add(mysql.vul_deze_text3_array[i]);
                    if (i > 1) { cbVolgorde.Enabled = true; }
                }
            }          

            // Vervolgens de (nog) niet gekoppelde...
            mysql.affected_rows     = 0;
            mysql.vul_deze_text1_array = new string [50];
            mysql.vul_deze_text1_array = new string [50];
            mysql.vul_deze_text2_array = new string [50];
            mysql.vul_deze_text3_array = new string [50];

            mysql.vul_deze_text1_array[1] = "FTA";
            mysql.DoQuery("SELECT   A.FuncProg, A.FuncText, A.FuncParm " +
                          "FROM     DashFunc A " +
                          "WHERE NOT EXISTS (  SELECT 1         " +
                                             " FROM DashGsfu B  " +
                                             " WHERE B.GsFuSubs = '" + strSubs + "'" +
                                             " AND   B.GsFuUgro = '" + strUserUgro + "'" +
                                             " AND   B.GsFuFunc = A.FuncProg " +
                                             " AND   B.GsFuParm = A.FuncParm )" ); 

            for (int i = 1;i< mysql.vul_deze_text1_array.Length - 1; i++)
            {
                if (mysql.vul_deze_text1_array[i] == null)
                {
                    break;
                }

                if (mysql.vul_deze_text1_array[i] != "FTA")
                {
                    alFuncProg_selN.Add(mysql.vul_deze_text1_array[i]);
                    alFuncName_selN.Add(mysql.vul_deze_text2_array[i]);
                    alFuncParm_selN.Add(mysql.vul_deze_text3_array[i]);
                }
            }

            cbFilter.SelectedIndex = 0;
            cmdReset.Enabled       = false;
            lblUgro.Text           = this.strUserUgro;
            lblSubs.Text           = this.strSubs;
            lblSelectedN_cnt.Text  = alFuncProg_selN.Count.ToString();
            lblSelectedY_cnt.Text  = alFuncProg_selY.Count.ToString();
            
            set_embed_buttons("INIT");
            clbEmbed.Items.Clear();
            
            bChanged         = false;
            cmdReset.Enabled = false;    
        }

        private void cmdOk_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;

            Opslaan_GSFU();

            this.Cursor = Cursors.Default;      
            if (bChanged)
            {
                this.DialogResult = DialogResult.Yes;
            }
            else
            {
                this.DialogResult = DialogResult.No;
            }
            this.Close();
        }

        private void Opslaan_GSFU()
        {
            int intGsfuVolg = 0;

            DoSql mysql = new DoSql();
            mysql.DoUpdate("DELETE FROM DashGsfu " +
                "WHERE GsfuUgro = '" + strUserUgro + "'" +
                "AND   gsfuSubs = '" + strSubs + "'");
            //
            for (int i=0;i<alFuncProg_selY.Count;i++)
            if (alFuncName_selY[i] != null)
            {
                intGsfuVolg = i + 1;
                
                // MessageBox.Show(clbFunc.CheckedItems[i].ToString());
                mysql.DoUpdate("INSERT INTO DashGsfu " +
                "( GsfuUgro, GsfuSubs, GsfuFunc, GsFuParm, GsFuVolg, GsfuCdat,  " +
                "  GsfuCtyd, GsfuCusr, GsfuMdat, GsfuMtyd, GsfuMusr ) " +
                " VALUES( '" + strUserUgro + "'" +
                        ",'" + strSubs + "'" +
                        ",'" + alFuncProg_selY[i] + "'" +
                        ",'" + alFuncParm_selY[i] + "'" +
                        "," + intGsfuVolg + 
                        ",'" + clDashFunction.get_mutdatum() + "'" +
                        ",'" + clDashFunction.get_muttijd() + "'" +
                        ",'" + strUserCode + "'" +
                        ",'" + clDashFunction.get_mutdatum() + "'" +
                        ",'" + clDashFunction.get_muttijd() + "'" +
                        ",'" + strUserCode + "')");
            }
        }

        private void opslaan_UGEX()
        {
            string strExfuProg = alFuncProg_selY[alFuncName_selY.IndexOf(clbFunc.Text)].ToString();
            string strExfuParm = alFuncParm_selY[alFuncName_selY.IndexOf(clbFunc.Text)].ToString();

            // Alles wegsodemieteren, en daarna alleen wat in de 
            DoSql mysql = new DoSql();
            mysql.DoUpdate("DELETE FROM DashUgEx " +
                           "WHERE  UgexProg = '" + strExfuProg + "' " +
                           "AND    UgexParm = '" + strExfuParm + "' " +
                           "AND    UgexUgro = '" + strUserUgro + "'");

            for (int j = 0; j < clbEmbed.CheckedItems.Count; j++)
            {
                mysql.DoUpdate("INSERT INTO DashUgex " +
                               "( UgexUgro, UgexProg, UgExParm, UgExFunc, UgExCdat,  " +
                               "  UgExCtyd, UgExCusr, UgExMdat, UgExMtyd, UgExMusr ) " +
                               " VALUES( '" + strUserUgro + "' " +
                               ",'" + strExfuProg + "'" +
                               ",'" + strExfuParm + "'" +
                               ",'" + clbEmbed.CheckedItems[j].ToString() + "'" +
                               ",'" + clDashFunction.get_mutdatum() + "'" +
                               ",'" + clDashFunction.get_muttijd() + "'" +
                               ",'" + strUserCode + "'" +
                               ",'" + clDashFunction.get_mutdatum() + "'" +
                               ",'" + clDashFunction.get_muttijd() + "'" +
                               ",'" + strUserCode + "')");
            }

        }


        private void clbFunc_SelectedIndexChanged(object sender, EventArgs e)
        {
            set_embed_buttons("INIT");
            grpEmbed.Text             = "Functie niet toegewezen";
            pcbembed_notavail.Visible = true;
            
            
            if (clbFunc.CheckedIndices.Contains(clbFunc.SelectedIndex))
            {
                // experimenteel toneel
                get_embedded_functions();
            }

            enable_up_down(new ItemCheckEventArgs(clbFunc.SelectedIndex,CheckState.Indeterminate,CheckState.Indeterminate));

        }

        private void cbFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            change_selectie();     
        }

        private void change_selectie()
        {
            switch (cbFilter.SelectedItem.ToString().ToUpper())
            {
                case "ALLES":
                    clbFunc.Items.Clear();
                    cbVolgorde.Enabled = true;
                    vul_selectedY();
                    vul_selectedN();
                    break;

                case "ALLEEN GESELECTEERD":
                    clbFunc.Items.Clear();
                    cbVolgorde.Enabled = true;
                    vul_selectedY();
                    break;

                case "ALLEEN NIET GESELECTEERD":
                    clbFunc.Items.Clear();
                    cbVolgorde.Enabled = false;
                    vul_selectedN();
                    break;

                default:
                    clDashFunction.Melding("Onbekend filteritem :" + cbFilter.SelectedText, 1, "E");
                    break;
            }
        }

        private void vul_selectedY()
        {
            for (int i = 0; i < alFuncName_selY.Count; i++)
            {
                if (alFuncName_selY[i] != null)
                {
                    int indexY = clbFunc.Items.Add(alFuncName_selY[i]);
                    clbFunc.SetItemChecked(indexY, true);                    
                }
            }            
        }
        
        private void vul_selectedN()
        {
            for (int i = 0; i < alFuncName_selN.Count; i++)
            {
                if (alFuncName_selN[i] != null)
                {
                    clbFunc.Items.Add(alFuncName_selN[i]);
                }
            }
        }

        private void clbFunc_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            if (e.NewValue != CheckState.Indeterminate)
            {
                grpEmbed.Text             = "Kies eerst een functie";
                pcbembed_notavail.Visible = true;

                clbEmbed.Items.Clear();

                bChanged = true;
                cmdReset.Enabled = true;

                enable_up_down(e);
                
                cbVolgorde.Enabled = false;

                if (e.NewValue == CheckState.Checked & clbFunc.SelectedItem != null)
                {
                    int intDexN = alFuncName_selN.IndexOf(clbFunc.SelectedItem.ToString());
                    if (intDexN >= 0)
                    {
                        alFuncName_selY.Add(alFuncName_selN[intDexN]);
                        int x = alFuncProg_selY.Add(alFuncProg_selN[intDexN]);
                        alFuncParm_selY.Add(alFuncParm_selN[intDexN]);
                        alFuncName_selN.RemoveAt(intDexN);
                        alFuncProg_selN.RemoveAt(intDexN);
                        alFuncParm_selN.RemoveAt(intDexN);

                        // Wanneer er een item wordt omgezet naar WEL geselecteerd
                        // als de keuze op: toon ALLEEN NIET GESELECTEERD aanstaat,moet het item
                        // ook uit de listbox verdwijnen
                        if (cbFilter.SelectedItem.ToString().ToUpper() == "ALLEEN NIET GESELECTEERD")
                        {
                            clbFunc.Items.Clear();
                            vul_selectedN();
                            e.NewValue = CheckState.Unchecked;
                        }

                        // experimenteel toneel
                        else
                        {
                            get_embedded_functions();
                        }
                    }
                }

                if (e.NewValue == CheckState.Unchecked & clbFunc.SelectedItem != null)
                {
                    int intDexY = alFuncName_selY.IndexOf(clbFunc.SelectedItem.ToString());
                    if (intDexY >= 0)
                    {
                        alFuncName_selN.Add(alFuncName_selY[intDexY]);
                        alFuncProg_selN.Add(alFuncProg_selY[intDexY]);
                        alFuncParm_selN.Add(alFuncParm_selY[intDexY]);
                        alFuncName_selY.RemoveAt(intDexY);
                        alFuncProg_selY.RemoveAt(intDexY);
                        alFuncParm_selY.RemoveAt(intDexY);

                        // Wanneer er een item wordt omgezet naar NIET geselecteerd
                        // als de keuze op: toon ALLEEN GESELECTEERD aanstaat,moet het item
                        // ook uit de listbox verdwijnen
                        if (cbFilter.SelectedItem.ToString().ToUpper() == "ALLEEN GESELECTEERD")
                        {
                            clbFunc.Items.Clear();
                            vul_selectedY();
                            e.NewValue = CheckState.Checked;
                        }
                    }
                }

                lblSelectedN_cnt.Text = alFuncProg_selN.Count.ToString();
                lblSelectedY_cnt.Text = alFuncProg_selY.Count.ToString();

                // Minimaal 2 items checked => Anders is volgorde wijzigen zinloos...

                if (alFuncName_selY.Count > 1)
                {
                    cbVolgorde.Enabled = true;
                }
            }
        }

        private void enable_up_down(ItemCheckEventArgs e)
        {
            // We zitten nu in de "verander functie volgorde" mode;
            // het klikken op een item mag nu geen (de)selectie veroorzaken
            if (bNoCheck_Change)
            {
                cmdUp.Enabled = false;
                cmdDown.Enabled = false;

                e.NewValue = CheckState.Checked;
                if (clbFunc.SelectedIndex > 0)
                {
                    cmdUp.Enabled = true;
                }
                if (clbFunc.SelectedIndex < clbFunc.Items.Count - 1)
                {
                    cmdDown.Enabled = true;
                }
                return;
            }
        }
        
        private void cmdReset_Click(object sender, EventArgs e)
        {
            if (!bChanged)
            {
                init_form();
                cmdReset.Enabled = false;
            }
            else
            {
                if (clDashFunction.Melding("Geselecteerde functie(s) gewijzigd ! Doorgaan met reset ?", 4, "Q") == DialogResult.Yes)
                {
                    init_form();
                    cmdReset.Enabled = false;
                    bChanged         = false;
                }
            }
        }

        private void cmdUp_Click(object sender, EventArgs e)
        {
            move_item("UP");            
        }        

        private void cmdDown_Click(object sender, EventArgs e)
        {
            move_item("DOWN");
        }
        
        private void cbVolgorde_CheckedChanged(object sender, EventArgs e)
        {
            Boolean bChanged_save = bChanged;

            if (cbVolgorde.Checked )
            {
                cbFilter.SelectedIndex = 1;
                cbFilter.Enabled       = false;

                if (clbFunc.CheckedItems.Count > 0)
                {
                    
                    clbFunc.SelectedIndex = 0;
                    cmdUp.Enabled         = false;
                    cmdDown.Enabled       = true;
                    bNoCheck_Change       = true;
                }

                else
                {
                    clDashFunction.Melding("Er zijn (nog) geen functies geselecteerd", 1, "E");
                    cbVolgorde.Checked = false;
                }               
            }
            else
            {
                bNoCheck_Change  = false;
                cbFilter.Enabled = true;
                cmdUp.Enabled    = false;
                cmdDown.Enabled  = false;
            }
            bChanged = bChanged_save;
        }
        
        private void move_item(string strDirection)
        {
            int intOld_index = clbFunc.SelectedIndex;
            int intNew_index = 0;

            switch (strDirection.ToUpper())
            {
              case "UP":
                    intNew_index = intOld_index - 1;
                    break;
              case "DOWN":
                    intNew_index = intOld_index + 1;
                    break;
              default:
                    clDashFunction.Melding("Onbekende parameter ("+strDirection+") in aanroep move_item",1,"E");
                    return;            
            }
            
            string strSave_Name = alFuncName_selY[intOld_index].ToString();
            string strSave_Prog = alFuncProg_selY[intOld_index].ToString();
            string strSave_Parm = alFuncParm_selY[intOld_index].ToString();

            clbFunc.Items  [intOld_index] = clbFunc.Items  [intNew_index];
            alFuncName_selY[intOld_index] = alFuncName_selY[intNew_index];
            alFuncProg_selY[intOld_index] = alFuncProg_selY[intNew_index];
            alFuncParm_selY[intOld_index] = alFuncParm_selY[intNew_index];

            clbFunc.Items  [intNew_index] = strSave_Name;
            alFuncName_selY[intNew_index] = strSave_Name;
            alFuncProg_selY[intNew_index] = strSave_Prog;
            alFuncParm_selY[intNew_index] = strSave_Parm;
            clbFunc.SelectedIndex         = intNew_index;

            if ( intNew_index < 1 )
            {
                cmdUp.Enabled = false;
            }
            else
            {
                cmdUp.Enabled = true;
            }
            if (intNew_index == clbFunc.CheckedItems.Count-1)
            {
                cmdDown.Enabled = false;
            }
            else
            {
                cmdDown.Enabled = true;
            }
        }

        private void cmdEmbedit_Click(object sender, EventArgs e)
        {
            set_embed_buttons("EMBEDIT");       
        }

        private void cmdEmbed_save_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            // Omwille van de data-integriteit worden ook eventuele wijzigingen op
            // functieniveau ge-effectueerd; anders krijgen we weduwen en wezen enzo.... 
            if (bChanged)
            {
                if (clDashFunction.Melding("Tevens functie(s) ge(de)selecteerd !\nDeze wijzigingen worden nu ook opgeslagen, Accoord ? ", 4, "Q") != DialogResult.Yes)
                {
                    this.Cursor = Cursors.Default;
                    return;
                }
                Opslaan_GSFU();
                bChanged = false;
            }

            if (bEmbed_changed)
            {
                opslaan_UGEX();

                get_embedded_functions();
                bChanged = false;
            }
            this.Cursor = Cursors.Default;
        }

        private void get_embedded_functions()
        {
            this.Cursor = Cursors.WaitCursor;            
            
            set_embed_buttons("INIT");

            clbEmbed.Items.Clear();
            alEmbedFunc_selN.Clear();
            alEmbedFunc_selY.Clear();

            string strExfuProg;
            string strExfuParm;

            if ( alFuncName_selY.IndexOf(clbFunc.Text) != -1 )
            {
                strExfuProg = alFuncProg_selY[alFuncName_selY.IndexOf(clbFunc.Text)].ToString();
                strExfuParm = alFuncParm_selY[alFuncName_selY.IndexOf(clbFunc.Text)].ToString();
                grpEmbed.Text = "Interne functies in " + clbFunc.Text;
                             
                DoSql mysql = new DoSql();
                mysql.vul_deze_arraylist = alEmbedFunc_selY;

                mysql.DoQuery("SELECT UgexFunc " +
                              "FROM   DashUgex " +
                              "WHERE  UgexProg = '" + strExfuProg + "' "+
                              "AND    UgexParm = '" + strExfuParm + "' "+
                              "AND    UgexUgro = '" + strUserUgro + "'");
                for (int i=0;i<alEmbedFunc_selY.Count;i++)
                {
                    int intItem=clbEmbed.Items.Add(alEmbedFunc_selY[i],true);
                    clbEmbed.SetItemCheckState(intItem, CheckState.Indeterminate);
                }
                
                mysql.vul_deze_arraylist = alEmbedFunc_selN;
                mysql.DoQuery("SELECT A.ExfuFunc  " +
                              "FROM DashExfu AS A " + 
                              "WHERE ExfuProg = '" + strExfuProg + "' " + 
                              "AND   ExfuParm = '" + strExfuParm + "' " +
                              "AND NOT EXISTS (  SELECT 1 "+        
                              "                  FROM DashUgex B "+  
                              "                  WHERE B.UgexProg   = '" + strExfuProg  + "'" +
                              "                  AND   B.UgexUgro   = '" + strUserUgro  + "'" +
                              "                  AND   B.UgexFunc   = A.ExfuFunc " + 
                              "                  AND   B.UgexParm   = A.ExfuParm ) ");

                for (int i = 0; i < alEmbedFunc_selN.Count; i++)
                {
                    clbEmbed.Items.Add(alEmbedFunc_selN[i], false);
                }
                if (clbEmbed.Items.Count > 0)
                {
                    pcbembed_notavail.Visible = false;
                    set_embed_buttons("SELECTED");
                }
                else
                {
                    pcbembed_notavail.Visible = true;
                }
            }
            
            this.Cursor = Cursors.Default;          
        }
        
        private void set_embed_buttons(string strSituatie)
        {
            switch (strSituatie)
            {
                case "INIT":
                    grpEmbed.Enabled        = false;
                    clbEmbed.Enabled        = false;
                    cmdEmbed_cancel.Enabled = false;
                    cmdEmbed_save.Enabled   = false;
                    cmdEmbedit.Enabled      = true;
                    grpFuncties.Enabled     = true;
                    for (int i = 0; i < clbFunc.CheckedItems.Count; i++)
                    {
                        // van 'disabled checked' naar 'enabled checked'
                        clbFunc.SetItemCheckState(clbFunc.CheckedIndices[i], CheckState.Checked);
                    }
                  
                    break;
                case "SELECTED":
                    grpEmbed.Enabled        = true;
                    clbEmbed.Enabled        = false;
                    cmdEmbed_cancel.Enabled = false;
                    cmdEmbed_save.Enabled   = false;
                    cmdEmbedit.Enabled      = true;
                    grpFuncties.Enabled     = true;
                    break;
                case "EMBEDIT":
                    grpEmbed.Enabled        = true;
                    clbEmbed.Enabled        = true;
                    cmdEmbed_cancel.Enabled = true;
                    cmdEmbed_save.Enabled   = false;
                    cmdEmbedit.Enabled      = false;
                    grpFuncties.Enabled     = false;
                    for (int i = 0; i < clbFunc.CheckedItems.Count; i++)
                    {
                        // van 'enabled checked' naar 'disabled checked'
                        clbFunc.SetItemCheckState(clbFunc.CheckedIndices[i], CheckState.Indeterminate);
                    }
                  
                    for (int i = 0; i < clbEmbed.CheckedItems.Count; i++)
                    {
                        // van 'disabled checked' naar 'enabled checked'
                        clbEmbed.SetItemCheckState(clbEmbed.CheckedIndices[i], CheckState.Checked);
                    }
                    bEmbed_changed = false;
                    break;
                default:
                    clDashFunction.Melding("set_embed_buttons aangeroepen met foutieve parameter (" + strSituatie + ")", 1, "E");
                    break;
            }
        }

        private void cmdEmbed_cancel_Click(object sender, EventArgs e)
        {
            if (bEmbed_changed)
            {
                if (clDashFunction.Melding("Er is data gewijzigd !\nWeet u zeker dat u wilt stoppen zonder opslaan ? (wijzigen gaan verloren) ", 4, "Q") != DialogResult.Yes)
                {
                    return;
                }
            }
            
            // Opnieuw selecteren; wijzigingen ongedaan maken...
            get_embedded_functions();
            set_embed_buttons("SELECTED");
        }

        private void clbEmbed_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            cmdEmbed_save.Enabled = false;
            if (e.CurrentValue != e.NewValue)
            {
                bEmbed_changed        = true;
                cmdEmbed_save.Enabled = true;
            }
            
        }                 
    }
}
