﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Stocks
{
    public partial class frmStockNames : Form
    {
        public string strDatabase;
        private string strSelectionMode;
        private int intKosh = 0;
        private int intShort_Unlinked = 0;
        private int intIndex_Unlinked = 0;

        public frmStockNames()
        {
            InitializeComponent();
        }

        private void cmdCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cmdShortinKours_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            strSelectionMode = "SIK"; // Shorts In Kourse

            view_shortfonds(false);
            this.Cursor = Cursors.Default;
        }

        private void cmdShortnotKours_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            strSelectionMode = "SNK"; // Shorts Not in Kourse
            view_shortfonds(true);
            this.Cursor = Cursors.Default;
        }

        /// <summary>
        /// Initialisation form
        /// </summary>
        private void frm_init()
        {           
            cmdSaveLink.Enabled = false;
                      
            ShazBat();
        }

        private void view_shortfonds(Boolean bNot)
        {
            dgKosh.Columns[1].Visible = false;
            dgKosh.Columns[0].Width = 500;

            string strNot = "";
            int intSQL_row = 0;

            if (bNot)
            {
                strNot = "NOT";
            }

            dgKosh.Rows.Clear();
            lbIndexStock.Items.Clear();
            lbShortStock.Items.Clear();
            this.Refresh();

            DoSql mysql = new DoSql();
            mysql.strAccess_Database = strDatabase;
            mysql.vul_deze_arraylist = new System.Collections.ArrayList();

            mysql.DoQuery("SELECT DISTINCT(ShortFonds) "
                + "        FROM KoursShort "
                + "        WHERE ShortFonds " + strNot + " IN ("
                + "              SELECT DISTINCT(KoursFonds)"
                + "              FROM KoursKours )");

            if (mysql.affected_rows > 0)
            {
                intSQL_row = 0;
                while (intSQL_row < mysql.affected_rows)
                {
                    dgKosh.Rows.Add();
                    dgKosh[0, intSQL_row].Value = mysql.vul_deze_arraylist[intSQL_row];
                    intSQL_row++;
                }
            }
        }       

        private void cmdKoshCross_Click(object sender, EventArgs e)
        {
            strSelectionMode = "CTA"; // Cross TAble


            // Alleen wanneer de "Cross Table" functie is gekozen

            if (strSelectionMode == "CTA")
            {
                dgKosh.Columns[0].Width = 250;
                dgKosh.Columns[1].Visible = true;
            }
            int intSQL_row = 0;

            dgKosh.Rows.Clear();
            this.Refresh();

            DoSql mysql = new DoSql();
            mysql.strAccess_Database = strDatabase;
            mysql.vul_deze_arraylist = new System.Collections.ArrayList();

            mysql.DoQuery("SELECT KoshKofo + '#' + KoshShfo "
                + "        FROM KoursKosh "); 
            
            if (mysql.affected_rows > 0)
            {
                intSQL_row = 0;
                while (intSQL_row < mysql.affected_rows)
                {
                    dgKosh.Rows.Add();

                    dgKosh[0, intSQL_row].Value = mysql.vul_deze_arraylist[intSQL_row].ToString().Split(Convert.ToChar("#"))[0];
                    dgKosh[1, intSQL_row].Value = mysql.vul_deze_arraylist[intSQL_row].ToString().Split(Convert.ToChar("#"))[1];
                    intSQL_row++;
                }
            }
        }

        private void fill_kosh_data()
        {
            strSelectionMode = "CTA"; // Cross TAble
            
            dgKosh.Columns[0].Width = 250;
            dgKosh.Columns[1].Visible = true;
            
            int intSQL_row = 0;

            dgKosh.Rows.Clear();
            this.Refresh();

            DoSql mysql = new DoSql();
            mysql.strAccess_Database = strDatabase;
            mysql.vul_deze_arraylist = new System.Collections.ArrayList();

            mysql.DoQuery("SELECT KoshKofo + '#' + KoshShfo "
                       +  "FROM KoursKosh ");

            if (mysql.affected_rows > 0)
            {
                intSQL_row = 0;
                while (intSQL_row < mysql.affected_rows)
                {
                    dgKosh.Rows.Add();

                    dgKosh[0, intSQL_row].Value = mysql.vul_deze_arraylist[intSQL_row].ToString().Split(Convert.ToChar("#"))[0];
                    dgKosh[1, intSQL_row].Value = mysql.vul_deze_arraylist[intSQL_row].ToString().Split(Convert.ToChar("#"))[1];
                    intSQL_row++;
                }
            }
        }


        private void ShazBat()
        {         

            // *************************************************************************
            // Part 1: SELECT from KoursKosh 
            // *************************************************************************
            dgKosh.Rows.Clear();

            DoSql mysql = new DoSql();
          
            mysql.strAccess_Database = strDatabase;
          
            mysql.vul_deze_arraylist = new System.Collections.ArrayList();

            mysql.DoQuery("SELECT KoshKofo + '#' + KoshShfo "
                        + "FROM   KoursKosh ");

            int intSQL_row = 0;

            if (mysql.affected_rows > 0)
            {                
                intSQL_row = 0;
                while (intSQL_row < mysql.affected_rows)
                {
                    int intNewRowNo = dgKosh.Rows.Add();
                    string[] strar_vul_deze_arraylist;
                    strar_vul_deze_arraylist = mysql.vul_deze_arraylist[intSQL_row].ToString().Split(Convert.ToChar("#"));
                    dgKosh[0, intNewRowNo].Value = strar_vul_deze_arraylist[0].ToString();
                    dgKosh[1, intNewRowNo].Value = strar_vul_deze_arraylist[1].ToString();
                    intSQL_row++;
                }
            }

            // *************************************************************************
            // Part 2: SELECT from KoursKours
            // *************************************************************************
            lbIndexStock.Items.Clear();            
           
            mysql.vul_deze_arraylist = new System.Collections.ArrayList();
            mysql.DoQuery("SELECT DISTINCT(KoursFonds) "
              + "        FROM KoursKours "
              + "        WHERE KoursFonds NOT IN ("
              + "              SELECT KoshKofo"
              + "              FROM KoursKosh )");

            intSQL_row = 0;

            if (mysql.affected_rows > 0)
            {
                intSQL_row = 0;
                while (intSQL_row < mysql.affected_rows)
                {                 
                    lbIndexStock.Items.Add(mysql.vul_deze_arraylist[intSQL_row].ToString());
                    do_index_unlinked(true);
                    intSQL_row++;
                }
            }

            // *************************************************************************
            // Part 3: SELECT from KoursShort
            // *************************************************************************
            lbShortStock.Items.Clear();
            mysql.vul_deze_arraylist = new System.Collections.ArrayList();
            mysql.DoQuery("SELECT DISTINCT(ShortFonds) "
            + "        FROM KoursShort "
            + "        WHERE ShortFonds NOT IN ("
            + "              SELECT KoshShfo"
            + "              FROM KoursKosh )");

            intSQL_row = 0;
           
            if (mysql.affected_rows > 0)
            {
                intSQL_row = 0;
                while (intSQL_row < mysql.affected_rows)
                {
                    lbShortStock.Items.Add(mysql.vul_deze_arraylist[intSQL_row].ToString());
                    do_short_unlinked(true);
                    intSQL_row++;
                }
            }

        }        

        private void frmStockNames_Load(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            frm_init();
            this.Cursor = Cursors.Default;
        }      
       
        private void dgKosh_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            remove_kosh(e.ColumnIndex, e.RowIndex);
        }    
   
        /// <summary>
        /// Add selected Kourse / Short combination to KoursKosh and add the value to dgKosh instantaneously
        /// </summary>
       

        private Boolean add_lb_kosh()
        {
            // Initialisation
            Boolean bReturn = false;

            string strKoshKofo = lbIndexStock.SelectedItem.ToString();
            string strKoshShfo = lbShortStock.SelectedItem.ToString();

            lbIndexStock.Items.RemoveAt(lbIndexStock.SelectedIndex);
            do_index_unlinked(false);

            lbShortStock.Items.RemoveAt(lbShortStock.SelectedIndex);
            do_short_unlinked(false);
                  
            DoSql mysql = new DoSql();
            mysql.strAccess_Database = strDatabase;

            // INSERT into the database
            mysql.DoUpdate("INSERT INTO KoursKosh ("
                       + "KoshCDatum, KoshCtijd, KoshKofo, KoshShfo, KoshMdatum, KoshMtijd ) "
                       + "VALUES ( '" + clDashFunction.get_mutdatum() + "'"
                       + ", '" + clDashFunction.get_muttijd() + "'"
                       + ", '" + strKoshKofo + "'"
                       + ", '" + strKoshShfo + "'"
                       + ", '" + clDashFunction.get_mutdatum() + "'"
                       + ", '" + clDashFunction.get_muttijd() + "' )");


            // Programmatically INSERT the new combination into the datagrid, otherwise whe have to execute timeconsuming queries again !! 
            int intNewRow = dgKosh.Rows.Add();
            dgKosh[0, intNewRow].Value = strKoshKofo;
            dgKosh[1, intNewRow].Value = strKoshShfo;
            dgKosh.Sort(colStockName, ListSortDirection.Ascending);
            dgKosh.FirstDisplayedScrollingRowIndex = intNewRow;

            return bReturn;
        }

        /// <summary>
        /// After confirmation, delete doubleclicked Kourse/Short mapping row and corresponding DB entry
        /// </summary>
        private void remove_kosh(int intColumn_nr, int intRow_nr)
        {

            string strIndexStock = dgKosh[0, intRow_nr].Value.ToString();
            string strShortStock = dgKosh[1, intRow_nr].Value.ToString();

            if (clDashFunction.Melding("Are you sure you want to delete mapping: " + strIndexStock, 4, "Q") == DialogResult.Yes)
            {
                DoSql mysql = new DoSql();
                mysql.strAccess_Database = strDatabase;
                mysql.DoUpdate("DELETE FROM KoursKosh "
                             + "WHERE KoshKofo = '" + strIndexStock.Trim() + "'");
                if (mysql.affected_rows != 1)
                {
                    clDashFunction.Melding("Strange... number of deleted rows is: " + mysql.affected_rows.ToString() + "!", 0, "I");
                }
                           

                lbShortStock.Items.Add(strShortStock);
                do_short_unlinked(true);

                lbIndexStock.Items.Add(strIndexStock);
                do_index_unlinked(true);
                               
                dgKosh.Rows.RemoveAt(intRow_nr);
            }
        }
              

        private void auto_link()
        {
            // ***********************************************************************************************
            // Part1 LOOP thru lbIndexStock ( De VOLLEDIGE lijst) , en zoek naar matches in de SHORT listbox
            // ***********************************************************************************************
            int intShRowNo = 0;
            int intKoRowNo = 0;
            int intMatch_counter = 0;
            string strKoshKofo = "";
            string strKoshShfo = "";
            Boolean bAdd2Index = true;           

            while (intKoRowNo < lbIndexStock.Items.Count)
            {
                lbIndexStock.SelectedIndices.Clear();
                lbShortStock.SelectedIndices.Clear();

                if (lbIndexStock.Items[intKoRowNo] != null)
                {
                    strKoshKofo = lbIndexStock.Items[intKoRowNo].ToString();                    

                    /*
                    if (strKoshKofo == "Fugro"|| strKoshKofo == "Galapagos")
                    {
                        clDashFunction.Melding("BreakieBreakie");
                    }
                    */

                    intShRowNo = 0;
                    while (intShRowNo < lbShortStock.Items.Count)
                    {
                        bAdd2Index = true;
                        if (lbShortStock.Items[intShRowNo] != null)
                        {
                            strKoshShfo = lbShortStock.Items[intShRowNo].ToString();

                            if (strKoshKofo.Replace(" ", "").Trim().Contains(strKoshShfo.Replace(" ", "").Trim()))
                            {
                                lbIndexStock.SelectedIndex = intKoRowNo;
                                lbShortStock.SelectedIndex = intShRowNo;
                                bAdd2Index = add_lb_kosh();
                                this.Refresh();
                                intMatch_counter++;
                                break;
                            }
                        }
                        intShRowNo++;
                    }
                }

                if (bAdd2Index)
                {
                    intKoRowNo++;
                }
            }           


            // ***********************************************************************************************
            // Part2 LOOP thru lbShortStock ( De SHORT listbox ), en zoek naar matches in de VOLLEDIGE lijst
            // ***********************************************************************************************
            intShRowNo = 0;
            intKoRowNo = 0;
            strKoshKofo = "";
            strKoshShfo = "";
            bAdd2Index = true;
                    
            while ( intShRowNo < lbShortStock.Items.Count)          
            {                
                lbShortStock.SelectedIndices.Clear();
                lbIndexStock.SelectedIndices.Clear();

                if (lbShortStock.Items[intShRowNo] != null)             
                {
                    strKoshShfo = lbShortStock.Items[intShRowNo].ToString();                 

                    intKoRowNo = 0;                  
                    while (intKoRowNo < lbIndexStock.Items.Count)
                    {
                        bAdd2Index = true;
                        if (lbIndexStock.Items[intKoRowNo] != null)
                        {
                            strKoshKofo = lbIndexStock.Items[intKoRowNo].ToString();

                            if (strKoshShfo.Replace(" ", "").Trim().Contains(strKoshKofo.Replace(" ", "").Trim()))
                            {
                                lbIndexStock.SelectedIndex = intKoRowNo;
                                lbShortStock.SelectedIndex = intShRowNo;
                                bAdd2Index = add_lb_kosh();
                                this.Refresh();
                                intMatch_counter++;
                                break;
                            }
                        }
                        intKoRowNo++;
                    }
                }

                if (bAdd2Index)
                {
                    intShRowNo++;
                }
            }    
          
            clDashFunction.Melding("Done, number of automatched items: " + intMatch_counter.ToString());
        }


        private void cmdAutoLink_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            auto_link();
            this.Cursor = Cursors.Default;
        }


        private void lbIndexStock_SelectedIndexChanged(object sender, EventArgs e)
        {
            check_listbox_selection();            
        }
        
        private void check_listbox_selection()
        {
            cmdSaveLink.Enabled = false;

            if (lbIndexStock.SelectedIndex > -1)
            {
                if (lbIndexStock.SelectedItems.Count + lbShortStock.SelectedItems.Count > 2)
                {
                    clDashFunction.Melding("Select only ONE entry in each listbox !");
                    return;
                }

                if (lbIndexStock.SelectedItems.Count + lbShortStock.SelectedItems.Count == 2)
                {
                    if (lbIndexStock.SelectedItems.Count == 2 || lbShortStock.SelectedItems.Count == 2)
                    {
                        clDashFunction.Melding("Select only ONE entry in each listbox !");
                        return;
                    }
                    cmdSaveLink.Enabled = true;
                }
            }
        }

        private void cmdSaveLink_Click(object sender, EventArgs e)
        {
            add_lb_kosh();
        }

        private void dgKosh_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            do_kosh_aant(true);
        } 
  
        private void dgKosh_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            do_kosh_aant(false);
        }

        /// <summary>
        /// Maintain dgKosh row counter and keep the displayed label value in sync at the same time
        /// </summary>
        /// <param name="bAdd"></param>
        private void do_kosh_aant(Boolean bAdd)
        {
            if (bAdd)
            {
                intKosh++;
            }
            // bAdd = False ? Then we have to subtract...
            else
            {
                intKosh--;
            }

            lblKosh_val.Text = intKosh.ToString();
        }

        /// <summary>
        /// Maintain number of items in the "Unlinked Shorts" listbox
        /// </summary>
        /// <param name="bAdd"></param>
        private void do_short_unlinked(Boolean bAdd)
        {
            if (bAdd)
            {
                intShort_Unlinked++;
            }
            // bAdd = False ? Then we have to subtract...
            else
            {
                intShort_Unlinked--;
            }
            lblShort_Unlinked_val.Text = intShort_Unlinked.ToString();
        }

        /// <summary>
        /// Maintain number of items in the "Unlinked Shorts" listbox
        /// </summary>
        /// <param name="bAdd"></param>
        private void do_index_unlinked(Boolean bAdd)
        {
            if (bAdd)
            {
                intIndex_Unlinked++;
            }
            // bAdd = False ? Then we have to subtract...
            else
            {
                intIndex_Unlinked--;
            }
            lblIndex_Unlinked_val.Text = intIndex_Unlinked.ToString();
        }
    }
}
