﻿namespace dbDashboard
{
    partial class frmDashSettings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDashSettings));
            this.rbGebruiker = new System.Windows.Forms.RadioButton();
            this.rbGroep = new System.Windows.Forms.RadioButton();
            this.lbGebrGroep = new System.Windows.Forms.ListBox();
            this.dgAuth = new System.Windows.Forms.DataGridView();
            this.cmdPref = new System.Windows.Forms.Button();
            this.grpAuthType = new System.Windows.Forms.GroupBox();
            this.grpAuthUsGr = new System.Windows.Forms.GroupBox();
            this.lblHint = new System.Windows.Forms.Label();
            this.grpAutab = new System.Windows.Forms.GroupBox();
            this.cmdOk = new System.Windows.Forms.Button();
            this.cmdCancel = new System.Windows.Forms.Button();
            this.cmdToepassen = new System.Windows.Forms.Button();
            this.lblWarn = new System.Windows.Forms.Label();
            this.grbConnect.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgAuth)).BeginInit();
            this.grpAuthType.SuspendLayout();
            this.grpAuthUsGr.SuspendLayout();
            this.grpAutab.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmdAfsluiten
            // 
            this.cmdAfsluiten.Location = new System.Drawing.Point(15, 220);
            // 
            // grbConnect
            // 
            this.grbConnect.Location = new System.Drawing.Point(135, 586);
            // 
            // lblHostName
            // 
            this.lblHostName.Location = new System.Drawing.Point(1, 564);
            this.lblHostName.Size = new System.Drawing.Size(122, 13);
            // this.lblHostName.Text = "EUROPE\\NL-5PQ3DS1";
            // 
            // rbGebruiker
            // 
            this.rbGebruiker.AutoSize = true;
            this.rbGebruiker.Location = new System.Drawing.Point(19, 43);
            this.rbGebruiker.Name = "rbGebruiker";
            this.rbGebruiker.Size = new System.Drawing.Size(76, 17);
            this.rbGebruiker.TabIndex = 0;
            this.rbGebruiker.TabStop = true;
            this.rbGebruiker.Text = "Gebruikers";
            this.rbGebruiker.UseVisualStyleBackColor = false;
            this.rbGebruiker.CheckedChanged += new System.EventHandler(this.rbGebruiker_CheckedChanged);
            // 
            // rbGroep
            // 
            this.rbGroep.AutoSize = true;
            this.rbGroep.Location = new System.Drawing.Point(19, 66);
            this.rbGroep.Name = "rbGroep";
            this.rbGroep.Size = new System.Drawing.Size(66, 17);
            this.rbGroep.TabIndex = 1;
            this.rbGroep.TabStop = true;
            this.rbGroep.Text = "Groepen";
            this.rbGroep.UseVisualStyleBackColor = true;
            this.rbGroep.CheckedChanged += new System.EventHandler(this.rbGroep_CheckedChanged);
            // 
            // lbGebrGroep
            // 
            this.lbGebrGroep.FormattingEnabled = true;
            this.lbGebrGroep.Location = new System.Drawing.Point(112, 43);
            this.lbGebrGroep.Name = "lbGebrGroep";
            this.lbGebrGroep.Size = new System.Drawing.Size(161, 134);
            this.lbGebrGroep.TabIndex = 2;
            this.lbGebrGroep.SelectedIndexChanged += new System.EventHandler(this.lbGebrGroep_SelectedIndexChanged);
            // 
            // dgAuth
            // 
            this.dgAuth.AllowUserToAddRows = false;
            this.dgAuth.AllowUserToDeleteRows = false;
            this.dgAuth.AllowUserToResizeColumns = false;
            this.dgAuth.AllowUserToResizeRows = false;
            this.dgAuth.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgAuth.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dgAuth.Location = new System.Drawing.Point(8, 20);
            this.dgAuth.MultiSelect = false;
            this.dgAuth.Name = "dgAuth";
            this.dgAuth.RowHeadersVisible = false;
            this.dgAuth.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgAuth.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgAuth.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgAuth.Size = new System.Drawing.Size(634, 259);
            this.dgAuth.TabIndex = 3;
            this.dgAuth.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgAuth_CellValueChanged);
            this.dgAuth.CurrentCellDirtyStateChanged += new System.EventHandler(this.dgAuth_CurrentCellDirtyStateChanged);
            this.dgAuth.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgAuth_RowHeaderMouseClick);
            // 
            // cmdPref
            // 
            this.cmdPref.Location = new System.Drawing.Point(7, 19);
            this.cmdPref.Name = "cmdPref";
            this.cmdPref.Size = new System.Drawing.Size(311, 158);
            this.cmdPref.TabIndex = 7;
            this.cmdPref.Text = "Directory voor lokale opslag...";
            this.cmdPref.UseVisualStyleBackColor = true;
            // 
            // grpAuthType
            // 
            this.grpAuthType.Controls.Add(this.cmdPref);
            this.grpAuthType.Location = new System.Drawing.Point(335, 23);
            this.grpAuthType.Name = "grpAuthType";
            this.grpAuthType.Size = new System.Drawing.Size(330, 190);
            this.grpAuthType.TabIndex = 8;
            this.grpAuthType.TabStop = false;
            this.grpAuthType.Text = "Type";
            // 
            // grpAuthUsGr
            // 
            this.grpAuthUsGr.Controls.Add(this.lblHint);
            this.grpAuthUsGr.Controls.Add(this.lbGebrGroep);
            this.grpAuthUsGr.Controls.Add(this.rbGebruiker);
            this.grpAuthUsGr.Controls.Add(this.rbGroep);
            this.grpAuthUsGr.Location = new System.Drawing.Point(12, 23);
            this.grpAuthUsGr.Name = "grpAuthUsGr";
            this.grpAuthUsGr.Size = new System.Drawing.Size(302, 190);
            this.grpAuthUsGr.TabIndex = 9;
            this.grpAuthUsGr.TabStop = false;
            this.grpAuthUsGr.Text = "Niveau";
            // 
            // lblHint
            // 
            this.lblHint.AutoSize = true;
            this.lblHint.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHint.Location = new System.Drawing.Point(11, 16);
            this.lblHint.Name = "lblHint";
            this.lblHint.Size = new System.Drawing.Size(274, 13);
            this.lblHint.TabIndex = 3;
            this.lblHint.Text = "Maak een keuze tussen Gebruikers of Groepen";
            // 
            // grpAutab
            // 
            this.grpAutab.Controls.Add(this.dgAuth);
            this.grpAutab.Location = new System.Drawing.Point(12, 248);
            this.grpAutab.Name = "grpAutab";
            this.grpAutab.Size = new System.Drawing.Size(653, 293);
            this.grpAutab.TabIndex = 10;
            this.grpAutab.TabStop = false;
            this.grpAutab.Text = "Overzicht";
            // 
            // cmdOk
            // 
            this.cmdOk.Location = new System.Drawing.Point(397, 547);
            this.cmdOk.Name = "cmdOk";
            this.cmdOk.Size = new System.Drawing.Size(75, 23);
            this.cmdOk.TabIndex = 11;
            this.cmdOk.Text = "Ok";
            this.cmdOk.UseVisualStyleBackColor = true;
            this.cmdOk.Click += new System.EventHandler(this.cmdOk_Click);
            // 
            // cmdCancel
            // 
            this.cmdCancel.Location = new System.Drawing.Point(477, 547);
            this.cmdCancel.Name = "cmdCancel";
            this.cmdCancel.Size = new System.Drawing.Size(75, 23);
            this.cmdCancel.TabIndex = 12;
            this.cmdCancel.Text = "Annuleren";
            this.cmdCancel.UseVisualStyleBackColor = true;
            this.cmdCancel.Click += new System.EventHandler(this.cmdCancel_Click);
            // 
            // cmdToepassen
            // 
            this.cmdToepassen.Location = new System.Drawing.Point(590, 547);
            this.cmdToepassen.Name = "cmdToepassen";
            this.cmdToepassen.Size = new System.Drawing.Size(75, 23);
            this.cmdToepassen.TabIndex = 13;
            this.cmdToepassen.Text = "Toepassen";
            this.cmdToepassen.UseVisualStyleBackColor = true;
            this.cmdToepassen.Click += new System.EventHandler(this.cmdToepassen_Click);
            // 
            // lblWarn
            // 
            this.lblWarn.AutoSize = true;
            this.lblWarn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWarn.Location = new System.Drawing.Point(245, 221);
            this.lblWarn.Name = "lblWarn";
            this.lblWarn.Size = new System.Drawing.Size(420, 20);
            this.lblWarn.TabIndex = 15;
            this.lblWarn.Text = "Let op: Dit form wordt geresized met fixed values !!!";
            // 
            // frmDashSettings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(677, 579);
            this.Controls.Add(this.lblWarn);
            this.Controls.Add(this.cmdToepassen);
            this.Controls.Add(this.cmdCancel);
            this.Controls.Add(this.cmdOk);
            this.Controls.Add(this.grpAutab);
            this.Controls.Add(this.grpAuthUsGr);
            this.Controls.Add(this.grpAuthType);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmDashSettings";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "DB Dashboard; instellingen per groep/gebruiker";
            this.Load += new System.EventHandler(this.frmDashSettings_Load);
            this.Controls.SetChildIndex(this.lblHostName, 0);
            this.Controls.SetChildIndex(this.grpAuthType, 0);
            this.Controls.SetChildIndex(this.grpAuthUsGr, 0);
            this.Controls.SetChildIndex(this.grpAutab, 0);
            this.Controls.SetChildIndex(this.cmdOk, 0);
            this.Controls.SetChildIndex(this.cmdCancel, 0);
            this.Controls.SetChildIndex(this.cmdToepassen, 0);
            this.Controls.SetChildIndex(this.lblWarn, 0);
            this.Controls.SetChildIndex(this.grbConnect, 0);
            this.Controls.SetChildIndex(this.cmdAfsluiten, 0);
            this.grbConnect.ResumeLayout(false);
            this.grbConnect.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgAuth)).EndInit();
            this.grpAuthType.ResumeLayout(false);
            this.grpAuthUsGr.ResumeLayout(false);
            this.grpAuthUsGr.PerformLayout();
            this.grpAutab.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton rbGebruiker;
        private System.Windows.Forms.RadioButton rbGroep;
        private System.Windows.Forms.ListBox lbGebrGroep;
        private System.Windows.Forms.DataGridView dgAuth;
        private System.Windows.Forms.Button cmdPref;
        private System.Windows.Forms.GroupBox grpAuthType;
        private System.Windows.Forms.GroupBox grpAuthUsGr;
        private System.Windows.Forms.GroupBox grpAutab;
        private System.Windows.Forms.Button cmdOk;
        private System.Windows.Forms.Button cmdCancel;
        private System.Windows.Forms.Button cmdToepassen;
        private System.Windows.Forms.Label lblWarn;
        private System.Windows.Forms.Label lblHint;
    }
}