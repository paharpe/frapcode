﻿using System;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

namespace dbDashboard
{
    public partial class lblMax : Label  
    {
        const string _strMax = "Max: ";
        private int _intMax;
        private Boolean _bChanged;

        public lblMax()
        {
            Label lblMax = new Label();
            this.Text = _strMax + "9999";          
        }

        public int Max
        {
            get { return this._intMax; }
            set { this._intMax = value; }
        }

        public Boolean bChanged
        {
            get { return this._bChanged; }
            set { this._bChanged = value; }
        }

        public Boolean SetMax(int intMax)
        {
            Boolean bMaxed = false;  

            if (intMax > this.Max)
            {
                this.Max = intMax;
                bChanged = true;
                bMaxed = true;
            }
            this.Text = _strMax + Max.ToString();
            return bMaxed;
        }
        
     }
}
