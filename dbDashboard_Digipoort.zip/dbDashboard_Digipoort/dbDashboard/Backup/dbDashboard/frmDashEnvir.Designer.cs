﻿namespace dbDashboard
{
    partial class frmDashEnvir
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDashEnvir));
            this.grpInitFout = new System.Windows.Forms.GroupBox();
            this.pgBar = new System.Windows.Forms.ProgressBar();
            this.lbBericht = new System.Windows.Forms.ListBox();
            this.lblInitFout = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.cmdSettings = new System.Windows.Forms.Button();
            this.grbConnectie.SuspendLayout();
            this.grpInitFout.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmdAfsluiten
            // 
            this.cmdAfsluiten.Location = new System.Drawing.Point(12, 250);
            this.cmdAfsluiten.Click += new System.EventHandler(this.cmdAfsluiten_Click_1);
            // 
            // grbConnectie
            // 
            this.grbConnectie.Location = new System.Drawing.Point(15, 289);
            // 
            // grpInitFout
            // 
            this.grpInitFout.Controls.Add(this.pgBar);
            this.grpInitFout.Controls.Add(this.lbBericht);
            this.grpInitFout.Controls.Add(this.lblInitFout);
            this.grpInitFout.Location = new System.Drawing.Point(12, 14);
            this.grpInitFout.Name = "grpInitFout";
            this.grpInitFout.Size = new System.Drawing.Size(527, 232);
            this.grpInitFout.TabIndex = 1;
            this.grpInitFout.TabStop = false;
            // 
            // pgBar
            // 
            this.pgBar.Location = new System.Drawing.Point(9, 214);
            this.pgBar.Name = "pgBar";
            this.pgBar.Size = new System.Drawing.Size(512, 10);
            this.pgBar.TabIndex = 2;
            // 
            // lbBericht
            // 
            this.lbBericht.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbBericht.HorizontalScrollbar = true;
            this.lbBericht.ItemHeight = 16;
            this.lbBericht.Location = new System.Drawing.Point(9, 37);
            this.lbBericht.Name = "lbBericht";
            this.lbBericht.Size = new System.Drawing.Size(512, 132);
            this.lbBericht.TabIndex = 1;
            // 
            // lblInitFout
            // 
            this.lblInitFout.AutoSize = true;
            this.lblInitFout.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInitFout.Location = new System.Drawing.Point(6, 16);
            this.lblInitFout.Name = "lblInitFout";
            this.lblInitFout.Size = new System.Drawing.Size(517, 13);
            this.lblInitFout.TabIndex = 0;
            this.lblInitFout.Text = "De volgende fouten zijn  geconstateerd; de applicatie zal mogelijk niet juist fun" +
                "ctioneren !";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // cmdSettings
            // 
            this.cmdSettings.Location = new System.Drawing.Point(335, 250);
            this.cmdSettings.Name = "cmdSettings";
            this.cmdSettings.Size = new System.Drawing.Size(204, 23);
            this.cmdSettings.TabIndex = 21;
            this.cmdSettings.Text = "Instellingen per groep/gebruiker...";
            this.cmdSettings.UseVisualStyleBackColor = true;
            this.cmdSettings.Click += new System.EventHandler(this.cmdSettings_Click);
            // 
            // frmDashEnvir
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(549, 277);
            this.Controls.Add(this.cmdSettings);
            this.Controls.Add(this.grpInitFout);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmDashEnvir";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "DB Dashboard; berichten";
            this.Load += new System.EventHandler(this.frmDashInit_Load);
            this.Shown += new System.EventHandler(this.frmDashInit_Shown);
            this.Controls.SetChildIndex(this.lblVoortgang, 0);
            this.Controls.SetChildIndex(this.cmdAfsluiten, 0);
            this.Controls.SetChildIndex(this.grbConnectie, 0);
            this.Controls.SetChildIndex(this.grpInitFout, 0);
            this.Controls.SetChildIndex(this.cmdSettings, 0);
            this.grbConnectie.ResumeLayout(false);
            this.grbConnectie.PerformLayout();
            this.grpInitFout.ResumeLayout(false);
            this.grpInitFout.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpInitFout;
        private System.Windows.Forms.Label lblInitFout;
        private System.Windows.Forms.ListBox lbBericht;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ProgressBar pgBar;
        private System.Windows.Forms.Button cmdSettings;
    }
}