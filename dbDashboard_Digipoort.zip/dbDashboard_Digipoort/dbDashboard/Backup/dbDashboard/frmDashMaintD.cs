﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace dbDashboard
{
    public partial class frmDashMaintD : frmDashBase
    {
        public  string      strSupplemental_Title;
        public  string      strFunctie;
        public  string      strBeheer_tabel;
        public  ArrayList   arr_DetailData;
       
        public frmDashMaintD()
        {
            InitializeComponent();
        }
          
        private void frmDashMaintD_Load(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            frm_init();
            this.Cursor = Cursors.Default;
        }

        private void frm_init()
        {
            grbFunMaintD.Visible = false;
            grbGrpMaintD.Visible = false;
            grbUsrMaintD.Visible = false;
            grbSubMaintD.Visible = false;
            grbTablMaintD.Visible = false;
            grbElemMaintD.Visible = false;
            grbConnMaintD.Visible = false;
            grbBronMaintD.Visible = false;
            grbUitgMaintD.Visible = false;
            grbPublMaintD.Visible = false;

            this.Text = this.Text + ";" + strSupplemental_Title;
            switch (strFunctie)
            {
                case "NIEUW":
                    init_nieuw(strBeheer_tabel);
                    break;
                case "WIJZIG":
                    init_wijzig(strBeheer_tabel);
                    break;
                default:
                    clDashFunction.Melding("Onbekende functie: " + strFunctie, 1, "I");
                    break;
            }
            bChanged = false;      
        }

        private void frmDashMaintD_Shown(object sender, EventArgs e)
        {
            switch (strBeheer_tabel)
            {
                case "BRON":
                    {
                        grbBronMaintD.Visible = true;
                        if (strFunctie == "NIEUW")
                        {
                            txtBronCode.Focus();
                        }
                        else
                        {
                            txtBronOmsc.Focus();
                        }
                        break;
                    }
                case "GEBRUIKER":
                    {
                        grbUsrMaintD.Visible = true;
                        if (strFunctie == "NIEUW")
                        {
                            txtUsrCode.Focus();
                        }
                        else
                        {
                            txtUsrNaam.Focus();
                        }
                        break;
                    }
                case "GROEP":
                    {
                        grbGrpMaintD.Visible = true;
                        if (strFunctie == "NIEUW")
                        {
                            txtGrpCode.Focus();
                        }
                        else
                        {
                            txtGrpNaam.Focus();
                        }
                        break;
                    }
                case "FUNCTIE":
                    {
                        grbFunMaintD.Visible = true;
                        if (strFunctie == "NIEUW")
                        {
                            txtFunProg.Focus();
                        }
                        else
                        {
                            txtFunParm.Focus();
                        }
                        break;
                    }
                
                case "PUBL":
                    {
                        grbPublMaintD.Visible = true;
                        if (strFunctie == "NIEUW")
                        {
                            txtPublCode.Focus();
                        }
                        else
                        {
                            txtPublOmsc.Focus();
                        }
                        break;
                    } 
                
                case "SUBSYS":
                    {
                        // NIEUW en WIJZIGEN hetzelfde
                        grbSubMaintD.Visible = true;
                        if (strFunctie == "NIEUW")
                        {
                            txtSubNaam.Focus();
                        }
                        else
                        {
                            txtSubOmsc.Focus();
                        }
                        break;
                    }
                case "TABELLEN":
                    {
                        grbTablMaintD.Visible = true;
                        if (strFunctie == "NIEUW")
                        {
                            txtTablTabn.Focus();
                        }
                        else
                        {
                            txtTablOmsc.Focus();                            
                        }
                        break;
                    }
                case "ELEMENTEN":
                    {
                        grbElemMaintD.Visible = true;
                        if (strFunctie == "NIEUW")
                        {
                            cmbElemTabn.SelectedIndex = 0;
                            cmbElemTabn.Focus();
                        }
                        else
                        {
                            txtElemOms1.Focus();
                        }
                        break;
                    }

                case "CONNECTIES":
                    {
                        grbConnMaintD.Visible = true;
                        if (strFunctie == "NIEUW")
                        {
                            txtConnSnam.Focus();
                        }
                        else
                        {
                            txtConnPass.PasswordChar = Convert.ToChar("*");
                            txtConnUser.PasswordChar = Convert.ToChar("*");
                            txtConnHost.Focus();
                        }
                        break;
                    }

                case "UITG":
                    {
                        grbUitgMaintD.Visible = true;
                        if (strFunctie == "NIEUW")
                        {
                            txtUitgCode.Focus();
                        }
                        else
                        {
                            txtUitgOmsc.Focus();
                        }
                        break;
                    }
                default:
                    {
                        clDashFunction.Melding("Onbekende beheertabel: " + strBeheer_tabel, 1, "I");
                        break;
                    }
            }
            bChanged = false;
        }
        private void cmdCancel_Click(object sender, EventArgs e)
        {
            if (bChanged)
            {
                if (clDashFunction.Melding("Gegevens zijn gewijzigd, afsluiten zonder opslaan ?",4,"Q") == DialogResult.Yes)
                {
                    this.Close();
                }
                else
                {
                  return;
                }

            }
            else
            {               
                this.Close();
            }
        }

        private void cmdOK_Click(object sender, EventArgs e)
        {
            if (strFunctie == "NIEUW")
            {
                if(verwerk_nieuw())
                {
                    switch (strBeheer_tabel)
                    {
                        case "ELEMENTEN":
                            {
                                bChanged = false;
                                break;
                            }

                        default:
                            {
                                this.Close();
                                break;
                            }
                    }
                
                }
            }
            if (strFunctie == "WIJZIG")
            {
                if (verwerk_wijzig())
                {
                    this.Close();
                }
            }
        }

        private void txtCode_TextChanged(object sender, EventArgs e)
        {
            bChanged = true;
        }

        private void txtNaam_TextChanged(object sender, EventArgs e)
        {
            bChanged = true;
        }

        /// <summary>
        /// Initiele acties klaarzetten wijzigingsscherm
        /// </summary>
        /// <param name="strBeheer_tabel"></param>
        private void init_nieuw(string strBeheer_tabel)
        {            
            switch (strBeheer_tabel)
            {
                case "BRON":
                    {                       
                        break;
                    }
                
                case "CONNECTIES":
                    {
                        break;
                    }
                
                case "FUNCTIE":
                    {
                        rbExec.Checked   = true;
                        cmdKies.Enabled  = true;
                        break;
                    }

                case "GROEP":
                    {                       
                        break;
                    }

                case "GEBRUIKER":
                    {
                        DoSql mysql = new DoSql();
                        mysql.vul_deze_combobox = this.cmbUsrGroep;
                        mysql.DoQuery("SELECT   DISTINCT UgroCode " +
                                      "FROM     DashUgro "+
                                      "ORDER BY UgroCode");
                        txtUsrId.Enabled    = false;
                        break;
                    }
                
                case "PUBL":
                    {                        
                        break;
                    }

                case "SUBSYS":
                    {
                        break;
                    }

                case "TABELLEN":
                    {                                         
                        break;
                    }

                case "ELEMENTEN":
                    {                      
                       // Hierbij de actuele waarden....
                       DoSql mysql = new DoSql();
                       mysql.vul_deze_text1_array  = new string [100];
                       mysql.vul_deze_text2_array  = new string [100];
                       mysql.vul_deze_text3_array  = new string [100];
                       mysql.vul_deze_text1_array[1] = "FTA";
                       mysql.DoQuery("SELECT TablTabn, TablOmsc, TablTabn " +
                                     "FROM   DashTabl "+
                                     "ORDER BY TablTabn ");
                        for (int i = 1; i <= mysql.affected_rows; i++)
                        {
                            cmbElemTabn.Items.Add(mysql.vul_deze_text1_array[i].ToString()+
                            " - " +
                            mysql.vul_deze_text2_array[i].ToString());
                        }                       
                        break;
                    }
                case "UITG":
                    {
                        DoSql mysql = new DoSql();
                        mysql.vul_deze_combobox = this.cmbUitgBron;
                        mysql.DoQuery("SELECT BronCode " +
                                      "FROM   DashBron " +
                                      "ORDER BY BronCode");
                        cmbUitgBron.Items.Add(" ");
                        mysql.vul_deze_combobox = this.cmbUitgPubl;
                        mysql.DoQuery("SELECT PublCode " +
                                      "FROM   DashPubl " +
                                      "ORDER BY PublCode"); 
                        break;
                    }
            }
        }

        /// <summary>
        /// Initiele acties klaarzetten wijzigingsscherm
        /// </summary>
        /// <param name="strBeheer_tabel"></param>
        private void init_wijzig(string strBeheer_tabel)
        {
            switch (strBeheer_tabel)
            {
                case "BRON":
                    {
                        txtBronCode.Text = arr_DetailData[0].ToString();
                        txtBronOmsc.Text = arr_DetailData[1].ToString();
                        txtBronCode.Enabled = false;
                        break;
                    }

                case "FUNCTIE":
                    {
                        rbInt.Enabled      = false;
                        rbExec.Enabled     = false;
                        cmdKies.Enabled    = false;
                        txtFunProg.Enabled = false;
                        txtFunParm.Enabled = false;
                        txtFunText.Text = arr_DetailData[0].ToString();
                        txtFunProg.Text = arr_DetailData[1].ToString();
                        txtFunParm.Text = arr_DetailData[2].ToString();
                        if (arr_DetailData[3].ToString() == "I")
                        {
                            rbInt.Checked   = true;                           
                        }
                        else
                        {
                            rbExec.Checked  = true;                            
                        }
                     
                        break;
                    }
                case "GROEP":
                    {
                        txtGrpCode.Text = arr_DetailData[0].ToString();
                        txtGrpNaam.Text = arr_DetailData[1].ToString();
                                                
                        txtGrpCode.Enabled  = false;
                        break;
                    }
                case "GEBRUIKER":
                    {
                        DoSql mysql = new DoSql();
                        mysql.vul_deze_combobox = this.cmbUsrGroep;
                        mysql.DoQuery("SELECT DISTINCT UgroCode " +
                                      "FROM DashUgro");
                        txtUsrId.Text   = arr_DetailData[0].ToString();
                        txtUsrCode.Text = arr_DetailData[1].ToString();
                        txtUsrNaam.Text = arr_DetailData[2].ToString();                        
                        cmbUsrGroep.SelectedIndex=
                        cmbUsrGroep.FindStringExact(arr_DetailData[3].ToString());
                        txtUsrPass.Text = arr_DetailData[4].ToString();   
                   
                        txtUsrId.Enabled    = false;
                        txtUsrCode.Enabled  = false;
                        break;
                    }
                case "SUBSYS":
                    {
                        txtSubNaam.Text    = arr_DetailData[0].ToString();
                        txtSubOmsc.Text    = arr_DetailData[1].ToString();
                        txtSubNaam.Enabled = false;                      
                        break;
                    }
                case "TABELLEN":
                    {
                        txtTablTabn.Text = arr_DetailData[0].ToString();
                        txtTablOmsc.Text = arr_DetailData[1].ToString();
                        txtTablElom.Text  = arr_DetailData[2].ToString();
                        txtTablO1om.Text  = arr_DetailData[3].ToString();
                        txtTablO2om.Text  = arr_DetailData[4].ToString();
                        txtTablTabn.Enabled = false;
                        break;
                    }
                case "CONNECTIES":
                    {
                        txtConnSnam.Text    = arr_DetailData[0].ToString();
                        txtConnHost.Text    = arr_DetailData[1].ToString();
                        txtConnUser.Text    = arr_DetailData[2].ToString();
                        txtConnPass.Text    = arr_DetailData[3].ToString();
                        txtConnFtpp.Text    = arr_DetailData[4].ToString();
                        txtConnTelp.Text    = arr_DetailData[5].ToString();
                        txtConnSnam.Enabled = false;
                        break;
                    }
                case "ELEMENTEN":
                    {
                        cmbElemTabn.Items.Add(arr_DetailData[0].ToString()+
                                              " - " + 
                                              arr_DetailData[1].ToString());
                        txtElemElem.Text    = arr_DetailData[2].ToString();
                        txtElemOms1.Text    = arr_DetailData[3].ToString();
                        txtElemOms2.Text    = arr_DetailData[4].ToString();                       
                        cmbElemTabn.Enabled = false;
                        txtElemElem.Enabled = false;
                        txtElemOms1.Enabled = true; 
                        cmbElemTabn.SelectedIndex = 0;
                        break;
                    }
                case "PUBL":
                    {
                        txtPublCode.Text = arr_DetailData[0].ToString();
                        txtPublOmsc.Text = arr_DetailData[1].ToString();
                        txtPublUdir.Text = arr_DetailData[2].ToString();
                        txtPublUenv.Text = arr_DetailData[3].ToString();
                        txtPublCode.Enabled = false;
                        break;
                    }
                case "UITG":
                    {
                        DoSql mysql = new DoSql();
                        mysql.vul_deze_combobox = this.cmbUitgBron;
                        mysql.DoQuery("SELECT BronCode " +
                                      "FROM   DashBron "+
                                      "ORDER BY BronCode" );
                        cmbUitgBron.Items.Add(" ");
                        mysql.vul_deze_combobox = this.cmbUitgPubl;
                        mysql.DoQuery("SELECT PublCode " +
                                      "FROM   DashPubl " +
                                      "ORDER BY PublCode");
                        txtUitgCode.Text = arr_DetailData[0].ToString();
                        txtUitgOmsc.Text = arr_DetailData[1].ToString();
                        cmbUitgPubl.SelectedIndex =
                        cmbUitgPubl.FindStringExact(arr_DetailData[2].ToString());
                        cmbUitgBron.SelectedIndex =
                        cmbUitgBron.FindStringExact(arr_DetailData[3].ToString());                        


                        txtUitgCode.Enabled = false;                        
                        break;
                    }
                default:
                    break;
            }
        }

        private Boolean verwerk_nieuw()
        {
            switch (strBeheer_tabel)
            {
                case "BRON":
                    {

                        if (!controleer(txtBronCode))
                        {
                            return false;
                        }
                        if (!controleer(txtBronOmsc))
                        {
                            return false;
                        }
                        
                        DoSql mysql = new DoSql();
                        mysql.vul_deze_string = "";
                        mysql.DoQuery("SELECT 1       " +
                                        "FROM DashBron  " +
                                        "WHERE BronCode = '" + txtBronCode.Text + "' ");                                       
                        if (mysql.vul_deze_string == "1")
                        {
                            clDashFunction.Melding("Bron is reeds aanwezig !", 1, "E");
                            return false;
                        }
                        mysql.DoUpdate("INSERT INTO DashBron " +
                                        "(BronCode, BronOmsc, BronCdat, BronCtyd, " +
                                        " BronCusr, BronMdat, BronMtyd, BronMusr) " +
                                        " VALUES('" + txtBronCode.Text + "'" +
                                                  ",'" + txtBronOmsc.Text + "'" +
                                                  ",'" + clDashFunction.get_mutdatum() + "'" +
                                                  ",'" + clDashFunction.get_muttijd() + "'" +
                                                  ",'" + strUserCode + "'" +
                                                  ",'" + clDashFunction.get_mutdatum() + "'" +
                                                  ",'" + clDashFunction.get_muttijd() + "'" +
                                                  ",'" + strUserCode + "')");
                        // Experimenteel stuk om in calling form (tabel) te focussen op de toegevoegde rij....
                        arr_DetailData.Add(txtBronCode.Text);                        
                        // Eind experimenteel stuk
                        return true;
                    }
                case "FUNCTIE":
                {

                    if (!controleer(txtFunText))
                    {
                         return false;
                    }
                    if (!controleer(txtFunProg))
                    {
                         return false;
                    }                    

                    DoSql mysql = new DoSql();
                    mysql.vul_deze_string = "";
                    mysql.DoQuery(  "SELECT 1       " +
                                    "FROM DashFunc  " +
                                    "WHERE FuncText = '" + txtFunText.Text + "' " +
                                    "AND   FuncParm = '" + txtFunParm.Text + "'" );
                    if (mysql.vul_deze_string == "1")
                    {
                        clDashFunction.Melding("Functie met deze naam en parameter(s) is reeds aanwezig !",1,"E");                        
                        return false;
                    }
                    mysql.DoUpdate("INSERT INTO DashFunc " +
                                    "(FuncText, FuncProg, FuncParm,FuncFuns, FuncCdat, FuncCtyd, " +
                                    " FuncCusr, FuncMdat, FuncMtyd, FuncMusr) " +
                                    " VALUES(   '" + txtFunText.Text    + "'" +
                                              ",'" + txtFunProg.Text    + "'" +
                                              ",'" + txtFunParm.Text    + "'" +
                                              ",'" + get_intORext_ind() + "'" +
                                              ",'" + clDashFunction.get_mutdatum() + "'" +
                                              ",'" + clDashFunction.get_muttijd () + "'" +
                                              ",'" + strUserCode                   + "'" +
                                              ",'" + clDashFunction.get_mutdatum() + "'" +
                                              ",'" + clDashFunction.get_muttijd () + "'" +
                                              ",'" + strUserCode                   + "')");
                    // Experimenteel stuk om in calling form (tabel) te focussen op de toegevoegde rij....
                    arr_DetailData.Add(txtFunProg.Text);
                    arr_DetailData.Add(txtFunParm.Text);
                    // Eind experimenteel stuk
                    return true;
                }

                case "GEBRUIKER":
                {
                    if (!controleer(txtUsrCode))
                    {
                        return false;
                    }
                    
                    if (!controleer(txtUsrNaam))
                    {
                        return false;
                    }
                    if (!controleer(txtUsrPass))
                    {
                        return false;
                    }              
                    if (!controleer(cmbUsrGroep))
                    {
                        return false;
                    }

                    DoSql mysql = new DoSql();
                    mysql.DoUpdate("INSERT INTO DashUser " +
                                   "(UserCode, UserNaam, UserPass, UserUgro, UserCdat, " +
                                   " UserCtyd,  UserCusr, UserMdat, UserMtyd, UserMusr) " +
                                   " VALUES('" + txtUsrCode.Text.ToUpper() + "'" +
                                            ",'" + txtUsrNaam.Text + "'" +
                                            ",'" + txtUsrPass.Text + "'" +
                                            ",'" + cmbUsrGroep.Text + "'" +
                                            ",'" + clDashFunction.get_mutdatum() + "'" +
                                            ",'" + clDashFunction.get_muttijd() + "'" +
                                            ",'" + strUserCode+ "'" +
                                            ",'" + clDashFunction.get_mutdatum() + "'" +
                                            ",'" + clDashFunction.get_muttijd() + "'" +
                                            ",'" + strUserCode+ "')");
                    // Experimenteel stuk om in calling form (tabel) te focussen op de toegevoegde rij....
                    arr_DetailData.Add(txtUsrCode.Text.ToUpper());
                    // Eind experimenteel stuk
                        return true;                        
                    }

                case "GROEP":
                    {

                        if (!controleer(txtGrpCode))
                        {
                            return false;
                        }
                        
                        if (!controleer(txtGrpNaam))
                        {
                            return false;
                        }
                        
                        DoSql tmysql = new DoSql();
                        tmysql.DoUpdate("INSERT INTO DashUgro " +
                                       "(UgroCode, UgroNaam, UgroCdat, Ugroctyd, " +
                                       " UgroCusr, UgroMdat, UgroMtyd, UgroMusr) " +
                                       " VALUES('" + txtGrpCode.Text.ToUpper() + "'" +
                                                ",'" + txtGrpNaam.Text + "'" +
                                                ",'" + clDashFunction.get_mutdatum() + "'" +
                                                ",'" + clDashFunction.get_muttijd()  + "'" +
                                                ",'" + strUserCode+ "'" +
                                                ",'" + clDashFunction.get_mutdatum() + "'" +
                                                ",'" + clDashFunction.get_muttijd()  + "'" +
                                                ",'" + strUserCode+ "')");
                        // Experimenteel stuk om in calling form (tabel) te focussen op de toegevoegde rij....
                        arr_DetailData.Add(txtGrpCode.Text.ToUpper());
                        // Eind experimenteel stuk
                        return true;     
                    }
                case "PUBL":
                    {

                        if (!controleer(txtPublCode))
                        {
                            return false;
                        }
                        if (!controleer(txtPublOmsc))
                        {
                            return false;
                        }
                        if (!controleer(txtPublUdir))
                        {
                            return false;
                        }
                        if (!controleer(txtPublUenv))
                        {
                            return false;
                        }
                        DoSql mysql = new DoSql();
                        mysql.vul_deze_string = "";
                        mysql.DoQuery(  "SELECT 1       " +
                                        "FROM DashPubl  " +
                                        "WHERE PublCode = '" + txtPublCode.Text + "' ");
                        if (mysql.vul_deze_string == "1")
                        {
                            clDashFunction.Melding("Uitgever is reeds aanwezig !", 1, "E");
                            return false;
                        }
                        mysql.DoUpdate("INSERT INTO DashPubl " +
                                        "(PublCode, PublOmsc, PublUdir, PublUenv ," + 
                                        " PublCdat, PublCtyd, PublCusr, " +
                                        " PublMdat, PublMtyd, PublMusr) " +
                                        " VALUES('" + txtPublCode.Text + "'" +
                                                  ",'" + txtPublOmsc.Text + "'" +
                                                  ",'" + txtPublUdir.Text + "'" +
                                                  ",'" + txtPublUenv.Text + "'" +
                                                  ",'" + clDashFunction.get_mutdatum() + "'" +
                                                  ",'" + clDashFunction.get_muttijd() + "'" +
                                                  ",'" + strUserCode + "'" +
                                                  ",'" + clDashFunction.get_mutdatum() + "'" +
                                                  ",'" + clDashFunction.get_muttijd() + "'" +
                                                  ",'" + strUserCode + "')");
                        // Experimenteel stuk om in calling form (tabel) te focussen op de toegevoegde rij....
                        arr_DetailData.Add(txtPublCode.Text.ToUpper());
                        // Eind experimenteel stuk
                        return true;
                    }
                case "SUBSYS":
                    {
                        if (!controleer(txtSubNaam))
                        {
                            return false;
                        }
                        
                        if (!controleer(txtSubOmsc))
                        {
                            return false;
                        }
                       
                        DoSql mysql = new DoSql();
                        mysql.vul_deze_string = "";
                        mysql.DoQuery("SELECT 1 " +
                                      "FROM  DashSubs " +
                                      "WHERE SubsNaam = '" + txtSubNaam.Text + "'");
                        if (mysql.vul_deze_string == "1")
                        {
                            clDashFunction.Melding("Subsysteem met deze omschrijving komt reeds voor !", 1, "I");
                            txtSubNaam.Focus();
                            return false;
                        }
                        mysql.vul_deze_string = ""; 
                        mysql.DoUpdate("INSERT INTO DashSubs " +
                                        "(SubsNaam, SubsOmsc, SubsCdat, SubsCtyd, " +
                                        " SubsCusr, SubsMdat, SubsMtyd, SubsMusr) " +
                                           " VALUES('" + txtSubNaam.Text + "'" +
                                                  ",'" + txtSubOmsc.Text + "'" +
                                                  ",'" + clDashFunction.get_mutdatum() + "'" +
                                                  ",'" + clDashFunction.get_muttijd() + "'" +
                                                  ",'" + strUserCode+ "'" +
                                                  ",'" + clDashFunction.get_mutdatum() + "'" +
                                                  ",'" + clDashFunction.get_muttijd() + "'" +
                                                  ",'" + strUserCode+ "')");
                        // Experimenteel stuk om in calling form (tabel) te focussen op de toegevoegde rij....
                        arr_DetailData.Add(txtSubNaam.Text);
                        // Eind experimenteel stuk
                        return true;
                    }
                case "TABELLEN":
                    {
                        if (!controleer(txtTablTabn))
                        {
                            return false;
                        }
                        if (!controleer(txtTablOmsc))
                        {
                            return false;
                        }

                        DoSql mysql = new DoSql();
                        mysql.vul_deze_string = "";
                        mysql.DoQuery("SELECT 1 "+
                                      "FROM  DashTabl "+
                                      "WHERE TablTabn = "+txtTablTabn.Text);
                        if (mysql.vul_deze_string == "1")
                        {
                            clDashFunction.Melding("Tabel met dit nummer komt reeds voor !", 1, "I");
                            txtTablTabn.Focus();
                            return false;
                        }
                        mysql.DoUpdate("INSERT INTO DashTabl " +
                                        "(TablTabn, TablOmsc, TablElom, TablO1om, TablO2om, "+
                                        " TablCdat, TablCtyd, " +
                                        " TablCusr, TablMdat, TablMtyd, TablMusr) " +
                                           " VALUES('" + txtTablTabn.Text + "'" +
                                                  ",'" + txtTablOmsc.Text + "'" + 
                                                  ",'" + txtTablElom.Text + "'" +
                                                  ",'" + txtTablO1om.Text + "'" +
                                                  ",'" + txtTablO2om.Text + "'" +
                                                  ",'" + clDashFunction.get_mutdatum() + "'" +
                                                  ",'" + clDashFunction.get_muttijd() + "'" +
                                                  ",'" + strUserCode + "'" +
                                                  ",'" + clDashFunction.get_mutdatum() + "'" +
                                                  ",'" + clDashFunction.get_muttijd() + "'" +
                                                  ",'" + strUserCode + "')");
                        // Experimenteel stuk om in calling form (tabel) te focussen op de toegevoegde rij....
                        arr_DetailData.Add(txtTablTabn.Text);
                        // Eind experimenteel stuk
                        return true;
                    }
                case "CONNECTIES":
                    {
                        if (!controleer(txtConnSnam))
                        {
                            return false;
                        }

                        if (!controleer(txtConnHost))
                        {
                            return false;
                        }
                        if (!controleer(txtConnUser))
                        {
                            return false;
                        }
                        if (!controleer(txtConnPass))
                        {
                            return false;
                        }
                        if (!controleer(txtConnFtpp))
                        {
                            return false;
                        }
                        if (!controleer(txtConnTelp))
                        {
                            return false;
                        }

                        DoSql mysql = new DoSql();
                        mysql.vul_deze_string = "";
                        mysql.DoQuery("SELECT 1 " +
                                      "FROM  DashConn " +
                                      "WHERE ConnSnam = '" + txtConnSnam.Text + "'");
                        if (mysql.vul_deze_string == "1")
                        {
                            clDashFunction.Melding("Connectie met deze omschrijving komt reeds voor !", 1, "I");
                            txtConnSnam.Focus();
                            return false;
                        }
                        mysql.DoUpdate("INSERT INTO DashConn " +
                                       "(ConnSnam, ConnHost, ConnUser, ConnPass, ConnFtpp, ConnTelp, ConnCdat, " +
                                       " ConnCtyd, ConnCusr, ConnMdat, ConnMtyd, ConnMusr) " +
                                       " VALUES('" + txtConnSnam.Text + "'" +
                                                ",'" + txtConnHost.Text + "'" +
                                                ",'" + txtConnUser.Text + "'" +
                                                ",'" + txtConnPass.Text + "'" +
                                                ",'" + txtConnFtpp.Text + "'" +
                                                ",'" + txtConnTelp.Text + "'" +
                                                ",'" + clDashFunction.get_mutdatum() + "'" +
                                                ",'" + clDashFunction.get_muttijd() + "'" +
                                                ",'" + strUserCode + "'" +
                                                ",'" + clDashFunction.get_mutdatum() + "'" +
                                                ",'" + clDashFunction.get_muttijd() + "'" +
                                                ",'" + strUserCode + "')");
                        // Experimenteel stuk om in calling form (tabel) te focussen op de toegevoegde rij....
                        arr_DetailData.Add(txtConnSnam.Text);
                        // Eind experimenteel stuk
                        return true;
                    }
                case "ELEMENTEN":
                    {
                        if (cmbElemTabn.SelectedIndex < 0)
                        {
                            clDashFunction.Melding("Tabelnummer moet worden geselecteerd !", 1, "I");
                            cmbElemTabn.Focus();
                            return false;
                        }

                        if (!controleer(txtElemElem))
                        {
                            return false;
                        }
                        if (!controleer(txtElemOms1))
                        {
                            return false;
                        }
                        // Hier moet eerst het numerieke tabelnummer worden uitgehacked,
                        // staat nu een gecombineerde string in....
                        string[] strCmbElem_splitted = Regex.Split(cmbElemTabn.Text, " - ");

                        DoSql mysql = new DoSql();
                        mysql.vul_deze_string = "";
                        mysql.DoQuery(  "SELECT 1 " +
                                        "FROM  DashElem " +
                                        "WHERE ElemTabn = " + strCmbElem_splitted[0] + " " +
                                        "AND   ElemElem = '" + txtElemElem.Text + "'" + " " +
                                        "AND   ElemOms1 = '" + txtElemOms1.Text + "'");
                        if (mysql.vul_deze_string == "1")
                        {
                            clDashFunction.Melding("Element met deze omschrijving1 reeds aanwezig !", 1, "E");
                            return false;
                        }
                        mysql.DoUpdate("INSERT INTO DashElem " +
                                        "(ElemTabn, ElemElem, ElemOms1, ElemOms2, "+
                                        " ElemCdat, ELemCtyd, ElemCusr, ELemMdat, " +
                                        " ElemMtyd, ElemMusr) " +
                                           " VALUES('" + strCmbElem_splitted[0] + "'" +
                                                  ",'" + txtElemElem.Text       + "'" +
                                                  ",'" + txtElemOms1.Text       + "'" + 
                                                  ",'" + txtElemOms2.Text       + "'" + 
                                                  ",'" + clDashFunction.get_mutdatum() + "'" +
                                                  ",'" + clDashFunction.get_muttijd() + "'" +
                                                  ",'" + strUserCode + "'" +
                                                  ",'" + clDashFunction.get_mutdatum() + "'" +
                                                  ",'" + clDashFunction.get_muttijd() + "'" +
                                                  ",'" + strUserCode + "')");

                        // Experimenteel stuk om in calling form (tabel) te focussen op de toegevoegde rij....
                        arr_DetailData.Add(strCmbElem_splitted[0]);
                        arr_DetailData.Add(txtElemElem.Text);                       
                        // Eind experimenteel stuk
                        txtElemElem.Text = "";
                        txtElemOms1.Text = "";
                        txtElemOms2.Text = "";
                        txtElemElem.Focus();
                        return true;
                    }

                case "UITG":
                    {
                        if (!controleer(txtUitgCode))
                        {
                            return false;
                        }

                        if (!controleer(txtUitgOmsc))
                        {
                            return false;
                        }

                        if (!controleer(cmbUitgPubl))
                        {
                            return false;
                        }

                        if (!controleer(cmbUitgBron))
                        {
                            return false;
                        }

                        DoSql mysql = new DoSql();
                        mysql.DoUpdate("INSERT INTO DashUitg " +
                                       "(UitgCode, UitgOmsc, UitgPubl, UitgBron, UitgCdat, " +
                                       " UitgCtyd, UitgCusr, UitgMdat, UitgMtyd, UitgMusr) " +
                                       " VALUES('" + txtUitgCode.Text.ToUpper() + "'" +
                                                ",'" + txtUitgOmsc.Text + "'" +
                                                ",'" + cmbUitgPubl.Text + "'" + 
                                                ",'" + cmbUitgBron.Text + "'" +
                                                ",'" + clDashFunction.get_mutdatum() + "'" +
                                                ",'" + clDashFunction.get_muttijd() + "'" +
                                                ",'" + strUserCode + "'" +
                                                ",'" + clDashFunction.get_mutdatum() + "'" +
                                                ",'" + clDashFunction.get_muttijd() + "'" +
                                                ",'" + strUserCode + "')");
                        // Experimenteel stuk om in calling form (tabel) te focussen op de toegevoegde rij....
                        arr_DetailData.Add(txtUitgCode.Text.ToUpper());                      
                        // Eind experimenteel stuk
                        return true;
                    }
               
                default:
                    clDashFunction.Melding("Onbekende beheer tabel: " + strBeheer_tabel,1,"E");                    
                    return false;
            }
        }
        private Boolean verwerk_wijzig()
        {
            switch (strBeheer_tabel)
            {
                case "BRON":
                    {
                        if (!controleer(txtBronCode))
                        {
                            return false;
                        }
                        if (!controleer(txtBronOmsc))
                        {
                            return false;
                        }

                        DoSql mysql = new DoSql();
                        mysql.DoUpdate(" UPDATE DashBron " +
                                       " SET BronOmsc = '" + txtBronOmsc.Text + "'" +
                                           ",BronMdat = '" + clDashFunction.get_mutdatum() + "'" +
                                           ",BronMtyd = '" + clDashFunction.get_muttijd() + "'" +
                                           ",BronMusr = '" + strUserCode + "'" +
                                       " WHERE BronCode = '" + txtBronCode.Text + "'" );                                      
                        return true;
                    }

                case "FUNCTIE":
                    {
                        if (!controleer(txtFunText))
                        {
                            return false;
                        }
                        if (!controleer(txtFunProg))
                        {
                            return false;
                        }
                        
                        DoSql mysql = new DoSql();
                        mysql.DoUpdate(" UPDATE DashFunc " +
                                       " SET  FuncText = '" + txtFunText.Text               + "'" +
                                            ",FuncFuns = '" + get_intORext_ind()            + "'" +
                                            ",FuncMdat = '" + clDashFunction.get_mutdatum() + "'" +
                                            ",FuncMtyd = '" + clDashFunction.get_muttijd()  + "'" +
                                            ",FuncMusr = '" + strUserCode                   + "'" +
                                       " WHERE FuncProg = '" + txtFunProg.Text + "' " +
                                       " AND   FuncParm = '" + txtFunParm.Text + "'");
                        return true;
                    }
                case "GEBRUIKER":
                    {
                        if (!controleer(txtUsrCode))
                        {
                            return false;
                        }
                        if (!controleer(txtUsrNaam))
                        {
                            return false;
                        }
                        if (!controleer(txtUsrPass))
                        {
                            return false;
                        }    
                        if (!controleer(cmbUsrGroep))
                        {
                            return false;
                        }

                        DoSql mysql = new DoSql();
                        mysql.DoUpdate("UPDATE DashUser " +
                                       "SET  UserNaam = '" + txtUsrNaam.Text + "'" +
                                           ",UserPass = '" + txtUsrPass.Text + "'" +
                                           ",UserUgro = '" + cmbUsrGroep.Text + "'" +
                                           ",UserMdat = '" + clDashFunction.get_mutdatum() + "'" +
                                           ",UserMtyd = '" + clDashFunction.get_muttijd() + "'" +
                                           ",UserMusr = '" + strUserCode+ "' " +
                                        "WHERE UserVolg = " + txtUsrId.Text);
                        return true;
                    }
                case "GROEP":
                    {
                     if (!controleer(txtGrpCode))
                        {
                            return false;
                         }
                     if (!controleer(txtGrpNaam))
                     {
                         return false;
                     }
                        DoSql tmysql = new DoSql();
                        tmysql.DoUpdate("UPDATE DashUgro " +
                                       "SET  UgroNaam = '" + txtGrpNaam.Text + "'" +
                                           ",UgroMdat = '" + clDashFunction.get_mutdatum() + "'" +
                                           ",UgroMtyd = '" + clDashFunction.get_muttijd() + "'" +
                                           ",UgroMusr = '" + strUserCode      + "' "+
                                       "WHERE UgroCode = '"+ txtGrpCode.Text + "'");
                        return true;
                    }
                case "PUBL":
                    {
                        if (!controleer(txtPublCode))
                        {
                            return false;
                        }
                        if (!controleer(txtPublOmsc))
                        {
                            return false;
                        }
                        if (!controleer(txtPublUdir))
                        {
                            return false;
                        }
                        if (!controleer(txtPublUenv))
                        {
                            return false;
                        }
                        DoSql mysql = new DoSql();
                        mysql.DoUpdate(" UPDATE DashPubl " +
                                       " SET PublOmsc = '" + txtPublOmsc.Text + "'" +
                                          ", PublUdir = '" + txtPublUdir.Text + "'" +
                                          ", PublUenv = '" + txtPublUenv.Text + "'" +
                                          ", PublMdat = '" + clDashFunction.get_mutdatum() + "'" +
                                          ", PublMtyd = '" + clDashFunction.get_muttijd() + "'" +
                                          ", PublMusr = '" + strUserCode + "'" +
                                       " WHERE PublCode = '" + txtPublCode.Text + "'");
                        return true;
                    }
                case "SUBSYS":
                    {
                        if (!controleer(txtSubNaam))
                        {
                            return false;
                        }
                        if (!controleer(txtSubOmsc))
                        {
                            return false;
                        }

                        DoSql mysql = new DoSql();
                        mysql.DoUpdate("UPDATE DashSubs " +
                                         "SET  SubsOmsc = '" + txtSubOmsc.Text + "'" +
                                             ",SubsMdat = '" + clDashFunction.get_mutdatum()  + "'" +
                                             ",SubsMtyd = '" + clDashFunction.get_muttijd()   + "'" +
                                             ",SubsMusr = '" + strUserCode+ "' " +
                                        "WHERE SubsNaam = '" + txtSubNaam.Text + "'" );
                        return true;
                    }
                case "TABELLEN":
                    {
                        if (!controleer(txtTablTabn))
                        {
                            return false;
                        }
                        if (!controleer(txtTablOmsc))
                        {
                            return false;
                        }

                        DoSql mysql = new DoSql();
                        mysql.DoUpdate("UPDATE DashTabl " +
                                         "SET  TablOmsc = '" + txtTablOmsc.Text + "'" +
                                             ",TablElom = '" + txtTablElom.Text + "'" +
                                             ",TablO1om = '" + txtTablO1om.Text + "'" +
                                             ",TablO2om = '" + txtTablO2om.Text + "'" +    
                                             ",TablMdat = '" + clDashFunction.get_mutdatum() + "'" +
                                             ",TablMtyd = '" + clDashFunction.get_muttijd() + "'" +
                                             ",TablMusr = '" + strUserCode + "' " +
                                        "WHERE TablTabn = " + txtTablTabn.Text);
                        return true;
                    }
                case "CONNECTIES":
                    {
                        if (!controleer(txtConnHost))
                        {
                            return false;
                        }
                        if (!controleer(txtConnUser))
                        {
                            return false;
                        }
                        if (!controleer(txtConnPass))
                        {
                            return false;
                        }
                        if (!controleer(txtConnFtpp))
                        {
                            return false;
                        }
                        if (!controleer(txtConnTelp))
                        {
                            return false;
                        }
                        DoSql mysql = new DoSql();
                        mysql.DoUpdate("UPDATE DashConn " +
                                       "SET  ConnHost = '" + txtConnHost.Text + "'" +
                                           ",ConnUser = '" + txtConnUser.Text + "'" +
                                           ",ConnPass = '" + txtConnPass.Text + "'" +
                                           ",ConnFtpp = '" + txtConnFtpp.Text + "'" +
                                           ",ConnTelp = '" + txtConnTelp.Text + "'" + 
                                           ",ConnMdat = '" + clDashFunction.get_mutdatum() + "'" +
                                           ",ConnMtyd = '" + clDashFunction.get_muttijd() + "'" +
                                           ",ConnMusr = '" + strUserCode + "' " +
                                        "WHERE ConnSnam = '" + txtConnSnam.Text + "'");
                        return true;
                    }
                case "ELEMENTEN":
                    {
                        if (!controleer(txtElemElem))
                        {
                            return false;
                        }
                        if (!controleer(txtElemOms1))
                        {
                            return false;
                        }

                        // Hier moet eerst het numerieke tabelnummer worden uitgehacked,
                        // staat nu een gecombineerde string in....
                        string[] strCmbElem_splitted = Regex.Split(cmbElemTabn.Text, " - ");


                        DoSql mysql = new DoSql();
                        mysql.DoUpdate("UPDATE DashElem " +
                                         "SET  ElemOms1 = '" + txtElemOms1.Text + "'" +                                            
                                            ", ElemOms2 = '" + txtElemOms2.Text + "'" +
                                            ", ElemMdat = '" + clDashFunction.get_mutdatum() + "'" +
                                            ", ElemMtyd = '" + clDashFunction.get_muttijd() + "'" +
                                            ", ElemMusr = '" + strUserCode + "' " +
                                        "WHERE ElemTabn = " + strCmbElem_splitted[0] + 
                                        "  AND ElemElem = '"+ txtElemElem.Text + "'" ); 
                                   // Zat vroeger in de primary key
                                   // + "  AND ElemOms1 = '"+ txtElemOms1.Text + "'" );
                        if (mysql.affected_rows == 0)
                        {
                            clDashFunction.Melding("SQL Update heeft 0 rijen gewijzigd !", 1, "I");
                        }
                        return true;
                    }

                case "UITG":
                    {
                        if (!controleer(txtUitgCode))
                        {
                            return false;
                        }
                        if (!controleer(txtUitgOmsc))
                        {
                            return false;
                        }
                        if (!controleer(cmbUitgPubl))
                        {
                            return false;
                        }
                        if (!controleer(cmbUitgBron))
                        {
                            return false;
                        }

                        DoSql mysql = new DoSql();
                        mysql.DoUpdate("UPDATE DashUitg " +
                                       "SET  UitgOmsc = '" + txtUitgOmsc.Text + "'" +
                                           ",UitgBron = '" + cmbUitgBron.Text + "'" +
                                           ",UitgPubl = '" + cmbUitgPubl.Text + "'" +
                                           ",UitgMdat = '" + clDashFunction.get_mutdatum() + "'" +
                                           ",UitgMtyd = '" + clDashFunction.get_muttijd() + "'" +                                         
                                       "WHERE UitgCode = '" + txtUitgCode.Text + "'");
                        return true;
                    }
                default:
                    clDashFunction.Melding("Onbekende beheer tabel: " + strBeheer_tabel, 1, "E");
                    return false;
            }
        }      

        private Boolean controleer(Control veld)
        {
            if (veld.Text == "")
            {
                clDashFunction.Melding(veld.Tag + " moet worden ingevuld", 1, "E");
                veld.Focus();
                return false;
            }

            if (veld.Name.ToUpper() == "TXTUSRPASS")
            {
                if (txtUsrPass.Text.Length < 5 || txtUsrPass.Text.Length > 8)
                {
                    clDashFunction.Melding("Password minimaal 5 en maximaal 8 tekens !", 1, "I");
                    txtUsrPass.Focus();
                    return false;
                }
            }
            if (veld.Name.ToUpper() == "TXTCONNFTPP")
            {
                if (txtConnFtpp.Text != "21")
                {
                    clDashFunction.Melding("Default FTP poort moet 21 zijn", 1, "I");
                    txtConnFtpp.Focus();
                    return false;
                }
            }
            
            if (veld.Name.ToUpper() == "TXTCONNTELP")
            {
                if (txtConnTelp.Text != "23")
                {
                    clDashFunction.Melding("Default Telnet poort moet 23 zijn", 1, "I");
                    txtConnTelp.Focus();
                    return false;
                }
            }
            return true;   
        }       

        private void cmdKies_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            openFileDialog1.InitialDirectory = "c:\\";
            openFileDialog1.Filter = "EXE files (*.exe)|*.exe";
            openFileDialog1.FilterIndex = 0;
            openFileDialog1.RestoreDirectory = true;
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                txtFunProg.Text = openFileDialog1.FileName;
            }
        }

        private string get_intORext_ind()
        {           
            if (rbExec.Checked)
            {
                return "E";
            }
            else
            {
                return "I";
            }
        }

        private void rbExec_CheckedChanged(object sender, EventArgs e)
        {
            if (rbExec.Checked)
            {
                grbProgfile.Text            = "Programma(path)"; 
                cmdKies.Enabled             = rbExec.Checked;
                lblSplit_instructie.Visible = rbExec.Checked;
            }            
        }

        private void rbInt_CheckedChanged(object sender, EventArgs e)
        {
            if (rbInt.Checked)
            {            
                grbProgfile.Text            = "Formnaam";
                cmdKies.Enabled             = rbExec.Checked;
                lblSplit_instructie.Visible = rbExec.Checked;
            }           
        }

        private void txtFunId_TextChanged(object sender, EventArgs e)
        {
            bChanged = true;
        }

        private void txtFunProg_TextChanged(object sender, EventArgs e)
        {
            bChanged = true;
        }

        private void txtFunText_TextChanged(object sender, EventArgs e)
        {
            bChanged = true;
        }

        private void txtGrpCode_TextChanged(object sender, EventArgs e)
        {
            bChanged = true;
        }

        private void txtGrpId_TextChanged(object sender, EventArgs e)
        {
            bChanged = true;
        }

        private void txtGrpNaam_TextChanged(object sender, EventArgs e)
        {
            bChanged = true;
        }

        private void txtSubNaam_TextChanged(object sender, EventArgs e)
        {
            bChanged = true;
        }

        private void txtUsrId_TextChanged(object sender, EventArgs e)
        {
            bChanged = true;
        }

        private void txtUsrPass_TextChanged(object sender, EventArgs e)
        {
            bChanged = true;
        }

        private void txtTablTabn_TextChanged(object sender, EventArgs e)
        {
            bChanged = true;
        }

        private void txtTablOmsc_TextChanged(object sender, EventArgs e)
        {
            bChanged = true;
        }        

        private void cmbElemTabn_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblElemElem.Text = "Tabelelement:";
            lblElemOms1.Text = "Omschrijving 1:";
            lblElemOms2.Text = "Omschrijving 2:";

            // Hier moet eerst het numerieke tabelnummer worden uitgehacked,
            // staat nu een gecombineerde string in....
            string[] strCmbElem_splitted = Regex.Split(cmbElemTabn.Text, " - ");

            DoSql tysql = new DoSql();
            // Eventueel aanwezige veldomschrijvingen ophalen; 
            tysql.vul_deze_text1_array = new string[2];
            tysql.vul_deze_text2_array = new string[2];
            tysql.vul_deze_text3_array = new string[2];
            tysql.vul_deze_text1_array[1] = "FTA";
            tysql.DoQuery("SELECT TablElOm, TablO1om, TablO2om " +
                          "FROM   DashTabl " +
                          "WHERE  TablTabn = " + strCmbElem_splitted[0] );
            if (tysql.vul_deze_text1_array[1].ToString() != "")
            {
                lblElemElem.Text = tysql.vul_deze_text1_array[1].ToString();                
            }
            if (tysql.vul_deze_text2_array[1].ToString() != "")
            {
                lblElemOms1.Text = tysql.vul_deze_text2_array[1].ToString();
            }
            if (tysql.vul_deze_text3_array[1].ToString() != "")
            {
                lblElemOms2.Text = tysql.vul_deze_text3_array[1].ToString();
            }
                                                       
            bChanged = true;
        }

        private void txtElemElem_TextChanged(object sender, EventArgs e)
        {
            bChanged = true;
        }

        private void txtElemOms1_TextChanged(object sender, EventArgs e)
        {
            bChanged = true;
        }

        private void txtElemOms2_TextChanged(object sender, EventArgs e)
        {
            bChanged = true;
        }
        private void txtConnSnam_TextChanged(object sender, EventArgs e)
        {
            bChanged = true;
        }

        private void txtConnHost_TextChanged(object sender, EventArgs e)
        {
            bChanged = true;
        }

        private void txtConnUser_TextChanged(object sender, EventArgs e)
        {
            bChanged = true;
        }

        private void txtConnPass_TextChanged(object sender, EventArgs e)
        {
            bChanged = true;
        }

        private void txtConnFtpp_TextChanged(object sender, EventArgs e)
        {
            bChanged = true;
        }

        private void txtConnTelp_TextChanged(object sender, EventArgs e)
        {
            bChanged = true;
        }

        private void txtUitgCode_TextChanged(object sender, EventArgs e)
        {
            bChanged = true;
        }

        private void txtUitgOmsc_TextChanged(object sender, EventArgs e)
        {
            bChanged = true;
        }

        private void cmbUitgBron_SelectedIndexChanged(object sender, EventArgs e)
        {
            bChanged = true;
        }

        private void txtBronCode_TextChanged(object sender, EventArgs e)
        {
            bChanged = true;
        }

        private void txtBronOmsc_TextChanged(object sender, EventArgs e)
        {
            bChanged = true;
        }
        private void txtPublCode_TextChanged(object sender, EventArgs e)
        {
            bChanged = true;
        }

        private void txtPublOmsc_TextChanged(object sender, EventArgs e)
        {
            bChanged = true;
        }

        private void txtPublUdir_TextChanged(object sender, EventArgs e)
        {
            bChanged = true;
        }

        private void txtPublUenv_TextChanged(object sender, EventArgs e)
        {
            bChanged = true;
        }           
        private void cmdTablElm_Click(object sender, EventArgs e)
        {
            strBeheer_tabel                  = "ELEMENTEN";
            frmDashMaintT DashMaintT         = new frmDashMaintT();
            DashMaintT.strTabel_nr           = "250";
            DashMaintT.strSupplemental_Title = strBeheer_tabel.ToLower();
            DashMaintT.strBeheer_tabel       = strBeheer_tabel;
            DashMaintT.strUserCode           = this.strUserCode;
            DashMaintT.Owner                 = this;
            DashMaintT.ShowDialog();      
        }

        private void cmbUsrGroep_SelectedIndexChanged(object sender, EventArgs e)
        {
            bChanged = true;
        }

        private void cmbUitgPubl_SelectedIndexChanged(object sender, EventArgs e)
        {
            bChanged = true;
        }

        private void txtSubOmsc_TextChanged(object sender, EventArgs e)
        {
            bChanged = true;
        }

        private void txtTablElom_TextChanged(object sender, EventArgs e)
        {
            bChanged = true;
        }

        private void txtTablO1om_TextChanged(object sender, EventArgs e)
        {
            bChanged = true;
        }

        private void txtTablO2om_TextChanged(object sender, EventArgs e)
        {
            bChanged = true;
        }                          
    }
}
