namespace dbDashboard
{
    partial class frmDashMaintT
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDashMaintT));
            this.grpMain = new System.Windows.Forms.GroupBox();
            this.cmdWijzig = new System.Windows.Forms.Button();
            this.cmdVerwijder = new System.Windows.Forms.Button();
            this.cmdNieuw = new System.Windows.Forms.Button();
            this.dgView = new System.Windows.Forms.DataGridView();
            this.cmpSearch1 = new dbDashboard.cmpSearch(this.components);
            this.cmpSearch2 = new dbDashboard.cmpSearch(this.components);
            this.grbConnect.SuspendLayout();
            this.grpMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgView)).BeginInit();
            this.SuspendLayout();
            // 
            // grbConnect
            // 
            this.grbConnect.Location = new System.Drawing.Point(12, 538);
            // 
            // lblHostName
            // 
            this.lblHostName.Location = new System.Drawing.Point(661, 470);
            this.lblHostName.Size = new System.Drawing.Size(145, 13);
            this.lblHostName.Text = "KPNNL\\WLD4BED923B63C";
            // 
            // grpMain
            // 
            this.grpMain.Controls.Add(this.cmdWijzig);
            this.grpMain.Controls.Add(this.cmdVerwijder);
            this.grpMain.Controls.Add(this.cmdNieuw);
            this.grpMain.Controls.Add(this.dgView);
            this.grpMain.Location = new System.Drawing.Point(12, 21);
            this.grpMain.Name = "grpMain";
            this.grpMain.Size = new System.Drawing.Size(778, 424);
            this.grpMain.TabIndex = 5;
            this.grpMain.TabStop = false;
            // 
            // cmdWijzig
            // 
            this.cmdWijzig.Location = new System.Drawing.Point(99, 385);
            this.cmdWijzig.Name = "cmdWijzig";
            this.cmdWijzig.Size = new System.Drawing.Size(75, 23);
            this.cmdWijzig.TabIndex = 8;
            this.cmdWijzig.Text = "Wijzig...";
            this.cmdWijzig.UseVisualStyleBackColor = true;
            this.cmdWijzig.Click += new System.EventHandler(this.cmdWijzig_Click);
            // 
            // cmdVerwijder
            // 
            this.cmdVerwijder.Location = new System.Drawing.Point(180, 385);
            this.cmdVerwijder.Name = "cmdVerwijder";
            this.cmdVerwijder.Size = new System.Drawing.Size(75, 23);
            this.cmdVerwijder.TabIndex = 7;
            this.cmdVerwijder.Text = "Verwijder...";
            this.cmdVerwijder.UseVisualStyleBackColor = true;
            this.cmdVerwijder.Click += new System.EventHandler(this.cmdVerwijder_Click);
            // 
            // cmdNieuw
            // 
            this.cmdNieuw.Location = new System.Drawing.Point(18, 385);
            this.cmdNieuw.Name = "cmdNieuw";
            this.cmdNieuw.Size = new System.Drawing.Size(75, 23);
            this.cmdNieuw.TabIndex = 6;
            this.cmdNieuw.Text = "Nieuw...";
            this.cmdNieuw.UseVisualStyleBackColor = true;
            this.cmdNieuw.Click += new System.EventHandler(this.cmdNieuw_Click);
            // 
            // dgView
            // 
            this.dgView.AllowUserToAddRows = false;
            this.dgView.AllowUserToDeleteRows = false;
            this.dgView.AllowUserToResizeRows = false;
            this.dgView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgView.Location = new System.Drawing.Point(19, 27);
            this.dgView.MultiSelect = false;
            this.dgView.Name = "dgView";
            this.dgView.ReadOnly = true;
            this.dgView.RowHeadersVisible = false;
            this.dgView.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgView.Size = new System.Drawing.Size(746, 341);
            this.dgView.TabIndex = 5;
            this.dgView.DoubleClick += new System.EventHandler(this.dgView_DoubleClick);
            // 
            // frmDashMaintT
            // 
            this.AcceptButton = this.cmdNieuw;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(803, 484);
            this.Controls.Add(this.grpMain);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Location = new System.Drawing.Point(30, 80);
            this.Name = "frmDashMaintT";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "DB Dashboard; beheer";
            this.Load += new System.EventHandler(this.frmDashMaintT_Load);
            this.Controls.SetChildIndex(this.lblHostName, 0);
            this.Controls.SetChildIndex(this.grbConnect, 0);
            this.Controls.SetChildIndex(this.grpMain, 0);
            this.Controls.SetChildIndex(this.cmdAfsluiten, 0);
            this.grbConnect.ResumeLayout(false);
            this.grbConnect.PerformLayout();
            this.grpMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpMain;
        private System.Windows.Forms.Button cmdWijzig;
        private System.Windows.Forms.Button cmdVerwijder;
        private System.Windows.Forms.Button cmdNieuw;
        private System.Windows.Forms.DataGridView dgView;
        private cmpSearch cmpSearch1;
        private cmpSearch cmpSearch2;
    }
}