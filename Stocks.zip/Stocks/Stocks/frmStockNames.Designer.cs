﻿namespace Stocks
{
    partial class frmStockNames
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmStockNames));
            this.grbKosh = new System.Windows.Forms.GroupBox();
            this.lblRemove_how = new System.Windows.Forms.Label();
            this.dgKosh = new System.Windows.Forms.DataGridView();
            this.colStockName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colShortName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cmdCancel = new System.Windows.Forms.Button();
            this.grbNoKosh = new System.Windows.Forms.GroupBox();
            this.lblShortStocks = new System.Windows.Forms.Label();
            this.lblAllStocks = new System.Windows.Forms.Label();
            this.cmdSaveLink = new System.Windows.Forms.Button();
            this.cmdAutoLink = new System.Windows.Forms.Button();
            this.lbShortStock = new System.Windows.Forms.ListBox();
            this.lbIndexStock = new System.Windows.Forms.ListBox();
            this.grbStats = new System.Windows.Forms.GroupBox();
            this.lblShort_Unlinked_val = new System.Windows.Forms.Label();
            this.lblShort_Unlinked_lbl = new System.Windows.Forms.Label();
            this.lblIndex_Unlinked_val = new System.Windows.Forms.Label();
            this.lblIndex_Unlinked_lbl = new System.Windows.Forms.Label();
            this.lblKosh_val = new System.Windows.Forms.Label();
            this.lblKosh_lbl = new System.Windows.Forms.Label();
            this.grbKosh.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgKosh)).BeginInit();
            this.grbNoKosh.SuspendLayout();
            this.grbStats.SuspendLayout();
            this.SuspendLayout();
            // 
            // grbKosh
            // 
            this.grbKosh.Controls.Add(this.lblRemove_how);
            this.grbKosh.Controls.Add(this.dgKosh);
            this.grbKosh.Location = new System.Drawing.Point(12, 23);
            this.grbKosh.Name = "grbKosh";
            this.grbKosh.Size = new System.Drawing.Size(476, 463);
            this.grbKosh.TabIndex = 1;
            this.grbKosh.TabStop = false;
            this.grbKosh.Text = "Linked Stock to Shortnames";
            // 
            // lblRemove_how
            // 
            this.lblRemove_how.AutoSize = true;
            this.lblRemove_how.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRemove_how.Location = new System.Drawing.Point(20, 24);
            this.lblRemove_how.Name = "lblRemove_how";
            this.lblRemove_how.Size = new System.Drawing.Size(198, 13);
            this.lblRemove_how.TabIndex = 13;
            this.lblRemove_how.Text = "Double click row to remove linked item...";
            // 
            // dgKosh
            // 
            this.dgKosh.AllowUserToAddRows = false;
            this.dgKosh.AllowUserToDeleteRows = false;
            this.dgKosh.AllowUserToOrderColumns = true;
            this.dgKosh.AllowUserToResizeColumns = false;
            this.dgKosh.AllowUserToResizeRows = false;
            this.dgKosh.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgKosh.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colStockName,
            this.colShortName});
            this.dgKosh.Location = new System.Drawing.Point(11, 44);
            this.dgKosh.MultiSelect = false;
            this.dgKosh.Name = "dgKosh";
            this.dgKosh.RowHeadersVisible = false;
            this.dgKosh.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgKosh.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgKosh.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgKosh.Size = new System.Drawing.Size(453, 407);
            this.dgKosh.TabIndex = 0;
            this.dgKosh.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgKosh_CellDoubleClick);
            this.dgKosh.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.dgKosh_RowsAdded);
            this.dgKosh.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.dgKosh_RowsRemoved);
            // 
            // colStockName
            // 
            this.colStockName.FillWeight = 250F;
            this.colStockName.HeaderText = "Index stock name";
            this.colStockName.MaxInputLength = 75;
            this.colStockName.MinimumWidth = 250;
            this.colStockName.Name = "colStockName";
            this.colStockName.Width = 250;
            // 
            // colShortName
            // 
            this.colShortName.FillWeight = 250F;
            this.colShortName.HeaderText = "Short stock name";
            this.colShortName.MaxInputLength = 75;
            this.colShortName.MinimumWidth = 250;
            this.colShortName.Name = "colShortName";
            this.colShortName.Width = 250;
            // 
            // cmdCancel
            // 
            this.cmdCancel.Location = new System.Drawing.Point(12, 490);
            this.cmdCancel.Name = "cmdCancel";
            this.cmdCancel.Size = new System.Drawing.Size(81, 25);
            this.cmdCancel.TabIndex = 4;
            this.cmdCancel.Text = "Cancel";
            this.cmdCancel.UseVisualStyleBackColor = true;
            this.cmdCancel.Click += new System.EventHandler(this.cmdCancel_Click);
            // 
            // grbNoKosh
            // 
            this.grbNoKosh.Controls.Add(this.lblShortStocks);
            this.grbNoKosh.Controls.Add(this.lblAllStocks);
            this.grbNoKosh.Controls.Add(this.cmdSaveLink);
            this.grbNoKosh.Controls.Add(this.cmdAutoLink);
            this.grbNoKosh.Controls.Add(this.lbShortStock);
            this.grbNoKosh.Controls.Add(this.lbIndexStock);
            this.grbNoKosh.Location = new System.Drawing.Point(506, 23);
            this.grbNoKosh.Name = "grbNoKosh";
            this.grbNoKosh.Size = new System.Drawing.Size(406, 396);
            this.grbNoKosh.TabIndex = 9;
            this.grbNoKosh.TabStop = false;
            this.grbNoKosh.Text = "Unlinked Stocknames";
            // 
            // lblShortStocks
            // 
            this.lblShortStocks.AutoSize = true;
            this.lblShortStocks.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblShortStocks.Location = new System.Drawing.Point(204, 16);
            this.lblShortStocks.Name = "lblShortStocks";
            this.lblShortStocks.Size = new System.Drawing.Size(78, 13);
            this.lblShortStocks.TabIndex = 13;
            this.lblShortStocks.Text = "Short stocks";
            // 
            // lblAllStocks
            // 
            this.lblAllStocks.AutoSize = true;
            this.lblAllStocks.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAllStocks.Location = new System.Drawing.Point(12, 18);
            this.lblAllStocks.Name = "lblAllStocks";
            this.lblAllStocks.Size = new System.Drawing.Size(62, 13);
            this.lblAllStocks.TabIndex = 12;
            this.lblAllStocks.Text = "All stocks";
            // 
            // cmdSaveLink
            // 
            this.cmdSaveLink.Location = new System.Drawing.Point(108, 328);
            this.cmdSaveLink.Name = "cmdSaveLink";
            this.cmdSaveLink.Size = new System.Drawing.Size(185, 25);
            this.cmdSaveLink.TabIndex = 11;
            this.cmdSaveLink.Text = "Link selected Stock to Shortname ";
            this.cmdSaveLink.UseVisualStyleBackColor = true;
            this.cmdSaveLink.Click += new System.EventHandler(this.cmdSaveLink_Click);
            // 
            // cmdAutoLink
            // 
            this.cmdAutoLink.Location = new System.Drawing.Point(114, 359);
            this.cmdAutoLink.Name = "cmdAutoLink";
            this.cmdAutoLink.Size = new System.Drawing.Size(169, 25);
            this.cmdAutoLink.TabIndex = 10;
            this.cmdAutoLink.Text = "Autolink Stock to Shortnames";
            this.cmdAutoLink.UseVisualStyleBackColor = true;
            this.cmdAutoLink.Click += new System.EventHandler(this.cmdAutoLink_Click);
            // 
            // lbShortStock
            // 
            this.lbShortStock.FormattingEnabled = true;
            this.lbShortStock.Location = new System.Drawing.Point(207, 32);
            this.lbShortStock.Name = "lbShortStock";
            this.lbShortStock.Size = new System.Drawing.Size(185, 290);
            this.lbShortStock.Sorted = true;
            this.lbShortStock.TabIndex = 9;
            this.lbShortStock.SelectedIndexChanged += new System.EventHandler(this.lbIndexStock_SelectedIndexChanged);
            // 
            // lbIndexStock
            // 
            this.lbIndexStock.FormattingEnabled = true;
            this.lbIndexStock.Location = new System.Drawing.Point(12, 32);
            this.lbIndexStock.Name = "lbIndexStock";
            this.lbIndexStock.Size = new System.Drawing.Size(185, 290);
            this.lbIndexStock.Sorted = true;
            this.lbIndexStock.TabIndex = 8;
            this.lbIndexStock.SelectedIndexChanged += new System.EventHandler(this.lbIndexStock_SelectedIndexChanged);
            // 
            // grbStats
            // 
            this.grbStats.Controls.Add(this.lblShort_Unlinked_val);
            this.grbStats.Controls.Add(this.lblShort_Unlinked_lbl);
            this.grbStats.Controls.Add(this.lblIndex_Unlinked_val);
            this.grbStats.Controls.Add(this.lblIndex_Unlinked_lbl);
            this.grbStats.Controls.Add(this.lblKosh_val);
            this.grbStats.Controls.Add(this.lblKosh_lbl);
            this.grbStats.Location = new System.Drawing.Point(506, 425);
            this.grbStats.Name = "grbStats";
            this.grbStats.Size = new System.Drawing.Size(406, 61);
            this.grbStats.TabIndex = 10;
            this.grbStats.TabStop = false;
            this.grbStats.Text = "Statistics";
            // 
            // lblShort_Unlinked_val
            // 
            this.lblShort_Unlinked_val.AutoSize = true;
            this.lblShort_Unlinked_val.Cursor = System.Windows.Forms.Cursors.UpArrow;
            this.lblShort_Unlinked_val.Location = new System.Drawing.Point(368, 34);
            this.lblShort_Unlinked_val.Name = "lblShort_Unlinked_val";
            this.lblShort_Unlinked_val.Size = new System.Drawing.Size(25, 13);
            this.lblShort_Unlinked_val.TabIndex = 5;
            this.lblShort_Unlinked_val.Text = "123";
            // 
            // lblShort_Unlinked_lbl
            // 
            this.lblShort_Unlinked_lbl.AutoSize = true;
            this.lblShort_Unlinked_lbl.Cursor = System.Windows.Forms.Cursors.UpArrow;
            this.lblShort_Unlinked_lbl.Location = new System.Drawing.Point(191, 32);
            this.lblShort_Unlinked_lbl.Name = "lblShort_Unlinked_lbl";
            this.lblShort_Unlinked_lbl.Size = new System.Drawing.Size(175, 13);
            this.lblShort_Unlinked_lbl.TabIndex = 4;
            this.lblShort_Unlinked_lbl.Text = "Number of unlinked in Short stocks:";
            // 
            // lblIndex_Unlinked_val
            // 
            this.lblIndex_Unlinked_val.AutoSize = true;
            this.lblIndex_Unlinked_val.Location = new System.Drawing.Point(368, 16);
            this.lblIndex_Unlinked_val.Name = "lblIndex_Unlinked_val";
            this.lblIndex_Unlinked_val.Size = new System.Drawing.Size(25, 13);
            this.lblIndex_Unlinked_val.TabIndex = 3;
            this.lblIndex_Unlinked_val.Text = "123";
            // 
            // lblIndex_Unlinked_lbl
            // 
            this.lblIndex_Unlinked_lbl.AutoSize = true;
            this.lblIndex_Unlinked_lbl.Cursor = System.Windows.Forms.Cursors.UpArrow;
            this.lblIndex_Unlinked_lbl.Location = new System.Drawing.Point(191, 14);
            this.lblIndex_Unlinked_lbl.Name = "lblIndex_Unlinked_lbl";
            this.lblIndex_Unlinked_lbl.Size = new System.Drawing.Size(161, 13);
            this.lblIndex_Unlinked_lbl.TabIndex = 2;
            this.lblIndex_Unlinked_lbl.Text = "Number of unlinked in All stocks:";
            // 
            // lblKosh_val
            // 
            this.lblKosh_val.AutoSize = true;
            this.lblKosh_val.Location = new System.Drawing.Point(120, 18);
            this.lblKosh_val.Name = "lblKosh_val";
            this.lblKosh_val.Size = new System.Drawing.Size(25, 13);
            this.lblKosh_val.TabIndex = 1;
            this.lblKosh_val.Text = "123";
            // 
            // lblKosh_lbl
            // 
            this.lblKosh_lbl.AutoSize = true;
            this.lblKosh_lbl.Location = new System.Drawing.Point(6, 18);
            this.lblKosh_lbl.Name = "lblKosh_lbl";
            this.lblKosh_lbl.Size = new System.Drawing.Size(117, 13);
            this.lblKosh_lbl.TabIndex = 0;
            this.lblKosh_lbl.Text = "Number of linked items:";
            // 
            // frmStockNames
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(921, 520);
            this.Controls.Add(this.grbStats);
            this.Controls.Add(this.grbNoKosh);
            this.Controls.Add(this.cmdCancel);
            this.Controls.Add(this.grbKosh);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmStockNames";
            this.Text = "frmStockNames";
            this.Load += new System.EventHandler(this.frmStockNames_Load);
            this.grbKosh.ResumeLayout(false);
            this.grbKosh.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgKosh)).EndInit();
            this.grbNoKosh.ResumeLayout(false);
            this.grbNoKosh.PerformLayout();
            this.grbStats.ResumeLayout(false);
            this.grbStats.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grbKosh;
        private System.Windows.Forms.Button cmdCancel;
        private System.Windows.Forms.DataGridView dgKosh;
        private System.Windows.Forms.DataGridViewTextBoxColumn colStockName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colShortName;
        private System.Windows.Forms.GroupBox grbNoKosh;
        private System.Windows.Forms.Label lblShortStocks;
        private System.Windows.Forms.Label lblAllStocks;
        private System.Windows.Forms.Button cmdSaveLink;
        private System.Windows.Forms.Button cmdAutoLink;
        private System.Windows.Forms.ListBox lbShortStock;
        private System.Windows.Forms.ListBox lbIndexStock;
        private System.Windows.Forms.Label lblRemove_how;
        private System.Windows.Forms.GroupBox grbStats;
        private System.Windows.Forms.Label lblKosh_val;
        private System.Windows.Forms.Label lblKosh_lbl;
        private System.Windows.Forms.Label lblShort_Unlinked_val;
        private System.Windows.Forms.Label lblShort_Unlinked_lbl;
        private System.Windows.Forms.Label lblIndex_Unlinked_val;
        private System.Windows.Forms.Label lblIndex_Unlinked_lbl;
    }
}