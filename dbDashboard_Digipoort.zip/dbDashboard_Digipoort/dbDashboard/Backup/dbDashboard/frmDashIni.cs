﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace dbDashboard
{
    public partial class frmDashIni : frmDashBase
    {
        public ArrayList alIni = new ArrayList();
        public string strIni_file;

        Label[] lblIni = new Label[10];
        TextBox[] txtIni = new TextBox[10];
        public frmDashIni()
        {
            InitializeComponent();
        }

        private void frmDashIni_Load(object sender, EventArgs e)
        {
            init_controls();           
        }

        private void cmdOpslaan_Click(object sender, EventArgs e)
        {
            schrijf_data();
            this.Close();
        }

        private void init_controls()
        {
            int intIni = 0;
            foreach (string strIni in alIni)
            {
                lblIni[intIni] = new Label();
                lblIni[intIni].Height = 15;
                lblIni[intIni].Width = 90;
                lblIni[intIni].Top = 40 + (intIni * 20);
                lblIni[intIni].Left = 15;
                lblIni[intIni].Text = alIni[intIni].ToString();
                grpIni.Controls.Add(lblIni[intIni]);

                txtIni[intIni] = new TextBox();
                txtIni[intIni].Height = 15;
                txtIni[intIni].Width = 330;
                txtIni[intIni].TextChanged += new System.EventHandler(txtIni_TextChanged);
             
                txtIni[intIni].Top = lblIni[intIni].Top;
                txtIni[intIni].Left = lblIni[intIni].Left + 90;
                grpIni.Controls.Add(txtIni[intIni]);
                txtIni[intIni].Text = clDashFunction.get_TagValue(alIni[intIni].ToString(), false);
                intIni++;
            }
            bChanged = false;
            cmdOpslaan.Enabled = false;
            cmdToepassen.Enabled = false;
        }
        private void txtIni_TextChanged(object sender, EventArgs e)
        {
            bChanged = true;
            cmdOpslaan.Enabled = true;
            cmdToepassen.Enabled = true;
        }

        private void schrijf_data()
        {
            // clDashFunction.Melding(strIni_file);
            StreamWriter sw = clDashFunction.open4write(strIni_file);
            if (sw != null)
            {
                int intIni = 0;
                foreach (string strIni in alIni)
                {
                    sw.WriteLine(lblIni[intIni].Text);
                    sw.WriteLine(txtIni[intIni].Text);
                    intIni++;
                }
                sw.Close();
            } 
        }

        private void cmdToepassen_Click(object sender, EventArgs e)
        {
            schrijf_data();
            init_controls();
        }
    }
}