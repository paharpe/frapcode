﻿namespace dbDashboard
{
    partial class frmDashShell
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.grbScript = new System.Windows.Forms.GroupBox();
            this.txtCmd = new System.Windows.Forms.TextBox();
            this.txtServer = new System.Windows.Forms.TextBox();
            this.cmdExecute = new System.Windows.Forms.Button();
            this.cmbScript = new System.Windows.Forms.ComboBox();
            this.lblScript = new System.Windows.Forms.Label();
            this.cmbServer = new System.Windows.Forms.ComboBox();
            this.cmbCmd = new System.Windows.Forms.ComboBox();
            this.grbOutput = new System.Windows.Forms.GroupBox();
            this.cmdSaveTo = new System.Windows.Forms.Button();
            this.lbResult = new System.Windows.Forms.ListBox();
            this.tmrScript = new System.Windows.Forms.Timer(this.components);
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.button1 = new System.Windows.Forms.Button();
            this.grbConnect.SuspendLayout();
            this.grbScript.SuspendLayout();
            this.grbOutput.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmdAfsluiten
            // 
            this.cmdAfsluiten.Location = new System.Drawing.Point(12, 548);
            // 
            // grbConnect
            // 
            this.grbConnect.Location = new System.Drawing.Point(497, 627);
            // 
            // lblHostName
            // 
            this.lblHostName.Location = new System.Drawing.Point(854, 585);
            this.lblHostName.Size = new System.Drawing.Size(145, 13);
            this.lblHostName.Text = "KPNNL\\WLD4BED923B63C";
            // 
            // grbScript
            // 
            this.grbScript.Controls.Add(this.txtCmd);
            this.grbScript.Controls.Add(this.txtServer);
            this.grbScript.Controls.Add(this.cmdExecute);
            this.grbScript.Controls.Add(this.cmbScript);
            this.grbScript.Controls.Add(this.lblScript);
            this.grbScript.Location = new System.Drawing.Point(12, 59);
            this.grbScript.Name = "grbScript";
            this.grbScript.Size = new System.Drawing.Size(984, 93);
            this.grbScript.TabIndex = 23;
            this.grbScript.TabStop = false;
            this.grbScript.Text = "Selection";
            // 
            // txtCmd
            // 
            this.txtCmd.Location = new System.Drawing.Point(570, 40);
            this.txtCmd.Name = "txtCmd";
            this.txtCmd.ReadOnly = true;
            this.txtCmd.Size = new System.Drawing.Size(314, 20);
            this.txtCmd.TabIndex = 8;
            // 
            // txtServer
            // 
            this.txtServer.Location = new System.Drawing.Point(510, 40);
            this.txtServer.Name = "txtServer";
            this.txtServer.ReadOnly = true;
            this.txtServer.Size = new System.Drawing.Size(54, 20);
            this.txtServer.TabIndex = 7;
            // 
            // cmdExecute
            // 
            this.cmdExecute.Location = new System.Drawing.Point(891, 38);
            this.cmdExecute.Name = "cmdExecute";
            this.cmdExecute.Size = new System.Drawing.Size(75, 23);
            this.cmdExecute.TabIndex = 2;
            this.cmdExecute.Text = "E&xecute";
            this.cmdExecute.UseVisualStyleBackColor = true;
            this.cmdExecute.Click += new System.EventHandler(this.cmdExecute_Click);
            // 
            // cmbScript
            // 
            this.cmbScript.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbScript.FormattingEnabled = true;
            this.cmbScript.Location = new System.Drawing.Point(46, 39);
            this.cmbScript.Name = "cmbScript";
            this.cmbScript.Size = new System.Drawing.Size(458, 21);
            this.cmbScript.TabIndex = 1;
            this.cmbScript.SelectedIndexChanged += new System.EventHandler(this.cmbScript_SelectedIndexChanged);
            // 
            // lblScript
            // 
            this.lblScript.AutoSize = true;
            this.lblScript.Location = new System.Drawing.Point(7, 42);
            this.lblScript.Name = "lblScript";
            this.lblScript.Size = new System.Drawing.Size(37, 13);
            this.lblScript.TabIndex = 0;
            this.lblScript.Text = "Script:";
            // 
            // cmbServer
            // 
            this.cmbServer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbServer.FormattingEnabled = true;
            this.cmbServer.Location = new System.Drawing.Point(33, 627);
            this.cmbServer.Name = "cmbServer";
            this.cmbServer.Size = new System.Drawing.Size(94, 21);
            this.cmbServer.TabIndex = 5;
            this.cmbServer.Visible = false;
            this.cmbServer.SelectedIndexChanged += new System.EventHandler(this.cmbServer_SelectedIndexChanged);
            // 
            // cmbCmd
            // 
            this.cmbCmd.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCmd.FormattingEnabled = true;
            this.cmbCmd.Location = new System.Drawing.Point(133, 627);
            this.cmbCmd.Name = "cmbCmd";
            this.cmbCmd.Size = new System.Drawing.Size(358, 21);
            this.cmbCmd.TabIndex = 4;
            this.cmbCmd.Visible = false;
            this.cmbCmd.SelectedIndexChanged += new System.EventHandler(this.cmbCmd_SelectedIndexChanged);
            // 
            // grbOutput
            // 
            this.grbOutput.Controls.Add(this.cmdSaveTo);
            this.grbOutput.Controls.Add(this.lbResult);
            this.grbOutput.Location = new System.Drawing.Point(12, 169);
            this.grbOutput.Name = "grbOutput";
            this.grbOutput.Size = new System.Drawing.Size(984, 373);
            this.grbOutput.TabIndex = 24;
            this.grbOutput.TabStop = false;
            this.grbOutput.Text = "Output";
            // 
            // cmdSaveTo
            // 
            this.cmdSaveTo.Location = new System.Drawing.Point(893, 338);
            this.cmdSaveTo.Name = "cmdSaveTo";
            this.cmdSaveTo.Size = new System.Drawing.Size(75, 23);
            this.cmdSaveTo.TabIndex = 26;
            this.cmdSaveTo.Text = "Save to...";
            this.cmdSaveTo.UseVisualStyleBackColor = true;
            this.cmdSaveTo.Click += new System.EventHandler(this.cmdSaveTo_Click);
            // 
            // lbResult
            // 
            this.lbResult.Font = new System.Drawing.Font("Courier New", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbResult.FormattingEnabled = true;
            this.lbResult.ItemHeight = 15;
            this.lbResult.Location = new System.Drawing.Point(9, 25);
            this.lbResult.Name = "lbResult";
            this.lbResult.Size = new System.Drawing.Size(959, 289);
            this.lbResult.TabIndex = 0;
            // 
            // tmrScript
            // 
            this.tmrScript.Enabled = true;
            this.tmrScript.Interval = 1000;
            this.tmrScript.Tick += new System.EventHandler(this.tmrScript_Tick);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Location = new System.Drawing.Point(0, 23);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1004, 24);
            this.menuStrip1.TabIndex = 25;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(0, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 23;
            // 
            // frmDashShell
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1004, 579);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.grbOutput);
            this.Controls.Add(this.cmbCmd);
            this.Controls.Add(this.cmbServer);
            this.Controls.Add(this.grbScript);
            this.Controls.Add(this.menuStrip1);
            this.Name = "frmDashShell";
            this.Text = "frmDashShell - Execute shell scripts";
            this.Load += new System.EventHandler(this.frmDashShell_Load);
            this.Controls.SetChildIndex(this.menuStrip1, 0);
            this.Controls.SetChildIndex(this.cmdAfsluiten, 0);
            this.Controls.SetChildIndex(this.grbConnect, 0);
            this.Controls.SetChildIndex(this.lblHostName, 0);
            this.Controls.SetChildIndex(this.grbScript, 0);
            this.Controls.SetChildIndex(this.cmbServer, 0);
            this.Controls.SetChildIndex(this.cmbCmd, 0);
            this.Controls.SetChildIndex(this.grbOutput, 0);
            this.Controls.SetChildIndex(this.button1, 0);
            this.grbConnect.ResumeLayout(false);
            this.grbConnect.PerformLayout();
            this.grbScript.ResumeLayout(false);
            this.grbScript.PerformLayout();
            this.grbOutput.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grbScript;
        private System.Windows.Forms.Label lblScript;
        private System.Windows.Forms.GroupBox grbOutput;
        private System.Windows.Forms.Button cmdExecute;
        private System.Windows.Forms.ComboBox cmbScript;
        private System.Windows.Forms.ListBox lbResult;
        private System.Windows.Forms.Timer tmrScript;
        private System.Windows.Forms.ComboBox cmbCmd;
        private System.Windows.Forms.ComboBox cmbServer;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.Button cmdSaveTo;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.TextBox txtCmd;
        private System.Windows.Forms.TextBox txtServer;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Button button1;
    }
}