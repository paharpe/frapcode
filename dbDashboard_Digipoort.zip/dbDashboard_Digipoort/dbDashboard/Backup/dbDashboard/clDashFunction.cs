﻿using System;
using System.Collections;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.IO;
using System.Threading;
using System.Windows.Forms.DataVisualization.Charting;
using System.Data;

namespace dbDashboard
{
    sealed class WindowsCharting
    {
        //method generates the chart
#pragma warning disable 0628
        protected internal Chart GenerateChart
    (DataTable dtChartDataSource, int width, int height, string bgColor, int intType)
        {
            Chart chart = new Chart()
            {
                Width = width,
                Height = height
            };
            chart.Legends.Add(new Legend() { Name = "Legend" });
            chart.Legends[0].Docking = Docking.Bottom;
            ChartArea chartArea = new ChartArea() { Name = "ChartArea" };
            //Remove X-axis grid lines
            chartArea.AxisX.MajorGrid.LineWidth = 0;
            //Remove Y-axis grid lines
            chartArea.AxisY.MajorGrid.LineWidth = 0;
            //Chart Area Back Color
            // chartArea.BackColor = Color.FromName(bgColor);
            chart.ChartAreas.Add(chartArea);
            chart.Palette = ChartColorPalette.BrightPastel;
            string series = string.Empty;
            //create series and add data points to the series
            if (dtChartDataSource != null)
            {
                foreach (DataColumn dc in dtChartDataSource.Columns)
                {
                    //a series to the chart
                    if (chart.Series.FindByName(dc.ColumnName) == null)
                    {
                        series = dc.ColumnName;
                        chart.Series.Add(series);
                        chart.Series[series].ChartType = (SeriesChartType)intType;
                    }
                    //Add data points to the series
                    foreach (DataRow dr in dtChartDataSource.Rows)
                    {
                        double dataPoint = 0;
                        double.TryParse(dr[dc.ColumnName].ToString(), out dataPoint);
                        DataPoint objDataPoint = new DataPoint() { AxisLabel = "series", YValues = new double[] { dataPoint } };
                        chart.Series[series].Points.Add(dataPoint);
                    }
                }
            }
            return chart;
        }
    }

    class clDashFunction
    {
        // Ophalen aantal seconden voordat wordt geautoclosed...
        public static Int16 get_autoclose()
        {
            DoSql mysql = new DoSql();
            mysql.vul_deze_string = "";
            mysql.DoQuery("SELECT ElemOms1 " +
                          "FROM   DashElem " +
                          "WHERE  ElemTabn = 10 " +
                          "AND    ElemElem = 'AUTOCLOSE'");
            if (mysql.affected_rows == 0)
            {
                return 10;
            }
            else
            {
                try
                {
                    return Convert.ToInt16(mysql.vul_deze_string);
                }
                catch
                {
                    return 10;
                }
            }
        }

        // Ophalen aantal seconden voordat wordt geautoclosed...
        public static string get_update_script()
        {
            string strServer = "SERVER";
            string strLocal="LOCAL";
            DoSql mysql = new DoSql();
            mysql.vul_deze_string = "";
            mysql.DoQuery("SELECT ElemOms1 " +
                          "FROM   DashElem " +
                          "WHERE  ElemTabn = 10 " +
                          "AND    ElemElem = 'UPDATE_SCRIPT'");
            if (mysql.affected_rows == 0)
            {
                clDashFunction.Melding("Tabel element 'UPDATE_SCRIPT' niet gevonden in tabel 10, returning value: "+strServer +" !", 1, "E");  
                return strServer;
            }
            else
            {
                if (mysql.vul_deze_string != strLocal && mysql.vul_deze_string != strServer)
                {
                    return strServer;
                }
                else
                {
                    return mysql.vul_deze_string;
                }
            }              
        }

        // Tonen van connect dialog en in arraylist teruggeven van de verschillende 
        // resultaatvelden
         
       
        public static Boolean block_form(ArrayList alForms_loaded,string strFormname)
        {
            if (alForms_loaded.IndexOf(strFormname) >= 0)
            {                
                return false;
            }
            else
            {
                mdiDashboard.alForms_loaded.Add(strFormname);
               return true;
            }
        }

        public static void release_form(ArrayList alForms_loaded, string strFormname)
        {
            for (int i = 0; i < alForms_loaded.Count; i++)
            {
                if (alForms_loaded[i].ToString() == strFormname)
                {
                    alForms_loaded.RemoveAt(i);
                    break;
                }
            }
            // if (alForms_loaded.Count < 1)
            // {
            //    mdiDashboard.AllMdiChildren_Closed();
            // }
        }

        public static string splits_string(string strSplits_in, string strSplit_char, int Woord_index)
        {
            string[] strFunc_item = Regex.Split(strSplits_in, strSplit_char);
            if ( Woord_index > strFunc_item.Length-1 )
            { 
                Melding("Opgegeven index groter dan aantal elementen in array !",1,"E");
                return " ";
            }
            return (strFunc_item[Woord_index].ToString());
        }        

        public static DialogResult Melding(string strMelding, int intButtons, string strInfQueErr)
        {
            MessageBoxIcon mbiMelding;
            MessageBoxButtons mbbMelding;

            switch (intButtons)
            {
                case 1:
                    mbbMelding = MessageBoxButtons.OK;
                    break;
                case 2:
                    mbbMelding = MessageBoxButtons.OKCancel;
                    break;
                case 3:
                    mbbMelding = MessageBoxButtons.RetryCancel;
                    break;
                case 4:
                    mbbMelding = MessageBoxButtons.YesNo;
                    break;
                case 5:
                    mbbMelding = MessageBoxButtons.YesNoCancel;
                    break;
                default:
                    mbbMelding = MessageBoxButtons.OK;
                    break;
            }

            switch (strInfQueErr)
            {
                case "I":
                    mbiMelding = MessageBoxIcon.Information;
                    break;
                case "Q":
                    mbiMelding = MessageBoxIcon.Question;
                    break;
                case "E":
                    mbiMelding = MessageBoxIcon.Error;
                    break;
                default:
                    mbiMelding = MessageBoxIcon.Stop;
                    break;
            }
            return MessageBox.Show(strMelding, "DB Dashboard", mbbMelding, mbiMelding);
        }

        // Overload met defaultbutton en icon
        public static DialogResult Melding(string strMelding)
        {
            return Melding(strMelding, 1, "E");
        }

        public static string get_mutdatum()
        {
            return DateTime.Now.Year.ToString ("0000") +
                   DateTime.Now.Month.ToString("00")   +
                   DateTime.Now.Day.ToString  ("00");
        }

        public static string get_muttijd()
        {
            return DateTime.Now.Hour.ToString       ("00")  +
                   DateTime.Now.Minute.ToString     ("00")  +
                   DateTime.Now.Second.ToString     ("000") +
                   DateTime.Now.Millisecond.ToString("000");

        }
        public static ArrayList get_tree_nodes(TreeView tvTreeView)            
        {
            // Arraylist met alle nodes uit de aangeboden treeview vullen
            // via recursieve truuk en de arraylist teruggeven.....
            ArrayList alTreeNodes = new ArrayList();
            LoopNodes(tvTreeView.Nodes, alTreeNodes);
           
            return alTreeNodes;
        }

        private static ArrayList LoopNodes(TreeNodeCollection nodes, ArrayList alTreeNodes)
        {           
            foreach (TreeNode n in nodes)
            {
                alTreeNodes.Add(n.Text);               

                if (n.Nodes != null)
                {
                    LoopNodes(n.Nodes,alTreeNodes);
                }
            }
            return alTreeNodes;
        }        

        public static ArrayList get_dir_file(string strDirANDFile)
        {
            // Bestandsnaam bijv. abc.txt destilleren uit "mysql.vul_deze_string" om verderop
            // dit wordt gedaan door te string te splitsen in 2 delen:
            // Deel 1 = alles vóór de laatste 2 slashes, levert path op
            // Deel 2 = alles na de laatste 2 slashes, levert filenaam op
            int inStart = 0;
            int i_old = 0;
            ArrayList alDirSEPFile = new ArrayList();
            for (int i = 1; i > 0; i++)
            {
                i_old = i;
                i = strDirANDFile.IndexOf("\\", inStart); //Na de laatste slashes staat de exe file
                inStart = i + 1;
            }
            // Eerste returnveld = file, tweede = directory
            alDirSEPFile.Add(strDirANDFile.Substring(i_old, (strDirANDFile.Length - i_old)));
            alDirSEPFile.Add(strDirANDFile.Substring(0, i_old - 1));

            return alDirSEPFile;
        }

        public static bool IsInteger(string theValue)
        {
            try
            {
                Convert.ToInt32(theValue);
                return true;
            }
            catch
            {
                return false;
            }
        } //IsInteger

        public static int get_weekday_number(string strDagnaam)
        {
            switch (strDagnaam.Trim().ToUpper())
            {
                case "MONDAY":
                    {
                        return 1;
                    }
                case "MAANDAG":
                    {
                        return 1;
                    }
                case "TUESDAY":
                    {
                        return 2;
                    }
                case "DINSDAG":
                    {
                        return 2;
                    }
                case "WEDNESDAY":
                    {
                        return 3;
                    }
                case "WOENSDAG":
                    {
                        return 3;
                    }
                case "THURSDAY":
                    {
                        return 4;
                    }
                case "DONDERDAG":
                    {
                        return 4;
                    }
                case "FRIDAY":
                    {
                        return 5;
                    }
                case "VRIJDAG":
                    {
                        return 5;
                    }
                case "SATURDAY":
                    {
                        return 6;
                    }
                case "ZATERDAG":
                    {
                        return 6;
                    }
                case "SUNDAY":
                    {
                        return 7;
                    }

                case "ZONDAG":
                    {
                        return 7;
                    }
                default:
                    clDashFunction.Melding("Dag (" + strDagnaam.ToUpper() + ") kan niet worden vertaald naar dagnummer", 1, "E");
                    return 0;
            }
        }
        
        public static int get_weekday_number()
        {
          return  get_weekday_number( DateTime.Today.DayOfWeek.ToString().ToUpper());           
        }

        public static string get_weekday_name(int intDayno)
        {
            switch (intDayno)
            {
                case 1:
                    {
                        return "Maandag";
                    }
                case 2:
                    {
                        return "Dinsdag" ;
                    }
                case 3:
                    {
                        return "Woensdag";
                    }
                case 4:
                    {
                       return "Donderdag" ;
                    }
                case 5:
                    {
                        return "Vrijdag";
                    }
                case 6:
                    {
                        return "Zaterdag";
                    }
                case 7:
                    {
                        return "Zondag";
                    }                
                default:
                    clDashFunction.Melding("Dagnummer("+intDayno.ToString()+") kan niet worden vertaald naar een geldige dagnaam", 1, "E");
                    return "Onbekend";
            }
        }

        public static void get_uitgevers(ListBox lbListBox)
        {           
            DoSql mysql = new DoSql();
            mysql.vul_deze_listbox = lbListBox;
            mysql.DoQuery("SELECT PublCode " +
                          "FROM   DashPubl " +
                          "ORDER BY PublCode ");
            if (mysql.affected_rows == 0)
            {
                clDashFunction.Melding("Geen uitgevers geselecteerd", 1, "I");
            } 
        }

        public static Boolean isValidDate(string strDate)
        {
            Boolean isDate = true;
            DateTime dt;

            try
            {
                dt = DateTime.Parse(strDate);
            }

            catch
            {
                isDate = false;
            }

            return isDate;
        }

        public static bool isNumeric(string val, System.Globalization.NumberStyles NumberStyle)
        {
            Double result;
            return Double.TryParse(val, NumberStyle,
                System.Globalization.CultureInfo.CurrentCulture, out result);
        }

        public static bool isNumeric(string val)
        {
            return isNumeric(val, System.Globalization.NumberStyles.Integer);
        }

        public static string get_word(string strInput, short shWord_index)
        {
            string strReturn_word;

            if (shWord_index < 0)
            {
                clDashFunction.Melding("Index mag niet kleiner zijn dan 0", 1, "I");
                strReturn_word = "";
            }
            string[] strarInput = Regex.Split(strInput, " ");
            if (shWord_index > strarInput.Length)
            {
                clDashFunction.Melding("Index groter dan het aantal woorden in de string", 1, "I");
                strReturn_word = "";
            }
            else
            {
                strReturn_word = strarInput[shWord_index];
            }
            return strReturn_word;
        }
        public static StreamWriter open4write(string strFile)
        {
            //if (File.Exists(strFile))
            //{
                StreamWriter sw = new StreamWriter(strFile);
                return sw;
            //}
            //else
           // {
              //  clDashFunction.Melding("Het te openen bestand " + strFile + " bestaat niet (meer)", 1, "E");
            //    return null;
           // }
        }

        /*
        public static StreamReader open4read(string strFile)
        {
            // Overload versie zonder RETRY mogelijkheid en NO talking
            return open4read(strFile, false,false);
        }

        public static StreamReader open4read(string strFile,Boolean bTalk)
        {
            // Overload versie zonder RETRY mogelijkheid MET talk
            return open4read(strFile,false,bTalk);
        }

        public static StreamReader open4read(string strFile, Boolean bAllowRetry,Boolean bTalk)
        */
        public static StreamReader open4read(string strFile)
        {           
            int intMaxTries=1;

            //if (bAllowRetry)
            //{ 
            //    intMaxTries = 10;
            // }
            
            int intTry=0;

            if (File.Exists(strFile))
            {
                while (intTry < intMaxTries)
                {
                    try
                    {
                        StreamReader sr = new StreamReader(strFile);
                        return sr;
                    }
                    catch (IOException e)
                    {
                        if (intTry >= intMaxTries)
                        {

                            Melding("Heb " + strFile + " niet kunnen openen ín " + intTry.ToString() + " pogingen. Error: " + e.Message, 1, "E");
                            return null;
                        }
                        else
                        {
                            Thread.Sleep(1000);
                            intTry++;
                        }
                    }
                }               
            }
            else
            {
                clDashFunction.Melding("Het te openen bestand " + strFile + " bestaat niet (meer)", 1, "E");
                return null;
            }
            return null;
        }

        public static Boolean is_file_empty(string strFile_id)
        {
            System.IO.FileInfo fi = new System.IO.FileInfo(strFile_id);
            return (fi.Length == 0);            
        }

        private static Boolean is_in_range(short shValue, short shFrom, short shTo)
        {
            if (shValue >= shFrom && shValue <= shTo)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static Boolean is_valid_hour(string strHour)
        {
            if (!isNumeric(strHour))            
            {
                return false;
            }
            return is_in_range(Convert.ToInt16(strHour),0,24);
        }
        
        public static Boolean is_valid_dayno(string strDayno)
        {
            if (!isNumeric(strDayno))
            {
                return false;
            }
            return is_in_range(Convert.ToInt16(strDayno), 1, 7);
        }
        
        public static Boolean is_valid_minute(string strMinute)
        {
            if (!isNumeric(strMinute))
            {
                return false;
            }
            return is_in_range(Convert.ToInt16(strMinute), 0, 59);
        }

        public static void do_wincmd(string strWinCmd,string strCmdParm,Boolean bShowWindow)
        {
            if (File.Exists(strWinCmd))
            {               
                System.Diagnostics.Process proc = new System.Diagnostics.Process();
                proc.EnableRaisingEvents = false;
                proc.StartInfo.FileName = strWinCmd;
                proc.StartInfo.Arguments = strCmdParm;
                proc.StartInfo.CreateNoWindow = true;
                if (bShowWindow)
                {
                    proc.StartInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Normal;
                }
                else
                {
                    proc.StartInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;

                }
                if (!proc.Start())
                {
                    clDashFunction.Melding("Het proces kan niet (goed) worden gestart", 1, "E");
                }
                // proc.WaitForExit();
                proc.Dispose();           
            }
            else
            {
                if (bShowWindow)
                {
                    Melding("Windows command (" + strWinCmd + ") bestaat niet !", 1, "E");
                }
            }
        }
        public static void Notepad(string strFile_id)
        {
            do_wincmd("c:\\Windows\\System32\\notepad.exe",strFile_id,true);                      
        }

        public static Boolean check_ini(string strIniFile, ArrayList alIniTags, ArrayList alIniVals)
        {          
            Boolean bCheck_ini = true;
            Boolean bExists_ini = false;
            ArrayList alDirFile;

            // Open de INI file of maak een nieuwe?
            StreamReader sr = clDashFunction.open4read(strIniFile);

            if (sr != null)
            {
                bExists_ini = true;
                sr.Close();
            }            

            if (!bExists_ini)
            {
                // Check of er überhaupt wel een nieuwe file kan worden gemaakt, immers het in de SQL tabel
                // genoemde "path"  hoeft niet te bestaan op de machine waarop deze app wordt gedraaid.
                alDirFile = clDashFunction.get_dir_file(strIniFile);
                if (Directory.Exists(alDirFile[1].ToString()))
                {
                    if (clDashFunction.Melding("Nieuw INI bestand aanmaken ?", 4, "Q") == DialogResult.Yes)
                    {                      
                        showInit(strIniFile, alIniTags);
                        lees_ini(strIniFile, alIniTags, alIniVals);
                    }
                    else
                    {
                        return bCheck_ini;
                    }                    
                }
                else
                {
                    Melding("De locatie waarop het INI bestand aanwezig zou moeten zijn: "+
                        System.Environment.NewLine + System.Environment.NewLine + 
                        alDirFile[1].ToString() +
                        System.Environment.NewLine + System.Environment.NewLine +
                        " is niet beschikbaar op deze server.");
                   return false;
                    
                }               
            }
            else
            {
                if (!lees_ini(strIniFile, alIniTags, alIniVals))
                {
                    frmDashIni frmIni = new frmDashIni();
                    frmIni.strIni_file = strIniFile;
                    foreach (string strIniTag in alIniTags)
                    {
                        frmIni.alIni.Add(strIniTag);
                    }
                    frmIni.ShowDialog();
                }
            }
            return true;
        }

        
        public static Boolean lees_ini(string strIniFile, ArrayList alIniTags, ArrayList alIniVals)
        {
            // Kijken of de benoemde en hard coded tags uit het MDI ook voorkomen in
            // de INI file
            Boolean bRead_next = true;
            string strIniRecord = "";
            ArrayList alIniTag_TagCheck = new ArrayList();
            ArrayList alIniTag_ValueCheck = new ArrayList();
            
            //Waarden in array helemaal opnieuw vullen vanaf [0]
            alIniVals.Clear();

            int intIniTel = 0;

            // Hier een extra arraylist maken om te kunnen
            // bijhouden of de inifile ook wel een corresponderende
            // waarde voor het bepaalde [TAG] bevat
            foreach (string strGlobalTags in alIniTags)
            {
                alIniTag_TagCheck.Add(false);
                alIniTag_ValueCheck.Add(false);
            }


            // De totale INI file doorlopen
            StreamReader sr = clDashFunction.open4read(strIniFile);
            if (sr != null)
            {
                while (!sr.EndOfStream)
                {
                    //Als we verderop soms 1 te ver hebben gelezen 
                    // ( TAG zonder value of andersom )
                    // dan kan bRead_next FALSE zijn 
                    if (bRead_next) { strIniRecord = sr.ReadLine(); }

                    // Testen of er een string uit de verzameling alIniTags
                    // gelijk is aan een gelezen record
                    foreach (string strTag in alIniTags)
                    {
                        if (strTag == strIniRecord)
                        {
                            // Nu moeten we kijken op welke plek het gevonden
                            // tag staat in de alIniTags arraylist uit het baseform
                            alIniTag_TagCheck[alIniTags.IndexOf(strTag)] = true;
                            // Tag gevonden, volgende entry is de value
                            // althans dat zou wel moeten. We controleren dit
                            // door te kijken of het volgende record niet een  [] bevat
                            // want dan gaan we ervanuit dat het een volgende tag is
                            // en de waarde van de zojuist gelezen (nog) ontbreekt.
                            if (!sr.EndOfStream)
                            {
                                string strPossible_TagValue = sr.ReadLine();

                                if (isTagValue(strPossible_TagValue))
                                {
                                    alIniTag_ValueCheck[alIniTags.IndexOf(strTag)] = true;
                                    alIniVals.Add(strPossible_TagValue);
                                }
                                else
                                {
                                    // We hebben waarschijnlijk 1 te ver gelezen:
                                    // al het nieuwe TAG terwijl we op zoek waren naar
                                    // de waarde van de 'vorige'.. Even geen nieuw record
                                    // en we vullen een dummy in op de arrays in sync te 
                                    // houden
                                    alIniVals.Add("");
                                    strIniRecord = strPossible_TagValue;
                                    bRead_next = false;
                                }
                                intIniTel++;
                            }
                            else
                            {
                                bRead_next = true;
                            }
                        }
                    }
                }
                sr.Close();
            }
            if (alIniTag_TagCheck.IndexOf(false) > -1 || alIniTag_ValueCheck.IndexOf(false) > -1)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public static Boolean isTag(string strTag)
        {
            Boolean bIsTag = false;
            
            if ( strTag.Contains("[") )
            {
                if ( strTag.Contains("]") )
                {
                    bIsTag = true;
                }
            }
            return bIsTag;
        }

        public static Boolean showInit(string strIniFile, ArrayList alIniTags)
        {
            Boolean bCheck_ini = true;
            frmDashIni frmIni = new frmDashIni();
            frmIni.strIni_file = strIniFile;
            foreach (string strIniTag in alIniTags)
            {
                frmIni.alIni.Add(strIniTag);
            }
            frmIni.ShowDialog();
            bCheck_ini = false;
            return bCheck_ini;
        }


        public static Boolean isTagValue(string strTagValue)
        {
            Boolean bIsTagValue = true;
            
            if (strTagValue.Contains("["))
            {
                bIsTagValue = false;
            }
            else if (strTagValue.Contains("]"))
            {
                bIsTagValue = false;
            }
            return bIsTagValue;
        }

        public static string get_TagValue(string strTag,Boolean bTalk)
        {
            int intTag_index;
            string strTag_value = "";
            
            intTag_index = mdiDashboard.alIniTags.IndexOf(strTag);
            if (intTag_index < 0)
            {
                if (bTalk) clDashFunction.Melding(strTag + " is geen geldige INI tag !");
            }
            else
            {
                if (mdiDashboard.alIniVals.Count > intTag_index)
                {
                    strTag_value = mdiDashboard.alIniVals[intTag_index].ToString();
                }
            }
            return strTag_value;
        }

        public static string fromS2DHMS(double dblSeconds,Boolean bSuppress0Days)
        {
            // Converteer van seconden naar Dagen, Uren:Minuten:Seconden
            // Input: 14838
            // Output: 
            // 4 dag(en), 3 uur, 12 minuten, 17 seconden
            //               WAARBIJ
            // als het aantal dagen 0 is en er is via de boolean
            // aangegeven dat dan het aantal dagen niet moet worden
            // getoond, dan is de output als volgt:
            // 3 uur, 12 minuten, 17 seconden
            
            string strDHMS = "";

            int intDays;
            int intHours;
            int intMinutes;
            int intSeconds;
            
            TimeSpan ts = TimeSpan.FromSeconds(dblSeconds);

            intDays = ts.Days;
            intHours = ts.Hours;
            intMinutes = ts.Minutes;
            intSeconds = ts.Seconds;
                       
            if (intDays > 0 || !bSuppress0Days) {
              strDHMS = intDays.ToString().PadLeft(2,'0') + " dag(en),";
            }
            strDHMS = strDHMS + ts.Hours.ToString().PadLeft(2,'0') + " uur, ";
            strDHMS = strDHMS + ts.Minutes.ToString().PadLeft(2, '0') + " min., ";
            strDHMS = strDHMS + ts.Seconds.ToString().PadLeft(2, '0') + " sec.";
            return strDHMS;
        }
     }
}
