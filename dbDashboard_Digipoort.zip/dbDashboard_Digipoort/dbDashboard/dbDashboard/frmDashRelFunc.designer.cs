﻿namespace dbDashboard
{
    partial class frmDashRelFunc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDashRelFunc));
            this.grpFuncties = new System.Windows.Forms.GroupBox();
            this.clbFunc = new System.Windows.Forms.CheckedListBox();
            this.cmdReset = new System.Windows.Forms.Button();
            this.cmdOk = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblSelectedN_cnt = new System.Windows.Forms.Label();
            this.lblSelectedN = new System.Windows.Forms.Label();
            this.lblSelectedY_cnt = new System.Windows.Forms.Label();
            this.lblSelectedY = new System.Windows.Forms.Label();
            this.grpText2 = new System.Windows.Forms.GroupBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.grpText3 = new System.Windows.Forms.GroupBox();
            this.cbFilter = new System.Windows.Forms.ComboBox();
            this.grpEmbed = new System.Windows.Forms.GroupBox();
            this.lblEmbed = new System.Windows.Forms.Label();
            this.pcbembed_notavail = new System.Windows.Forms.PictureBox();
            this.cmdEmbed_cancel = new System.Windows.Forms.Button();
            this.cmdEmbed_save = new System.Windows.Forms.Button();
            this.cmdEmbedit = new System.Windows.Forms.Button();
            this.clbEmbed = new System.Windows.Forms.CheckedListBox();
            this.pnlStreep1 = new System.Windows.Forms.Panel();
            this.pnlStreep2 = new System.Windows.Forms.Panel();
            this.pnlStreep3 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.lblSubs = new System.Windows.Forms.Label();
            this.lblSubs_lbl = new System.Windows.Forms.Label();
            this.lblUgro_lbl = new System.Windows.Forms.Label();
            this.lblUgro = new System.Windows.Forms.Label();
            this.grpText = new System.Windows.Forms.GroupBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.grpText4 = new System.Windows.Forms.GroupBox();
            this.cbVolgorde = new System.Windows.Forms.CheckBox();
            this.cmdDown = new System.Windows.Forms.Button();
            this.cmdUp = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.grbConnect.SuspendLayout();
            this.grpFuncties.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.grpText3.SuspendLayout();
            this.grpEmbed.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcbembed_notavail)).BeginInit();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel4.SuspendLayout();
            this.grpText4.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmdAfsluiten
            // 
            this.cmdAfsluiten.Location = new System.Drawing.Point(8, 455);
            // 
            // grbConnect
            // 
            this.grbConnect.Location = new System.Drawing.Point(554, 489);
            this.grbConnect.Size = new System.Drawing.Size(245, 24);
            // 
            // lblHostName
            // 
            this.lblHostName.Location = new System.Drawing.Point(635, 470);
            this.lblHostName.Size = new System.Drawing.Size(145, 13);
            this.lblHostName.Text = "KPNNL\\WLD4BED923B63C";
            // 
            // grpFuncties
            // 
            this.grpFuncties.Controls.Add(this.clbFunc);
            this.grpFuncties.Controls.Add(this.cmdReset);
            this.grpFuncties.Controls.Add(this.cmdOk);
            this.grpFuncties.Location = new System.Drawing.Point(235, 2);
            this.grpFuncties.Name = "grpFuncties";
            this.grpFuncties.Size = new System.Drawing.Size(241, 405);
            this.grpFuncties.TabIndex = 0;
            this.grpFuncties.TabStop = false;
            this.grpFuncties.Text = "Functies";
            // 
            // clbFunc
            // 
            this.clbFunc.FormattingEnabled = true;
            this.clbFunc.Location = new System.Drawing.Point(8, 18);
            this.clbFunc.Name = "clbFunc";
            this.clbFunc.Size = new System.Drawing.Size(226, 349);
            this.clbFunc.TabIndex = 1;
            this.clbFunc.ThreeDCheckBoxes = true;
            this.clbFunc.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.clbFunc_ItemCheck);
            this.clbFunc.Click += new System.EventHandler(this.clbFunc_SelectedIndexChanged);
            this.clbFunc.SelectedIndexChanged += new System.EventHandler(this.clbFunc_SelectedIndexChanged);
            // 
            // cmdReset
            // 
            this.cmdReset.Location = new System.Drawing.Point(89, 373);
            this.cmdReset.Name = "cmdReset";
            this.cmdReset.Size = new System.Drawing.Size(75, 23);
            this.cmdReset.TabIndex = 16;
            this.cmdReset.Text = "&Reset";
            this.cmdReset.UseVisualStyleBackColor = true;
            this.cmdReset.Click += new System.EventHandler(this.cmdReset_Click);
            // 
            // cmdOk
            // 
            this.cmdOk.Location = new System.Drawing.Point(8, 373);
            this.cmdOk.Name = "cmdOk";
            this.cmdOk.Size = new System.Drawing.Size(75, 23);
            this.cmdOk.TabIndex = 13;
            this.cmdOk.Text = "&Ok";
            this.cmdOk.UseVisualStyleBackColor = true;
            this.cmdOk.Click += new System.EventHandler(this.cmdOk_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Control;
            this.panel2.Controls.Add(this.lblSelectedN_cnt);
            this.panel2.Controls.Add(this.lblSelectedN);
            this.panel2.Controls.Add(this.lblSelectedY_cnt);
            this.panel2.Controls.Add(this.lblSelectedY);
            this.panel2.Controls.Add(this.grpText2);
            this.panel2.Location = new System.Drawing.Point(6, 116);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(221, 90);
            this.panel2.TabIndex = 11;
            // 
            // lblSelectedN_cnt
            // 
            this.lblSelectedN_cnt.AutoSize = true;
            this.lblSelectedN_cnt.Location = new System.Drawing.Point(122, 73);
            this.lblSelectedN_cnt.Name = "lblSelectedN_cnt";
            this.lblSelectedN_cnt.Size = new System.Drawing.Size(88, 13);
            this.lblSelectedN_cnt.TabIndex = 12;
            this.lblSelectedN_cnt.Text = "lblSelectedN_cnt";
            // 
            // lblSelectedN
            // 
            this.lblSelectedN.AutoSize = true;
            this.lblSelectedN.Location = new System.Drawing.Point(1, 73);
            this.lblSelectedN.Name = "lblSelectedN";
            this.lblSelectedN.Size = new System.Drawing.Size(124, 13);
            this.lblSelectedN.TabIndex = 11;
            this.lblSelectedN.Text = "Aantal niet geselecteerd:";
            // 
            // lblSelectedY_cnt
            // 
            this.lblSelectedY_cnt.AllowDrop = true;
            this.lblSelectedY_cnt.AutoSize = true;
            this.lblSelectedY_cnt.Location = new System.Drawing.Point(122, 49);
            this.lblSelectedY_cnt.Name = "lblSelectedY_cnt";
            this.lblSelectedY_cnt.Size = new System.Drawing.Size(87, 13);
            this.lblSelectedY_cnt.TabIndex = 10;
            this.lblSelectedY_cnt.Text = "lblSelectedY_cnt";
            // 
            // lblSelectedY
            // 
            this.lblSelectedY.AutoSize = true;
            this.lblSelectedY.Location = new System.Drawing.Point(1, 49);
            this.lblSelectedY.Name = "lblSelectedY";
            this.lblSelectedY.Size = new System.Drawing.Size(104, 13);
            this.lblSelectedY.TabIndex = 9;
            this.lblSelectedY.Text = "Aantal geselecteerd:";
            // 
            // grpText2
            // 
            this.grpText2.Location = new System.Drawing.Point(-4, 26);
            this.grpText2.Name = "grpText2";
            this.grpText2.Size = new System.Drawing.Size(228, 72);
            this.grpText2.TabIndex = 8;
            this.grpText2.TabStop = false;
            this.grpText2.Text = "Info";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.Control;
            this.panel3.Controls.Add(this.grpText3);
            this.panel3.Location = new System.Drawing.Point(6, 213);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(223, 90);
            this.panel3.TabIndex = 15;
            // 
            // grpText3
            // 
            this.grpText3.Controls.Add(this.cbFilter);
            this.grpText3.Location = new System.Drawing.Point(-4, 24);
            this.grpText3.Name = "grpText3";
            this.grpText3.Size = new System.Drawing.Size(232, 72);
            this.grpText3.TabIndex = 8;
            this.grpText3.TabStop = false;
            this.grpText3.Text = "Filter op getoonde functies";
            // 
            // cbFilter
            // 
            this.cbFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbFilter.FormattingEnabled = true;
            this.cbFilter.Items.AddRange(new object[] {
            "Alles",
            "Alleen geselecteerd",
            "Alleen niet geselecteerd"});
            this.cbFilter.Location = new System.Drawing.Point(8, 19);
            this.cbFilter.Name = "cbFilter";
            this.cbFilter.Size = new System.Drawing.Size(192, 21);
            this.cbFilter.TabIndex = 16;
            this.cbFilter.SelectedIndexChanged += new System.EventHandler(this.cbFilter_SelectedIndexChanged);
            // 
            // grpEmbed
            // 
            this.grpEmbed.Controls.Add(this.lblEmbed);
            this.grpEmbed.Controls.Add(this.pcbembed_notavail);
            this.grpEmbed.Controls.Add(this.cmdEmbed_cancel);
            this.grpEmbed.Controls.Add(this.cmdEmbed_save);
            this.grpEmbed.Controls.Add(this.cmdEmbedit);
            this.grpEmbed.Controls.Add(this.clbEmbed);
            this.grpEmbed.Location = new System.Drawing.Point(518, 125);
            this.grpEmbed.Name = "grpEmbed";
            this.grpEmbed.Size = new System.Drawing.Size(255, 302);
            this.grpEmbed.TabIndex = 23;
            this.grpEmbed.TabStop = false;
            this.grpEmbed.Text = "Interne functies in";
            // 
            // lblEmbed
            // 
            this.lblEmbed.AutoSize = true;
            this.lblEmbed.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmbed.ForeColor = System.Drawing.Color.Blue;
            this.lblEmbed.Location = new System.Drawing.Point(6, 26);
            this.lblEmbed.Name = "lblEmbed";
            this.lblEmbed.Size = new System.Drawing.Size(224, 26);
            this.lblEmbed.TabIndex = 29;
            this.lblEmbed.Text = "Sommige functies hebben interne subfuncties \r\ndie hier apart moeten worden toegew" +
    "ezen";
            // 
            // pcbembed_notavail
            // 
            this.pcbembed_notavail.Image = ((System.Drawing.Image)(resources.GetObject("pcbembed_notavail.Image")));
            this.pcbembed_notavail.Location = new System.Drawing.Point(9, 69);
            this.pcbembed_notavail.Name = "pcbembed_notavail";
            this.pcbembed_notavail.Size = new System.Drawing.Size(159, 197);
            this.pcbembed_notavail.TabIndex = 5;
            this.pcbembed_notavail.TabStop = false;
            this.pcbembed_notavail.Visible = false;
            // 
            // cmdEmbed_cancel
            // 
            this.cmdEmbed_cancel.Location = new System.Drawing.Point(175, 95);
            this.cmdEmbed_cancel.Name = "cmdEmbed_cancel";
            this.cmdEmbed_cancel.Size = new System.Drawing.Size(75, 23);
            this.cmdEmbed_cancel.TabIndex = 4;
            this.cmdEmbed_cancel.Text = "Annuleren";
            this.cmdEmbed_cancel.UseVisualStyleBackColor = true;
            this.cmdEmbed_cancel.Click += new System.EventHandler(this.cmdEmbed_cancel_Click);
            // 
            // cmdEmbed_save
            // 
            this.cmdEmbed_save.Location = new System.Drawing.Point(175, 70);
            this.cmdEmbed_save.Name = "cmdEmbed_save";
            this.cmdEmbed_save.Size = new System.Drawing.Size(75, 23);
            this.cmdEmbed_save.TabIndex = 3;
            this.cmdEmbed_save.Text = "Opslaan";
            this.cmdEmbed_save.UseVisualStyleBackColor = true;
            this.cmdEmbed_save.Click += new System.EventHandler(this.cmdEmbed_save_Click);
            // 
            // cmdEmbedit
            // 
            this.cmdEmbedit.Location = new System.Drawing.Point(7, 275);
            this.cmdEmbedit.Name = "cmdEmbedit";
            this.cmdEmbedit.Size = new System.Drawing.Size(75, 23);
            this.cmdEmbedit.TabIndex = 2;
            this.cmdEmbedit.Text = "Bewerken";
            this.cmdEmbedit.UseVisualStyleBackColor = true;
            this.cmdEmbedit.Click += new System.EventHandler(this.cmdEmbedit_Click);
            // 
            // clbEmbed
            // 
            this.clbEmbed.BackColor = System.Drawing.Color.White;
            this.clbEmbed.FormattingEnabled = true;
            this.clbEmbed.Location = new System.Drawing.Point(8, 68);
            this.clbEmbed.Name = "clbEmbed";
            this.clbEmbed.Size = new System.Drawing.Size(161, 199);
            this.clbEmbed.Sorted = true;
            this.clbEmbed.TabIndex = 1;
            this.clbEmbed.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.clbEmbed_ItemCheck);
            // 
            // pnlStreep1
            // 
            this.pnlStreep1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlStreep1.Location = new System.Drawing.Point(490, 128);
            this.pnlStreep1.Name = "pnlStreep1";
            this.pnlStreep1.Size = new System.Drawing.Size(12, 1);
            this.pnlStreep1.TabIndex = 24;
            // 
            // pnlStreep2
            // 
            this.pnlStreep2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlStreep2.Location = new System.Drawing.Point(501, 276);
            this.pnlStreep2.Name = "pnlStreep2";
            this.pnlStreep2.Size = new System.Drawing.Size(17, 1);
            this.pnlStreep2.TabIndex = 25;
            // 
            // pnlStreep3
            // 
            this.pnlStreep3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlStreep3.Location = new System.Drawing.Point(501, 129);
            this.pnlStreep3.Name = "pnlStreep3";
            this.pnlStreep3.Size = new System.Drawing.Size(1, 148);
            this.pnlStreep3.TabIndex = 26;
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.panel6);
            this.panel5.Controls.Add(this.panel4);
            this.panel5.Controls.Add(this.grpFuncties);
            this.panel5.Controls.Add(this.panel2);
            this.panel5.Controls.Add(this.panel3);
            this.panel5.Location = new System.Drawing.Point(8, 28);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(483, 419);
            this.panel5.TabIndex = 27;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.Control;
            this.panel6.Controls.Add(this.lblSubs);
            this.panel6.Controls.Add(this.lblSubs_lbl);
            this.panel6.Controls.Add(this.lblUgro_lbl);
            this.panel6.Controls.Add(this.lblUgro);
            this.panel6.Controls.Add(this.grpText);
            this.panel6.Location = new System.Drawing.Point(5, 16);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(221, 93);
            this.panel6.TabIndex = 30;
            // 
            // lblSubs
            // 
            this.lblSubs.AutoSize = true;
            this.lblSubs.Location = new System.Drawing.Point(122, 72);
            this.lblSubs.Name = "lblSubs";
            this.lblSubs.Size = new System.Drawing.Size(41, 13);
            this.lblSubs.TabIndex = 7;
            this.lblSubs.Text = "lblSubs";
            // 
            // lblSubs_lbl
            // 
            this.lblSubs_lbl.AutoSize = true;
            this.lblSubs_lbl.Location = new System.Drawing.Point(1, 72);
            this.lblSubs_lbl.Name = "lblSubs_lbl";
            this.lblSubs_lbl.Size = new System.Drawing.Size(67, 13);
            this.lblSubs_lbl.TabIndex = 6;
            this.lblSubs_lbl.Text = "Subsysteem:";
            // 
            // lblUgro_lbl
            // 
            this.lblUgro_lbl.AutoSize = true;
            this.lblUgro_lbl.Location = new System.Drawing.Point(1, 51);
            this.lblUgro_lbl.Name = "lblUgro_lbl";
            this.lblUgro_lbl.Size = new System.Drawing.Size(88, 13);
            this.lblUgro_lbl.TabIndex = 4;
            this.lblUgro_lbl.Text = "Gebruikersgroep:";
            // 
            // lblUgro
            // 
            this.lblUgro.AutoSize = true;
            this.lblUgro.Location = new System.Drawing.Point(122, 51);
            this.lblUgro.Name = "lblUgro";
            this.lblUgro.Size = new System.Drawing.Size(40, 13);
            this.lblUgro.TabIndex = 5;
            this.lblUgro.Text = "lblUgro";
            // 
            // grpText
            // 
            this.grpText.Location = new System.Drawing.Point(-2, 33);
            this.grpText.Name = "grpText";
            this.grpText.Size = new System.Drawing.Size(226, 72);
            this.grpText.TabIndex = 3;
            this.grpText.TabStop = false;
            this.grpText.Text = "Functies selecteren";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.Control;
            this.panel4.Controls.Add(this.grpText4);
            this.panel4.Location = new System.Drawing.Point(6, 310);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(223, 94);
            this.panel4.TabIndex = 18;
            // 
            // grpText4
            // 
            this.grpText4.Controls.Add(this.cbVolgorde);
            this.grpText4.Controls.Add(this.cmdDown);
            this.grpText4.Controls.Add(this.cmdUp);
            this.grpText4.ForeColor = System.Drawing.Color.Red;
            this.grpText4.Location = new System.Drawing.Point(-3, 18);
            this.grpText4.Name = "grpText4";
            this.grpText4.Size = new System.Drawing.Size(230, 88);
            this.grpText4.TabIndex = 23;
            this.grpText4.TabStop = false;
            // 
            // cbVolgorde
            // 
            this.cbVolgorde.AutoSize = true;
            this.cbVolgorde.ForeColor = System.Drawing.SystemColors.ControlText;
            this.cbVolgorde.Location = new System.Drawing.Point(12, -1);
            this.cbVolgorde.Name = "cbVolgorde";
            this.cbVolgorde.Size = new System.Drawing.Size(145, 17);
            this.cbVolgorde.TabIndex = 18;
            this.cbVolgorde.Text = "Functie volgorde wijzigen";
            this.cbVolgorde.UseVisualStyleBackColor = true;
            this.cbVolgorde.CheckedChanged += new System.EventHandler(this.cbVolgorde_CheckedChanged);
            // 
            // cmdDown
            // 
            this.cmdDown.BackColor = System.Drawing.Color.White;
            this.cmdDown.ForeColor = System.Drawing.SystemColors.ControlText;
            this.cmdDown.Image = ((System.Drawing.Image)(resources.GetObject("cmdDown.Image")));
            this.cmdDown.Location = new System.Drawing.Point(193, 45);
            this.cmdDown.Name = "cmdDown";
            this.cmdDown.Size = new System.Drawing.Size(33, 26);
            this.cmdDown.TabIndex = 20;
            this.cmdDown.UseVisualStyleBackColor = false;
            this.cmdDown.Click += new System.EventHandler(this.cmdDown_Click);
            // 
            // cmdUp
            // 
            this.cmdUp.BackColor = System.Drawing.Color.White;
            this.cmdUp.ForeColor = System.Drawing.SystemColors.ControlText;
            this.cmdUp.Image = ((System.Drawing.Image)(resources.GetObject("cmdUp.Image")));
            this.cmdUp.Location = new System.Drawing.Point(193, 13);
            this.cmdUp.Name = "cmdUp";
            this.cmdUp.Size = new System.Drawing.Size(33, 26);
            this.cmdUp.TabIndex = 19;
            this.cmdUp.UseVisualStyleBackColor = false;
            this.cmdUp.Click += new System.EventHandler(this.cmdUp_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(862, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 19;
            this.label1.Text = "label1";
            // 
            // frmDashRelFunc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(778, 482);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.grpEmbed);
            this.Controls.Add(this.pnlStreep3);
            this.Controls.Add(this.pnlStreep2);
            this.Controls.Add(this.pnlStreep1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmDashRelFunc";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "DB Dashboard; Functies per gebruikersgroep/subsysteem";
            this.Load += new System.EventHandler(this.frmDashRelFunc_Load);
            this.Controls.SetChildIndex(this.pnlStreep1, 0);
            this.Controls.SetChildIndex(this.pnlStreep2, 0);
            this.Controls.SetChildIndex(this.lblHostName, 0);
            this.Controls.SetChildIndex(this.pnlStreep3, 0);
            this.Controls.SetChildIndex(this.grpEmbed, 0);
            this.Controls.SetChildIndex(this.panel5, 0);
            this.Controls.SetChildIndex(this.cmdAfsluiten, 0);
            this.Controls.SetChildIndex(this.grbConnect, 0);
            this.grbConnect.ResumeLayout(false);
            this.grbConnect.PerformLayout();
            this.grpFuncties.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.grpText3.ResumeLayout(false);
            this.grpEmbed.ResumeLayout(false);
            this.grpEmbed.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcbembed_notavail)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.grpText4.ResumeLayout(false);
            this.grpText4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpFuncties;
        private System.Windows.Forms.CheckedListBox clbFunc;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblSelectedN_cnt;
        private System.Windows.Forms.Label lblSelectedN;
        private System.Windows.Forms.Label lblSelectedY;
        private System.Windows.Forms.Label lblSelectedY_cnt;
        private System.Windows.Forms.GroupBox grpText2;
        private System.Windows.Forms.Button cmdOk;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.GroupBox grpText3;
        private System.Windows.Forms.ComboBox cbFilter;
        private System.Windows.Forms.Button cmdReset;
        private System.Windows.Forms.GroupBox grpEmbed;
        private System.Windows.Forms.CheckedListBox clbEmbed;
        private System.Windows.Forms.Button cmdEmbedit;
        private System.Windows.Forms.Button cmdEmbed_save;
        private System.Windows.Forms.Panel pnlStreep1;
        private System.Windows.Forms.Panel pnlStreep2;
        private System.Windows.Forms.Panel pnlStreep3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button cmdEmbed_cancel;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.GroupBox grpText4;
        private System.Windows.Forms.CheckBox cbVolgorde;
        private System.Windows.Forms.Button cmdDown;
        private System.Windows.Forms.Button cmdUp;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label lblSubs;
        private System.Windows.Forms.Label lblSubs_lbl;
        private System.Windows.Forms.Label lblUgro_lbl;
        private System.Windows.Forms.Label lblUgro;
        private System.Windows.Forms.GroupBox grpText;
        private System.Windows.Forms.PictureBox pcbembed_notavail;
        private System.Windows.Forms.Label lblEmbed;
    }
}