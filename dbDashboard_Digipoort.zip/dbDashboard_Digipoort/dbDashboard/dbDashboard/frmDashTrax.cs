﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;

namespace dbDashboard
{
    public partial class frmDashTrax : frmDashBase
    {
        public frmDashTrax()
        {
            InitializeComponent();
        }

        Boolean bInit_Ok = true;
        string strCore = null;
        string strCP_LogPath = null;    
        string strGrep = null;
        string strPlink = null;
        string strSSH = null;
        string strTranx = null;
        string strTraxSaveAs = null;

        const string strFrom      = "'From=<";
        const string strRecipient = "'Recipient=<";
        const string strSubject   = "'Subject=";

        const string lbSeperator = "-";
        const string strDateFix  = "Select dates (max 10)";

        private void Select_date()
        {
            // From 1-7-2014 
            //   To 20140701
            string strFormattedDate = monthCalendar1.SelectionRange.Start.Year.ToString() + monthCalendar1.SelectionRange.Start.Month.ToString("0#") + monthCalendar1.SelectionRange.Start.Day.ToString("0#");

            if (monthCalendar1.SelectionRange.Start > System.DateTime.Now)
            {
                clDashFunction.Melding("Future logfiles do not yet exist !");
            }
            else
            {
                if (lbDates.Items.IndexOf(strFormattedDate) < 0)
                {
                    if (lbDates.Items.Count > 9)
                    {
                        clDashFunction.Melding("Number of selected dates has reached its limit !", 1, "I");
                    }
                    else
                    {
                        lbDates.Items.Add(strFormattedDate);
                    }
                }
                else
                {
                    lbDates.Items.Remove(strFormattedDate);
                }
                Do_Dates_Bold();
                Check_Input();
            }
        }
        

        private void lbDates_DoubleClick(object sender, EventArgs e)
        {
            if (lbDates.SelectedIndex > -1)
            {                             
                lbDates.Items.RemoveAt(lbDates.SelectedIndex);
            }
            Do_Dates_Bold();
        }


        private void Do_Dates_Bold()
        {
            DateTime[] myDates = new DateTime[10];
            int int_myDateIndex = 0;
            monthCalendar1.BoldedDates = null;
            while (lbDates.Items.Count > int_myDateIndex)
            {
                // Hier moeten we datums uit de listbox omwerken tot een 'echte' datetime
                // want alleen dan kunnen ze in de myDates array worden gezet om dan vervolgens
                // weer de datums VET te kunnen maken in het kalender control
                //  MessageBox.Show(lbDates.Items[i].ToString());
                string strDateOut = clDashFunction.convert_date(lbDates.Items[int_myDateIndex].ToString());
                if (int_myDateIndex < 10)
                {
                    myDates[int_myDateIndex] = Convert.ToDateTime(strDateOut);
                }
                int_myDateIndex++;
            }
            monthCalendar1.BoldedDates = myDates;
            lblDatesMax.Text = strDateFix;

            if (lbDates.Items.Count > 0)
            {
                lblDatesMax.Text = strDateFix + ", " + lbDates.Items.Count.ToString() + " currently selected";
            }
        }


        private void lbDates_SelectedIndexChanged(object sender, EventArgs e)
        {
            Check_Input();
        }
        
       
        private void txtSubject_TextChanged(object sender, EventArgs e)
        {
          Check_Input();
        }

        private void frmDashTrax_Load(object sender, EventArgs e)
        {
            Init_Form();            
        }

        private void Init_Form()
        {
            DoSql mySql = new DoSql();
            mySql.vul_deze_text1_array[1] = "FTA";

            mySql.DoQuery("SELECT ElemElem, ElemOms1,'DUMMY' " +
                          "FROM   DashElem " +
                          "WHERE  ElemTabn = 10 " +
                          "AND    ElemElem LIKE 'TRAX%'");

            if (mySql.affected_rows < 1)
            {
                clDashFunction.Melding("Geen TRAX stuurgegevens bekend in tabel 10", 1, "I");
                bInit_Ok = false;
            }

            // Ophalen van diverse variabelen uit DashElem
            for (int intI = 1; intI < mySql.vul_deze_text1_array.Length; intI++)
            {
                if (mySql.vul_deze_text1_array[intI] != null)
                {
                    switch (mySql.vul_deze_text1_array[intI])
                    {
                        // Waar staan de CP logbestanden ook weer ?
                        case "TRAX_CP_LOGPATH":
                            strCP_LogPath = mySql.vul_deze_text2_array[intI];
                            break;
                        // Wat is het vaste deel van de grep syntax ?
                        case "TRAX_GREP":
                            strGrep = mySql.vul_deze_text2_array[intI];
                            break;
                        // Wat en waar is de file waarin we de listbox detail info naartoe saven ?
                        case "TRAX_SAVEAS":
                            strTraxSaveAs = mySql.vul_deze_text2_array[intI];
                            break;
                        case "TRAX_TRANS":
                            strTranx = mySql.vul_deze_text2_array[intI];
                            break;
                        case "TRAX_CORE":
                            strCore = mySql.vul_deze_text2_array[intI];
                            break;
                        default:
                            break;
                    }
                }
            }
            if ( strCore == null )
            {
                clDashFunction.Melding("Stuurdata niet compleet! Check element TRAX_CORE in tabel 10");
                bInit_Ok = false;
            }    

            if (strCP_LogPath == null)
            {
                clDashFunction.Melding("Stuurdata niet compleet! Check element TRAX_CP_LOGPATH in tabel 10");
                bInit_Ok = false;
            }
            if (strGrep == null)
            {
                clDashFunction.Melding("Stuurdata niet compleet! Check element TRAX_GREP in tabel 10");
                bInit_Ok = false;
            }
            if (strTraxSaveAs == null)
            {
                clDashFunction.Melding("Stuurdata niet compleet! Check element TRAX_SAVEAS in tabel 10");
                bInit_Ok = false;
            }
            if (strTranx == null)
            {
                clDashFunction.Melding("Stuurdata niet compleet! Check element TRAX_TRANS in tabel 10");
                bInit_Ok = false;
            }
            
            mySql = new DoSql();
            mySql.vul_deze_text1_array[1] = "FTA";

            mySql.DoQuery("SELECT ElemElem, ElemOms1,ElemOms2 " +
                          "FROM   DashElem " +
                          "WHERE  ElemTabn = 12 " +
                          "AND    ElemOms1 like '%SMTP%' " +
                          "ORDER BY ElemOms2,ElemOms1,ElemElem");

            if (mySql.affected_rows < 1)
            {
                clDashFunction.Melding("Geen SMTP servers gedefinieerd in tabel 12", 1, "I");
                bInit_Ok = false;
            }

            // Hier vullen van de 2 listboxes: 1 met CBI/DBI en een 'schaduw' listbox
            // met daarin de paden
            string strText2_old = "";
            string strText3_old = "";
            for (int intI = 1; intI < mySql.vul_deze_text1_array.Length; intI++)
            {
                if (intI == 1)
                {
                    strText2_old = mySql.vul_deze_text2_array[intI];
                    strText3_old = mySql.vul_deze_text3_array[intI];
                }

                if (mySql.vul_deze_text1_array[intI] != null)
                {
                   
                    if (mySql.vul_deze_text2_array[intI] != strText2_old ||
                        mySql.vul_deze_text3_array[intI] != strText3_old)
                    {
                        lbServer.Items.Add(lbSeperator);
                    }
                    lbServer.Items.Add(mySql.vul_deze_text1_array[intI].ToLower());

                    strText2_old = mySql.vul_deze_text2_array[intI];
                    strText3_old = mySql.vul_deze_text3_array[intI];
                }
            }
                        
            // De controls worden alleen enabled als er geen fouten bij het initialiseren zijn opgetreden
            txtSubject.Enabled = bInit_Ok;
            cmdSelect.Enabled = bInit_Ok;
            cmdTrans.Enabled = bInit_Ok;
            lbServer.Enabled = bInit_Ok;
            lbDates.Enabled = bInit_Ok;
            monthCalendar1.Enabled = bInit_Ok;           

            // Kopieer kolomnamen uit datagrid over naar de combobox ten behoeve van de search functie.
            int idgCols = 0;
            while (idgCols < dgTrax.ColumnCount)
            {
              cmbTraxSearch.Items.Add(dgTrax.Columns[idgCols].HeaderText);
              idgCols++;
            }


            if (bInit_Ok)
            {
                Check_Input();
            }

            Set_Traxbutes(true);

            lblTraxCount.Visible = false;
            lblTraxStatus.Visible = false;
            grbMsgId.Visible = false;
            lblMsgId.Visible = false;
        }

        private void cmdSelect_Click(object sender, EventArgs e)
        {
            // Set cursor as hourglass
            Cursor.Current = Cursors.WaitCursor;

            string strServer;
            string strDate;

            dgTrax.Rows.Clear();

            Set_Traxbutes(true);
            grbMsgId.Visible = false;
            lblMsgId.Visible = false;
           
            int intServer = 0;
            // Loop thru selected server(s)
            while (intServer < lbServer.SelectedIndices.Count)
            {
                strServer = lbServer.SelectedItems[intServer].ToString();

                // Loop thru selected data(s)
                int intDate = 0;
                while (intDate < lbDates.Items.Count)
                {
                    strDate = lbDates.Items[intDate].ToString();
                    do_grep(strServer, strDate);
                    intDate++;
                }
                intServer++;
            }

            setTraxCount(dgTrax.Rows.Count,dgTrax.Rows.Count);
            lblTraxStatus.Text = "";

            cmdTraxReset_Click(new object(), new EventArgs());

            // Zoekdialog alleen als er rows geselecteerd zijn
            if (dgTrax.Rows.Count > 0)
            {
                Set_Traxbutes(false);
                lblMsgId.Visible = true;
                Check_Search();
            }
            else
            {
                clDashFunction.Melding("No SMTP-log records selected!", 1, "I");
            }


            // Set cursor as default
            Cursor.Current = Cursors.Default;
        }

        private void setTraxCount(int intSelected, int intSearched)
        {
            lblTraxCount.Text = "Item count: " + intSelected.ToString() + " shown: " + intSearched.ToString();
        }

        private void do_grep(string strServer, string strDate)
        {
            int intRowNo = 0;
            lblTraxStatus.Text = "Running date: " + strDate + " on server: " + strServer;

            this.Refresh();

            string strQuery = strGrep + " " + txtSubject.Text + " " + strCP_LogPath + strDate + "*";

            StreamReader myStreamReader = clDashFunction.get_linux_data(strServer, strQuery);
            if (myStreamReader.EndOfStream == false)
            {

                while (!myStreamReader.EndOfStream)
                {
                    string myString = myStreamReader.ReadLine();

                    intRowNo = dgTrax.Rows.Add();
                    dgTrax[0, intRowNo].Value = strServer;
                    dgTrax[1, intRowNo].Value = strDate; //myString.Substring(0, 8);                       // Datum
                    dgTrax[2, intRowNo].Value = myString.Substring(9, 8);                       // Tijd
                    dgTrax[3, intRowNo].Value = myString.Substring(18, 16);                     // ID
                    dgTrax[4, intRowNo].Value = myString.Substring(35, myString.Length - 35);   // Messagetext                    
                }
                myStreamReader.Close();
            }
            else
            {
                if (mdiDashboard.bDebug)
                {
                    intRowNo = dgTrax.Rows.Add();
                    strServer = "kslv999";
                    string myString = "2015010123:59:591234567890ABCDEFMessagetext";

                    dgTrax[0, intRowNo].Value = strServer;
                    dgTrax[1, intRowNo].Value = myString.Substring(0, 8);                       // Datum
                    dgTrax[2, intRowNo].Value = myString.Substring(8, 8);                       // Tijd
                    dgTrax[3, intRowNo].Value = myString.Substring(16, 16);                     // ID
                    dgTrax[4, intRowNo].Value = myString.Substring(32, myString.Length - 32);   // Messagetext   
                }
            }
        }

        private void do_grep_msg(string strServer, string strDate, string strMsgId)
        {
            lbMsgId.Items.Clear();

            lblTraxStatus.Text = "Running msgid: " + strMsgId + " on server: " + strServer;

            this.Refresh();

            string strQuery = strGrep + " " + strMsgId + " " + strCP_LogPath + strDate + "*";
            
            StreamReader myStreamReader = clDashFunction.get_linux_data(strServer, strQuery);
            if (!myStreamReader.EndOfStream)
            {

                while (!myStreamReader.EndOfStream)
                {
                    string myString = myStreamReader.ReadLine();

                    lbMsgId.Items.Add(myString);

                    // clDashFunction.Melding(myString);                                    
                }                
                myStreamReader.Close();

                grpTraxSearch.Visible = false;
                grbMsgId.Visible = true;
                lblMsgId.Visible = false;
            }
            else
            {
                if (mdiDashboard.bDebug)
                {
                    lbMsgId.Items.Add("TESTREGEL");
                }
                else
                {
                    clDashFunction.Melding("Function 'do_grep_msg' did not select anything !");
                }
            }
        }

        private void lbServer_SelectedIndexChanged(object sender, EventArgs e)
        {
            Check_Input();
        }

        private void cmdTraxSearch_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            Do_SubSearch(cmbTraxSearch.SelectedItem.ToString().ToUpper(), txtTraxSearch.Text, cmbTraxSearch.SelectedIndex);
            Cursor.Current = Cursors.Default;
        }

        private void Do_SubSearch(string strTargetColumn, string strTargetValue, int intIndex)
        {
            int intRowno = 0;
            int intFound = 0;

            if (strTargetColumn == "Time".ToUpper() && strTargetValue.Contains("~"))
            {
                DateTime dtOut;

                string[] alTijdRange = Regex.Split(strTargetValue, "~");

                if (!DateTime.TryParse(alTijdRange[0].ToString(), out dtOut) || !DateTime.TryParse(alTijdRange[1].ToString(), out dtOut))
                {
                    clDashFunction.Melding("Het opgegeven tijdstip is niet geldig",1,"I"); 
                }
            }

           
            while (intRowno < dgTrax.Rows.Count)
            {
                dgTrax.Rows[intRowno].Visible = false;

                // WEL op tijd selecteren
                if (strTargetColumn == "Time".ToUpper() && strTargetValue.Contains("~"))
                {
                    string[] alTijdRange = Regex.Split(strTargetValue, "~");

                    if (DateTime.Parse(dgTrax[intIndex, intRowno].Value.ToString()) >= DateTime.Parse(alTijdRange[0].ToString()))
                    {
                        dgTrax.Rows[intRowno].Visible = DateTime.Parse(dgTrax[intIndex, intRowno].Value.ToString()) <= DateTime.Parse(alTijdRange[1].ToString());
                    }
                }
                // NIET op tijd selecteren
                else
                {
                    dgTrax.Rows[intRowno].Visible = dgTrax[intIndex, intRowno].Value.ToString().Contains(strTargetValue);
                }

                if (dgTrax.Rows[intRowno].Visible)
                {
                    intFound++;
                }

                intRowno++;
            }

            setTraxCount(dgTrax.Rows.Count, intFound);
        }

        private void cmdTraxReset_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            // Reset searchcontrols
            cmbTraxSearch.SelectedIndex = -1;
            txtTraxSearch.Text = "";

            int intRowno = 0;
            while (intRowno < dgTrax.Rows.Count)
            {
                dgTrax.Rows[intRowno].Visible = true;
                intRowno++;
            }
            
            setTraxCount(dgTrax.Rows.Count,dgTrax.Rows.Count);
            Cursor.Current = Cursors.Default;
        }

        private void Check_Input()
        {
            cmdSelect.Enabled = false;
            
            int intlbIndex = 0;
            while (intlbIndex < lbServer.Items.Count)
            {
                if (lbServer.Items[intlbIndex].ToString() == lbSeperator)
                {
                    lbServer.SelectedIndices.Remove(intlbIndex);
                }
                intlbIndex++;
            }
            if (txtSubject.Text != "" & txtSubject.Text.Length > 2)
            {                
                if (lbDates.Items.Count > 0 & lbServer.SelectedIndices.Count > 0)
                {
                    cmdSelect.Enabled = true;
                }
            }
        }

        private void Set_Traxbutes(Boolean bTF)
        {           
            lblTraxCount.Visible = !bTF;
            lblTraxStatus.Visible = bTF;
            grpTraxSearch.Visible = !bTF;           
        }

        private void cmbTraxSearch_SelectedIndexChanged(object sender, EventArgs e)
        {
            Check_Search();   
        }
        
        private void txtTraxSearch_TextChanged(object sender, EventArgs e)
        {
            Check_Search();
        }


        private void Check_Search()
        {
            cmdTraxSearch.Enabled = false;
            if (cmbTraxSearch.SelectedIndex > -1 && txtSubject.Text != "")
            {
                cmdTraxSearch.Enabled = true;                
            }
        }


        private void monthCalendar1_DateSelected(object sender, DateRangeEventArgs e)
        {
            Select_date();
        }

        private void cmdTrans_Click(object sender, EventArgs e)
        {
            frmDashTran frmTran = new frmDashTran();
            frmTran.strCore = strCore;
            frmTran.strPlink = strPlink;
            frmTran.strSSH = strSSH;
            frmTran.strTranx = strTranx;
            switch (txtSubjectType.Text.ToUpper())
            {
                case "L":
                    frmTran.strSelectedAddress = txtSubject.Text;
                    frmTran.strSelectedAddressType = txtSubjectType.Text;
                    break;
                case "P":
                    frmTran.strSelectedAddress = txtSubject.Text;
                    frmTran.strSelectedAddressType = txtSubjectType.Text;
                    break;
                default:
                    // frmTran.strSelectedAddress = "";
                    frmTran.strSelectedAddress = txtSubject.Text;

                    frmTran.strSelectedAddressType = txtSubjectType.Text;
                    // frmTran.strSelectedAddressType = "P";
                    break;
            }
            frmTran.ShowDialog(this);
            txtSubject.Text=frmTran.strSelectedAddress;
            txtSubjectType.Text = frmTran.strSelectedAddressType;
        }

        private void frmDashTrax_Activated(object sender, EventArgs e)
        {
            txtSubject.Focus();
        }

        /// <summary>
        /// We gaan wat doen met de waarde van msgid uit de aangeklikte row/kolom
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgTrax_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            string strServer_value;
            string strDate_value;
            string strMsgId_value;

            if (e.ColumnIndex == 3)
            {
                strServer_value  = dgTrax[0, e.RowIndex].Value.ToString();
                strDate_value    = dgTrax[1, e.RowIndex].Value.ToString();
                strMsgId_value   = dgTrax[e.ColumnIndex, e.RowIndex].Value.ToString();
                if (strMsgId_value != "")
                {
                    Cursor.Current = Cursors.WaitCursor;
                   // clDashFunction.Melding(dgTrax[e.ColumnIndex, e.RowIndex].Value.ToString());
                   do_grep_msg(strServer_value, strDate_value, strMsgId_value);
                   Cursor.Current = Cursors.Default;
                }
            }
        }

        private void cmdMsgId_Close_Click(object sender, EventArgs e)
        {
            grbMsgId.Visible = false;
            lblMsgId.Visible = true;
            grpTraxSearch.Visible = true;           
        }

        private void cmdDate_reset_Click(object sender, EventArgs e)
        {            
            while (lbDates.Items.Count>0)
            {
                lbDates.Items.RemoveAt(0);               
            }
            Do_Dates_Bold();
            monthCalendar1.SetDate(System.DateTime.Now);
        }

        private void cmdNotePad_Click(object sender, EventArgs e)
        {
            StreamWriter sw = clDashFunction.open4write(strTraxSaveAs);
            int lbIndex = 0;
            while (lbIndex < lbMsgId.Items.Count)
            {
                sw.WriteLine(lbMsgId.Items[lbIndex].ToString());
                lbIndex++;
            }
            sw.Close();
            if (clDashFunction.Melding("Done, " + lbIndex.ToString() + " listbox rows saved to:\n" + strTraxSaveAs+"\n\n Would you like to open this file ?",2,"Q") == DialogResult.OK)
            {
                clDashFunction.Notepad(strTraxSaveAs);
            }
        }

        private void rbTemplateNone_CheckedChanged(object sender, EventArgs e)
        {
            if (txtSubject.Text.Trim() != "")
            {
                txtSubject.Text = remove_voorloop_string(txtSubject.Text);
            }
        }

        private void rbTemplateFrom_CheckedChanged(object sender, EventArgs e)
        {

            if (txtSubject.Text.Trim() != "")
            {
                txtSubject.Text = remove_voorloop_string(txtSubject.Text);
                if (txtSubject.Text.Trim() != "")
                {
                    txtSubject.Text = strFrom + txtSubject.Text + "'";
                }
            }
        }
        
        private void rbTemplateRecipient_CheckedChanged(object sender, EventArgs e)
        {
            if (txtSubject.Text.Trim() != "")
            {
                txtSubject.Text = remove_voorloop_string(txtSubject.Text);
                if (txtSubject.Text.Trim() != "")
                {
                    txtSubject.Text = strRecipient + txtSubject.Text + "'";
                }
            }
        }

        private void rbTemplateSubject_CheckedChanged(object sender, EventArgs e)
        {
            if (txtSubject.Text.Trim() != "")
            {
                txtSubject.Text = remove_voorloop_string(txtSubject.Text);
                if (txtSubject.Text.Trim() != "")
                {
                    txtSubject.Text = strSubject + txtSubject.Text + "'";
                }
            }
        } 

        private string remove_voorloop_string(string strInput)
        {
            if (strInput.IndexOf(strFrom) > -1)
            {
                // Staat "From=" er al in ? wegwezen
                strInput = strInput.Remove(0, strFrom.Length);
            }

            if (strInput.IndexOf(strRecipient) > -1)
            {
                // Staat "Recipient=" er al in ? wegwezen
                strInput = strInput.Remove(0, strRecipient.Length);               
            }

            if (strInput.IndexOf(strSubject) > -1)
            {
                // Staat "Subject=" er al in ? wegwezen
                strInput = strInput.Remove(0, strSubject.Length);                             
            }

           strInput= strInput.Replace("'", "");

           return strInput;
        }

        private void txtSubject_Enter(object sender, EventArgs e)
        {
            remove_voorloop_string(txtSubject.Text);
        }             
    }
}
