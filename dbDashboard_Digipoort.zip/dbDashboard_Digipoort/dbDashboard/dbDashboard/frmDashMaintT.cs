using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace dbDashboard
{
    public partial class frmDashMaintT : frmDashBase
    {
        string[] strQueryArgs = new string[] { "[0]", "[1] ", "[2] ", "[4]", "[5]" };

        public  string       strTabel_nr;
        public  string       strBeheer_tabel;        
        public  string       strSupplemental_Title;
        private ArrayList    arr_DetailData;
             
        // ***********************************************************************
        // Onderstaande 2 arrays zijn om Userid en Password te bewaren omdat deze
        // in het detail form als een * worden weergegeven...
        // ***********************************************************************
        private ArrayList    alPassword = new ArrayList();
        private ArrayList    alUserid   = new ArrayList();

        public frmDashMaintT()
        {
            InitializeComponent();
        }
     
        private void frmDashMaintT_Load(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            frm_init(); 
            this.Cursor = Cursors.Default;
        }

        private void frm_init()
        {
            this.Text = this.Text + "(" + strSupplemental_Title + ")";
            if (strTabel_nr == null)
            {
                strQueryArgs[0] = "";
                if (!DoSqlQuery(strBeheer_tabel, strQueryArgs))
                {
                    return;
                }
            }
            else
            {
                // strQueryArgs[0] = "WHERE ElemTabn = " + strTabel_nr;
                strQueryArgs[0] = "AND ElemTabn = " + strTabel_nr;
                if (!DoSqlQuery(strBeheer_tabel, strQueryArgs))
                {
                    return;
                }
            }             
        }

        public Boolean DoSqlQuery(string strBeheer_tabel, string[] strValue)
        {
            DoSql mysql = new DoSql();
            mysql.vul_dit_datagrid = this.dgView;

            switch (strBeheer_tabel)
            {
                 case "FUNCTIE":
                    {
                        mysql.DoQuery("SELECT   FuncText, FuncProg, FuncParm, FuncFuns " +
                                      "FROM     DashFunc " +
                                      "ORDER BY FuncText");
                        dgView.Columns[0].Width = 215;
                        dgView.Columns[1].Width = 215;
                        dgView.Columns[2].Width = 215;
                        dgView.Columns[3].Width = 90;
                        dgView.Columns[0].HeaderText = "Functie omschrijving";
                        dgView.Columns[1].HeaderText = "Programma";
                        dgView.Columns[2].HeaderText = "Parameter(s)";
                        dgView.Columns[3].HeaderText = "Int/Ext";                      
                        break;
                    }

                case "GEBRUIKER":
                    {
                        mysql.DoQuery("SELECT UserVolg, UserCode, "+
                                             "UserNaam, UserUgro, UserPass " +
                                      "FROM DashUser    " +
                                      "ORDER BY UserVolg");
                        dgView.Columns[0].Width = 75;
                        dgView.Columns[1].Width = 150;
                        dgView.Columns[2].Width = 300;
                        dgView.Columns[3].Width = 300;
                        dgView.Columns[4].Width = 0; //150;
                        dgView.Columns[0].HeaderText = "Volgnr";
                        dgView.Columns[1].HeaderText = "Code";
                        dgView.Columns[2].HeaderText = "Naam";
                        dgView.Columns[3].HeaderText = "Groep";
                        dgView.Columns[4].HeaderText = "Password";
                        dgView.Columns[4].Visible = false;
                        break;
                    }

                case "GROEP":
                    {
                        mysql.DoQuery("SELECT   UgroCode, UgroNaam " +
                                      "FROM     DashUgro " +
                                      "ORDER BY UgroCode");
                        dgView.Columns[0].Width = 150;
                        dgView.Columns[1].Width = 300;
                        dgView.Columns[0].HeaderText = "Code";
                        dgView.Columns[1].HeaderText = "Omschrijving";
                        break;
                    }

                case "SUBSYS":
                    {
                        mysql.DoQuery("SELECT SubsNaam, SubsOmsc " +
                                      "FROM DashSubs " +
                                      "ORDER BY SubsNaam");
                        dgView.Columns[0].Width = 300;
                        dgView.Columns[1].Width = 300;
                        dgView.Columns[0].HeaderText = "Subsysteem";
                        dgView.Columns[1].HeaderText = "Omschrijving";
                        break;
                    }
                case "TABELLEN":
                    {
                        mysql.DoQuery("SELECT TablTabn, TablOmsc, TablElom, TablO1om, TablO2om " +
                                      "FROM DashTabl " +
                                      "ORDER BY TablTabn");
                        dgView.Columns[0].Width = 75;
                        dgView.Columns[1].Width = 400;
                        dgView.Columns[2].Width = 200;
                        dgView.Columns[3].Width = 200;
                        dgView.Columns[4].Width = 200;
                        dgView.Columns[0].HeaderText = "Tabelnr";
                        dgView.Columns[1].HeaderText = "Omschrijving";
                        dgView.Columns[2].HeaderText = "Beschrijving element";
                        dgView.Columns[3].HeaderText = "Beschrijving Oms1";
                        dgView.Columns[4].HeaderText = "Beschrijving Oms2";
                        break;
                    }
                case "ELEMENTEN":
                    {
                        mysql.DoQuery("SELECT A.ElemTabn, B.TablOmsc, A.ElemElem, A.ElemOms1, " +
                                      "A.ElemOms2 " +
                                      "FROM   DashElem A, DashTabl B " +
                                      "WHERE  B.TablTabn = A.ElemTabn "+
                                      strValue[0].ToString() + 
                                      " "+ 
                                      "ORDER BY ElemTabn, ElemElem");
                        
                        dgView.Columns[0].Width = 60;
                        dgView.Columns[1].Width = 150;
                        dgView.Columns[2].Width = 100;
                        dgView.Columns[3].Width = 300;
                        dgView.Columns[4].Width = 300;
                        dgView.Columns[0].HeaderText = "Tabelnr";
                        dgView.Columns[1].HeaderText = "Tabelnaam";
                        dgView.Columns[2].HeaderText = "Element";
                        dgView.Columns[3].HeaderText = "Element-Omschrijving 1";
                        dgView.Columns[4].HeaderText = "Element-Omschrijving 2";
                        break;
                    }
                case "SCRIPTS":
                    {
                        mysql.DoQuery("SELECT A.ElemTabn, B.TablOmsc, A.ElemElem, A.ElemOms1, " +
                                      "A.ElemOms2 " +
                                      "FROM   DashElem A, DashTabl B " +
                                      "WHERE  B.TablTabn = A.ElemTabn " +
                                      strValue[0].ToString() +
                                      " " +
                                      "ORDER BY ElemTabn, ElemElem");

                        dgView.Columns[0].Width = 60;
                        dgView.Columns[1].Width = 150;
                        dgView.Columns[2].Width = 100;
                        dgView.Columns[3].Width = 300;
                        dgView.Columns[4].Width = 300;
                        dgView.Columns[0].HeaderText = "Tabelnr";
                        dgView.Columns[1].HeaderText = "Tabelnaam";
                        dgView.Columns[2].HeaderText = "Key";
                        dgView.Columns[3].HeaderText = "Omschrijving";
                        dgView.Columns[4].HeaderText = "Server:Path&Command";
                        break;
                    }

                default:
                    {
                        clDashFunction.Melding("Foute parameter (" +
                                                strBeheer_tabel +
                                               ") in DoSqlQuery", 1, "E");
                        break;
                    }
            }

            if (dgView.Columns.Count > 0 )
            {
                // Datagrid en form resizen naar aantal en breedte van kolommen
                dgView.Width = 0;
                for (int i = 0; i < dgView.Columns.Count; i++)
                {
                    dgView.Width = dgView.Width + dgView.Columns[i].Width;

                }
                // dgView.Width         = dgView.Width + 10;
                this.Width           = dgView.Width + 60;
                grpMain.Width        = this.Width   - 30;
                cmdNieuw.Enabled     = true;
                if (dgView.RowCount > 0)
                {
                    cmdWijzig.Enabled    = true;
                    cmdVerwijder.Enabled = true;
                }
                else
                {
                    cmdWijzig.Enabled    = false;
                    cmdVerwijder.Enabled = false;
                }
                  
                this.CenterToParent();
                return true;
            }
            else
            {
                cmdNieuw.Enabled     = false;
                cmdWijzig.Enabled    = false;
                cmdVerwijder.Enabled = false;
                return false;
            }
        }

        private void cmdSluiten_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgView_RowStateChanged(Object sender, DataGridViewRowStateChangedEventArgs e)
        {
            System.Text.StringBuilder messageBoxCS = new System.Text.StringBuilder();
            messageBoxCS.AppendFormat("{0} = {1}", "Row", e.Row);
            messageBoxCS.AppendLine();
            messageBoxCS.AppendFormat("{0} = {1}", "StateChanged", e.StateChanged);
            messageBoxCS.AppendLine();
            MessageBox.Show(messageBoxCS.ToString(), "RowStateChanged Event");
        }

        private void cmdNieuw_Click(object sender, EventArgs e)
        {   
            frmDashMaintD DashMaintD         = new frmDashMaintD();
            DashMaintD.arr_DetailData        = new ArrayList();
            DashMaintD.strFunctie            = "NIEUW";
            DashMaintD.strBeheer_tabel       = strBeheer_tabel;
            DashMaintD.strUserCode           = strUserCode;
            DashMaintD.strSupplemental_Title = this.strSupplemental_Title;

            DashMaintD.ShowDialog();
            
            // Tabel opnieuw vullen....
            DoSqlQuery(strBeheer_tabel, strQueryArgs);
            
            // Positioneren op nieuwe waarde...
            if (DashMaintD.arr_DetailData.Count>0)
            {
                switch (strBeheer_tabel)
                {
                    case "ELEMENTEN":
                        dgView_position_new(0, DashMaintD.arr_DetailData[0].ToString(), 
                                            2, DashMaintD.arr_DetailData[1].ToString());   
                        break;
                    case "FUNCTIE":
                        dgView_position_new(1, DashMaintD.arr_DetailData[0].ToString(), 
                                            2, DashMaintD.arr_DetailData[1].ToString());
                        break;                   
                    case "GEBRUIKER":
                        dgView_position_new(1, DashMaintD.arr_DetailData[0].ToString());                        
                        break;
                    case "GROEP":
                        dgView_position_new(0, DashMaintD.arr_DetailData[0].ToString());           
                        break;
                    case "SUBSYS":
                        dgView_position_new(0, DashMaintD.arr_DetailData[0].ToString());      
                        break;
                    case "TABELLEN":
                        dgView_position_new(0, DashMaintD.arr_DetailData[0].ToString());   
                        break;
                    default:
                        break;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            


                }
            }
        }        

        private void cmdWijzig_Click(object sender, EventArgs e)
        {
            int intSelected_row_save         = dgView.SelectedRows[0].Index;
            frmDashMaintD DashMaintD         = new frmDashMaintD();
            DashMaintD.strFunctie            = "WIJZIG";
            DashMaintD.strBeheer_tabel       = strBeheer_tabel;
            DashMaintD.strUserCode           = strUserCode;
            DashMaintD.strSupplemental_Title = this.strSupplemental_Title;
            
            this.arr_DetailData = new ArrayList();

            // ******************************************************************************
            // Tabel data opslaan in array, en in volgend form weer terugplaatsen
            // Voor alle functies behalve CONNECTIES kunnen alle datagridwaarden worden
            // gebruikt..
            // ******************************************************************************
            if (strBeheer_tabel != "CONNECTIES")
            {
                for (int i = 0; i < dgView.Columns.Count; i++)
                {
                    arr_DetailData.Add(dgView[i, dgView.SelectedRows[0].Index].Value);
                }
            }

            // ******************************************************************************
            // Tabel data opslaan in array, en in volgend form weer terugplaatsen
            // Voor kolommen 2 (userid)  en 3 (password) geldt een uitzondering: 
            // deze worden gevuld vanuit de (eerder gevulde) arrays alUserid en alPassword
            // Deze truuk wordt uitgehaald omdat deze waarden als * worden weergegeven maar
            // de 'echte' waarden wel moeten worden doorgegeven naar het volgende form en 
            // dus vervolgens naar SQL
            DashMaintD.arr_DetailData = this.arr_DetailData;
            DashMaintD.ShowDialog();

            DoSqlQuery(strBeheer_tabel, strQueryArgs);

            // Terugkeren naar de laatst geselecteerde row...
            dgView.Rows[intSelected_row_save].Selected  = true;
            dgView.FirstDisplayedScrollingRowIndex      = intSelected_row_save;
        }

        private void cmdVerwijder_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            if (clDashFunction.Melding("Weet u zeker dat het item uit tabel " + strBeheer_tabel.ToLower() + " moet worden verwijderd ?", 4, "Q") == DialogResult.Yes)
            {
                if (verwijderen())
                {
                    dgView.Rows.RemoveAt(dgView.SelectedRows[0].Index);
                }
            }
            this.Cursor = Cursors.Default;
        }

        private Boolean verwijderen( )
        {
            int []  intAantal_verwijderd = new int [10];
            Boolean bReturn = true;
            switch (strBeheer_tabel)
            {
                    case "FUNCTIE":
                    {
                          DoSql mysql = new DoSql();
                          // Alle koppelingen GebruikersGroep / Subsysteem / Functie verwijderen.
                          mysql.DoUpdate("DELETE FROM DashGsfu " +
                                         "WHERE GsFuFunc = '" + dgView[1, dgView.SelectedRows[0].Index].Value.ToString() + "' " +
                                         "AND   GsFuParm = '" + dgView[2, dgView.SelectedRows[0].Index].Value.ToString() + "'");
                          intAantal_verwijderd[0] = mysql.affected_rows;

                          // Verwijder functie zelf..
                          mysql.DoUpdate("DELETE FROM DashFunc " +
                                         "WHERE FuncProg = '" + dgView[1, dgView.SelectedRows[0].Index].Value.ToString() + "'");
                          intAantal_verwijderd[1] = mysql.affected_rows;
                          break;
                    }
                    case "GROEP":
                    {
                        DoSql mysql = new DoSql();
                        // Alle koppelingen GebruikersGroep / Subsysteem / Functie verwijderen.
                        mysql.DoUpdate("DELETE FROM DashGsfu " +
                                       "WHERE GsFuUgro = '" + dgView[0, dgView.SelectedRows[0].Index].Value.ToString() + "'");
                        intAantal_verwijderd[0] = mysql.affected_rows;

                        // Alle koppelingen Groep / Subsysteem verwijderen.
                        mysql.DoUpdate("DELETE FROM DashUgss " +
                                       "WHERE UgssUgro = '" + dgView[0, dgView.SelectedRows[0].Index].Value.ToString() + "'");
                        intAantal_verwijderd[1] = mysql.affected_rows;
                        
                        // Alle koppelingen Groep / Unix connecties verwijderen.
                        mysql.DoUpdate("DELETE FROM DashUgco " +
                                       "WHERE UgcoUgro = '" + dgView[0, dgView.SelectedRows[0].Index].Value.ToString() + "'");
                        intAantal_verwijderd[2] = mysql.affected_rows;

                        // Groepcode van gebruikers resetten
                        mysql.DoUpdate("UPDATE DashUser " +
                                       "SET    UserUgro = '' " +
                                       "WHERE  UserUgro = '" + dgView[0, dgView.SelectedRows[0].Index].Value.ToString() + "'");
                        intAantal_verwijderd[3] = mysql.affected_rows;
                
                        // Groepcode zelf verwijderen
                        mysql.DoUpdate("DELETE FROM DashUgro " +
                                       "WHERE UgroCode = '" + dgView[0, dgView.SelectedRows[0].Index].Value.ToString() + "'");
                        intAantal_verwijderd[4] = mysql.affected_rows;
                        break;
                    }
                    case "GEBRUIKER":
                    {
                        DoSql mysql = new DoSql();
                        mysql.DoUpdate("DELETE FROM DashUser " +
                                       "WHERE UserVolg = " + dgView[0, dgView.SelectedRows[0].Index].Value.ToString());
                        break;
                    }
                    case "SUBSYS":
                    {
                        DoSql mysql = new DoSql();
                        // Alle koppelingen GebruikersGroep / Subsysteem / Functie verwijderen.
                        mysql.DoUpdate("DELETE FROM DashGsfu " +
                                       "WHERE GsFuSubs = '" + dgView[0, dgView.SelectedRows[0].Index].Value.ToString() + "'");
                        intAantal_verwijderd[0] = mysql.affected_rows;
                        
                        // Alle koppelingen Subsysteem / Functie verwijderen.
                        mysql.DoUpdate("DELETE FROM DashUgss " +
                                       "WHERE UgssSubs = '" + dgView[0, dgView.SelectedRows[0].Index].Value.ToString() + "'");
                        intAantal_verwijderd[1] = mysql.affected_rows;
                        
                        // Subsysteem zelf verwijderen
                        mysql.DoUpdate("DELETE FROM DashSubs " +
                                       "WHERE SubsNaam = '" + dgView[0, dgView.SelectedRows[0].Index].Value.ToString() + "'");
                        intAantal_verwijderd[2] = mysql.affected_rows;
                        break;
                    }
                    case "TABELLEN":
                    {
                        DoSql mysql = new DoSql();
                        mysql.vul_deze_string = "";
                        mysql.DoQuery("SELECT DISTINCT 1 " +
                                      "FROM DashElem " +
                                      "WHERE ElemTabn = " + dgView[0, dgView.SelectedRows[0].Index].Value.ToString());
                        if (mysql.affected_rows > 0)
                        {
                            clDashFunction.Melding("Verwijderen niet mogelijk, er zijn nog " + "\n" +
                                                   "onderliggende tabelelementen ", 1, "I");
                            bReturn = false;
                            return bReturn;
                        }
                        mysql.DoUpdate("DELETE FROM DashTabl " +
                                       "WHERE TablTabn = " + dgView[0, dgView.SelectedRows[0].Index].Value.ToString());
                        break;
                    }
                    case "ELEMENTEN":
                    case "SCRIPTS":
                    {
                        DoSql mysql = new DoSql();
                        mysql.DoUpdate("DELETE FROM DashElem " +
                                       "WHERE ElemTabn = " + dgView[0, dgView.SelectedRows[0].Index].Value.ToString() +
                                       " " +
                                       "AND   ElemElem = '" + dgView[2, dgView.SelectedRows[0].Index].Value.ToString() + "'" +
                                       " " +
                                       "AND   ElemOms1 = '" + dgView[3, dgView.SelectedRows[0].Index].Value.ToString() + "'");
                        break;
                    }
                    default:
                    {
                        clDashFunction.Melding("Onbekende beheertabel: " + strBeheer_tabel, 1, "E");
                        break;
                    }
            }
            return bReturn;
        }

        private void dgView_DoubleClick(object sender, EventArgs e)
        {
            cmdWijzig_Click(sender, e);
        }

        private void dgView_position_new(int intPos_col1, string strPos_value1)
        {
            for (int inti = 0; inti < dgView.Rows.Count; inti++)
            {
                if (dgView[intPos_col1, inti].Value.ToString() == strPos_value1)
                {
                    dgView[0, inti].Selected = true;
                    break;
                }
            }
        }
        private void dgView_position_new(int intPos_col1, string strPos_value1, int intPos_col2, string strPos_value2)
        {
            for (int inti = 0; inti < dgView.Rows.Count; inti++)
            {
                if (dgView[intPos_col1, inti].Value.ToString() == strPos_value1 &&
                    dgView[intPos_col2, inti].Value.ToString() == strPos_value2)
                {
                    dgView[0, inti].Selected = true;
                    break;
                }
            }
        }
     }
}