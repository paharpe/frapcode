﻿using System;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

namespace dbDashboard
{
    public partial class lblMaxDate : Label  
    {
        const string _strMax = "Op: ";
        private DateTime _dtMax;
        private Boolean _bChanged;

        public lblMaxDate()
        {
            Label lblMaxDate = new Label();
            this.Text = _strMax + "2012-01-01";          
        }

        public DateTime MaxDate
        {
            get { return this._dtMax; }
            set { this._dtMax = value; }
        }

        public Boolean bChanged
        {
            get { return this._bChanged; }
            set { this._bChanged = value; }
        }

        public void SetMax(DateTime dtMax)
        {           
                this.MaxDate = dtMax;
                bChanged = true;
                this.Text = _strMax + MaxDate.ToString();            
        }

     }
}
