namespace dbDashboard
{
    partial class frmDashMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDashMenu));
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.gebruikersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groepenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.subsystemenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.funcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tvMenu = new System.Windows.Forms.TreeView();
            this.flwPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.grbConnect.SuspendLayout();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmdAfsluiten
            // 
            this.cmdAfsluiten.Location = new System.Drawing.Point(761, 670);
            this.cmdAfsluiten.Size = new System.Drawing.Size(12, 10);
            this.cmdAfsluiten.Visible = false;
            // 
            // grbConnect
            // 
            this.grbConnect.Location = new System.Drawing.Point(779, 670);
            this.grbConnect.Size = new System.Drawing.Size(68, 10);
            this.grbConnect.Visible = false;
            // 
            // lblHostName
            // 
            this.lblHostName.Location = new System.Drawing.Point(693, 635);
            this.lblHostName.Size = new System.Drawing.Size(145, 13);
            this.lblHostName.Text = "KPNNL\\WLD4BED923B63C";
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "Dashboard.bmp");
            this.imageList1.Images.SetKeyName(1, "Dashboard_blue.bmp");
            // 
            // gebruikersToolStripMenuItem
            // 
            this.gebruikersToolStripMenuItem.Name = "gebruikersToolStripMenuItem";
            this.gebruikersToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.gebruikersToolStripMenuItem.Text = "Gebruikers";
            // 
            // groepenToolStripMenuItem
            // 
            this.groepenToolStripMenuItem.Name = "groepenToolStripMenuItem";
            this.groepenToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.groepenToolStripMenuItem.Text = "Groepen";
            // 
            // subsystemenToolStripMenuItem
            // 
            this.subsystemenToolStripMenuItem.Name = "subsystemenToolStripMenuItem";
            this.subsystemenToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.subsystemenToolStripMenuItem.Text = "Subsystemen";
            // 
            // funcToolStripMenuItem
            // 
            this.funcToolStripMenuItem.Name = "funcToolStripMenuItem";
            this.funcToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.funcToolStripMenuItem.Text = "Functies";
            // 
            // tvMenu
            // 
            this.tvMenu.BackColor = System.Drawing.Color.White;
            this.tvMenu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tvMenu.ImageIndex = 0;
            this.tvMenu.ImageList = this.imageList1;
            this.tvMenu.Location = new System.Drawing.Point(0, 0);
            this.tvMenu.Name = "tvMenu";
            this.tvMenu.SelectedImageIndex = 0;
            this.tvMenu.Size = new System.Drawing.Size(234, 629);
            this.tvMenu.TabIndex = 8;
            this.tvMenu.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.tvMenu_AfterSelect);
            // 
            // flwPanel
            // 
            this.flwPanel.AutoScroll = true;
            this.flwPanel.BackColor = System.Drawing.Color.White;
            this.flwPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flwPanel.CausesValidation = false;
            this.flwPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flwPanel.Location = new System.Drawing.Point(0, 0);
            this.flwPanel.Margin = new System.Windows.Forms.Padding(3, 10, 3, 1);
            this.flwPanel.Name = "flwPanel";
            this.flwPanel.Padding = new System.Windows.Forms.Padding(0, 20, 0, 0);
            this.flwPanel.Size = new System.Drawing.Size(596, 629);
            this.flwPanel.TabIndex = 9;
            // 
            // splitContainer1
            // 
            this.splitContainer1.BackColor = System.Drawing.SystemColors.Control;
            this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer1.Location = new System.Drawing.Point(1, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.tvMenu);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.flwPanel);
            this.splitContainer1.Size = new System.Drawing.Size(835, 631);
            this.splitContainer1.SplitterDistance = 236;
            this.splitContainer1.SplitterWidth = 1;
            this.splitContainer1.TabIndex = 22;
            // 
            // frmDashMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(836, 648);
            this.Controls.Add(this.splitContainer1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Name = "frmDashMenu";
            this.Text = "Digipoort Dashboard";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmDashMenu_FormClosing);
            this.Load += new System.EventHandler(this.frmDashMenu_Load);
            this.Controls.SetChildIndex(this.lblHostName, 0);
            this.Controls.SetChildIndex(this.splitContainer1, 0);
            this.Controls.SetChildIndex(this.cmdAfsluiten, 0);
            this.Controls.SetChildIndex(this.grbConnect, 0);
            this.grbConnect.ResumeLayout(false);
            this.grbConnect.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.ToolStripMenuItem gebruikersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem groepenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem subsystemenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem funcToolStripMenuItem;
        private System.Windows.Forms.TreeView tvMenu;
        private System.Windows.Forms.FlowLayoutPanel flwPanel;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.SplitContainer splitContainer1;
    }
}

