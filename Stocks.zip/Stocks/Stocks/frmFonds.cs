﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
using System.IO;

namespace Stocks
{
    public partial class frmFonds : Form
    {
        string strFonds;
        string strIndex;
              
        public string strDatabase;


        const string strNothing = "Nothing to display";

        public frmFonds()
        {
            InitializeComponent();
        }

        private void frmFonds_Load(object sender, EventArgs e)
        {
            frm_init();
        }

        private void cmdCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        private void dgFonds_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            load_fields(e.RowIndex);
            get_details(strFonds, strIndex);
        }

        private void cmdDetails_Click(object sender, EventArgs e)
        {
            get_details(strFonds, strIndex);
        }

        private Boolean prepare_database()
        {
            Boolean bReturn = false; 
           
            strDatabase = clDashFunction.get_database(Stocks.Properties.Settings.Default.Database);

            if (strDatabase != "-1")
            {              
                Stocks.Properties.Settings.Default.Database = strDatabase;
                Stocks.Properties.Settings.Default.Save();
                bReturn = true;
            }

            return bReturn;
        }

        private void frm_init()
        {

            if ( !prepare_database() )
            {
                clDashFunction.Melding("No database has been found or opened, application will end now ", 1, "I");
                this.Close();
            }


            // (Experimenteel) gebruik van application properties met updatemogelijkheid....
            txtProperty.Text = strDatabase;
            cmdPropdate.Enabled = false;

            // Select entry[0]. This should be the one where the text contains "All"
            cmbSelect.SelectedIndex = 1;
            
            Hide_pct();
            lbMin.Enabled = false;
            lbMax.Enabled = false;
            cbHighLowShow.Visible = false;

            lblToday.Text = System.DateTime.Now.ToShortDateString();

            grbAnalyse.Visible = false;

            // grbdgFonds.Rows[0].Selected = false;      
     

        }


        /// <summary>
        /// Initialize form controls
        /// </summary>
        private void load_funds(Boolean bGot)
        {
            // bGot = false; // Got thise stocks myself only ?

            // Reset screen vars
            dgFonds.DataSource = null;
            dgKoers.DataSource = null;
            lblKoers_count.Text = "";
           
            txtDate_high.Text = "";
            txtDate_low.Text = "";
            txtDate_now.Text = "";
            
            txtShortMax.Text = "";
            txtShortRecent.Text = "";
           
            txtKoers_high.Text = "";
            txtKoers_low.Text = "";
            txtKoers_now.Text = "";


            DoSql mysql = new DoSql();
            mysql.strAccess_Database = strDatabase;
            mysql.vul_dit_datagrid = dgFonds;

            if (bGot)
            {
                
                // Only the ones I have got myself
                mysql.DoQuery("SELECT FondsFonds, FondsIndex "
                            + "FROM KoursFonds "
                            + "ORDER BY FondsFonds");

              

               // clDashFunction.Melding(mysql.affected_rows.ToString());

            }
            else
            {
                    // All
                    mysql.DoQuery("SELECT DISTINCT(KoursFonds),KoursIndex "
                                + "FROM KoursKours ");               
            }

            if ( dgFonds.Columns.Count < 1)
            {
                clDashFunction.Melding("Error during populating dgFonds !", 1, "E");
                return;
            }
            dgFonds.AllowUserToResizeRows = false;
            dgFonds.Columns[0].Width = 200;
            dgFonds.Columns[1].Width = 200;
            dgFonds.Columns[0].HeaderText = "Fonds";
            dgFonds.Columns[1].HeaderText = "Index";
            lblFonds_count_val.Text = " " + mysql.affected_rows; // + " record(s)";

            lblFonds_Amsterdam_lbl.Tag = 0;
            lblFonds_AMX_lbl.Tag = 0;
            lblFonds_AScX_lbl.Tag = 0;
            lblFonds_Lokaal_lbl.Tag = 0;

            int intIRow = 0;
            while (intIRow < dgFonds.Rows.Count)
            {

                // Hier had ik vantevoren een mooie telling willen doen.. maar helaas (nog)

                // Ook al omdat strIndex geen teller maar de Beursindex AEX enzo voorstelt
                // dgFonds.Rows[intIRow].Selected = true;
                // get_max_koers(dgFonds[0, intIRow].Value.ToString(), dgFonds[1, intIRow].Value.ToString());
                // dgFonds.Rows[intIRow].Selected = false;

                string [] strarIndex;
                strarIndex=dgFonds[1,intIRow].Value.ToString().ToUpper().Trim().Split(Convert.ToChar("."));
                if (strarIndex.Length == 2)
                    if (lblFonds_Amsterdam_lbl.Text.ToUpper().Trim().Replace(":","") == strarIndex[0])
                    {
                        lblFonds_Amsterdam_lbl.Tag = (Convert.ToInt16(lblFonds_Amsterdam_lbl.Tag) + 1).ToString();
                    }
                    else if (lblFonds_AMX_lbl.Text.ToUpper().Trim().Replace(":", "") == strarIndex[0])
                    {
                        lblFonds_AMX_lbl.Tag = (Convert.ToInt16(lblFonds_AMX_lbl.Tag) + 1).ToString();
                    }
                    else if (lblFonds_AScX_lbl.Text.ToUpper().Trim().Replace(":", "") == strarIndex[0])
                    {
                        lblFonds_AScX_lbl.Tag = (Convert.ToInt16(lblFonds_AScX_lbl.Tag) + 1).ToString();
                    }
                    else if (lblFonds_Lokaal_lbl.Text.ToUpper().Trim().Replace(":", "") == strarIndex[0])
                    {
                        lblFonds_Lokaal_lbl.Tag = (Convert.ToInt16(lblFonds_Lokaal_lbl.Tag) + 1).ToString();
                    }
                    else
                    {
                        clDashFunction.Melding( "Vreemde soort"+ strarIndex[0]);
                    }
                intIRow++;
            }

            // Totalen per indexsoort neerzetten
            lblFonds_Amsterdam_val.Text = lblFonds_Amsterdam_lbl.Tag.ToString();
            lblFonds_AMX_val.Text = lblFonds_AMX_lbl.Tag.ToString();
            lblFonds_AScX_val.Text = lblFonds_AScX_lbl.Tag.ToString();
            lblFonds_Lokaal_val.Text = lblFonds_Lokaal_lbl.Tag.ToString();
            
        }

        private void load_fields(int intRowIndex)
        {
            strFonds = dgFonds[0, intRowIndex].Value.ToString();
            strIndex = dgFonds[1, intRowIndex].Value.ToString();
            // strMdatum = dgFonds[2, intRowIndex].Value.ToString();
            // strMtijd = dgFonds[3, intRowIndex].Value.ToString();
        }

        private void get_details(string strFonds, string strIndex)
        {
            // -1: Change index to trigger actions on related fields 
            cmbChoose.SelectedIndex = -1;
           
            cmbChoose.Items.Clear();

            DoSql mySql = new DoSql();
            mySql.strAccess_Database = strDatabase;
            mySql.vul_dit_datagrid = dgKoers;

            // Query1: Probeer direct KoshShFo ( Short fondsnaam ) op te halen in KoursKosh...
            mySql.DoQuery("SELECT KoursKoers, KoursMdatum, KoursMtijd, KoshShFo " +
                         "FROM KoursKours, KoursKosh " +
                         "WHERE KoursFonds   = '" + strFonds + "' " +
                         "AND   KoursIndex   = '" + strIndex + "' " +
                         "AND   KoshKofo     = KoursFonds " +
                         "ORDER BY KoursMdatum, KoursMtijd" );
            if ( mySql.affected_rows == 0)
            {
                // Query2: Als er geen Short-data is voor een bepaald fonds, dan levert Query1 0 rijen op. In dat
                //         geval doen we een 2e query om alleen over de koersgegevens te beschikken
                mySql.DoQuery("SELECT KoursKoers, KoursMdatum, KoursMtijd " +
                        "FROM KoursKours " +
                        "WHERE KoursFonds   = '" + strFonds + "' " +
                        "AND   KoursIndex   = '" + strIndex + "' " +
                        "ORDER BY KoursMdatum, KoursMtijd");
            }
            dgKoers.AllowUserToResizeRows = false;

            DataGridViewCellStyle dgcsKoers = new DataGridViewCellStyle();
            dgcsKoers.BackColor = Color.White;
            dgcsKoers.Format = "c";
            dgKoers.Columns[0].DefaultCellStyle = dgcsKoers;

            dgKoers.Columns[0].Width = 100;
            dgKoers.Columns[1].Width = 100;
            dgKoers.Columns[2].Width = 100;
            dgKoers.Columns[0].HeaderText = "Koers";
            dgKoers.Columns[1].HeaderText = "Mutatiedatum";
            dgKoers.Columns[2].HeaderText = "Mutatietijd";
            lblKoers_count.Text = " " + mySql.affected_rows + " record(s)";

            // Determine MIN, MAX and CURRENT values
            int intKoers_index = 0;
            double intKoers_min = 9999999;
            double intKoers_max = 0;
            double intKoers_now = 0;

            string strKoers_min = "20150101";
            string strKoers_max = "20150101";

            string strKoers_now_date = "20150101";
            string strKoers_now_time = "00000000";
            string strKoers_now_datetime = strKoers_now_date + strKoers_now_time;
            string strKoers_now_date_seperated = clDashFunction.convert_date(strKoers_now_date);
           
            string strKoers_wrk_date = "20150101";
            string strKoers_wrk_time = "00000000";
            string strKoers_wrk_datetime = strKoers_wrk_date + strKoers_wrk_time;


            if (dgKoers.Rows.Count > 0)
            {
                // Alleen als Query1 is goedgegaan ( we hebben minimaal een entry in KoursShort gevonden ), dan
                // kijken we éénmalig ( bij index 0 ) even hoe de situatie in KoursShort is....
                if (dgKoers.ColumnCount > 3)
                {
                    get_short(dgKoers[3, intKoers_index].Value.ToString());
                }
                else
                {
                    txtShortRecent.Text = "No data";
                    txtShortMax.Text = "No data";
                }

                while (intKoers_index < dgKoers.Rows.Count)
                {
                    if (Convert.ToDouble(dgKoers[0, intKoers_index].Value) > intKoers_max)
                    {
                        intKoers_max = Convert.ToDouble(dgKoers[0, intKoers_index].Value);
                        strKoers_max = dgKoers[1, intKoers_index].Value.ToString();
                        //blah strKoers_max = "2015-12-17 10:12:33";
                       // strKoers_max = "blah";
                    }
                    if (Convert.ToDouble(dgKoers[0, intKoers_index].Value) < intKoers_min)
                    {
                        intKoers_min = Convert.ToDouble(dgKoers[0, intKoers_index].Value);
                        strKoers_min = dgKoers[1, intKoers_index].Value.ToString();
                    }

                    strKoers_wrk_date = dgKoers[1, intKoers_index].Value.ToString();
                    strKoers_wrk_time = dgKoers[2, intKoers_index].Value.ToString();
                    strKoers_wrk_datetime = strKoers_wrk_date + strKoers_wrk_time;

                    if (Convert.ToInt64(strKoers_wrk_datetime) > Convert.ToInt64(strKoers_now_datetime))
                    {
                        intKoers_now = Convert.ToDouble(dgKoers[0, intKoers_index].Value);

                        // YYYYMMDD
                        strKoers_now_date = strKoers_wrk_date;
                        // from YYYYMMDD to YYYY-MM-DD
                        strKoers_now_date_seperated = clDashFunction.convert_date(strKoers_now_date);

                        strKoers_now_time = strKoers_wrk_time;
                        strKoers_now_datetime = strKoers_now_date + strKoers_now_time;
                    }

                    // Combobox vullen met unieke reeks datums
                    if (cmbChoose.Items.Contains(strKoers_wrk_date))
                    {
                       // clDashFunction.Melding(strKoers_wrk_date + " bestaat al");

                    }
                    else
                    {
                        cmbChoose.Items.Add(strKoers_wrk_date);
                    }

                    intKoers_index++;
                }
            }

            // Highest Koers Today ?
            /*
            if (strKoers_max == strKoers_now_date)
            {
                txtDate_high.ForeColor = Color.Red;
                txtKoers_high.ForeColor = Color.Red;
            }
            else
            {
                txtDate_high.ForeColor = Color.Black;
                txtKoers_high.ForeColor = Color.Black;
            }
            */

            txtDate_high.Text = clDashFunction.convert_date(strKoers_max);
            txtDate_low.Text = clDashFunction.convert_date(strKoers_min);
            txtDate_now.Text = clDashFunction.convert_date(strKoers_now_date);

            txtDiff_low.Text = (DateTime.Parse(strKoers_now_date_seperated) - DateTime.Parse(clDashFunction.convert_date(strKoers_min))).Days.ToString();
            txtDiff_high.Text = (DateTime.Parse(strKoers_now_date_seperated) - DateTime.Parse(clDashFunction.convert_date(strKoers_max))).Days.ToString();
            //blah txtDiff_high.Text = (DateTime.Parse("2015-12-16 09:33:22") - DateTime.Parse(clDashFunction.convert_date(strKoers_max))).Days.ToString();


            txtKoers_high.Text = intKoers_max.ToString("##0.#0");
            txtKoers_low.Text = intKoers_min.ToString("##0.#0");
            txtKoers_now.Text = intKoers_now.ToString("##0.#0");


            lblKoers.Text = strFonds;
            grbDetail.Text = "Detailinfo " + strFonds;           
            
        }

        private void get_short(string strShortFonds)
        {
            DoSql mySql = new DoSql();
            mySql.strAccess_Database = strDatabase;
            mySql.vul_deze_text1_array[1] = "FTA";
            mySql.DoQuery("SELECT TOP 1 ShortShort, ShortDatum, ShortCrease " +
                          "FROM KoursShort " +
                          "WHERE ShortFonds = '" + strShortFonds + "' " +
                          "ORDER BY ShortShort DESC ");
            if ( mySql.affected_rows > 0)
            {
                int intLastRow=mySql.affected_rows;
                txtShortMax.Text = mySql.vul_deze_text2_array[intLastRow].ToString() + ": " + mySql.vul_deze_text1_array[intLastRow].ToString();
            }
           
            mySql =  new DoSql();
            mySql.strAccess_Database = strDatabase;
            mySql.vul_deze_text1_array[1] = "FTA";
            mySql.DoQuery("SELECT TOP 1 ShortShort, ShortDatum, ShortCrease " +
                          "FROM KoursShort " +
                          "WHERE ShortFonds = '" + strShortFonds + "' "+
                          "ORDER BY ShortDatum DESC " );
            if (mySql.affected_rows > 0)
            {
                int intLastRow = mySql.affected_rows;
                txtShortRecent.Text = mySql.vul_deze_text2_array[intLastRow].ToString() + ": " + mySql.vul_deze_text1_array[intLastRow].ToString();
            }
        }

        private void get_max_koers(int intDgRow, string strFonds, string strIndex, string strNow)
        {          
            DoSql mySql = new DoSql();
            mySql.strAccess_Database = strDatabase;
            mySql.vul_deze_string = "FTS";

            mySql.DoQuery("SELECT DISTINCT(KoursCdatum) & '@' & KoursKoers " +
                          "FROM KoursKours " +
                          "WHERE KoursFonds   = '" + strFonds + "' " +
                          "AND   KoursIndex   = '" + strIndex + "' " +
                          "AND   KoursKoers = ( " +
                          "      SELECT MAX(KoursKoers) " +
                          "      FROM KoursKours " +
                          "      WHERE KoursFonds   = '" + strFonds + "' " +
                          "      AND   KoursIndex   = '" + strIndex + "') ");
            
            //Returned: 20151026@14,56
            if (mySql.affected_rows == 1)
            {
                string [] arMax = mySql.vul_deze_string.Split('@');
                //Returned: [0] 20151026
                //          [1] 14,56
                if (arMax.Length == 2)
                {                    
                    if (arMax[0].ToString() == strNow)
                    {
                        double dblMax = Convert.ToDouble(arMax[1]);
                        lbMax.Items.Add(strFonds + " | " + strIndex);
                        dgFonds[0,intDgRow].ToolTipText = dblMax.ToString("##0.#0");
                        dgFonds[0, intDgRow].Style.BackColor = Color.GreenYellow;
                        dgFonds[1, intDgRow].Style.BackColor = Color.GreenYellow;
                        dgFonds.Rows[intDgRow].Tag = "1";
                    }
                }
            }
        }


        private void get_min_koers(int intDgRow, string strFonds, string strIndex,string strNow)
        {
            DoSql mySql = new DoSql();
            mySql.strAccess_Database = strDatabase;
            mySql.vul_deze_string = "FTS";

            mySql.DoQuery("SELECT DISTINCT(KoursCdatum) & '@' & KoursKoers " +
                          "FROM KoursKours " +
                          "WHERE KoursFonds   = '" + strFonds + "' " +
                          "AND   KoursIndex   = '" + strIndex + "' " +
                          "AND   KoursKoers = ( " +
                          "      SELECT MIN(KoursKoers) " +
                          "      FROM KoursKours " +
                          "      WHERE KoursFonds   = '" + strFonds + "' " +
                          "      AND   KoursIndex   = '" + strIndex + "') ");
           
            //Returned: 20151026@0,04
            if (mySql.affected_rows == 1)
            {
                string[] arMin = mySql.vul_deze_string.Split('@');
                //Returned: [0] 20151026
                //          [1] 0,04
                if (arMin.Length == 2)
                {
                    if (arMin[0].ToString() == strNow)
                    {
                        double dblMin = Convert.ToDouble(arMin[1]);
                        lbMin.Items.Add(strFonds + " | " + strIndex);
                        dgFonds[0, intDgRow].ToolTipText = dblMin.ToString("##0.#0");
                        dgFonds[0, intDgRow].Style.BackColor = Color.OrangeRed; 
                        dgFonds[1, intDgRow].Style.BackColor = Color.OrangeRed;
                        dgFonds.Rows[intDgRow].Tag = "2";
                    }
                }
            }
        }


        private void dgFonds_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            get_details(strFonds, strIndex);
        }

        private void dgFonds_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            get_details(strFonds, strIndex);
        }

       
        private void dgFonds_DoubleClick(object sender, EventArgs e)
        {
            if (cmbSelect.SelectedItem.ToString().ToUpper().Trim().Contains("all".ToUpper().Trim()))
            {
                add_fonds();
            }
            else
            {
                delete_fonds();
            }
        }

        private void delete_fonds()
        {
            DoSql mysql = new DoSql();
            mysql.strAccess_Database = strDatabase;
            mysql.vul_deze_string = "";
            mysql.DoQuery("SELECT 1 "
                        + "FROM KoursFonds "
                        + "WHERE FondsFonds = '" + strFonds + "' "
                        + "AND FondsIndex = '" + strIndex + "'");

            if (mysql.affected_rows > 0)
            {
                if (clDashFunction.Melding("Are you sure you want to delete this fund from the 'my stocks' pool ?", 4, "Q") == DialogResult.Yes)
                {

                    mysql.DoUpdate("DELETE FROM KoursFonds "
                                 + "WHERE FondsFonds = '" + strFonds + "' "
                                 + "AND   FondsIndex = '" + strIndex + "'");


                    // Refresh screen
                    cmbSelect_SelectedIndexChanged(new object(), new EventArgs());                    
                }
            }
        }

        private void add_fonds()
        {
            DoSql mysql = new DoSql();

            mysql.strAccess_Database = strDatabase;
            mysql.vul_deze_string = "";
            mysql.DoQuery("SELECT 1 "
                        + "FROM KoursFonds "
                        + "WHERE FondsFonds = '" + strFonds + "' "
                        + "AND FondsIndex = '" + strIndex + "'");

            if (mysql.affected_rows < 1)
            {
                if (clDashFunction.Melding("Are you sure you want to add this fund to the 'my stocks' pool ?", 4, "Q") == DialogResult.Yes)
                {

                    mysql.DoUpdate("INSERT INTO KoursFonds ("
                        + "FondsFonds, FondsIndex, FondsCdatum, FondsCtijd, FondsMdatum, FondsMtijd ) "
                        + "VALUES ( '" + strFonds + "' "
                        + ", '" + strIndex + "'"
                        + ", '" + clDashFunction.get_mutdatum() + "'"
                        + ", '" + clDashFunction.get_muttijd() + "'"
                        + ", '" + clDashFunction.get_mutdatum() + "'"
                        + ", '" + clDashFunction.get_muttijd() + "' )");

                    clDashFunction.Melding("Added");
                    
                    // dgFonds[0, dgFonds.SelectedRows[0].Index].Style.BackColor = Color.LightGray;

                }
            }
        }

        private void do_bg_koersen()
        {
            int intIRow = 0;
            float flt1Pct = dgFonds.Rows.Count;
            flt1Pct = 101 / flt1Pct;
            float flt100Pct;
            string strNow = System.DateTime.Now.Year.ToString() + System.DateTime.Now.Month.ToString("0#") + System.DateTime.Now.Day.ToString("0#");
            Show_pct();           
            
            while (intIRow < dgFonds.Rows.Count)
            {
                // Back to default color
                dgFonds[0, intIRow].Style.BackColor = Color.White;
                dgFonds[1, intIRow].Style.BackColor = Color.White;
                dgFonds.Rows[intIRow].Tag = "0";

                get_max_koers(intIRow,dgFonds[0, intIRow].Value.ToString(), dgFonds[1, intIRow].Value.ToString(),strNow);

                get_min_koers(intIRow,dgFonds[0, intIRow].Value.ToString(), dgFonds[1, intIRow].Value.ToString(), strNow);
               
                lblMacPerc.Text = dgFonds[0, intIRow].Value.ToString() + " ("+Convert.ToInt16(intIRow * flt1Pct).ToString() + " %)";
               /*
                if ((intIRow * flt1Pct > 60))
                {
                    lblMacPerc.BackColor = Color.Lime;
                }
                */
                flt100Pct = intIRow * flt1Pct;
                pgMax.Value = Convert.ToInt16(flt100Pct);
                lblHigh_val.Text = lbMax.Items.Count.ToString();
                lblLow_val.Text = lbMin.Items.Count.ToString();
                this.Refresh();

                intIRow++;
            }
            
            // ***************************************************************************
            // No rows in Max and/or Min listboxes: insert the "Nothing to display" string
            // ***************************************************************************
            cbHighLowShow.Visible = false;

            if ( lbMax.Items.Count < 1)
            {
                lbMax.Items.Add(strNothing);
                lbMax.Enabled = false;
            }
            else
            {
                lbMax.Enabled = true;
            }

            if (lbMin.Items.Count < 1)
            {
                lbMin.Items.Add(strNothing);
                lbMin.Enabled = false;
            }
            else
            {
                lbMin.Enabled = true;
            }

            if ( lbMin.Items.Count + lbMax.Items.Count > 0 )
            {
                cbHighLowShow.Visible = true;

            }

            // ***************************************************************************
            // Everything completely done: 100%
            // ***************************************************************************
            lblMacPerc.Text = "100 %";
            pgMax.Value = 100;
            
            this.Refresh();
            
            Hide_pct();

        }


        private void doe_bg_koersen()
        {
            int intIRow = 0;
            
            string strNow = System.DateTime.Now.Year.ToString() + System.DateTime.Now.Month.ToString("0#") + System.DateTime.Now.Day.ToString("0#");
            
            while (intIRow < dgFonds.Rows.Count)
            {
                // Back to default color
             //   dgFonds[0, intIRow].Style.BackColor = Color.White;
             //   dgFonds[1, intIRow].Style.BackColor = Color.White;
             //   dgFonds.Rows[intIRow].Tag = "0";

                get_max_koers(intIRow, dgFonds[0, intIRow].Value.ToString(), dgFonds[1, intIRow].Value.ToString(), strNow);

                get_min_koers(intIRow, dgFonds[0, intIRow].Value.ToString(), dgFonds[1, intIRow].Value.ToString(), strNow);

                

                intIRow++;
            }

            // ***************************************************************************
            // No rows in Max and/or Min listboxes: insert the "Nothing to display" string
            // ***************************************************************************
            cbHighLowShow.Visible = false;

            if (lbMax.Items.Count < 1)
            {
                lbMax.Items.Add(strNothing);
                lbMax.Enabled = false;
            }
            else
            {
                lbMax.Enabled = true;
            }

            if (lbMin.Items.Count < 1)
            {
                lbMin.Items.Add(strNothing);
                lbMin.Enabled = false;
            }
            else
            {
                lbMin.Enabled = true;
            }

            if (lbMin.Items.Count + lbMax.Items.Count > 0)
            {
                cbHighLowShow.Visible = true;

            }

            // ***************************************************************************
            // Everything completely done: 100%
            // ***************************************************************************
            lblMacPerc.Text = "100 %";
            pgMax.Value = 100;

            this.Refresh();

            Hide_pct();

        }

        private void cmdHighLowAnalyze_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            
            /* SMS: ASYNC uit
            if (backgroundWorker1.IsBusy != true)
            {
                cmdHighLowAnalyze.Enabled = false;

                lbMax.Items.Clear();
                lbMin.Items.Clear();

                grbAnalyse.Visible = true;
                pgMax.Value = 0;
                pgMax.Visible = true;
                lblMacPerc.Visible = true;
                lblHigh_val.Text = "0";
                lblHigh_val.Visible = true;
                lblHigh_lbl.Visible = true;
                lblLow_val.Text = "0";
                lblLow_val.Visible = true;
                lblLow_lbl.Visible = true;

                backgroundWorker1.RunWorkerAsync();
                cmdHighLowAnalyze.Enabled = true;

                // Experimenteel toneel
                cbHighLowShow.Checked = true;

                this.Refresh();
            }
            this.Cursor = Cursors.Default;
            */



            // ASYNC block weg
            this.Cursor = Cursors.WaitCursor;
                       
            cmdHighLowAnalyze.Enabled = false;
            
            lbMax.Items.Clear();
            lbMin.Items.Clear();
            
            do_bg_koersen();
            
            cmdHighLowAnalyze.Enabled = true;

            // Experimenteel toneel
            cbHighLowShow.Checked = true;

            this.Refresh();

            this.Cursor = Cursors.Default;
            //
        }
        
        private void Hide_pct()
        {
            // grbAnalyse.Visible = false;
            lblMacPerc.Visible = false;
            lblMacPerc.Text = "0 %";
            pgMax.Visible = false;
            pgMax.Value = 0;
            lblHigh_val.Text = "0";
            lblHigh_val.Visible = false;
            lblHigh_lbl.Visible = false;
            lblLow_val.Text = "0";
            lblLow_val.Visible = false;
            lblLow_lbl.Visible = false;
        }

        private void Show_pct()
        {
            grbAnalyse.Visible = true;
            pgMax.Value = 0;
            pgMax.Visible = true;
            lblMacPerc.Visible = true;
            lblHigh_val.Text = "0";
            lblHigh_val.Visible = true;
            lblHigh_lbl.Visible = true;
            lblLow_val.Text = "0";
            lblLow_val.Visible = true;
            lblLow_lbl.Visible = true;
        }

        private void lbMax_Click(object sender, EventArgs e)
        {
            get_peak_detail(lbMax);
        }

        private void lbMin_Click(object sender, EventArgs e)
        {
            get_peak_detail(lbMin);           
        }
               
        private void get_peak_detail(ListBox lbPeak)
        {
            Boolean bFound = false;
            string strFonds = "";
            string strIndex = "";
            string[] arItem;
            
            if (lbPeak.SelectedItem != null)
            {
                if (lbPeak.SelectedItem.ToString() != "")
                {
                    arItem = lbPeak.SelectedItem.ToString().Split('|');
                    if (arItem.Length > 1)
                    {
                        strIndex = lbPeak.SelectedItem.ToString().Split('|')[1].Trim();
                        strFonds = lbPeak.SelectedItem.ToString().Split('|')[0].Trim();
                        
                       // strFonds = "Yatra Capital";
                       // strIndex = "AScX.aspx";                      

                        int intRow = 0;
                        while (intRow < dgFonds.Rows.Count)
                        {
                            if (dgFonds[0, intRow].Value.ToString() == strFonds &&
                                dgFonds[1, intRow].Value.ToString() == strIndex)
                            {
                                dgFonds.Rows[intRow].Selected = true;
                                get_details(strFonds, strIndex);

                                //Position toprow
                                if ((intRow - 4) > dgFonds.Rows.Count)
                                {
                                    dgFonds.FirstDisplayedScrollingRowIndex = intRow - 4;
                                }
                                else
                                {
                                    dgFonds.FirstDisplayedScrollingRowIndex = intRow;
                                }
                                
                                bFound = true;
                                break;
                            }
                            intRow++;
                        }
                    }
                    else
                    {
                        clDashFunction.Melding("I was not able to extract valid 'Fonds' and 'Index' strings out of the listbox item", 1, "I");
                    }

                }
            }
            if (!bFound)
            {
                clDashFunction.Melding("No entry found in 'Fonds' table with values: (" + strFonds + " / " + strIndex + ")");
            }
        }      

        private void cmdPropdate_Click(object sender, EventArgs e)
        {
            Stocks.Properties.Settings.Default.Database = txtProperty.Text;
            Stocks.Properties.Settings.Default.Save();
            cmdPropdate.Enabled = false;
        }

        private void txtProperty_TextChanged(object sender, EventArgs e)
        {
            cmdPropdate.Enabled = true;
        }

        private void lbMax_SelectedIndexChanged(object sender, EventArgs e)
        {
            get_peak_detail(lbMax);
        }

        private void cbHighLowShow_CheckedChanged(object sender, EventArgs e)
        {
            int intIrow = 0;
            int intFirstVisibleRowIndex = -1;

            while (intIrow < dgFonds.Rows.Count)
            {
                dgFonds.Rows[intIrow].Visible = true;
                dgFonds.Rows[intIrow].Selected = false;

                if (cbHighLowShow.Checked)
                {
                    if (dgFonds.Rows[intIrow].Tag != null)
                    {
                        if (dgFonds.Rows[intIrow].Tag.ToString() == "0")
                        {
                            // Alseme dit niet doen dan kunnen we dit gezeur krijgen: "Row associated with the currency manager's position cannot be made invisible"
                            CurrencyManager cuMa = (CurrencyManager)BindingContext[dgFonds.DataSource];
                            cuMa.SuspendBinding();

                            dgFonds.Rows[intIrow].Visible = false;
                        }
                        else                            
                        {
                            // Hier bewaren we de indexnr, de FondsNaam en de IndexNaam van de 1e ( bovenste ) 
                            // zichtbare rij het het DG.
                            // Hiermee voeren we na afloop een 'get_detail" uit om zo allerlei waarden die
                            // bij dat fonds horen ook automatisch gevuld te krijgen
                            if ( intFirstVisibleRowIndex < 0) // Geinitialiseerd op -1; dus indien < 0 istie nog niet gebruikt
                            {
                                strFonds = dgFonds[0, intIrow].Value.ToString();
                                strIndex = dgFonds[1, intIrow].Value.ToString();
                                intFirstVisibleRowIndex = intIrow;
                            }
                        }
                        cmdHighLowAnalyze.Visible = false;
                    }
                }
                else
                {
                    cmdHighLowAnalyze.Visible = true;
                }
                intIrow++;
            }

          

            // *************************************************
            // Vul detailinfo van de 1e zichtbare rij in het dg
            // *************************************************
            get_details(strFonds, strIndex);
        }

        private void cmdStockNames_Click(object sender, EventArgs e)
        {
            frmStockNames frmStockName = new frmStockNames();
            frmStockName.strDatabase = strDatabase;
            frmStockName.ShowDialog(this);
        }

        private void cmbSelect_SelectedIndexChanged(object sender, EventArgs e)
        {
            if ( cmbSelect.SelectedItem.ToString().ToUpper().Trim().Contains("All".ToUpper().Trim()))
            {
                load_funds(false);
                lblDoubleClick.Text = "Doubleclick row to add fund to the 'my stocks' pool";
            }
            else
	        {
                load_funds(true);                
                lblDoubleClick.Text = "Doubleclick row to remove fund from the 'my stocks' pool";
	        }

            cbHighLowShow.Checked = false;
            grbAnalyse.Visible = false;
            lbMin.Items.Clear();            
            lbMax.Items.Clear();  
        }

        private void cmbChoose_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtChoose.Text = "";
            string strFiller = " | ";
            int intFiller = strFiller.Length;

            int intI = 0;

            while ( intI < dgKoers.Rows.Count)
            {
                if (dgKoers[1, intI].Value.ToString().Trim().ToUpper() == cmbChoose.Text.ToString().Trim().ToUpper())
                {
                    txtChoose.Text = txtChoose.Text + strFiller + Convert.ToDouble(dgKoers[0, intI].Value).ToString("###.#0");
                }
                intI++;
            }
            int intChoose_length=txtChoose.Text.Length - intFiller;
            if (intChoose_length > 0)
            {
                txtChoose.Text = txtChoose.Text.Substring(intFiller, intChoose_length);
            }
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            BackgroundWorker worker = sender as BackgroundWorker;
           
           

            doe_bg_koersen();

            

       

            
        }

        private void backgroundWorker1_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            float flt1Pct = dgFonds.Rows.Count;
            flt1Pct = 101 / flt1Pct;
            float flt100Pct;

            int intIRow = 20; // moet echte teller worden

            lblMacPerc.Text = dgFonds[0, intIRow].Value.ToString() + " (" + Convert.ToInt16(intIRow * flt1Pct).ToString() + " %)";
            /*
             if ((intIRow * flt1Pct > 60))
             {
                 lblMacPerc.BackColor = Color.Lime;
             }
             */
            flt100Pct = intIRow * flt1Pct;
            pgMax.Value = Convert.ToInt16(flt100Pct);
            lblHigh_val.Text = lbMax.Items.Count.ToString();
            lblLow_val.Text = lbMin.Items.Count.ToString();
            // this.Refresh();
        }                         
    }
}

