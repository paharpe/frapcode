﻿namespace dbDashboard
{
    partial class frmDashBase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDashBase));
            this.cmdAfsluiten = new System.Windows.Forms.Button();
            this.grbConnectie = new System.Windows.Forms.GroupBox();
            this.cmdConnect = new System.Windows.Forms.Button();
            this.lblConnected = new System.Windows.Forms.Label();
            this.lblVoortgang = new System.Windows.Forms.Label();
            this.grbConnectie.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmdAfsluiten
            // 
            this.cmdAfsluiten.Location = new System.Drawing.Point(12, 455);
            this.cmdAfsluiten.Name = "cmdAfsluiten";
            this.cmdAfsluiten.Size = new System.Drawing.Size(75, 23);
            this.cmdAfsluiten.TabIndex = 0;
            this.cmdAfsluiten.Text = "Afsluiten";
            this.cmdAfsluiten.UseVisualStyleBackColor = true;
            this.cmdAfsluiten.Click += new System.EventHandler(this.cmdAfsluiten_Click);
            // 
            // grbConnectie
            // 
            this.grbConnectie.Controls.Add(this.cmdConnect);
            this.grbConnectie.Controls.Add(this.lblConnected);
            this.grbConnectie.Location = new System.Drawing.Point(304, 443);
            this.grbConnectie.Name = "grbConnectie";
            this.grbConnectie.Size = new System.Drawing.Size(505, 35);
            this.grbConnectie.TabIndex = 19;
            this.grbConnectie.TabStop = false;
            this.grbConnectie.Text = "Connectie";
            // 
            // cmdConnect
            // 
            this.cmdConnect.Location = new System.Drawing.Point(366, 9);
            this.cmdConnect.Name = "cmdConnect";
            this.cmdConnect.Size = new System.Drawing.Size(126, 23);
            this.cmdConnect.TabIndex = 11;
            this.cmdConnect.Text = "Wijzig Unix connectie...";
            this.cmdConnect.UseVisualStyleBackColor = true;
            // 
            // lblConnected
            // 
            this.lblConnected.AutoSize = true;
            this.lblConnected.Location = new System.Drawing.Point(6, 15);
            this.lblConnected.Name = "lblConnected";
            this.lblConnected.Size = new System.Drawing.Size(69, 13);
            this.lblConnected.TabIndex = 14;
            this.lblConnected.Text = "lblConnected";
            // 
            // lblVoortgang
            // 
            this.lblVoortgang.AutoSize = true;
            this.lblVoortgang.Location = new System.Drawing.Point(310, 427);
            this.lblVoortgang.Name = "lblVoortgang";
            this.lblVoortgang.Size = new System.Drawing.Size(66, 13);
            this.lblVoortgang.TabIndex = 20;
            this.lblVoortgang.Text = "lblVoortgang";
            this.lblVoortgang.Visible = false;
            // 
            // frmDashBase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(820, 491);
            this.Controls.Add(this.lblVoortgang);
            this.Controls.Add(this.grbConnectie);
            this.Controls.Add(this.cmdAfsluiten);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmDashBase";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "DB Dashboard; base form";
            this.Load += new System.EventHandler(this.frmDashBase_Load);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmDashBase_FormClosed);
            this.grbConnectie.ResumeLayout(false);
            this.grbConnectie.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Button cmdAfsluiten;
        protected System.Windows.Forms.GroupBox grbConnectie;
        protected System.Windows.Forms.Button cmdConnect;
        protected System.Windows.Forms.Label lblConnected;
        protected System.Windows.Forms.Label lblVoortgang;
    }
}