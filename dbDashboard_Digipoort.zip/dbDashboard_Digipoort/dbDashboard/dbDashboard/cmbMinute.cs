﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace dbDashboard
{
    public partial class cmbMinute : ComboBox
    {
        private Boolean _bChanged = false;
        private int _intMinute = 0;

        public cmbMinute()
        {
            ComboBox cmbMinute = new ComboBox();

            this.Size = new System.Drawing.Size(45, 20);
            this.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        public Boolean bChanged
        {
            get { return this._bChanged; }
            set { this._bChanged = value; }
        }

        public int intMinute
        {
            get { return this._intMinute; }
            set { this._intMinute = value; }
        }

        public cmbMinute(IContainer container)
        {
            container.Add(this);

            InitializeComponent();
        }

        protected override void OnCreateControl()
        {
            int intMinute = 0;
            while (intMinute < 60)
            {
                this.Items.Add(intMinute.ToString("0#"));
                intMinute++;
            }

            base.OnCreateControl();
        }

        protected override void OnSelectedIndexChanged(EventArgs e)
        {
            this.bChanged = false;
            if (Convert.ToInt32(this.SelectedItem) != this._intMinute)
            {
                this._intMinute = Convert.ToInt32(this.SelectedItem);
                this.bChanged = true;
            }
            base.OnSelectedIndexChanged(e);
        }
    }
}