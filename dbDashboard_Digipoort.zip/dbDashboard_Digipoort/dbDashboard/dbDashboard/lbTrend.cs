﻿using System;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

namespace dbDashboard
{
    public partial class lbTrend : ListBox  
    {
        private Int16 _Max_Occs = 0;
        private Boolean _bChanged = false;
        private Int16 _intSeli;
        private int _intTrend;

        public lbTrend()
        {
            ListBox lbTrend = new ListBox();
            this.Width = 200;
            this.Height = 40;            
        }

        public Int16 Max_Occs
        {
            get { return this._Max_Occs; }
            set { this._Max_Occs = value; }
        }

        public Boolean bChanged
        {
            get { return this._bChanged; }
            set { this._bChanged = value; }
        }

        public Int16 intSeli
        {
            get { return this._intSeli; }
            set { this._intSeli = value; }
        }

        public int intTrend
        {
            get { return this._intTrend; }
            set { this._intTrend = value; }
        }
        
        public int GetAverage()
        {
            intSeli = 0;
            intTrend = 0;
            string strThis_Value="";
            while (intSeli < this.Items.Count)
            {
                this.SelectedIndex = intSeli;

                strThis_Value = clDashFunction.get_word(this.Text, 2);
                if (strThis_Value != "")
                {
                    intTrend = intTrend + Convert.ToInt32(strThis_Value);
                }
                intSeli++;
            }
            // Voorkom delen door nul
            if (this.Items.Count > 0)
            {
                intTrend = intTrend / this.Items.Count;
            }
            return intTrend;                
        }

        /// <summary>
        /// Adds value to bottom of listbox and removes first value if Max_Occs is reachted
        /// </summary>
        /// <param name="strTrendValue"></param>
        /// <returns></returns>
        public int AddValue(string strTrendValue)
        {          
            // Temp Prutsel..
            strTrendValue = System.DateTime.Now.Hour.ToString("0#") + ":" + System.DateTime.Now.Minute.ToString("0#") + " / " + strTrendValue;
            // Temp Prutsel


            this.Items.Add(strTrendValue); // hulpconstructie voor trendberekening
            if (this.Items.Count > this.Max_Occs)
            {
                this.Items.RemoveAt(0);
            }
            return this.GetAverage();
        }
        // Overload
        public int AddValue(int intTrendValue)
        {
            this.AddValue(intTrendValue.ToString()); // hulpconstructie voor trendberekening  
            return this.GetAverage();
        }
     }
}
