﻿namespace Stocks
{
    partial class frmMystock
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgStock = new System.Windows.Forms.DataGridView();
            this.grbStock = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgStock)).BeginInit();
            this.grbStock.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgStock
            // 
            this.dgStock.AllowUserToAddRows = false;
            this.dgStock.AllowUserToDeleteRows = false;
            this.dgStock.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgStock.Location = new System.Drawing.Point(14, 24);
            this.dgStock.MultiSelect = false;
            this.dgStock.Name = "dgStock";
            this.dgStock.ReadOnly = true;
            this.dgStock.RowHeadersVisible = false;
            this.dgStock.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgStock.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgStock.Size = new System.Drawing.Size(599, 420);
            this.dgStock.TabIndex = 5;
            // 
            // grbStock
            // 
            this.grbStock.Controls.Add(this.dgStock);
            this.grbStock.Location = new System.Drawing.Point(11, 12);
            this.grbStock.Name = "grbStock";
            this.grbStock.Size = new System.Drawing.Size(629, 465);
            this.grbStock.TabIndex = 6;
            this.grbStock.TabStop = false;
            this.grbStock.Text = "groupBox1";
            this.grbStock.Enter += new System.EventHandler(this.grbStock_Enter);
            // 
            // frmMystock
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(650, 530);
            this.Controls.Add(this.grbStock);
            this.Name = "frmMystock";
            this.Text = "frmMystock";
            ((System.ComponentModel.ISupportInitialize)(this.dgStock)).EndInit();
            this.grbStock.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgStock;
        private System.Windows.Forms.GroupBox grbStock;
    }
}