﻿namespace dbDashboard
{
    partial class frmDashFTPSstats
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grbSTAccounter = new System.Windows.Forms.GroupBox();
            this.cmdHowFile = new System.Windows.Forms.Button();
            this.grbSTAData = new System.Windows.Forms.GroupBox();
            this.cmdIDXAll = new System.Windows.Forms.Button();
            this.cmdSave = new System.Windows.Forms.Button();
            this.lblRecentLoggedOn = new System.Windows.Forms.Label();
            this.lblRowsRecentLoggedOn_Count = new System.Windows.Forms.Label();
            this.lblNeverLoggedOn = new System.Windows.Forms.Label();
            this.lblRowsNeverLoggedOn_Count = new System.Windows.Forms.Label();
            this.lblRowsMoreThanMaxIdleCount = new System.Windows.Forms.Label();
            this.lblRowsSelected_Count = new System.Windows.Forms.Label();
            this.lblRowsSelected = new System.Windows.Forms.Label();
            this.lblDaysIdleDays = new System.Windows.Forms.Label();
            this.lblDaysIdle = new System.Windows.Forms.Label();
            this.txtDaysIdle = new System.Windows.Forms.TextBox();
            this.lblIDXText = new System.Windows.Forms.Label();
            this.cmdIDXText = new System.Windows.Forms.Button();
            this.txtIDXText = new System.Windows.Forms.TextBox();
            this.cmdChooseFile = new System.Windows.Forms.Button();
            this.txtInputFile = new System.Windows.Forms.TextBox();
            this.lblInputFile = new System.Windows.Forms.Label();
            this.dgSTAccounter = new System.Windows.Forms.DataGridView();
            this.colTranslation = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colLastLogin = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDaysIdle = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.openFileDlg = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDlg = new System.Windows.Forms.SaveFileDialog();
            this.grbConnect.SuspendLayout();
            this.grbSTAccounter.SuspendLayout();
            this.grbSTAData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgSTAccounter)).BeginInit();
            this.SuspendLayout();
            // 
            // cmdAfsluiten
            // 
            this.cmdAfsluiten.Location = new System.Drawing.Point(5, 643);
            // 
            // lblHostName
            // 
            this.lblHostName.Location = new System.Drawing.Point(376, 654);
            this.lblHostName.Size = new System.Drawing.Size(145, 13);
            this.lblHostName.Text = "KPNNL\\WLD4BED923B63C";
            // 
            // grbSTAccounter
            // 
            this.grbSTAccounter.Controls.Add(this.cmdHowFile);
            this.grbSTAccounter.Controls.Add(this.grbSTAData);
            this.grbSTAccounter.Controls.Add(this.cmdChooseFile);
            this.grbSTAccounter.Controls.Add(this.txtInputFile);
            this.grbSTAccounter.Controls.Add(this.lblInputFile);
            this.grbSTAccounter.Controls.Add(this.dgSTAccounter);
            this.grbSTAccounter.Location = new System.Drawing.Point(10, 32);
            this.grbSTAccounter.Name = "grbSTAccounter";
            this.grbSTAccounter.Size = new System.Drawing.Size(499, 596);
            this.grbSTAccounter.TabIndex = 23;
            this.grbSTAccounter.TabStop = false;
            this.grbSTAccounter.Text = "FTPS accounts; login information";
            // 
            // cmdHowFile
            // 
            this.cmdHowFile.Location = new System.Drawing.Point(444, 53);
            this.cmdHowFile.Name = "cmdHowFile";
            this.cmdHowFile.Size = new System.Drawing.Size(25, 23);
            this.cmdHowFile.TabIndex = 4;
            this.cmdHowFile.Text = "?";
            this.cmdHowFile.UseVisualStyleBackColor = true;
            this.cmdHowFile.Click += new System.EventHandler(this.cmdHowFile_Click);
            // 
            // grbSTAData
            // 
            this.grbSTAData.Controls.Add(this.cmdIDXAll);
            this.grbSTAData.Controls.Add(this.cmdSave);
            this.grbSTAData.Controls.Add(this.lblRecentLoggedOn);
            this.grbSTAData.Controls.Add(this.lblRowsRecentLoggedOn_Count);
            this.grbSTAData.Controls.Add(this.lblNeverLoggedOn);
            this.grbSTAData.Controls.Add(this.lblRowsNeverLoggedOn_Count);
            this.grbSTAData.Controls.Add(this.lblRowsMoreThanMaxIdleCount);
            this.grbSTAData.Controls.Add(this.lblRowsSelected_Count);
            this.grbSTAData.Controls.Add(this.lblRowsSelected);
            this.grbSTAData.Controls.Add(this.lblDaysIdleDays);
            this.grbSTAData.Controls.Add(this.lblDaysIdle);
            this.grbSTAData.Controls.Add(this.txtDaysIdle);
            this.grbSTAData.Controls.Add(this.lblIDXText);
            this.grbSTAData.Controls.Add(this.cmdIDXText);
            this.grbSTAData.Controls.Add(this.txtIDXText);
            this.grbSTAData.Location = new System.Drawing.Point(17, 431);
            this.grbSTAData.Name = "grbSTAData";
            this.grbSTAData.Size = new System.Drawing.Size(454, 123);
            this.grbSTAData.TabIndex = 0;
            this.grbSTAData.TabStop = false;
            this.grbSTAData.Text = "Data";
            // 
            // cmdIDXAll
            // 
            this.cmdIDXAll.Location = new System.Drawing.Point(362, 96);
            this.cmdIDXAll.Name = "cmdIDXAll";
            this.cmdIDXAll.Size = new System.Drawing.Size(71, 23);
            this.cmdIDXAll.TabIndex = 14;
            this.cmdIDXAll.Text = "Select All";
            this.cmdIDXAll.UseVisualStyleBackColor = true;
            this.cmdIDXAll.Click += new System.EventHandler(this.cmdIDXAll_Click);
            // 
            // cmdSave
            // 
            this.cmdSave.Location = new System.Drawing.Point(11, 50);
            this.cmdSave.Name = "cmdSave";
            this.cmdSave.Size = new System.Drawing.Size(90, 23);
            this.cmdSave.TabIndex = 13;
            this.cmdSave.Text = "Save counters..";
            this.cmdSave.UseVisualStyleBackColor = true;
            this.cmdSave.Click += new System.EventHandler(this.cmdSave_Click);
            // 
            // lblRecentLoggedOn
            // 
            this.lblRecentLoggedOn.AutoSize = true;
            this.lblRecentLoggedOn.Location = new System.Drawing.Point(240, 55);
            this.lblRecentLoggedOn.Name = "lblRecentLoggedOn";
            this.lblRecentLoggedOn.Size = new System.Drawing.Size(150, 13);
            this.lblRecentLoggedOn.TabIndex = 12;
            this.lblRecentLoggedOn.Text = "translations recently logged on";
            // 
            // lblRowsRecentLoggedOn_Count
            // 
            this.lblRowsRecentLoggedOn_Count.AutoSize = true;
            this.lblRowsRecentLoggedOn_Count.Location = new System.Drawing.Point(214, 55);
            this.lblRowsRecentLoggedOn_Count.Name = "lblRowsRecentLoggedOn_Count";
            this.lblRowsRecentLoggedOn_Count.Size = new System.Drawing.Size(13, 13);
            this.lblRowsRecentLoggedOn_Count.TabIndex = 11;
            this.lblRowsRecentLoggedOn_Count.Text = "0";
            this.lblRowsRecentLoggedOn_Count.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblNeverLoggedOn
            // 
            this.lblNeverLoggedOn.AutoSize = true;
            this.lblNeverLoggedOn.Location = new System.Drawing.Point(240, 37);
            this.lblNeverLoggedOn.Name = "lblNeverLoggedOn";
            this.lblNeverLoggedOn.Size = new System.Drawing.Size(140, 13);
            this.lblNeverLoggedOn.TabIndex = 10;
            this.lblNeverLoggedOn.Text = "translations never logged on";
            // 
            // lblRowsNeverLoggedOn_Count
            // 
            this.lblRowsNeverLoggedOn_Count.AutoSize = true;
            this.lblRowsNeverLoggedOn_Count.Location = new System.Drawing.Point(214, 37);
            this.lblRowsNeverLoggedOn_Count.Name = "lblRowsNeverLoggedOn_Count";
            this.lblRowsNeverLoggedOn_Count.Size = new System.Drawing.Size(13, 13);
            this.lblRowsNeverLoggedOn_Count.TabIndex = 9;
            this.lblRowsNeverLoggedOn_Count.Text = "0";
            this.lblRowsNeverLoggedOn_Count.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblRowsMoreThanMaxIdleCount
            // 
            this.lblRowsMoreThanMaxIdleCount.AutoSize = true;
            this.lblRowsMoreThanMaxIdleCount.Location = new System.Drawing.Point(214, 20);
            this.lblRowsMoreThanMaxIdleCount.Name = "lblRowsMoreThanMaxIdleCount";
            this.lblRowsMoreThanMaxIdleCount.Size = new System.Drawing.Size(13, 13);
            this.lblRowsMoreThanMaxIdleCount.TabIndex = 3;
            this.lblRowsMoreThanMaxIdleCount.Text = "0";
            this.lblRowsMoreThanMaxIdleCount.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblRowsSelected_Count
            // 
            this.lblRowsSelected_Count.AutoSize = true;
            this.lblRowsSelected_Count.Location = new System.Drawing.Point(8, 20);
            this.lblRowsSelected_Count.Name = "lblRowsSelected_Count";
            this.lblRowsSelected_Count.Size = new System.Drawing.Size(13, 13);
            this.lblRowsSelected_Count.TabIndex = 0;
            this.lblRowsSelected_Count.Text = "0";
            // 
            // lblRowsSelected
            // 
            this.lblRowsSelected.AutoSize = true;
            this.lblRowsSelected.Location = new System.Drawing.Point(34, 20);
            this.lblRowsSelected.Name = "lblRowsSelected";
            this.lblRowsSelected.Size = new System.Drawing.Size(103, 13);
            this.lblRowsSelected.TabIndex = 2;
            this.lblRowsSelected.Text = "translations selected";
            // 
            // lblDaysIdleDays
            // 
            this.lblDaysIdleDays.AutoSize = true;
            this.lblDaysIdleDays.Location = new System.Drawing.Point(401, 20);
            this.lblDaysIdleDays.Name = "lblDaysIdleDays";
            this.lblDaysIdleDays.Size = new System.Drawing.Size(35, 13);
            this.lblDaysIdleDays.TabIndex = 6;
            this.lblDaysIdleDays.Text = "day(s)";
            // 
            // lblDaysIdle
            // 
            this.lblDaysIdle.AutoSize = true;
            this.lblDaysIdle.Location = new System.Drawing.Point(240, 20);
            this.lblDaysIdle.Name = "lblDaysIdle";
            this.lblDaysIdle.Size = new System.Drawing.Size(132, 13);
            this.lblDaysIdle.TabIndex = 4;
            this.lblDaysIdle.Text = "translations idle more than:";
            // 
            // txtDaysIdle
            // 
            this.txtDaysIdle.Location = new System.Drawing.Point(377, 16);
            this.txtDaysIdle.Name = "txtDaysIdle";
            this.txtDaysIdle.ReadOnly = true;
            this.txtDaysIdle.Size = new System.Drawing.Size(22, 20);
            this.txtDaysIdle.TabIndex = 5;
            this.txtDaysIdle.Text = "90";
            // 
            // lblIDXText
            // 
            this.lblIDXText.AutoSize = true;
            this.lblIDXText.Location = new System.Drawing.Point(10, 101);
            this.lblIDXText.Name = "lblIDXText";
            this.lblIDXText.Size = new System.Drawing.Size(164, 13);
            this.lblIDXText.TabIndex = 7;
            this.lblIDXText.Text = "Find translation(s) containing text:";
            // 
            // cmdIDXText
            // 
            this.cmdIDXText.Location = new System.Drawing.Point(282, 96);
            this.cmdIDXText.Name = "cmdIDXText";
            this.cmdIDXText.Size = new System.Drawing.Size(71, 23);
            this.cmdIDXText.TabIndex = 0;
            this.cmdIDXText.Text = "Find";
            this.cmdIDXText.UseVisualStyleBackColor = true;
            this.cmdIDXText.Click += new System.EventHandler(this.cmdIDXText_Click);
            // 
            // txtIDXText
            // 
            this.txtIDXText.Location = new System.Drawing.Point(177, 97);
            this.txtIDXText.Name = "txtIDXText";
            this.txtIDXText.Size = new System.Drawing.Size(105, 20);
            this.txtIDXText.TabIndex = 8;
            this.txtIDXText.TextChanged += new System.EventHandler(this.txtIDXText_TextChanged);
            // 
            // cmdChooseFile
            // 
            this.cmdChooseFile.Location = new System.Drawing.Point(420, 53);
            this.cmdChooseFile.Name = "cmdChooseFile";
            this.cmdChooseFile.Size = new System.Drawing.Size(25, 23);
            this.cmdChooseFile.TabIndex = 3;
            this.cmdChooseFile.Text = "...";
            this.cmdChooseFile.UseVisualStyleBackColor = true;
            this.cmdChooseFile.Click += new System.EventHandler(this.cmdChooseFile_Click);
            // 
            // txtInputFile
            // 
            this.txtInputFile.Location = new System.Drawing.Point(17, 55);
            this.txtInputFile.Name = "txtInputFile";
            this.txtInputFile.ReadOnly = true;
            this.txtInputFile.Size = new System.Drawing.Size(404, 20);
            this.txtInputFile.TabIndex = 2;
            // 
            // lblInputFile
            // 
            this.lblInputFile.AutoSize = true;
            this.lblInputFile.Location = new System.Drawing.Point(13, 36);
            this.lblInputFile.Name = "lblInputFile";
            this.lblInputFile.Size = new System.Drawing.Size(153, 13);
            this.lblInputFile.TabIndex = 1;
            this.lblInputFile.Text = "SecureTransport XML inputfile:";
            // 
            // dgSTAccounter
            // 
            this.dgSTAccounter.AllowUserToAddRows = false;
            this.dgSTAccounter.AllowUserToDeleteRows = false;
            this.dgSTAccounter.AllowUserToOrderColumns = true;
            this.dgSTAccounter.AllowUserToResizeColumns = false;
            this.dgSTAccounter.AllowUserToResizeRows = false;
            this.dgSTAccounter.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgSTAccounter.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colTranslation,
            this.colLastLogin,
            this.colDaysIdle});
            this.dgSTAccounter.Location = new System.Drawing.Point(17, 87);
            this.dgSTAccounter.Name = "dgSTAccounter";
            this.dgSTAccounter.RowHeadersVisible = false;
            this.dgSTAccounter.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgSTAccounter.Size = new System.Drawing.Size(454, 332);
            this.dgSTAccounter.TabIndex = 5;
            // 
            // colTranslation
            // 
            this.colTranslation.FillWeight = 200F;
            this.colTranslation.HeaderText = "Translation";
            this.colTranslation.MaxInputLength = 25;
            this.colTranslation.Name = "colTranslation";
            this.colTranslation.Width = 200;
            // 
            // colLastLogin
            // 
            this.colLastLogin.FillWeight = 150F;
            this.colLastLogin.HeaderText = "LastLogin";
            this.colLastLogin.MaxInputLength = 20;
            this.colLastLogin.Name = "colLastLogin";
            this.colLastLogin.Width = 150;
            // 
            // colDaysIdle
            // 
            this.colDaysIdle.HeaderText = "DaysIdle";
            this.colDaysIdle.MaxInputLength = 5;
            this.colDaysIdle.Name = "colDaysIdle";
            // 
            // openFileDlg
            // 
            this.openFileDlg.FileName = "*.xml";
            // 
            // frmDashFTPSstats
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(518, 670);
            this.Controls.Add(this.grbSTAccounter);
            this.Name = "frmDashFTPSstats";
            this.Text = "frmDashFTPSstats";
            this.Load += new System.EventHandler(this.frmDashFTPSstats_Load);
            this.Controls.SetChildIndex(this.cmdAfsluiten, 0);
            this.Controls.SetChildIndex(this.grbConnect, 0);
            this.Controls.SetChildIndex(this.lblHostName, 0);
            this.Controls.SetChildIndex(this.grbSTAccounter, 0);
            this.grbConnect.ResumeLayout(false);
            this.grbConnect.PerformLayout();
            this.grbSTAccounter.ResumeLayout(false);
            this.grbSTAccounter.PerformLayout();
            this.grbSTAData.ResumeLayout(false);
            this.grbSTAData.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgSTAccounter)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grbSTAccounter;
        private System.Windows.Forms.Button cmdHowFile;
        private System.Windows.Forms.GroupBox grbSTAData;
        private System.Windows.Forms.Button cmdIDXAll;
        private System.Windows.Forms.Button cmdSave;
        private System.Windows.Forms.Label lblRecentLoggedOn;
        private System.Windows.Forms.Label lblRowsRecentLoggedOn_Count;
        private System.Windows.Forms.Label lblNeverLoggedOn;
        private System.Windows.Forms.Label lblRowsNeverLoggedOn_Count;
        private System.Windows.Forms.Label lblRowsMoreThanMaxIdleCount;
        private System.Windows.Forms.Label lblRowsSelected_Count;
        private System.Windows.Forms.Label lblRowsSelected;
        private System.Windows.Forms.Label lblDaysIdleDays;
        private System.Windows.Forms.Label lblDaysIdle;
        private System.Windows.Forms.TextBox txtDaysIdle;
        private System.Windows.Forms.Label lblIDXText;
        private System.Windows.Forms.Button cmdIDXText;
        private System.Windows.Forms.TextBox txtIDXText;
        private System.Windows.Forms.Button cmdChooseFile;
        private System.Windows.Forms.TextBox txtInputFile;
        private System.Windows.Forms.Label lblInputFile;
        private System.Windows.Forms.DataGridView dgSTAccounter;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTranslation;
        private System.Windows.Forms.DataGridViewTextBoxColumn colLastLogin;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDaysIdle;
        private System.Windows.Forms.OpenFileDialog openFileDlg;
        private System.Windows.Forms.SaveFileDialog saveFileDlg;
    }
}