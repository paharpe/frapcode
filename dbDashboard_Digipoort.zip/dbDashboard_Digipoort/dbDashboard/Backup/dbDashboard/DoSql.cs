using System;
using System.Collections;
using System.Text;
using System.Data.OleDb;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace dbDashboard
{
    public class DoSql
    {
        public ListBox      vul_deze_listbox;
        public ComboBox     vul_deze_combobox;
        public DataGridView vul_dit_datagrid;
        public TreeView     vul_deze_treeview;
        public string[]     vul_deze_text1_array  = new string[50];
        public string[]     vul_deze_text2_array  = new string[50];
        public string[]     vul_deze_text3_array = new string[50];
        public string       vul_deze_string;
        public ArrayList    vul_deze_arraylist;
        private string      vul_id;
       
        public int      affected_rows;
        public TreeNode Parent_Node;
        public TreeNode Child_Node;
               
        public void DoQuery(string sqlquery)
        {
            if (vul_deze_string != null)
            {
                vul_id = "TX";
            }

            if (vul_deze_listbox != null)
            {
                vul_id = "LB";
                vul_deze_listbox.Items.Clear();
            }

            if (vul_deze_combobox != null)
            {
                vul_id = "CB";
                vul_deze_combobox.Text = "";
                vul_deze_combobox.Items.Clear();
            }

            if (vul_dit_datagrid != null)
            {
                vul_id = "DG";
            }

            if (vul_deze_treeview != null)
            {
                vul_id = "TV";
            }
            
            if (vul_deze_text1_array[1] == "FTA")
            {
                vul_id = "PB";                
            }
            if (vul_deze_arraylist != null)
            {
                vul_id = "AL";
            }

            OleDbConnection connection;     // ADO connection.
            OleDbCommand command;           // ADO command
            OleDbDataReader dataReader;     // ADO data reader     

            dataReader    = null;
            affected_rows = 0;
            try
            {
                connection = new OleDbConnection();

                connection.ConnectionString = mdiDashboard.access_connection;

                connection.Open();

                command = new OleDbCommand(sqlquery, connection);                

                switch (vul_id)
                {
                    case "TV":  //Treeview
                        {                           
                            dataReader = command.ExecuteReader();
                            while (dataReader.Read())
                            {
                                if (dataReader[1].ToString() == "0") // Hoofdnode
                                {
                                    Parent_Node = vul_deze_treeview.Nodes.Add(dataReader[2].ToString());
                                    Parent_Node.Tag = null;
                                }
                                if (dataReader[1].ToString() == "1") // Subnode
                                {
                                    Child_Node = Parent_Node.Nodes.Add(dataReader[2].ToString());
                                    Child_Node.Tag = Convert.ToString(Convert.ToInt16(dataReader[0])+0);
                                } 
                                
                                if (dataReader[1].ToString() == "2") // SubSubnode
                                {
                                    Child_Node = Parent_Node.Nodes.Add(dataReader[2].ToString());
                                    Child_Node.Tag = Convert.ToString(Convert.ToInt16(dataReader[0]) + 0);
                                }

                                affected_rows++;
                            }
                            dataReader.Close();
                            if (affected_rows <= 1)
                            {
                                vul_deze_treeview.Nodes.Clear();
                                clDashFunction.Melding("Geen subsystemen toegewezen",1,"E");                               
                            }
                            break;
                        }
                    case "LB":  // Listbox
                        {
                            dataReader = command.ExecuteReader();
                            while (dataReader.Read())
                            {
                                vul_deze_listbox.Items.Add(dataReader[0].ToString());
                                affected_rows++;
                            }
                            dataReader.Close();
                            break;
                        }
                    case "CB":  // Combobox
                        {
                            dataReader = command.ExecuteReader();
                            while (dataReader.Read())
                            {
                                vul_deze_combobox.Items.Add(dataReader[0].ToString());
                                affected_rows++;
                            }
                            dataReader.Close();
                            break;
                        }
                    case "DG":  // Datagrid
                        {
                            command.CommandType = CommandType.Text;
                            OleDbDataAdapter da = new OleDbDataAdapter(command);
                            DataTable grid_table = new DataTable();
                            da.Fill(grid_table);
                            vul_dit_datagrid.DataSource = grid_table;
                            affected_rows = grid_table.Rows.Count;
                            break;
                        }
                        case "PB":  // Pushbutton
                        {
                            // Alleen buttonteksten laden, rest op form....                            
                            dataReader = command.ExecuteReader();
                            while (dataReader.Read())
                            {                               
                                affected_rows++;
                                vul_deze_text1_array [affected_rows] = dataReader[0].ToString();
                                vul_deze_text2_array [affected_rows] = dataReader[1].ToString();
                                vul_deze_text3_array [affected_rows] = dataReader[2].ToString();
                            }
                            dataReader.Close();
                            break;
                        }
                        case "TX":  // Text(string)
                        {
                            // Alleen buttonteksten laden, rest op form....                            
                            dataReader = command.ExecuteReader();
                            while (dataReader.Read())
                            {
                                affected_rows++;                                
                                vul_deze_string = dataReader[0].ToString();                               
                            }
                            dataReader.Close();
                            break;
                        }
                        case "AL":  // Arraylist
                        {
                            dataReader = command.ExecuteReader();
                            while (dataReader.Read())
                            {
                                affected_rows++;
                                vul_deze_arraylist.Add(dataReader[0].ToString());
                            }
                            dataReader.Close();
                            break;
                        }
                    default:
                        {
                            clDashFunction.Melding("Deze identifier (" + vul_id + ") is onbekend", 1, "E");
                            break;
                        }
                }
                connection.Close();
                return;
            }
            catch (OleDbException e)
            {
                clDashFunction.Melding(e.ToString(),1,"E");
                if (dataReader != null)
                {
                    if (dataReader.IsClosed == false)
                        dataReader.Close();
                }
                return;
            }
        }

        public void DoUpdate(string sqlquery)
        {
            OleDbConnection connection;    // ADO connection.
            OleDbCommand command;          // ADO command

            try
            {
                connection = new OleDbConnection();

                connection.ConnectionString = mdiDashboard.access_connection;
                connection.Open();

                command = new OleDbCommand(sqlquery, connection);
                affected_rows = command.ExecuteNonQuery();

                connection.Close();
                return;
            }
            catch (OleDbException e)
            {
                clDashFunction.Melding(e.ToString(), 1, "E");
            }
        }
    }
}