﻿using System;
using System.Collections;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.IO;
using System.Threading;
// using System.Windows.Forms.DataVisualization.Charting;
using System.Data;
using System.Diagnostics;
using System.Drawing;

namespace Stocks
{
    
#pragma warning disable 0628

    class clDashFunction
    {
        // Ophalen aantal seconden voordat wordt geautoclosed...
        public static Int16 get_autoclose()
        {
            DoSql mysql = new DoSql();
            mysql.vul_deze_string = "";
            mysql.DoQuery("SELECT KoursFonds " +
                          "FROM   KoursBours " +
                          "WHERE  KoursKoers < 100 ");
            if (mysql.affected_rows == 0)
            {
                return 10;
            }
            else
            {
                try
                {
                    return Convert.ToInt16(mysql.vul_deze_string);
                }
                catch
                {
                    return 10;
                }
            }
        }

        /// <summary>
        /// Get alternate full path name (ElemOms2) from DashElem table 10
        /// </summary>
        /// <param name="strElem"></param>
        /// <returns></returns>
        public static string get_alternate_path(string strElem)
        {
            return get_path(strElem, false, true);
        }

        /// <summary>
        /// Get full path name (ElemOms1) from DashElem table 10
        /// </summary>
        /// <param name="strElem"></param>
        /// <returns></returns>
        public static string get_path(string strElem)
        {
            return get_path(strElem, false, false);
        }

        /// <summary>
        /// Returns a flat, delimited string based on the input array
        /// </summary>
        /// <param name="separator"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string join_array(string separator, string[] value)
        {
            string strReturn = "";
            foreach (string strSting in value)
            {
                strReturn = strReturn + separator + strSting;
            }
            return strReturn.Trim();
        }

        /// <summary>
        /// Check existance of strServer in table 11
        /// Note: strServer will be UCASEd cause (being the ElemElem column) it will be in uppercase in table 11 as well
        /// </summary>
        /// <param name>strServer</param>
        /// <returns>bReturn</returns>
        public static Boolean validate_server(string strServer)
        {
            Boolean bReturn = false;

            DoSql mySql = new DoSql();
            mySql.vul_deze_string = "";
            mySql.DoQuery("SELECT  ElemElem " +
                           "FROM   DashElem " +
                           "WHERE  ElemTabn = 12 " +
                           "AND    ElemElem = '" + strServer.ToUpper() + "'");

            if (mySql.affected_rows == 1)
            {
                bReturn = true;
            }

            return bReturn;
        }

        /// <summary>
        /// Returns string containing solution name or "None"
        /// </summary>
        /// <returns></returns>
        public static string get_solution_name()
        {
            string strSolution = "None";

            string[] strarSolution = System.Reflection.Assembly.GetExecutingAssembly().ToString().Split(',');

            if (strarSolution.Length > 0)
            {
                strSolution =strarSolution[0];
            }
            return strSolution;
        }


        /// <summary>
        /// Returns solution path string upto the first subdir containing the solution name
        /// </summary>
        /// <returns>D</returns>
        /// <example>Working directory: C:\\Documents and Settings\\C#Solutions\\Solution\\Solution\\Solution\\debug\\bin\\</example>
        /// <example>Returns          : C:\\Documents and Settings\\C#Solutions\\Solution\\</example>
        public static string get_solution_path()
        {
            string strSolution_Path = "C:\\";
            string strSolution=get_solution_name();
            int intSolution_Length=strSolution.Length;
            int intSolution_Location=System.Environment.CurrentDirectory.IndexOf(strSolution);
            if (intSolution_Location > -1)
            {
                strSolution_Path = System.Environment.CurrentDirectory.Substring(0, intSolution_Location + intSolution_Length + 1);
            }
            return strSolution_Path;
        }

      /// <summary>
      /// 
      /// </summary>
      /// <param name="strDatabase_name"></param>
      /// <returns></returns>
        public static string get_database(string strDatabase_parm)
        {
            // *********************************************************
            // Ok, datbasefile exists, no further quests your honour !
            // *********************************************************
             if (File.Exists(strDatabase_parm))
             {
                 return strDatabase_parm;
             }

            // Try to seperate the inputstring in a @Directory and a @Filename part....
            ArrayList alDatabase = clDashFunction.get_dir_file(strDatabase_parm);

            string strDatabase_name = alDatabase[0].ToString();
            string strDatabase_path = alDatabase[1].ToString();
            string strDatabase = "-1";

            if (strDatabase_name.Trim() == "")
            {
                Melding("No databasename has been suplied !", 1, "I");
            }

            else
            {
                // Set database(path)
                // If the path supplied by the strDatabase_parm value is invalid, then
                // the solutions working directory is assumed to be the ( new ) database path
                if (!Directory.Exists(strDatabase_path))
                {
                    strDatabase_path = get_solution_path();
                }

                // But does it exist ?
                if (!File.Exists(strDatabase_path + strDatabase_name))
                {
                    clDashFunction.Melding("Was expecting database to be: \n" +
                        strDatabase_path + strDatabase_name + "\n" +
                       "it seems to be not present though \n\n" +
                       "Please point to the database using the next dialog", 1, "I");

                    OpenFileDialog ofdDatabase = new OpenFileDialog();
                    ofdDatabase.InitialDirectory = strDatabase_path;
                    ofdDatabase.DefaultExt = "accdb";
                    ofdDatabase.Filter = "Access DB files (*.accdb)|*.accdb|All files (*.*)|*.*";
                    ofdDatabase.FilterIndex = 0;
                    ofdDatabase.FileName = "";
                    ofdDatabase.Multiselect = false;
                    if (ofdDatabase.ShowDialog() == DialogResult.OK)
                    {
                        if (File.Exists(ofdDatabase.FileName))
                        {
                            strDatabase = ofdDatabase.FileName;
                        }                        
                    }                    
                }
            }
            return strDatabase;
        }


        /// <summary>
        /// Returns Boolean Value indicating if debug information is shown
        /// </summary>
        /// <returns></returns>
        public static void getDebug()
        {
            DoSql mySql = new DoSql();
            mySql.vul_deze_string = "FTA";

            mySql.DoQuery("SELECT ElemOms1 " +
                          "FROM   DashElem " +
                          "WHERE  ElemTabn = 10 " +
                          "AND    ElemElem = 'DEBUG'");
        }


        public static string get_path(string strElem, Boolean bCheckLocalFS, Boolean bAltPath)
        {
            string strAccColumn = "ElemOms1";

            if (bAltPath)
            {
                strAccColumn = "ElemOms2";
            }

            DoSql mySql = new DoSql();
            mySql.vul_deze_string = "";
            mySql.DoQuery("SELECT  " + strAccColumn + " " +
                           "FROM   DashElem " +
                           "WHERE  ElemTabn = 10 " +
                           "AND    ElemElem = '" + strElem + "'");

            if (mySql.affected_rows == 0)
            {
                Melding("No rows found in DashElem: \n\n <Tab:10> <Elm: " + strElem.Trim() + ">", 1, "I");
            }

            else
            {
                if (bCheckLocalFS)
                {
                    if (!Directory.Exists(mySql.vul_deze_string))
                    {
                        clDashFunction.Melding("Path : " + mySql.vul_deze_string + " does not exist \n" +
                                                "You may check <Tab:10> <Elm: " + strElem.Trim() + ">", 1, "E");
                    }
                }
            }
            return mySql.vul_deze_string;
        }

        /// <summary>
        /// Remove unwanted inherited control  
        /// </summary>
        /// <param name="clCallingForm"></param>
        /// <param name="strControl_2b_removed"></param>
        public static void remove_inherited_control(Form clCallingForm, string strControl_2b_removed)
        {
            foreach (Control ctr in clCallingForm.Controls)
                if (ctr.Name.ToUpper().Trim() == strControl_2b_removed.ToUpper().Trim())
                {
                    // clDashFunction.Melding("Hijahoepa! we hebben hem: "+strControl_2b_removed);
                    clCallingForm.Controls.Remove(ctr);
                    break;
                }
        }

        /// <summary>
        /// Returns the index in strFilters corresponding with strExtension
        /// </summary>
        /// <param name="strExtension"></param>
        /// <param name="strFilters"></param>
        /// <returns></returns>
        public static int get_filter_index(string strFilters, string strExtension)
        {
            if (strExtension.Trim() == "")
            {
                strExtension = "*";
            }

            strExtension = "*" + strExtension;
            string[] alFilters;
            int intFilterIndex = -1;
            int intAllIndex = -1;

            alFilters = strFilters.Split(Convert.ToChar("|"));
            // Something like:
            // alFilters[0]=Text files (*.txt)
            // alFilters[1]=*.txt
            // alFilters[2]=csv files (*.csv)
            // alFilters[3]=*.csv
            // alFilters[4]=All files (*.*)
            // alFilters[5]=*.*


            int intFilters = 0;

            foreach (string strFilter in alFilters)
            {
                // In case no known extension will be found; we will return the index corresponding with *.* ( if available in alFilters )
                // So if we meet entry *.* along the way, we will save the index for possible future use 
                if (strFilter == "*.*")
                {
                    intAllIndex = intFilters - 1;
                }

                if (strFilter == strExtension)
                {
                    intFilterIndex = intFilters - 1;
                    break;
                }
                intFilters++;
            }

            if (intFilterIndex < 0 && intAllIndex < 0)
            {
                Melding("No matching extension filter found and no '*.*' has been specified ");
            }
            return intFilterIndex;
        }

        /// <summary>
        /// /// Returns the index in strFilters corresponding with strExtension
        /// </summary>
        /// <param name="strExtension"></param>
        /// <returns></returns>
        public static int get_filter_index(string strExtension)
        {
            return get_filter_index("Text files (*.txt)|*.txt|All files (*.*)|*.*", strExtension);
        }

        // Ophalen occurences dat wordt aangehouden in de trend listboxes voordat wordt geschoond
        public static Int16 get_trend_occs()
        {
            Int16 intDefault_occ = 5;

            DoSql mysql = new DoSql();
            mysql.vul_deze_string = "";
            mysql.DoQuery("SELECT ElemOms1 " +
                          "FROM   DashElem " +
                          "WHERE  ElemTabn = 10 " +
                          "AND    ElemElem = 'TREND_OCCS'");
            if (mysql.affected_rows == 0)
            {
                return intDefault_occ;
            }
            else
            {
                try
                {
                    return Convert.ToInt16(mysql.vul_deze_string);
                }
                catch
                {
                    return intDefault_occ;
                }
            }
        }
        /// <summary>
        /// Changes all double space occs to a single one
        /// </summary>
        /// <param name="strStringIn"></param>
        /// <returns></returns>
        public static string remove_multiple_spaces(string strStringIn)
        {
            return strStringIn.Replace("  ", " ");
        }

        // Ophalen aantal seconden voordat wordt geautoclosed...
        public static string get_update_script()
        {
            string strServer = "SERVER";
            string strLocal = "LOCAL";
            DoSql mysql = new DoSql();
            mysql.vul_deze_string = "";
            mysql.DoQuery("SELECT ElemOms1 " +
                          "FROM   DashElem " +
                          "WHERE  ElemTabn = 10 " +
                          "AND    ElemElem = 'UPDATE_SCRIPT'");
            if (mysql.affected_rows == 0)
            {
                clDashFunction.Melding("Tabel element 'UPDATE_SCRIPT' niet gevonden in tabel 10, returning value: " + strServer + " !", 1, "E");
                return strServer;
            }
            else
            {
                if (mysql.vul_deze_string != strLocal && mysql.vul_deze_string != strServer)
                {
                    return strServer;
                }
                else
                {
                    return mysql.vul_deze_string;
                }
            }
        }


        // Tonen van connect dialog en in arraylist teruggeven van de verschillende 
        // resultaatvelden
        public static string splits_string(string strSplits_in, string strSplit_char, int Woord_index)
        {
            string[] strFunc_item = Regex.Split(strSplits_in, strSplit_char);
            if (Woord_index > strFunc_item.Length - 1)
            {
                Melding("Opgegeven index groter dan aantal elementen in array !", 1, "E");
                return " ";
            }
            return (strFunc_item[Woord_index].ToString());
        }

        /// <summary>
        /// Show Message. Buttons: <default>1=OK</default>, 2=OKCancel, 3=RetryCancel, 4=YesNo, 5=YesNoCancel
        ///               Icons: <default>I=Information</default>, Q=Question, E=Error,S=Stop
        /// </summary>
        /// <param name="strMelding"></param>
        /// <param name="intButtons"></param>
        /// <param name="strInfQueErr"></param>
        /// <returns></returns>
        public static DialogResult Melding(string strMelding, int intButtons, string strInfQueErr)
        {
            MessageBoxIcon mbiMelding;
            MessageBoxButtons mbbMelding;

            switch (intButtons)
            {
                case 1:
                    mbbMelding = MessageBoxButtons.OK;
                    break;
                case 2:
                    mbbMelding = MessageBoxButtons.OKCancel;
                    break;
                case 3:
                    mbbMelding = MessageBoxButtons.RetryCancel;
                    break;
                case 4:
                    mbbMelding = MessageBoxButtons.YesNo;
                    break;
                case 5:
                    mbbMelding = MessageBoxButtons.YesNoCancel;
                    break;
                case 6:
                    mbbMelding = MessageBoxButtons.AbortRetryIgnore;
                    break;
                default:
                    mbbMelding = MessageBoxButtons.OK;
                    break;
            }

            switch (strInfQueErr)
            {
                case "I":
                    mbiMelding = MessageBoxIcon.Information;
                    break;
                case "Q":
                    mbiMelding = MessageBoxIcon.Question;
                    break;
                case "E":
                    mbiMelding = MessageBoxIcon.Error;
                    break;
                case "S":
                    mbiMelding = MessageBoxIcon.Stop;
                    break;
                default:
                    mbiMelding = MessageBoxIcon.Information;
                    break;
            }
            return MessageBox.Show(strMelding, "DB Dashboard", mbbMelding, mbiMelding);
        }

        public static Boolean isTagValue(string strTagValue)
        {
            Boolean bIsTagValue = true;

            if (strTagValue.Contains("["))
            {
                bIsTagValue = false;
            }
            else if (strTagValue.Contains("]"))
            {
                bIsTagValue = false;
            }
            return bIsTagValue;
        }

        public static string get_TagValue(string strTag, ArrayList arIni_Keys, ArrayList arIni_Vals, Boolean bTalk)
        {
            int intTag_index;
            string strTag_value = "";

            intTag_index = arIni_Keys.IndexOf(strTag);
            if (intTag_index < 0)
            {
                if (bTalk) clDashFunction.Melding(strTag + " is geen geldige INI tag !");
            }
            else
            {
                if (arIni_Vals.Count > intTag_index)
                {
                    strTag_value = arIni_Vals[intTag_index].ToString();
                }
            }
            return strTag_value;
        }

        // Overload met defaultbutton en icon
        public static DialogResult Melding(string strMelding)
        {
            return Melding(strMelding, 1, "E");
        }

        public static string get_mutdatum()
        {
            return DateTime.Now.Year.ToString("0000") +
                   DateTime.Now.Month.ToString("00") +
                   DateTime.Now.Day.ToString("00");
        }

        public static string get_muttijd()
        {
            return DateTime.Now.Hour.ToString("00") +
                   DateTime.Now.Minute.ToString("00") +
                   DateTime.Now.Second.ToString("000") +
                   DateTime.Now.Millisecond.ToString("000");

        }
        public static ArrayList get_tree_nodes(TreeView tvTreeView)
        {
            // Arraylist met alle nodes uit de aangeboden treeview vullen
            // via recursieve truuk en de arraylist teruggeven.....
            ArrayList alTreeNodes = new ArrayList();
            LoopNodes(tvTreeView.Nodes, alTreeNodes);

            return alTreeNodes;
        }

        private static ArrayList LoopNodes(TreeNodeCollection nodes, ArrayList alTreeNodes)
        {
            foreach (TreeNode n in nodes)
            {
                alTreeNodes.Add(n.Text);

                if (n.Nodes != null)
                {
                    LoopNodes(n.Nodes, alTreeNodes);
                }
            }
            return alTreeNodes;
        }

        /// <summary>
        /// Returns arraylist containing filename on index 0 and directory on index 1
        /// </summary>
        /// <param name="strDirANDFile"></param>
        /// <returns></returns>
        public static ArrayList get_dir_file(string strDirANDFile)
        {
            ArrayList alDirSEPFile = new ArrayList();

            // Blanks in, then blanks out as well.
            // As all 'calling' solutions assume to get an arraylist containing 2 occ, there will be 2 blanks inserted
            if (strDirANDFile.Length == 0)
            {
                alDirSEPFile.Add("");
                alDirSEPFile.Add("");
            }

            else
            {
                // Split the -non empty- inputstring in two parts ( Assuming the input string is properly formatted )
                // Part 1 = everything before the last 2 slashes, builts the PATH
                // Part 2 = everything after the last 2 slashes, provides the FILENAME
                int inStart = 0;
                int i_old = 0;

                for (int i = 1; i > 0; i++)
                {
                    i_old = i;
                    i = strDirANDFile.IndexOf("\\", inStart); //Na de laatste slashes staat de exe file
                    inStart = i + 1;
                }
                // Eerste returnveld = file, tweede = directory
                alDirSEPFile.Add(strDirANDFile.Substring(i_old, (strDirANDFile.Length - i_old)));
                alDirSEPFile.Add(strDirANDFile.Substring(0, i_old - 1));
            }
            return alDirSEPFile;
        }

        public static bool IsInteger(string theValue)
        {
            try
            {
                Convert.ToInt32(theValue);
                return true;
            }
            catch
            {
                return false;
            }
        } //IsInteger

        public static int get_weekday_number(string strDagnaam)
        {
            switch (strDagnaam.Trim().ToUpper())
            {
                case "MONDAY":
                    {
                        return 1;
                    }
                case "MAANDAG":
                    {
                        return 1;
                    }
                case "TUESDAY":
                    {
                        return 2;
                    }
                case "DINSDAG":
                    {
                        return 2;
                    }
                case "WEDNESDAY":
                    {
                        return 3;
                    }
                case "WOENSDAG":
                    {
                        return 3;
                    }
                case "THURSDAY":
                    {
                        return 4;
                    }
                case "DONDERDAG":
                    {
                        return 4;
                    }
                case "FRIDAY":
                    {
                        return 5;
                    }
                case "VRIJDAG":
                    {
                        return 5;
                    }
                case "SATURDAY":
                    {
                        return 6;
                    }
                case "ZATERDAG":
                    {
                        return 6;
                    }
                case "SUNDAY":
                    {
                        return 7;
                    }

                case "ZONDAG":
                    {
                        return 7;
                    }
                default:
                    clDashFunction.Melding("Dag (" + strDagnaam.ToUpper() + ") kan niet worden vertaald naar dagnummer", 1, "E");
                    return 0;
            }
        }

        public static int get_weekday_number()
        {
            return get_weekday_number(DateTime.Today.DayOfWeek.ToString().ToUpper());
        }

        public static string get_weekday_name(int intDayno)
        {
            switch (intDayno)
            {
                case 1:
                    {
                        return "Maandag";
                    }
                case 2:
                    {
                        return "Dinsdag";
                    }
                case 3:
                    {
                        return "Woensdag";
                    }
                case 4:
                    {
                        return "Donderdag";
                    }
                case 5:
                    {
                        return "Vrijdag";
                    }
                case 6:
                    {
                        return "Zaterdag";
                    }
                case 7:
                    {
                        return "Zondag";
                    }
                default:
                    clDashFunction.Melding("Dagnummer(" + intDayno.ToString() + ") kan niet worden vertaald naar een geldige dagnaam", 1, "E");
                    return "Onbekend";
            }
        }

        public static void get_uitgevers(ListBox lbListBox)
        {
            DoSql mysql = new DoSql();
            mysql.vul_deze_listbox = lbListBox;
            mysql.DoQuery("SELECT PublCode " +
                          "FROM   DashPubl " +
                          "ORDER BY PublCode ");
            if (mysql.affected_rows == 0)
            {
                clDashFunction.Melding("Geen uitgevers geselecteerd", 1, "I");
            }
        }

        /// <summary>
        /// Get english full monthname based on monthnumber
        /// </summary>
        /// <param name="intMonthNumber"></param>
        /// <returns></returns>
        public static string get_monthname(int intMonthNumber)
        {
            string strMonthName = "Unknown";

            string[] strMonthNames = new string[12];
            strMonthNames[0] = "January";
            strMonthNames[1] = "February";
            strMonthNames[2] = "March";
            strMonthNames[3] = "April";
            strMonthNames[4] = "May";
            strMonthNames[5] = "June";
            strMonthNames[6] = "July";
            strMonthNames[7] = "August";
            strMonthNames[8] = "September";
            strMonthNames[9] = "October";
            strMonthNames[10] = "November";
            strMonthNames[11] = "December";

            if (intMonthNumber > 0 && intMonthNumber < 13)
            {
                strMonthName = strMonthNames[intMonthNumber - 1];
            }

            return strMonthName;
        }

        public static Boolean isValidDate(string strDate)
        {
            Boolean isDate = true;
            DateTime dt;

            try
            {
                dt = DateTime.Parse(strDate);
            }

            catch
            {
                isDate = false;
            }

            return isDate;
        }

        public static string convert_date(string strDateIn)
        {
            // Input: 20141125
            // Output: 2014-11-25
            DateTime dtDateOut;
            string strDateOut = strDateIn;
            if (strDateIn.Length == 8)
            {
                string strYear = strDateIn.Substring(0, 4);
                string strMonth = strDateIn.Substring(4, 2);
                string strDay = strDateIn.Substring(6, 2);

                strDateOut = strYear + "-" + strMonth + "-" + strDay + " 00:00:00";

                dtDateOut = Convert.ToDateTime(strDateOut);

                strDateOut = dtDateOut.ToString();
                if (isValidDate(strDateOut) == false)
                {
                    Melding("Datum " + strDateOut + " is geen geldige datum");
                }
            }
            else
            {
                Melding("Lengte van inputdatum moet gelijk zijn aan 8 characters");
            }
            return strDateOut;
        }

        public static bool isNumeric(string val, System.Globalization.NumberStyles NumberStyle)
        {
            Double result;
            return Double.TryParse(val, NumberStyle,
                System.Globalization.CultureInfo.CurrentCulture, out result);
        }

        public static bool isNumeric(string val)
        {
            return isNumeric(val, System.Globalization.NumberStyles.Integer);
        }

        public static string get_word(string strInput, short shWord_index)
        {
            string strReturn_word;

            if (shWord_index < 0)
            {
                clDashFunction.Melding("Index mag niet kleiner zijn dan 0", 1, "I");
                strReturn_word = "";
            }
            string[] strarInput = Regex.Split(strInput, " ");
            if (shWord_index > strarInput.Length)
            {
                clDashFunction.Melding("Index groter dan het aantal woorden in de string", 1, "I");
                strReturn_word = "";
            }
            else
            {
                strReturn_word = strarInput[shWord_index];
            }
            return strReturn_word;
        }

        /// <summary>
        /// Convert array to string
        /// Input arg1: AA
        ///             BB
        ///             CC
        ///             
        ///       arg2: @delim
        ///        
        /// Output: AA @delim BB @delim CC
        /// </summary>
        /// <param name="arArray"></param>
        /// <returns>strString</returns>
        public static string fromarray2string(ArrayList arArray, string strDelim)
        {
            string strString = "";
            foreach (string strKey in arArray)
            {
                strString = strString + strDelim + strKey;
            }
            // Remove  first delimiter:
            strString = strString.Substring(strDelim.Length, strString.Length - strDelim.Length);
            return strString;
        }

        /// <summary>
        /// Convert array to string
        /// Input arg1: AA
        ///             BB
        ///             CC
        ///             
        ///        
        /// Output: AA | BB | CC
        /// </summary>
        /// <param name="arArray"></param>
        /// <returns>strString</returns>
        public static string fromarray2string(ArrayList arArray)
        {
            string strDelim = " | ";

            return fromarray2string(arArray, strDelim);
        }

        public static StreamWriter open4write(string strFile)
        {
            //if (File.Exists(strFile))
            //{
            StreamWriter sw = new StreamWriter(strFile);
            return sw;
            //}
            //else
            // {
            //  clDashFunction.Melding("Het te openen bestand " + strFile + " bestaat niet (meer)", 1, "E");
            //    return null;
            // }
        }

        /*
        public static StreamReader open4read(string strFile)
        {
            // Overload versie zonder RETRY mogelijkheid en NO talking
            return open4read(strFile, false,false);
        }

        public static StreamReader open4read(string strFile,Boolean bTalk)
        {
            // Overload versie zonder RETRY mogelijkheid MET talk
            return open4read(strFile,false,bTalk);
        }

        public static StreamReader open4read(string strFile, Boolean bAllowRetry,Boolean bTalk)
        */
        public static StreamReader open4read(string strFile)
        {
            int intMaxTries = 1;

            //if (bAllowRetry)
            //{ 
            //    intMaxTries = 10;
            // }

            int intTry = 0;

            if (File.Exists(strFile))
            {
                while (intTry < intMaxTries)
                {
                    try
                    {
                        StreamReader sr = new StreamReader(strFile);
                        return sr;
                    }
                    catch (IOException e)
                    {
                        if (intTry >= intMaxTries)
                        {

                            Melding("Heb " + strFile + " niet kunnen openen ín " + intTry.ToString() + " pogingen. Error: " + e.Message, 1, "E");
                            return null;
                        }
                        else
                        {
                            Thread.Sleep(1000);
                            intTry++;
                        }
                    }
                }
            }
            else
            {
                clDashFunction.Melding("Het te openen bestand " + strFile + " bestaat niet (meer)", 1, "E");
                return null;
            }
            return null;
        }

        public static Boolean Write2File(string strValue, string strFileId, Boolean bTalk)
        {
            Boolean bReturn = false;

            if (!File.Exists(strFileId))
            {
                if (bTalk)
                {
                    clDashFunction.Melding("Path or filename (" + strFileId + ") not found ", 1, "E");
                }
            }
            else
            {
                StreamWriter sw = clDashFunction.open4write(strFileId);
                if (sw != null)
                {
                    try
                    {
                        sw.WriteLine(strValue);
                        sw.Close();
                        bReturn = true;
                    }
                    catch (Exception e)
                    {
                        if (bTalk)
                        {
                            clDashFunction.Melding("Error during write to (" + strFileId + ") \n\n " + e.Message, 1, "E");
                        }
                    }
                }
            }

            return bReturn;
        }

        public static Boolean Write2File(string strValue, string strFileId)
        {
            return Write2File(strValue, strFileId, false);
        }

        public static Boolean is_file_empty(string strFile_id)
        {
            System.IO.FileInfo fi = new System.IO.FileInfo(strFile_id);
            return (fi.Length == 0);
        }

        private static Boolean is_in_range(short shValue, short shFrom, short shTo)
        {
            if (shValue >= shFrom && shValue <= shTo)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static Boolean is_valid_hour(string strHour)
        {
            if (!isNumeric(strHour))
            {
                return false;
            }
            return is_in_range(Convert.ToInt16(strHour), 0, 24);
        }

        public static Boolean is_valid_dayno(string strDayno)
        {
            if (!isNumeric(strDayno))
            {
                return false;
            }
            return is_in_range(Convert.ToInt16(strDayno), 1, 7);
        }

        public static Boolean is_valid_minute(string strMinute)
        {
            if (!isNumeric(strMinute))
            {
                return false;
            }
            return is_in_range(Convert.ToInt16(strMinute), 0, 59);
        }

        //Tijdelijk, totdat het 'echte' command is uitgebreid met een variabele check op exists() 


        public static void do_wincmd(string strWinCmd, string strCmdParm, Boolean bShowWindow)
        {
            if (File.Exists(strWinCmd))
            {
                System.Diagnostics.Process proc = new System.Diagnostics.Process();
                proc.EnableRaisingEvents = false;
                proc.StartInfo.FileName = strWinCmd;
                proc.StartInfo.Arguments = strCmdParm;
                proc.StartInfo.CreateNoWindow = true;
                if (bShowWindow)
                {
                    proc.StartInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Normal;
                }
                else
                {
                    proc.StartInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;

                }
                if (!proc.Start())
                {
                    clDashFunction.Melding("Het proces kan niet (goed) worden gestart", 1, "E");
                }
                // proc.WaitForExit();
                proc.Dispose();
            }
            else
            {
                if (bShowWindow)
                {
                    Melding("Windows command (" + strWinCmd + ") bestaat niet !", 1, "E");
                }
            }
        }
        public static void Notepad(string strFile_id)
        {
            do_wincmd("c:\\Windows\\System32\\notepad.exe", strFile_id, true);
        }



        public static Boolean isTag(string strTag)
        {
            Boolean bIsTag = false;

            if (strTag.Contains("["))
            {
                if (strTag.Contains("]"))
                {
                    bIsTag = true;
                }
            }
            return bIsTag;
        }

        /// <summary>
        /// Update de INI file met een nieuwe waarde..
        /// Schrijf de oorspronkelijke file inclusief de wijziging door naar een nieuwe versie 
        /// met de toevoeging aan de extensie "_temp_new_file"
        /// Na afloop: replace de oorspronkelijke file door de zojuist geschreven nieuwe file 
        /// </summary>
        /// <param name="strIniFile"></param>
        /// <param name="strTag"></param>
        /// <param name="strTagValue"></param>
        public static void update_ini_tag_value(string strIniFile, string strTag, string strTagValue)
        {
            Boolean bExists_ini = false;
            Boolean bWriteNext = false;
            string strTagRecord = "";
            string strIniFile_new = strIniFile + "_temp_new_file";
            string strIniFile_bak = strIniFile + "_bakkebak";
            ArrayList alNewRecords = new ArrayList();

            // Open de originele INI file 4 READ
            StreamReader sr = clDashFunction.open4read(strIniFile);

            if (sr != null)
            {
                bExists_ini = true;

                // Open de nieuwe INI file 4 WRITE
                StreamWriter sw = clDashFunction.open4write(strIniFile_new);

                while (!sr.EndOfStream)
                {
                    strTagRecord = sr.ReadLine();
                    if (bWriteNext)
                    {
                        // alNewRecords.Add(alTagValue);
                        sw.WriteLine(strTagValue);
                        bWriteNext = false;
                    }
                    else
                    {
                        if (strTagRecord == strTag)
                        {
                            bWriteNext = true;
                        }

                        // alNewRecords.Add(strTagRecord);
                        sw.WriteLine(strTagRecord);
                    }
                }

                sr.Close();
                sw.Close();

                File.Replace(strIniFile_new, strIniFile, strIniFile_bak);
            }

            if (!bExists_ini)
            {
                clDashFunction.Melding("Something is terribly wrong; ini file " + strIniFile + " does not exist !", 1, "E");
            }
        }


        /// <summary>
        /// Count words with Regex.
        /// </summary>
        public static int count_words(string s)
        {
            MatchCollection collection = Regex.Matches(s, @"[\S]+");
            return collection.Count;
        }

        public static string fromS2DHMS(double dblSeconds, Boolean bSuppress0Days)
        {
            // Converteer van seconden naar Dagen, Uren:Minuten:Seconden
            // Input: 14838
            // Output: 
            // 4 dag(en), 3 uur, 12 minuten, 17 seconden
            //               WAARBIJ
            // als het aantal dagen 0 is en er is via de boolean
            // aangegeven dat dan het aantal dagen niet moet worden
            // getoond, dan is de output als volgt:
            // 3 uur, 12 minuten, 17 seconden

            string strDHMS = "";

            int intDays;
            int intHours;
            int intMinutes;
            int intSeconds;

            TimeSpan ts = TimeSpan.FromSeconds(dblSeconds);

            intDays = ts.Days;
            intHours = ts.Hours;
            intMinutes = ts.Minutes;
            intSeconds = ts.Seconds;

            if (intDays > 0 || !bSuppress0Days)
            {
                strDHMS = intDays.ToString().PadLeft(2, '0') + " dag(en),";
            }
            strDHMS = strDHMS + ts.Hours.ToString().PadLeft(2, '0') + " uur, ";
            strDHMS = strDHMS + ts.Minutes.ToString().PadLeft(2, '0') + " min., ";
            strDHMS = strDHMS + ts.Seconds.ToString().PadLeft(2, '0') + " sec.";
            return strDHMS;
        }

        /// <summary>
        /// Convert seconds into mm:ss
        /// </summary>
        /// <param name="dblSeconds"></param>
        /// <returns></returns>
        public static string fromS2MS(int intSeconds)
        {
            // This function only reports minutes and seconds.  
            // If the inputvalue it (too) large ands exceeds the 59:59 representation, 
            // a different function (fromS2DHMS) will be executed in order to return the inputvalue in the following format: 0n dag(en), 0n uur, 0n min., 0n sec.
            if (intSeconds > 3599)
            {
                return fromS2DHMS(intSeconds, true);
            }
            else
            {
                return (intSeconds / 60).ToString("0#") + ":" + (intSeconds % 60).ToString("0#");
            }
        }
    }
}
