﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace dbDashboard
{
    public partial class cmpSearch : Component
    {
        public cmpSearch()
        {
            InitializeComponent();
        }

        public cmpSearch(IContainer container)
        {
            container.Add(this);

            InitializeComponent();
        }

        private void pnlSearch_Paint(object sender, PaintEventArgs e)
        {
            // 
            // pnlSearch
            // 
            this.pnlSearch.Controls.Add(this.cmdSearch);
            this.pnlSearch.Controls.Add(this.txtSearch);
            this.pnlSearch.Controls.Add(this.cmdReset);
            this.pnlSearch.Location = new System.Drawing.Point(753, 209);
            this.pnlSearch.Name = "pnlSearch";
            this.pnlSearch.Size = new System.Drawing.Size(160, 25);
            this.pnlSearch.TabIndex = 23;
            // 
        }       
       
    }
}
