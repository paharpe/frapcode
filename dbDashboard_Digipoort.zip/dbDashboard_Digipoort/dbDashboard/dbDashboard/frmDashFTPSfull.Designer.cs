﻿namespace dbDashboard
{
    partial class frmDashFTPSfull
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDashFTPSfull));
            this.grbTransferLog = new System.Windows.Forms.GroupBox();
            this.lblTransferLog = new System.Windows.Forms.Label();
            this.pnlSearch_transfer = new System.Windows.Forms.Panel();
            this.cmdSearch_transfer = new System.Windows.Forms.Button();
            this.txtSearch_transfer = new System.Windows.Forms.TextBox();
            this.cmdSall_transfer = new System.Windows.Forms.Button();
            this.dgTransferLog = new System.Windows.Forms.DataGridView();
            this.colTransferServer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grbSelect = new System.Windows.Forms.GroupBox();
            this.lblDebug = new System.Windows.Forms.Label();
            this.cbTime = new DBDashboard.cbMaint();
            this.dtPicker = new System.Windows.Forms.DateTimePicker();
            this.grbTimeFrame = new System.Windows.Forms.GroupBox();
            this.grbTimeUpTo = new System.Windows.Forms.GroupBox();
            this.cmbToMinute = new dbDashboard.cmbMinute(this.components);
            this.cmbToHour = new dbDashboard.cmbHour(this.components);
            this.lblToHHMM = new System.Windows.Forms.Label();
            this.grbTimeFrom = new System.Windows.Forms.GroupBox();
            this.cmbFromMinute = new dbDashboard.cmbMinute(this.components);
            this.cmbFromHour = new dbDashboard.cmbHour(this.components);
            this.lblFromHHMM = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.grbEnvironment = new System.Windows.Forms.GroupBox();
            this.rbProduction = new System.Windows.Forms.RadioButton();
            this.rbPreProduction = new System.Windows.Forms.RadioButton();
            this.lblLocigal_min = new System.Windows.Forms.Label();
            this.txtLogical = new System.Windows.Forms.TextBox();
            this.lblLogical = new System.Windows.Forms.Label();
            this.cmdSelect = new System.Windows.Forms.Button();
            this.grbCommandLog = new System.Windows.Forms.GroupBox();
            this.lblCommandLog = new System.Windows.Forms.Label();
            this.pnlSearch = new System.Windows.Forms.Panel();
            this.cmdSearch = new System.Windows.Forms.Button();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.cmdSall = new System.Windows.Forms.Button();
            this.dgCommandLog = new System.Windows.Forms.DataGridView();
            this.colCommandServer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grbFilesIn = new System.Windows.Forms.GroupBox();
            this.lblFilesIn = new System.Windows.Forms.Label();
            this.dgFilesIn = new System.Windows.Forms.DataGridView();
            this.colFileInName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFileInTimeStamp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFileInSize = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grbFilesOut = new System.Windows.Forms.GroupBox();
            this.lblFilesOut = new System.Windows.Forms.Label();
            this.dgFilesOut = new System.Windows.Forms.DataGridView();
            this.colFileOutName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFileOutTimeStamp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFileOutSize = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cmdReset = new System.Windows.Forms.Button();
            this.trackBar2 = new System.Windows.Forms.TrackBar();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.grbConnect.SuspendLayout();
            this.grbTransferLog.SuspendLayout();
            this.pnlSearch_transfer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgTransferLog)).BeginInit();
            this.grbSelect.SuspendLayout();
            this.grbTimeFrame.SuspendLayout();
            this.grbTimeUpTo.SuspendLayout();
            this.grbTimeFrom.SuspendLayout();
            this.grbEnvironment.SuspendLayout();
            this.grbCommandLog.SuspendLayout();
            this.pnlSearch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgCommandLog)).BeginInit();
            this.grbFilesIn.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgFilesIn)).BeginInit();
            this.grbFilesOut.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgFilesOut)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            this.SuspendLayout();
            // 
            // cmdAfsluiten
            // 
            this.cmdAfsluiten.Location = new System.Drawing.Point(12, 895);
            this.cmdAfsluiten.TabIndex = 5;
            // 
            // grbConnect
            // 
            this.grbConnect.Location = new System.Drawing.Point(369, 943);
            // 
            // lblHostName
            // 
            this.lblHostName.Location = new System.Drawing.Point(1322, 917);
            this.lblHostName.Size = new System.Drawing.Size(145, 13);
            this.lblHostName.TabIndex = 6;
            this.lblHostName.Text = "KPNNL\\WLD4BED923B63C";
            // 
            // grbTransferLog
            // 
            this.grbTransferLog.Controls.Add(this.lblTransferLog);
            this.grbTransferLog.Controls.Add(this.pnlSearch_transfer);
            this.grbTransferLog.Controls.Add(this.dgTransferLog);
            this.grbTransferLog.Location = new System.Drawing.Point(12, 409);
            this.grbTransferLog.Name = "grbTransferLog";
            this.grbTransferLog.Size = new System.Drawing.Size(1330, 235);
            this.grbTransferLog.TabIndex = 2;
            this.grbTransferLog.TabStop = false;
            this.grbTransferLog.Text = "OTP_transfer log";
            // 
            // lblTransferLog
            // 
            this.lblTransferLog.AutoSize = true;
            this.lblTransferLog.Location = new System.Drawing.Point(91, 1);
            this.lblTransferLog.Name = "lblTransferLog";
            this.lblTransferLog.Size = new System.Drawing.Size(44, 13);
            this.lblTransferLog.TabIndex = 25;
            this.lblTransferLog.Text = "0 row(s)";
            // 
            // pnlSearch_transfer
            // 
            this.pnlSearch_transfer.Controls.Add(this.cmdSearch_transfer);
            this.pnlSearch_transfer.Controls.Add(this.txtSearch_transfer);
            this.pnlSearch_transfer.Controls.Add(this.cmdSall_transfer);
            this.pnlSearch_transfer.Location = new System.Drawing.Point(1162, 205);
            this.pnlSearch_transfer.Name = "pnlSearch_transfer";
            this.pnlSearch_transfer.Size = new System.Drawing.Size(160, 25);
            this.pnlSearch_transfer.TabIndex = 24;
            // 
            // cmdSearch_transfer
            // 
            this.cmdSearch_transfer.Image = ((System.Drawing.Image)(resources.GetObject("cmdSearch_transfer.Image")));
            this.cmdSearch_transfer.Location = new System.Drawing.Point(104, 1);
            this.cmdSearch_transfer.Name = "cmdSearch_transfer";
            this.cmdSearch_transfer.Size = new System.Drawing.Size(26, 23);
            this.cmdSearch_transfer.TabIndex = 23;
            this.cmdSearch_transfer.Tag = "dgTransferLog";
            this.cmdSearch_transfer.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.cmdSearch_transfer.UseVisualStyleBackColor = true;
            this.cmdSearch_transfer.Click += new System.EventHandler(this.cmdSearch_Click);
            // 
            // txtSearch_transfer
            // 
            this.txtSearch_transfer.Location = new System.Drawing.Point(3, 3);
            this.txtSearch_transfer.MaxLength = 20;
            this.txtSearch_transfer.Name = "txtSearch_transfer";
            this.txtSearch_transfer.Size = new System.Drawing.Size(100, 20);
            this.txtSearch_transfer.TabIndex = 21;
            this.txtSearch_transfer.TextChanged += new System.EventHandler(this.txtSearch_transfer_TextChanged);
            // 
            // cmdSall_transfer
            // 
            this.cmdSall_transfer.Location = new System.Drawing.Point(131, 1);
            this.cmdSall_transfer.Name = "cmdSall_transfer";
            this.cmdSall_transfer.Size = new System.Drawing.Size(26, 23);
            this.cmdSall_transfer.TabIndex = 22;
            this.cmdSall_transfer.Tag = "dgTransferLog";
            this.cmdSall_transfer.Text = "All";
            this.cmdSall_transfer.UseVisualStyleBackColor = true;
            this.cmdSall_transfer.Click += new System.EventHandler(this.cmdSall_Click);
            // 
            // dgTransferLog
            // 
            this.dgTransferLog.AllowUserToAddRows = false;
            this.dgTransferLog.AllowUserToDeleteRows = false;
            this.dgTransferLog.AllowUserToOrderColumns = true;
            this.dgTransferLog.AllowUserToResizeRows = false;
            this.dgTransferLog.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgTransferLog.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colTransferServer,
            this.dataGridViewTextBoxColumn1});
            this.dgTransferLog.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgTransferLog.Location = new System.Drawing.Point(16, 19);
            this.dgTransferLog.MultiSelect = false;
            this.dgTransferLog.Name = "dgTransferLog";
            this.dgTransferLog.RowHeadersVisible = false;
            this.dgTransferLog.ShowCellErrors = false;
            this.dgTransferLog.ShowCellToolTips = false;
            this.dgTransferLog.ShowEditingIcon = false;
            this.dgTransferLog.ShowRowErrors = false;
            this.dgTransferLog.Size = new System.Drawing.Size(1301, 179);
            this.dgTransferLog.TabIndex = 0;
            this.dgTransferLog.Click += new System.EventHandler(this.dgTransferLog_Click);
            // 
            // colTransferServer
            // 
            this.colTransferServer.FillWeight = 50F;
            this.colTransferServer.HeaderText = "Server";
            this.colTransferServer.MaxInputLength = 8;
            this.colTransferServer.MinimumWidth = 75;
            this.colTransferServer.Name = "colTransferServer";
            this.colTransferServer.Width = 75;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.FillWeight = 500F;
            this.dataGridViewTextBoxColumn1.HeaderText = "Transferlog record";
            this.dataGridViewTextBoxColumn1.MaxInputLength = 250;
            this.dataGridViewTextBoxColumn1.MinimumWidth = 1250;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 1250;
            // 
            // grbSelect
            // 
            this.grbSelect.Controls.Add(this.lblDebug);
            this.grbSelect.Controls.Add(this.cbTime);
            this.grbSelect.Controls.Add(this.dtPicker);
            this.grbSelect.Controls.Add(this.grbTimeFrame);
            this.grbSelect.Controls.Add(this.lblDate);
            this.grbSelect.Controls.Add(this.grbEnvironment);
            this.grbSelect.Controls.Add(this.lblLocigal_min);
            this.grbSelect.Controls.Add(this.txtLogical);
            this.grbSelect.Controls.Add(this.lblLogical);
            this.grbSelect.Controls.Add(this.cmdSelect);
            this.grbSelect.Location = new System.Drawing.Point(12, 25);
            this.grbSelect.Name = "grbSelect";
            this.grbSelect.Size = new System.Drawing.Size(1330, 130);
            this.grbSelect.TabIndex = 0;
            this.grbSelect.TabStop = false;
            this.grbSelect.Text = "Criteria";
            // 
            // lblDebug
            // 
            this.lblDebug.AutoSize = true;
            this.lblDebug.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDebug.Location = new System.Drawing.Point(958, 16);
            this.lblDebug.Name = "lblDebug";
            this.lblDebug.Size = new System.Drawing.Size(283, 73);
            this.lblDebug.TabIndex = 9;
            this.lblDebug.Text = "Debug !!";
            this.lblDebug.Visible = false;
            // 
            // cbTime
            // 
            this.cbTime.AutoSize = true;
            this.cbTime.bChanged = false;
            this.cbTime.BitValue = ((short)(0));
            this.cbTime.Location = new System.Drawing.Point(605, 19);
            this.cbTime.Name = "cbTime";
            this.cbTime.OldValue = false;
            this.cbTime.Size = new System.Drawing.Size(107, 17);
            this.cbTime.TabIndex = 6;
            this.cbTime.Text = "Selection on time";
            this.cbTime.UseVisualStyleBackColor = true;
            this.cbTime.CheckedChanged += new System.EventHandler(this.cbTimeFrame_CheckedChanged);
            // 
            // dtPicker
            // 
            this.dtPicker.Location = new System.Drawing.Point(137, 62);
            this.dtPicker.Name = "dtPicker";
            this.dtPicker.Size = new System.Drawing.Size(200, 20);
            this.dtPicker.TabIndex = 4;
            // 
            // grbTimeFrame
            // 
            this.grbTimeFrame.Controls.Add(this.grbTimeUpTo);
            this.grbTimeFrame.Controls.Add(this.grbTimeFrom);
            this.grbTimeFrame.Location = new System.Drawing.Point(605, 32);
            this.grbTimeFrame.Name = "grbTimeFrame";
            this.grbTimeFrame.Size = new System.Drawing.Size(329, 86);
            this.grbTimeFrame.TabIndex = 7;
            this.grbTimeFrame.TabStop = false;
            // 
            // grbTimeUpTo
            // 
            this.grbTimeUpTo.Controls.Add(this.cmbToMinute);
            this.grbTimeUpTo.Controls.Add(this.cmbToHour);
            this.grbTimeUpTo.Controls.Add(this.lblToHHMM);
            this.grbTimeUpTo.Location = new System.Drawing.Point(168, 13);
            this.grbTimeUpTo.Name = "grbTimeUpTo";
            this.grbTimeUpTo.Size = new System.Drawing.Size(113, 60);
            this.grbTimeUpTo.TabIndex = 3;
            this.grbTimeUpTo.TabStop = false;
            this.grbTimeUpTo.Text = "To";
            // 
            // cmbToMinute
            // 
            this.cmbToMinute.bChanged = false;
            this.cmbToMinute.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbToMinute.FormattingEnabled = true;
            this.cmbToMinute.intMinute = 0;
            this.cmbToMinute.Items.AddRange(new object[] {
            "00",
            "01",
            "02",
            "03",
            "04",
            "05",
            "06",
            "07",
            "08",
            "09",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31",
            "32",
            "33",
            "34",
            "35",
            "36",
            "37",
            "38",
            "39",
            "40",
            "41",
            "42",
            "43",
            "44",
            "45",
            "46",
            "47",
            "48",
            "49",
            "50",
            "51",
            "52",
            "53",
            "54",
            "55",
            "56",
            "57",
            "58",
            "59"});
            this.cmbToMinute.Location = new System.Drawing.Point(54, 31);
            this.cmbToMinute.Name = "cmbToMinute";
            this.cmbToMinute.Size = new System.Drawing.Size(45, 21);
            this.cmbToMinute.TabIndex = 2;
            // 
            // cmbToHour
            // 
            this.cmbToHour.bChanged = false;
            this.cmbToHour.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbToHour.FormattingEnabled = true;
            this.cmbToHour.intHour = 0;
            this.cmbToHour.Items.AddRange(new object[] {
            "00",
            "01",
            "02",
            "03",
            "04",
            "05",
            "06",
            "07",
            "08",
            "09",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23"});
            this.cmbToHour.Location = new System.Drawing.Point(10, 31);
            this.cmbToHour.Name = "cmbToHour";
            this.cmbToHour.Size = new System.Drawing.Size(43, 21);
            this.cmbToHour.TabIndex = 1;
            // 
            // lblToHHMM
            // 
            this.lblToHHMM.AutoSize = true;
            this.lblToHHMM.Location = new System.Drawing.Point(34, 15);
            this.lblToHHMM.Name = "lblToHHMM";
            this.lblToHHMM.Size = new System.Drawing.Size(44, 13);
            this.lblToHHMM.TabIndex = 0;
            this.lblToHHMM.Text = "HH:MM";
            // 
            // grbTimeFrom
            // 
            this.grbTimeFrom.Controls.Add(this.cmbFromMinute);
            this.grbTimeFrom.Controls.Add(this.cmbFromHour);
            this.grbTimeFrom.Controls.Add(this.lblFromHHMM);
            this.grbTimeFrom.Location = new System.Drawing.Point(22, 13);
            this.grbTimeFrom.Name = "grbTimeFrom";
            this.grbTimeFrom.Size = new System.Drawing.Size(113, 60);
            this.grbTimeFrom.TabIndex = 2;
            this.grbTimeFrom.TabStop = false;
            this.grbTimeFrom.Text = "From";
            // 
            // cmbFromMinute
            // 
            this.cmbFromMinute.bChanged = false;
            this.cmbFromMinute.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFromMinute.FormattingEnabled = true;
            this.cmbFromMinute.intMinute = 0;
            this.cmbFromMinute.Items.AddRange(new object[] {
            "00",
            "01",
            "02",
            "03",
            "04",
            "05",
            "06",
            "07",
            "08",
            "09",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31",
            "32",
            "33",
            "34",
            "35",
            "36",
            "37",
            "38",
            "39",
            "40",
            "41",
            "42",
            "43",
            "44",
            "45",
            "46",
            "47",
            "48",
            "49",
            "50",
            "51",
            "52",
            "53",
            "54",
            "55",
            "56",
            "57",
            "58",
            "59"});
            this.cmbFromMinute.Location = new System.Drawing.Point(54, 31);
            this.cmbFromMinute.Name = "cmbFromMinute";
            this.cmbFromMinute.Size = new System.Drawing.Size(45, 21);
            this.cmbFromMinute.TabIndex = 2;
            // 
            // cmbFromHour
            // 
            this.cmbFromHour.bChanged = false;
            this.cmbFromHour.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFromHour.FormattingEnabled = true;
            this.cmbFromHour.intHour = 0;
            this.cmbFromHour.Items.AddRange(new object[] {
            "00",
            "01",
            "02",
            "03",
            "04",
            "05",
            "06",
            "07",
            "08",
            "09",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23"});
            this.cmbFromHour.Location = new System.Drawing.Point(10, 31);
            this.cmbFromHour.Name = "cmbFromHour";
            this.cmbFromHour.Size = new System.Drawing.Size(43, 21);
            this.cmbFromHour.TabIndex = 1;
            // 
            // lblFromHHMM
            // 
            this.lblFromHHMM.AutoSize = true;
            this.lblFromHHMM.Location = new System.Drawing.Point(34, 15);
            this.lblFromHHMM.Name = "lblFromHHMM";
            this.lblFromHHMM.Size = new System.Drawing.Size(44, 13);
            this.lblFromHHMM.TabIndex = 0;
            this.lblFromHHMM.Text = "HH:MM";
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Location = new System.Drawing.Point(6, 68);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(33, 13);
            this.lblDate.TabIndex = 3;
            this.lblDate.Text = "Date:";
            // 
            // grbEnvironment
            // 
            this.grbEnvironment.Controls.Add(this.rbProduction);
            this.grbEnvironment.Controls.Add(this.rbPreProduction);
            this.grbEnvironment.Location = new System.Drawing.Point(397, 32);
            this.grbEnvironment.Name = "grbEnvironment";
            this.grbEnvironment.Size = new System.Drawing.Size(200, 86);
            this.grbEnvironment.TabIndex = 5;
            this.grbEnvironment.TabStop = false;
            this.grbEnvironment.Text = "Environment";
            // 
            // rbProduction
            // 
            this.rbProduction.AutoSize = true;
            this.rbProduction.Location = new System.Drawing.Point(10, 17);
            this.rbProduction.Name = "rbProduction";
            this.rbProduction.Size = new System.Drawing.Size(76, 17);
            this.rbProduction.TabIndex = 0;
            this.rbProduction.TabStop = true;
            this.rbProduction.Text = "Production";
            this.rbProduction.UseVisualStyleBackColor = true;
            this.rbProduction.CheckedChanged += new System.EventHandler(this.rbProduction_CheckedChanged);
            // 
            // rbPreProduction
            // 
            this.rbPreProduction.AutoSize = true;
            this.rbPreProduction.Location = new System.Drawing.Point(10, 48);
            this.rbPreProduction.Name = "rbPreProduction";
            this.rbPreProduction.Size = new System.Drawing.Size(92, 17);
            this.rbPreProduction.TabIndex = 1;
            this.rbPreProduction.TabStop = true;
            this.rbPreProduction.Text = "PreProduction";
            this.rbPreProduction.UseVisualStyleBackColor = true;
            this.rbPreProduction.CheckedChanged += new System.EventHandler(this.rbPreProduction_CheckedChanged);
            // 
            // lblLocigal_min
            // 
            this.lblLocigal_min.AutoSize = true;
            this.lblLocigal_min.Location = new System.Drawing.Point(279, 32);
            this.lblLocigal_min.Name = "lblLocigal_min";
            this.lblLocigal_min.Size = new System.Drawing.Size(70, 13);
            this.lblLocigal_min.TabIndex = 2;
            this.lblLocigal_min.Text = "(min. 4 chars)";
            // 
            // txtLogical
            // 
            this.txtLogical.Location = new System.Drawing.Point(137, 29);
            this.txtLogical.Name = "txtLogical";
            this.txtLogical.Size = new System.Drawing.Size(136, 20);
            this.txtLogical.TabIndex = 1;
            this.txtLogical.TextChanged += new System.EventHandler(this.txtLogical_TextChanged);
            // 
            // lblLogical
            // 
            this.lblLogical.AutoSize = true;
            this.lblLogical.Location = new System.Drawing.Point(6, 32);
            this.lblLogical.Name = "lblLogical";
            this.lblLogical.Size = new System.Drawing.Size(127, 13);
            this.lblLogical.TabIndex = 0;
            this.lblLogical.Text = "Logical address contains:";
            // 
            // cmdSelect
            // 
            this.cmdSelect.Location = new System.Drawing.Point(1242, 95);
            this.cmdSelect.Name = "cmdSelect";
            this.cmdSelect.Size = new System.Drawing.Size(75, 23);
            this.cmdSelect.TabIndex = 8;
            this.cmdSelect.Text = "Select";
            this.cmdSelect.UseVisualStyleBackColor = true;
            this.cmdSelect.Click += new System.EventHandler(this.cmdSelect_Click);
            // 
            // grbCommandLog
            // 
            this.grbCommandLog.Controls.Add(this.lblCommandLog);
            this.grbCommandLog.Controls.Add(this.pnlSearch);
            this.grbCommandLog.Controls.Add(this.dgCommandLog);
            this.grbCommandLog.Location = new System.Drawing.Point(11, 164);
            this.grbCommandLog.Name = "grbCommandLog";
            this.grbCommandLog.Size = new System.Drawing.Size(1330, 233);
            this.grbCommandLog.TabIndex = 1;
            this.grbCommandLog.TabStop = false;
            this.grbCommandLog.Text = "OTP_command log";
            // 
            // lblCommandLog
            // 
            this.lblCommandLog.AutoSize = true;
            this.lblCommandLog.Location = new System.Drawing.Point(103, 1);
            this.lblCommandLog.Name = "lblCommandLog";
            this.lblCommandLog.Size = new System.Drawing.Size(44, 13);
            this.lblCommandLog.TabIndex = 26;
            this.lblCommandLog.Text = "0 row(s)";
            // 
            // pnlSearch
            // 
            this.pnlSearch.Controls.Add(this.cmdSearch);
            this.pnlSearch.Controls.Add(this.txtSearch);
            this.pnlSearch.Controls.Add(this.cmdSall);
            this.pnlSearch.Location = new System.Drawing.Point(1160, 202);
            this.pnlSearch.Name = "pnlSearch";
            this.pnlSearch.Size = new System.Drawing.Size(160, 25);
            this.pnlSearch.TabIndex = 23;
            // 
            // cmdSearch
            // 
            this.cmdSearch.Image = ((System.Drawing.Image)(resources.GetObject("cmdSearch.Image")));
            this.cmdSearch.Location = new System.Drawing.Point(104, 1);
            this.cmdSearch.Name = "cmdSearch";
            this.cmdSearch.Size = new System.Drawing.Size(26, 23);
            this.cmdSearch.TabIndex = 23;
            this.cmdSearch.Tag = "dgCommandLog";
            this.cmdSearch.UseVisualStyleBackColor = true;
            this.cmdSearch.Click += new System.EventHandler(this.cmdSearch_Click);
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(3, 3);
            this.txtSearch.MaxLength = 20;
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(100, 20);
            this.txtSearch.TabIndex = 21;
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            // 
            // cmdSall
            // 
            this.cmdSall.Location = new System.Drawing.Point(131, 1);
            this.cmdSall.Name = "cmdSall";
            this.cmdSall.Size = new System.Drawing.Size(26, 23);
            this.cmdSall.TabIndex = 22;
            this.cmdSall.Tag = "dgCommandLog";
            this.cmdSall.Text = "All";
            this.cmdSall.UseVisualStyleBackColor = true;
            this.cmdSall.Click += new System.EventHandler(this.cmdSall_Click);
            // 
            // dgCommandLog
            // 
            this.dgCommandLog.AllowUserToAddRows = false;
            this.dgCommandLog.AllowUserToDeleteRows = false;
            this.dgCommandLog.AllowUserToOrderColumns = true;
            this.dgCommandLog.AllowUserToResizeRows = false;
            this.dgCommandLog.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgCommandLog.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colCommandServer,
            this.dataGridViewTextBoxColumn2});
            this.dgCommandLog.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgCommandLog.Location = new System.Drawing.Point(16, 19);
            this.dgCommandLog.MultiSelect = false;
            this.dgCommandLog.Name = "dgCommandLog";
            this.dgCommandLog.RowHeadersVisible = false;
            this.dgCommandLog.ShowCellErrors = false;
            this.dgCommandLog.ShowCellToolTips = false;
            this.dgCommandLog.ShowEditingIcon = false;
            this.dgCommandLog.ShowRowErrors = false;
            this.dgCommandLog.Size = new System.Drawing.Size(1303, 179);
            this.dgCommandLog.TabIndex = 0;
            // 
            // colCommandServer
            // 
            this.colCommandServer.HeaderText = "Server";
            this.colCommandServer.MaxInputLength = 8;
            this.colCommandServer.MinimumWidth = 75;
            this.colCommandServer.Name = "colCommandServer";
            this.colCommandServer.Width = 75;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.FillWeight = 500F;
            this.dataGridViewTextBoxColumn2.HeaderText = "Commandlog record";
            this.dataGridViewTextBoxColumn2.MaxInputLength = 250;
            this.dataGridViewTextBoxColumn2.MinimumWidth = 1250;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 1250;
            // 
            // grbFilesIn
            // 
            this.grbFilesIn.Controls.Add(this.lblFilesIn);
            this.grbFilesIn.Controls.Add(this.dgFilesIn);
            this.grbFilesIn.Location = new System.Drawing.Point(12, 653);
            this.grbFilesIn.Name = "grbFilesIn";
            this.grbFilesIn.Size = new System.Drawing.Size(653, 206);
            this.grbFilesIn.TabIndex = 3;
            this.grbFilesIn.TabStop = false;
            this.grbFilesIn.Text = "/in";
            // 
            // lblFilesIn
            // 
            this.lblFilesIn.AutoSize = true;
            this.lblFilesIn.Location = new System.Drawing.Point(30, 1);
            this.lblFilesIn.Name = "lblFilesIn";
            this.lblFilesIn.Size = new System.Drawing.Size(44, 13);
            this.lblFilesIn.TabIndex = 1;
            this.lblFilesIn.Text = "0 row(s)";
            // 
            // dgFilesIn
            // 
            this.dgFilesIn.AllowUserToAddRows = false;
            this.dgFilesIn.AllowUserToDeleteRows = false;
            this.dgFilesIn.AllowUserToOrderColumns = true;
            this.dgFilesIn.AllowUserToResizeRows = false;
            this.dgFilesIn.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgFilesIn.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colFileInName,
            this.colFileInTimeStamp,
            this.colFileInSize});
            this.dgFilesIn.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgFilesIn.Location = new System.Drawing.Point(16, 22);
            this.dgFilesIn.MultiSelect = false;
            this.dgFilesIn.Name = "dgFilesIn";
            this.dgFilesIn.RowHeadersVisible = false;
            this.dgFilesIn.ShowCellErrors = false;
            this.dgFilesIn.ShowCellToolTips = false;
            this.dgFilesIn.ShowEditingIcon = false;
            this.dgFilesIn.ShowRowErrors = false;
            this.dgFilesIn.Size = new System.Drawing.Size(628, 153);
            this.dgFilesIn.TabIndex = 0;
            this.dgFilesIn.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgFilesIn_CellContentClick);
            // 
            // colFileInName
            // 
            this.colFileInName.HeaderText = "FileName";
            this.colFileInName.MaxInputLength = 100;
            this.colFileInName.MinimumWidth = 335;
            this.colFileInName.Name = "colFileInName";
            this.colFileInName.Width = 335;
            // 
            // colFileInTimeStamp
            // 
            this.colFileInTimeStamp.FillWeight = 215F;
            this.colFileInTimeStamp.HeaderText = "TimeStamp";
            this.colFileInTimeStamp.MaxInputLength = 100;
            this.colFileInTimeStamp.Name = "colFileInTimeStamp";
            this.colFileInTimeStamp.Width = 215;
            // 
            // colFileInSize
            // 
            this.colFileInSize.FillWeight = 75F;
            this.colFileInSize.HeaderText = "# Bytes";
            this.colFileInSize.MaxInputLength = 12;
            this.colFileInSize.Name = "colFileInSize";
            this.colFileInSize.Width = 75;
            // 
            // grbFilesOut
            // 
            this.grbFilesOut.Controls.Add(this.lblFilesOut);
            this.grbFilesOut.Controls.Add(this.dgFilesOut);
            this.grbFilesOut.Location = new System.Drawing.Point(677, 653);
            this.grbFilesOut.Name = "grbFilesOut";
            this.grbFilesOut.Size = new System.Drawing.Size(664, 206);
            this.grbFilesOut.TabIndex = 4;
            this.grbFilesOut.TabStop = false;
            this.grbFilesOut.Text = "/out";
            // 
            // lblFilesOut
            // 
            this.lblFilesOut.AutoSize = true;
            this.lblFilesOut.Location = new System.Drawing.Point(30, 1);
            this.lblFilesOut.Name = "lblFilesOut";
            this.lblFilesOut.Size = new System.Drawing.Size(44, 13);
            this.lblFilesOut.TabIndex = 2;
            this.lblFilesOut.Text = "0 row(s)";
            // 
            // dgFilesOut
            // 
            this.dgFilesOut.AllowUserToAddRows = false;
            this.dgFilesOut.AllowUserToDeleteRows = false;
            this.dgFilesOut.AllowUserToOrderColumns = true;
            this.dgFilesOut.AllowUserToResizeRows = false;
            this.dgFilesOut.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgFilesOut.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colFileOutName,
            this.colFileOutTimeStamp,
            this.colFileOutSize});
            this.dgFilesOut.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgFilesOut.Location = new System.Drawing.Point(21, 22);
            this.dgFilesOut.MultiSelect = false;
            this.dgFilesOut.Name = "dgFilesOut";
            this.dgFilesOut.RowHeadersVisible = false;
            this.dgFilesOut.ShowCellErrors = false;
            this.dgFilesOut.ShowCellToolTips = false;
            this.dgFilesOut.ShowEditingIcon = false;
            this.dgFilesOut.ShowRowErrors = false;
            this.dgFilesOut.Size = new System.Drawing.Size(628, 153);
            this.dgFilesOut.TabIndex = 0;
            // 
            // colFileOutName
            // 
            this.colFileOutName.FillWeight = 500F;
            this.colFileOutName.HeaderText = "FileName";
            this.colFileOutName.MaxInputLength = 250;
            this.colFileOutName.MinimumWidth = 335;
            this.colFileOutName.Name = "colFileOutName";
            this.colFileOutName.Width = 335;
            // 
            // colFileOutTimeStamp
            // 
            this.colFileOutTimeStamp.FillWeight = 215F;
            this.colFileOutTimeStamp.HeaderText = "TimeStamp";
            this.colFileOutTimeStamp.MaxInputLength = 100;
            this.colFileOutTimeStamp.MinimumWidth = 215;
            this.colFileOutTimeStamp.Name = "colFileOutTimeStamp";
            this.colFileOutTimeStamp.Width = 215;
            // 
            // colFileOutSize
            // 
            this.colFileOutSize.FillWeight = 75F;
            this.colFileOutSize.HeaderText = "# Bytes";
            this.colFileOutSize.MaxInputLength = 8;
            this.colFileOutSize.MinimumWidth = 75;
            this.colFileOutSize.Name = "colFileOutSize";
            this.colFileOutSize.Width = 75;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.cmdReset);
            this.panel1.Controls.Add(this.trackBar2);
            this.panel1.Controls.Add(this.trackBar1);
            this.panel1.Location = new System.Drawing.Point(1343, 170);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(92, 471);
            this.panel1.TabIndex = 31;
            // 
            // cmdReset
            // 
            this.cmdReset.Location = new System.Drawing.Point(21, 200);
            this.cmdReset.Name = "cmdReset";
            this.cmdReset.Size = new System.Drawing.Size(44, 70);
            this.cmdReset.TabIndex = 33;
            this.cmdReset.Text = "Reset";
            this.cmdReset.UseVisualStyleBackColor = true;
            this.cmdReset.Click += new System.EventHandler(this.cmdReset_Click);
            // 
            // trackBar2
            // 
            this.trackBar2.Location = new System.Drawing.Point(26, 12);
            this.trackBar2.Minimum = -25;
            this.trackBar2.Name = "trackBar2";
            this.trackBar2.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackBar2.Size = new System.Drawing.Size(45, 186);
            this.trackBar2.TabIndex = 32;
            this.trackBar2.Scroll += new System.EventHandler(this.trackBar2_Scroll);
            // 
            // trackBar1
            // 
            this.trackBar1.Location = new System.Drawing.Point(26, 273);
            this.trackBar1.Minimum = -25;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackBar1.Size = new System.Drawing.Size(45, 188);
            this.trackBar1.TabIndex = 31;
            this.trackBar1.Scroll += new System.EventHandler(this.trackBar1_Scroll);
            // 
            // frmDashFTPSfull
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1465, 930);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.grbFilesOut);
            this.Controls.Add(this.grbFilesIn);
            this.Controls.Add(this.grbCommandLog);
            this.Controls.Add(this.grbTransferLog);
            this.Controls.Add(this.grbSelect);
            this.Name = "frmDashFTPSfull";
            this.Text = "frmDashFTPSfull";
            this.Load += new System.EventHandler(this.frmDashFTPSfull_Load);
            this.Controls.SetChildIndex(this.grbSelect, 0);
            this.Controls.SetChildIndex(this.grbTransferLog, 0);
            this.Controls.SetChildIndex(this.grbCommandLog, 0);
            this.Controls.SetChildIndex(this.grbFilesIn, 0);
            this.Controls.SetChildIndex(this.grbFilesOut, 0);
            this.Controls.SetChildIndex(this.cmdAfsluiten, 0);
            this.Controls.SetChildIndex(this.lblHostName, 0);
            this.Controls.SetChildIndex(this.grbConnect, 0);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.grbConnect.ResumeLayout(false);
            this.grbConnect.PerformLayout();
            this.grbTransferLog.ResumeLayout(false);
            this.grbTransferLog.PerformLayout();
            this.pnlSearch_transfer.ResumeLayout(false);
            this.pnlSearch_transfer.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgTransferLog)).EndInit();
            this.grbSelect.ResumeLayout(false);
            this.grbSelect.PerformLayout();
            this.grbTimeFrame.ResumeLayout(false);
            this.grbTimeUpTo.ResumeLayout(false);
            this.grbTimeUpTo.PerformLayout();
            this.grbTimeFrom.ResumeLayout(false);
            this.grbTimeFrom.PerformLayout();
            this.grbEnvironment.ResumeLayout(false);
            this.grbEnvironment.PerformLayout();
            this.grbCommandLog.ResumeLayout(false);
            this.grbCommandLog.PerformLayout();
            this.pnlSearch.ResumeLayout(false);
            this.pnlSearch.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgCommandLog)).EndInit();
            this.grbFilesIn.ResumeLayout(false);
            this.grbFilesIn.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgFilesIn)).EndInit();
            this.grbFilesOut.ResumeLayout(false);
            this.grbFilesOut.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgFilesOut)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grbTransferLog;
        private System.Windows.Forms.DataGridView dgTransferLog;
        private System.Windows.Forms.GroupBox grbSelect;
        private System.Windows.Forms.Label lblLocigal_min;
        private System.Windows.Forms.TextBox txtLogical;
        private System.Windows.Forms.Label lblLogical;
        private System.Windows.Forms.Button cmdSelect;
        private System.Windows.Forms.GroupBox grbCommandLog;
        private System.Windows.Forms.DataGridView dgCommandLog;
        private System.Windows.Forms.GroupBox grbFilesIn;
        private System.Windows.Forms.DataGridView dgFilesIn;
        private System.Windows.Forms.GroupBox grbEnvironment;
        private System.Windows.Forms.RadioButton rbProduction;
        private System.Windows.Forms.RadioButton rbPreProduction;
        private System.Windows.Forms.GroupBox grbFilesOut;
        private System.Windows.Forms.DataGridView dgFilesOut;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.DateTimePicker dtPicker;
        private DBDashboard.cbMaint cbTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTransferServer;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCommandServer;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.Panel pnlSearch;
        private System.Windows.Forms.Panel pnlSearch_transfer;
        private System.Windows.Forms.Button cmdSearch_transfer;
        private System.Windows.Forms.TextBox txtSearch_transfer;
        private System.Windows.Forms.Button cmdSall_transfer;
        private System.Windows.Forms.Label lblDebug;
        private System.Windows.Forms.Label lblTransferLog;
        private System.Windows.Forms.Label lblCommandLog;
        private System.Windows.Forms.Label lblFilesIn;
        private System.Windows.Forms.Label lblFilesOut;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFileInName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFileInTimeStamp;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFileInSize;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFileOutName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFileOutTimeStamp;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFileOutSize;
        private System.Windows.Forms.Button cmdSearch;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button cmdSall;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button cmdReset;
        private System.Windows.Forms.TrackBar trackBar2;
        private System.Windows.Forms.TrackBar trackBar1;
        private System.Windows.Forms.GroupBox grbTimeFrame;
        private System.Windows.Forms.GroupBox grbTimeFrom;
        private cmbMinute cmbFromMinute;
        private cmbHour cmbFromHour;
        private System.Windows.Forms.Label lblFromHHMM;
        private System.Windows.Forms.GroupBox grbTimeUpTo;
        private cmbMinute cmbToMinute;
        private cmbHour cmbToHour;
        private System.Windows.Forms.Label lblToHHMM;
    }
}