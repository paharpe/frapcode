﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.IO;

namespace dbDashboard
{
    public partial class frmDashPOP3 : frmDashBase
    {
        string strPOP3 = "POP3_BOXES";
        string strPOP3_BOXES_CMD;
        int intdgPOP3_max_Rows = 14;
        int intdgPOP3_min_With = 433;
        int intdgPOP3_max_With = 448;

        public frmDashPOP3()
        {
            InitializeComponent();
        }
               

        private void frmDashPOP3_Load(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            frm_init();
            this.Cursor = Cursors.Default;
        }

        private void frm_init()
        {
            Boolean bInit_OK = false;

            cmdShow.Enabled = false;
            grbStats.Visible = false;

            // Scriptcommand ophalen uit tabel
            DoSql mysql = new DoSql();
            mysql.affected_rows = 0;
            mysql.vul_deze_string = "";
            mysql.DoQuery(" SELECT ElemOms1 " +
                          " FROM DashElem " +
                          " WHERE ElemTabn = 10 " +
                          " AND   ElemElem = '"+strPOP3+"'");
            if (mysql.affected_rows == 0)
            {                
                clDashFunction.Melding("Tabelelement '"+strPOP3+"' in tabel 10 ontbreekt !",1,"E");
            }
            else
            {
                strPOP3_BOXES_CMD = mysql.vul_deze_string;
                
            }

            // ***********************************************************
            // Vul Listbox met POP3 servers en Combobox met environments
            // ***********************************************************
            DoSql mySql = new DoSql();
            mySql.vul_deze_text1_array[1] = "FTA";

            mySql.DoQuery("SELECT   ElemElem, ElemOms1,ElemOms2 " +
                          "FROM     DashElem " +
                          "WHERE    ElemTabn = 12 " +
                          "AND      ElemOms1 = 'POP3' " +
                          "ORDER BY ElemOms2,ElemOms1,ElemElem");

            if (mySql.affected_rows < 1)
            {
                clDashFunction.Melding("Geen POP3 servers gedefinieerd in tabel 12", 1, "I");
                bInit_OK = false;
            }
            else
            {
                int intAffected_rows_index = 1;
                while (intAffected_rows_index <= mySql.affected_rows)
                {
                    if (mySql.vul_deze_text1_array[intAffected_rows_index] != null)
                    {
                        lbEnvironment.Items.Add(mySql.vul_deze_text1_array[intAffected_rows_index]);
                        cmbEnvironment.Items.Add(mySql.vul_deze_text3_array[intAffected_rows_index]);
                        
                    }
                    intAffected_rows_index++;
                }
                cmbEnvironment.SelectedIndex = 1;

                bInit_OK = true;
            }

            cmdShow.Enabled = bInit_OK;
        }

        private void cmdShow_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            get_POP3_queue();
            this.Cursor = Cursors.Default;
        }

        private void get_POP3_queue()
        {            
            grbStats.Visible = false;

            string strServer = lbEnvironment.Text;
            string strGrep = "";
            string strPOP3QueueRecord;
            int intRowNo = 0;
            dgPOP3Q_BDR.Rows.Clear();
            dgPOP3Q_BDR.Width = intdgPOP3_min_With;
            grbBDR_Q.Width = intdgPOP3_min_With + 26;
            this.Refresh();

            if (mdiDashboard.Talk)
            {
                clDashFunction.Melding("QueryParms: strServer: " + strServer + "\n strTrans:" + strGrep, 1, "I");
            }

            StreamReader myStreamReader = clDashFunction.get_linux_data(strServer, strPOP3_BOXES_CMD);
            if (myStreamReader != null)
            {
                while (!myStreamReader.EndOfStream)
                {
                    // Zo ziet een record er uit:
                    //     0       1        2            3                     4                   5             6          7      
                    // RESPONSE~kslv047~POP3_OUT_BDR~2015-08-31 16:26:20~2015-08-31 01:16:51~2015-08-31 01:18:54~3~wscs1984@bedrijven.otpnet.nl

                    strPOP3QueueRecord = myStreamReader.ReadLine();

                    string[] strarPOP3QueueRecord = Regex.Split(strPOP3QueueRecord, "~");

                    if (strarPOP3QueueRecord.Length > 6)
                    {
                        intRowNo = dgPOP3Q_BDR.Rows.Add();

                        // No presented in table, but fill in the loop anyway
                        lblServer_val.Text = strarPOP3QueueRecord[1].ToString();
                        lblCheckTime_val.Text = strarPOP3QueueRecord[3].ToString(); 

                        dgPOP3Q_BDR[0, intRowNo].Value = strarPOP3QueueRecord[7].ToString(); // adres
                        dgPOP3Q_BDR[1, intRowNo].Value = Convert.ToInt32(strarPOP3QueueRecord[6]); // queue
                        dgPOP3Q_BDR[2, intRowNo].Value = strarPOP3QueueRecord[4].ToString(); // oldest
                        dgPOP3Q_BDR[3, intRowNo].Value = strarPOP3QueueRecord[5].ToString(); // newest            
                                                
                        if (dgPOP3Q_BDR.Rows.Count > intdgPOP3_max_Rows)
                        {
                            dgPOP3Q_BDR.Width = intdgPOP3_max_With;
                            grbBDR_Q.Width = intdgPOP3_max_With + 26;
                        }

                        this.Refresh();
                    }
                }
            }
            if (intRowNo < 1)
            {
                dgPOP3Q_BDR.Enabled = false;
                clDashFunction.Melding("No POP3 mailboxes selected; or all are empty !", 1, "I");
            }
            else
            {             
                dgPOP3Q_BDR.Enabled = true;
                grbStats.Visible = true;                             
            }

            // nul = nul, maar anders komt de telling steevast 1 te laag uit.
            //            we beginnen immers te tellen bij rij 0 en die bevat record 1
            if (intRowNo > 0)
            { intRowNo++; }

            lblCount.Text = intRowNo.ToString();
        }

        private void cmbEnvironment_SelectedIndexChanged(object sender, EventArgs e)
        {
            lbEnvironment.SelectedIndex = cmbEnvironment.SelectedIndex;
            dgPOP3Q_BDR.Rows.Clear();
        }        
    }
}
