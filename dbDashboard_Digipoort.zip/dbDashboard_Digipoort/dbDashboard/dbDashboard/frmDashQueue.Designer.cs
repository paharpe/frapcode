﻿namespace dbDashboard
{
    partial class frmDashQueue
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDashQueue));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tmrSMTPQ = new System.Windows.Forms.Timer(this.components);
            this.tmrCoreQ = new System.Windows.Forms.Timer(this.components);
            this.tmrX400Q = new System.Windows.Forms.Timer(this.components);
            this.tmrRefresh = new System.Windows.Forms.Timer(this.components);
            this.tmrSeconds = new System.Windows.Forms.Timer(this.components);
            this.lblMsgs_OVH = new System.Windows.Forms.Label();
            this.lblMsgs_BDR = new System.Windows.Forms.Label();
            this.dgSMTPQ_OVH = new System.Windows.Forms.DataGridView();
            this.colSMTP_OVH_Server = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSMTP_OVH_Queue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSMTPQ_OVH_checktime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSMTP_OVH_Domain = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSMTP_OVH_Age = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgSMTPQ_BDR = new System.Windows.Forms.DataGridView();
            this.colSMTPQ_BDR_server = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSMTPQ_BDR_Queue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSMTPQ_BDR_checktime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSMTPQ_BDR_Domain = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSMTP_BDR_Age = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grbCore_Q = new System.Windows.Forms.GroupBox();
            this.grbCoreAlarm = new System.Windows.Forms.GroupBox();
            this.flpCoreAlarm = new System.Windows.Forms.FlowLayoutPanel();
            this.pnlCore_Split = new System.Windows.Forms.Panel();
            this.pnlCoreMax = new System.Windows.Forms.Panel();
            this.lblCore_SMTP_MAX = new dbDashboard.lblMax();
            this.lblCore_X400_MAX = new dbDashboard.lblMax();
            this.lblCore_SMTP_MaxTime = new dbDashboard.lblMaxTime();
            this.lblCore_X400_MaxTime = new dbDashboard.lblMaxTime();
            this.lblCoreTrend_X400 = new dbDashboard.lblMax();
            this.lblCoreTrend_SMTP = new dbDashboard.lblMax();
            this.lbCoreQ_X400 = new dbDashboard.lbTrend();
            this.lblCoreQ = new System.Windows.Forms.Label();
            this.lbCoreQ_SMTP = new dbDashboard.lbTrend();
            this.pnlCore2 = new System.Windows.Forms.Panel();
            this.lblMsgs_Core_Age2 = new System.Windows.Forms.Label();
            this.lblMsgs_Core_Total2 = new System.Windows.Forms.Label();
            this.lblCoreOldest2 = new System.Windows.Forms.Label();
            this.lblCoreTotal2 = new System.Windows.Forms.Label();
            this.pnlCore1 = new System.Windows.Forms.Panel();
            this.lblCoreTotal1 = new System.Windows.Forms.Label();
            this.lblMsgs_Core_Total1 = new System.Windows.Forms.Label();
            this.lblCoreOldest1 = new System.Windows.Forms.Label();
            this.lblMsgs_Core_Age1 = new System.Windows.Forms.Label();
            this.dgCoreQ = new System.Windows.Forms.DataGridView();
            this.colCoreQ_Server = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCoreQ_Proto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCoreQ_Queue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCoreQ_CheckTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCoreQ_Oldest = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCoreQ_Newest = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.lblNagios = new System.Windows.Forms.Label();
            this.grbOVH_Q = new System.Windows.Forms.GroupBox();
            this.pnlX400_OVH_Max = new System.Windows.Forms.Panel();
            this.lblX400Q_OVH_MAX = new dbDashboard.lblMax();
            this.lblX400Q_OVH_MAXTime = new dbDashboard.lblMaxTime();
            this.pnlSMTP_OVH_Max = new System.Windows.Forms.Panel();
            this.lblSMTPQ_OVH_MAX = new dbDashboard.lblMax();
            this.lblSMTPQ_OVH_MAXTime = new dbDashboard.lblMaxTime();
            this.lblX400Q_OVH = new System.Windows.Forms.Label();
            this.lbX400Q_OVH = new dbDashboard.lbTrend();
            this.lblSMTPQ_OVH = new System.Windows.Forms.Label();
            this.lbSMTPQ_OVH = new dbDashboard.lbTrend();
            this.lblSMTP_OVH = new System.Windows.Forms.Label();
            this.dgX400Q_OVH = new System.Windows.Forms.DataGridView();
            this.colX400Q_OVH_Server = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colX400Q_OVH_Queue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colX400Q_OVH_CheckTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colX400Q_OVH_Oldest = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colX400Q_OVH_Newest = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblX400_OVH = new System.Windows.Forms.Label();
            this.grbBDR_Q = new System.Windows.Forms.GroupBox();
            this.pnlX400_BDR_Max = new System.Windows.Forms.Panel();
            this.lblX400Q_BDR_MAX = new dbDashboard.lblMax();
            this.lblX400Q_BDR_MAXTime = new dbDashboard.lblMaxTime();
            this.pnlSMTP_BDR_Max = new System.Windows.Forms.Panel();
            this.lblSMTPQ_BDR_MAX = new dbDashboard.lblMax();
            this.lblSMTPQ_BDR_MAXTime = new dbDashboard.lblMaxTime();
            this.lblX400Q_BDR = new System.Windows.Forms.Label();
            this.lbX400Q_BDR = new dbDashboard.lbTrend();
            this.lblSMTPQ_BDR = new System.Windows.Forms.Label();
            this.lbSMTPQ_BDR = new dbDashboard.lbTrend();
            this.pnSMTPQ_BDR = new System.Windows.Forms.Panel();
            this.lblSMTP_BDR = new System.Windows.Forms.Label();
            this.lblX400_BDR = new System.Windows.Forms.Label();
            this.dgX400Q_BDR = new System.Windows.Forms.DataGridView();
            this.colX400Q_BDR_Server = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colX400Q_BDR_Queue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colX400Q_BDR_CheckTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colX400Q_BDR_Oldest = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colX400Q_BDR_Newest = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grbAllQueue = new System.Windows.Forms.GroupBox();
            this.grbNagios = new System.Windows.Forms.GroupBox();
            this.txtNagios_Queue = new System.Windows.Forms.TextBox();
            this.lblNoDebug = new System.Windows.Forms.Label();
            this.pnlNoDebug = new System.Windows.Forms.Panel();
            this.cbDebug = new System.Windows.Forms.CheckBox();
            this.cmdDebugLog_Toggle = new System.Windows.Forms.Button();
            this.lblSettings = new System.Windows.Forms.Label();
            this.lblCore = new System.Windows.Forms.Label();
            this.grbDigipoort = new System.Windows.Forms.GroupBox();
            this.pbDigipoort = new System.Windows.Forms.PictureBox();
            this.lblOverheden = new System.Windows.Forms.Label();
            this.grbLog = new System.Windows.Forms.GroupBox();
            this.lblLog = new System.Windows.Forms.Label();
            this.cmdDebugLog_Clear = new System.Windows.Forms.Button();
            this.lblDebugError_val = new System.Windows.Forms.Label();
            this.lbDebug = new System.Windows.Forms.ListBox();
            this.lblDebugError_text = new System.Windows.Forms.Label();
            this.lblBedrijven = new System.Windows.Forms.Label();
            this.grpSettings = new System.Windows.Forms.GroupBox();
            this.cmbEnv = new System.Windows.Forms.ComboBox();
            this.lblEnv = new System.Windows.Forms.Label();
            this.grbOptions = new System.Windows.Forms.GroupBox();
            this.lblSaveToOptions = new System.Windows.Forms.Label();
            this.lblSaveFile = new System.Windows.Forms.Label();
            this.cmdSaveToOptions = new System.Windows.Forms.Button();
            this.pnlSettings = new System.Windows.Forms.Panel();
            this.lblAutoUpdate = new System.Windows.Forms.Label();
            this.cmdManualUpdate = new System.Windows.Forms.Button();
            this.lblUpdte = new System.Windows.Forms.Label();
            this.lblRefresh_till_refresh = new System.Windows.Forms.Label();
            this.lblRefresh_last_refresh = new System.Windows.Forms.Label();
            this.rbAutoUpdateOn = new System.Windows.Forms.RadioButton();
            this.rbAutoUpdateOff = new System.Windows.Forms.RadioButton();
            this.cmbGroupSMTP = new System.Windows.Forms.ComboBox();
            this.lblGroupSMTP = new System.Windows.Forms.Label();
            this.grbConnect.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgSMTPQ_OVH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgSMTPQ_BDR)).BeginInit();
            this.grbCore_Q.SuspendLayout();
            this.grbCoreAlarm.SuspendLayout();
            this.pnlCoreMax.SuspendLayout();
            this.pnlCore2.SuspendLayout();
            this.pnlCore1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgCoreQ)).BeginInit();
            this.grbOVH_Q.SuspendLayout();
            this.pnlX400_OVH_Max.SuspendLayout();
            this.pnlSMTP_OVH_Max.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgX400Q_OVH)).BeginInit();
            this.grbBDR_Q.SuspendLayout();
            this.pnlX400_BDR_Max.SuspendLayout();
            this.pnlSMTP_BDR_Max.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgX400Q_BDR)).BeginInit();
            this.grbAllQueue.SuspendLayout();
            this.grbNagios.SuspendLayout();
            this.grbDigipoort.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbDigipoort)).BeginInit();
            this.grbLog.SuspendLayout();
            this.grpSettings.SuspendLayout();
            this.grbOptions.SuspendLayout();
            this.pnlSettings.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmdAfsluiten
            // 
            this.cmdAfsluiten.Location = new System.Drawing.Point(9, 878);
            this.cmdAfsluiten.Size = new System.Drawing.Size(75, 26);
            this.cmdAfsluiten.Click += new System.EventHandler(this.cmdAfsluiten_Click_1);
            // 
            // grbConnect
            // 
            this.grbConnect.Location = new System.Drawing.Point(829, 937);
            // 
            // lblHostName
            // 
            this.lblHostName.Location = new System.Drawing.Point(1365, 895);
            this.lblHostName.Size = new System.Drawing.Size(145, 13);
            this.lblHostName.Text = "KPNNL\\WLD4BED923B63C";
            // 
            // tmrSMTPQ
            // 
            this.tmrSMTPQ.Interval = 45000;
            this.tmrSMTPQ.Tick += new System.EventHandler(this.tmrSMTPQ_Tick);
            // 
            // tmrCoreQ
            // 
            this.tmrCoreQ.Interval = 55000;
            this.tmrCoreQ.Tick += new System.EventHandler(this.tmrCoreQ_Tick);
            // 
            // tmrX400Q
            // 
            this.tmrX400Q.Interval = 50000;
            this.tmrX400Q.Tick += new System.EventHandler(this.tmrX400Q_Tick);
            // 
            // tmrRefresh
            // 
            this.tmrRefresh.Interval = 59000;
            this.tmrRefresh.Tick += new System.EventHandler(this.tmrRefresh_Tick);
            // 
            // tmrSeconds
            // 
            this.tmrSeconds.Interval = 1000;
            this.tmrSeconds.Tick += new System.EventHandler(this.tmrSeconds_Tick);
            // 
            // lblMsgs_OVH
            // 
            this.lblMsgs_OVH.AutoSize = true;
            this.lblMsgs_OVH.Location = new System.Drawing.Point(6, 207);
            this.lblMsgs_OVH.Name = "lblMsgs_OVH";
            this.lblMsgs_OVH.Size = new System.Drawing.Size(84, 13);
            this.lblMsgs_OVH.TabIndex = 4;
            this.lblMsgs_OVH.Text = "Total messages:";
            // 
            // lblMsgs_BDR
            // 
            this.lblMsgs_BDR.AutoSize = true;
            this.lblMsgs_BDR.Location = new System.Drawing.Point(6, 207);
            this.lblMsgs_BDR.Name = "lblMsgs_BDR";
            this.lblMsgs_BDR.Size = new System.Drawing.Size(84, 13);
            this.lblMsgs_BDR.TabIndex = 3;
            this.lblMsgs_BDR.Text = "Total messages:";
            // 
            // dgSMTPQ_OVH
            // 
            this.dgSMTPQ_OVH.AllowUserToAddRows = false;
            this.dgSMTPQ_OVH.AllowUserToDeleteRows = false;
            this.dgSMTPQ_OVH.AllowUserToResizeColumns = false;
            this.dgSMTPQ_OVH.AllowUserToResizeRows = false;
            this.dgSMTPQ_OVH.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgSMTPQ_OVH.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colSMTP_OVH_Server,
            this.colSMTP_OVH_Queue,
            this.colSMTPQ_OVH_checktime,
            this.colSMTP_OVH_Domain,
            this.colSMTP_OVH_Age});
            this.dgSMTPQ_OVH.Location = new System.Drawing.Point(10, 46);
            this.dgSMTPQ_OVH.MultiSelect = false;
            this.dgSMTPQ_OVH.Name = "dgSMTPQ_OVH";
            this.dgSMTPQ_OVH.ReadOnly = true;
            this.dgSMTPQ_OVH.RowHeadersVisible = false;
            this.dgSMTPQ_OVH.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgSMTPQ_OVH.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgSMTPQ_OVH.Size = new System.Drawing.Size(634, 159);
            this.dgSMTPQ_OVH.TabIndex = 0;
            this.dgSMTPQ_OVH.SelectionChanged += new System.EventHandler(this.dgSMTPQ_OVH_SelectionChanged);
            // 
            // colSMTP_OVH_Server
            // 
            this.colSMTP_OVH_Server.HeaderText = "Server";
            this.colSMTP_OVH_Server.MaxInputLength = 8;
            this.colSMTP_OVH_Server.MinimumWidth = 65;
            this.colSMTP_OVH_Server.Name = "colSMTP_OVH_Server";
            this.colSMTP_OVH_Server.ReadOnly = true;
            this.colSMTP_OVH_Server.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colSMTP_OVH_Server.Width = 65;
            // 
            // colSMTP_OVH_Queue
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle1.Format = "N0";
            dataGridViewCellStyle1.NullValue = null;
            this.colSMTP_OVH_Queue.DefaultCellStyle = dataGridViewCellStyle1;
            this.colSMTP_OVH_Queue.HeaderText = "Queue";
            this.colSMTP_OVH_Queue.MaxInputLength = 7;
            this.colSMTP_OVH_Queue.MinimumWidth = 50;
            this.colSMTP_OVH_Queue.Name = "colSMTP_OVH_Queue";
            this.colSMTP_OVH_Queue.ReadOnly = true;
            this.colSMTP_OVH_Queue.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colSMTP_OVH_Queue.Width = 50;
            // 
            // colSMTPQ_OVH_checktime
            // 
            this.colSMTPQ_OVH_checktime.HeaderText = "CheckTime";
            this.colSMTPQ_OVH_checktime.Name = "colSMTPQ_OVH_checktime";
            this.colSMTPQ_OVH_checktime.ReadOnly = true;
            this.colSMTPQ_OVH_checktime.Width = 130;
            // 
            // colSMTP_OVH_Domain
            // 
            this.colSMTP_OVH_Domain.HeaderText = "Domain";
            this.colSMTP_OVH_Domain.MaxInputLength = 100;
            this.colSMTP_OVH_Domain.MinimumWidth = 190;
            this.colSMTP_OVH_Domain.Name = "colSMTP_OVH_Domain";
            this.colSMTP_OVH_Domain.ReadOnly = true;
            this.colSMTP_OVH_Domain.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colSMTP_OVH_Domain.Width = 190;
            // 
            // colSMTP_OVH_Age
            // 
            this.colSMTP_OVH_Age.HeaderText = "Age";
            this.colSMTP_OVH_Age.MaxInputLength = 100;
            this.colSMTP_OVH_Age.MinimumWidth = 200;
            this.colSMTP_OVH_Age.Name = "colSMTP_OVH_Age";
            this.colSMTP_OVH_Age.ReadOnly = true;
            this.colSMTP_OVH_Age.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colSMTP_OVH_Age.Width = 200;
            // 
            // dgSMTPQ_BDR
            // 
            this.dgSMTPQ_BDR.AllowUserToAddRows = false;
            this.dgSMTPQ_BDR.AllowUserToDeleteRows = false;
            this.dgSMTPQ_BDR.AllowUserToResizeColumns = false;
            this.dgSMTPQ_BDR.AllowUserToResizeRows = false;
            this.dgSMTPQ_BDR.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgSMTPQ_BDR.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colSMTPQ_BDR_server,
            this.colSMTPQ_BDR_Queue,
            this.colSMTPQ_BDR_checktime,
            this.colSMTPQ_BDR_Domain,
            this.colSMTP_BDR_Age});
            this.dgSMTPQ_BDR.Location = new System.Drawing.Point(10, 47);
            this.dgSMTPQ_BDR.MultiSelect = false;
            this.dgSMTPQ_BDR.Name = "dgSMTPQ_BDR";
            this.dgSMTPQ_BDR.ReadOnly = true;
            this.dgSMTPQ_BDR.RowHeadersVisible = false;
            this.dgSMTPQ_BDR.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgSMTPQ_BDR.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgSMTPQ_BDR.Size = new System.Drawing.Size(540, 159);
            this.dgSMTPQ_BDR.TabIndex = 0;
            this.dgSMTPQ_BDR.SelectionChanged += new System.EventHandler(this.dgSMTPQ_BDR_SelectionChanged);
            // 
            // colSMTPQ_BDR_server
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.colSMTPQ_BDR_server.DefaultCellStyle = dataGridViewCellStyle2;
            this.colSMTPQ_BDR_server.HeaderText = "Server";
            this.colSMTPQ_BDR_server.MaxInputLength = 8;
            this.colSMTPQ_BDR_server.MinimumWidth = 65;
            this.colSMTPQ_BDR_server.Name = "colSMTPQ_BDR_server";
            this.colSMTPQ_BDR_server.ReadOnly = true;
            this.colSMTPQ_BDR_server.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colSMTPQ_BDR_server.Width = 65;
            // 
            // colSMTPQ_BDR_Queue
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle3.Format = "N0";
            dataGridViewCellStyle3.NullValue = null;
            this.colSMTPQ_BDR_Queue.DefaultCellStyle = dataGridViewCellStyle3;
            this.colSMTPQ_BDR_Queue.HeaderText = "Queue";
            this.colSMTPQ_BDR_Queue.MaxInputLength = 7;
            this.colSMTPQ_BDR_Queue.MinimumWidth = 50;
            this.colSMTPQ_BDR_Queue.Name = "colSMTPQ_BDR_Queue";
            this.colSMTPQ_BDR_Queue.ReadOnly = true;
            this.colSMTPQ_BDR_Queue.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colSMTPQ_BDR_Queue.Width = 50;
            // 
            // colSMTPQ_BDR_checktime
            // 
            this.colSMTPQ_BDR_checktime.HeaderText = "CheckTime";
            this.colSMTPQ_BDR_checktime.MaxInputLength = 80;
            this.colSMTPQ_BDR_checktime.Name = "colSMTPQ_BDR_checktime";
            this.colSMTPQ_BDR_checktime.ReadOnly = true;
            this.colSMTPQ_BDR_checktime.Width = 110;
            // 
            // colSMTPQ_BDR_Domain
            // 
            this.colSMTPQ_BDR_Domain.HeaderText = "Domain";
            this.colSMTPQ_BDR_Domain.MaxInputLength = 100;
            this.colSMTPQ_BDR_Domain.MinimumWidth = 160;
            this.colSMTPQ_BDR_Domain.Name = "colSMTPQ_BDR_Domain";
            this.colSMTPQ_BDR_Domain.ReadOnly = true;
            this.colSMTPQ_BDR_Domain.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colSMTPQ_BDR_Domain.Width = 160;
            // 
            // colSMTP_BDR_Age
            // 
            this.colSMTP_BDR_Age.FillWeight = 80F;
            this.colSMTP_BDR_Age.HeaderText = "Age";
            this.colSMTP_BDR_Age.MaxInputLength = 80;
            this.colSMTP_BDR_Age.MinimumWidth = 182;
            this.colSMTP_BDR_Age.Name = "colSMTP_BDR_Age";
            this.colSMTP_BDR_Age.ReadOnly = true;
            this.colSMTP_BDR_Age.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colSMTP_BDR_Age.Width = 182;
            // 
            // grbCore_Q
            // 
            this.grbCore_Q.BackColor = System.Drawing.SystemColors.Control;
            this.grbCore_Q.Controls.Add(this.grbCoreAlarm);
            this.grbCore_Q.Controls.Add(this.pnlCore_Split);
            this.grbCore_Q.Controls.Add(this.pnlCoreMax);
            this.grbCore_Q.Controls.Add(this.lblCoreTrend_X400);
            this.grbCore_Q.Controls.Add(this.lblCoreTrend_SMTP);
            this.grbCore_Q.Controls.Add(this.lbCoreQ_X400);
            this.grbCore_Q.Controls.Add(this.lblCoreQ);
            this.grbCore_Q.Controls.Add(this.lbCoreQ_SMTP);
            this.grbCore_Q.Controls.Add(this.pnlCore2);
            this.grbCore_Q.Controls.Add(this.pnlCore1);
            this.grbCore_Q.Controls.Add(this.dgCoreQ);
            this.grbCore_Q.Location = new System.Drawing.Point(660, 24);
            this.grbCore_Q.Name = "grbCore_Q";
            this.grbCore_Q.Size = new System.Drawing.Size(819, 366);
            this.grbCore_Q.TabIndex = 28;
            this.grbCore_Q.TabStop = false;
            // 
            // grbCoreAlarm
            // 
            this.grbCoreAlarm.Controls.Add(this.flpCoreAlarm);
            this.grbCoreAlarm.Location = new System.Drawing.Point(10, 255);
            this.grbCoreAlarm.Name = "grbCoreAlarm";
            this.grbCoreAlarm.Size = new System.Drawing.Size(718, 99);
            this.grbCoreAlarm.TabIndex = 79;
            this.grbCoreAlarm.TabStop = false;
            this.grbCoreAlarm.Text = "OTP_transfer alarm(s)";
            // 
            // flpCoreAlarm
            // 
            this.flpCoreAlarm.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flpCoreAlarm.Location = new System.Drawing.Point(7, 17);
            this.flpCoreAlarm.Margin = new System.Windows.Forms.Padding(0);
            this.flpCoreAlarm.Name = "flpCoreAlarm";
            this.flpCoreAlarm.Size = new System.Drawing.Size(699, 73);
            this.flpCoreAlarm.TabIndex = 0;
            // 
            // pnlCore_Split
            // 
            this.pnlCore_Split.BackColor = System.Drawing.Color.White;
            this.pnlCore_Split.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlCore_Split.Location = new System.Drawing.Point(725, 210);
            this.pnlCore_Split.Name = "pnlCore_Split";
            this.pnlCore_Split.Size = new System.Drawing.Size(2, 37);
            this.pnlCore_Split.TabIndex = 78;
            // 
            // pnlCoreMax
            // 
            this.pnlCoreMax.BackColor = System.Drawing.Color.White;
            this.pnlCoreMax.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlCoreMax.Controls.Add(this.lblCore_SMTP_MAX);
            this.pnlCoreMax.Controls.Add(this.lblCore_X400_MAX);
            this.pnlCoreMax.Controls.Add(this.lblCore_SMTP_MaxTime);
            this.pnlCoreMax.Controls.Add(this.lblCore_X400_MaxTime);
            this.pnlCoreMax.Location = new System.Drawing.Point(643, 209);
            this.pnlCoreMax.Name = "pnlCoreMax";
            this.pnlCoreMax.Size = new System.Drawing.Size(165, 38);
            this.pnlCoreMax.TabIndex = 75;
            // 
            // lblCore_SMTP_MAX
            // 
            this.lblCore_SMTP_MAX.AutoSize = true;
            this.lblCore_SMTP_MAX.bChanged = false;
            this.lblCore_SMTP_MAX.Location = new System.Drawing.Point(1, 3);
            this.lblCore_SMTP_MAX.Max = 0;
            this.lblCore_SMTP_MAX.Name = "lblCore_SMTP_MAX";
            this.lblCore_SMTP_MAX.Size = new System.Drawing.Size(39, 13);
            this.lblCore_SMTP_MAX.TabIndex = 69;
            this.lblCore_SMTP_MAX.Text = "Max: 0";
            // 
            // lblCore_X400_MAX
            // 
            this.lblCore_X400_MAX.AutoSize = true;
            this.lblCore_X400_MAX.bChanged = false;
            this.lblCore_X400_MAX.Location = new System.Drawing.Point(82, 3);
            this.lblCore_X400_MAX.Max = 0;
            this.lblCore_X400_MAX.Name = "lblCore_X400_MAX";
            this.lblCore_X400_MAX.Size = new System.Drawing.Size(39, 13);
            this.lblCore_X400_MAX.TabIndex = 70;
            this.lblCore_X400_MAX.Text = "Max: 0";
            // 
            // lblCore_SMTP_MaxTime
            // 
            this.lblCore_SMTP_MaxTime.AutoSize = true;
            this.lblCore_SMTP_MaxTime.bChanged = false;
            this.lblCore_SMTP_MaxTime.Location = new System.Drawing.Point(1, 19);
            this.lblCore_SMTP_MaxTime.MaxTime = new System.DateTime(((long)(0)));
            this.lblCore_SMTP_MaxTime.Name = "lblCore_SMTP_MaxTime";
            this.lblCore_SMTP_MaxTime.Size = new System.Drawing.Size(50, 13);
            this.lblCore_SMTP_MaxTime.TabIndex = 73;
            this.lblCore_SMTP_MaxTime.Text = "At:  --:--:--";
            // 
            // lblCore_X400_MaxTime
            // 
            this.lblCore_X400_MaxTime.AutoSize = true;
            this.lblCore_X400_MaxTime.bChanged = false;
            this.lblCore_X400_MaxTime.Location = new System.Drawing.Point(82, 19);
            this.lblCore_X400_MaxTime.MaxTime = new System.DateTime(((long)(0)));
            this.lblCore_X400_MaxTime.Name = "lblCore_X400_MaxTime";
            this.lblCore_X400_MaxTime.Size = new System.Drawing.Size(50, 13);
            this.lblCore_X400_MaxTime.TabIndex = 75;
            this.lblCore_X400_MaxTime.Text = "At:  --:--:--";
            // 
            // lblCoreTrend_X400
            // 
            this.lblCoreTrend_X400.AutoSize = true;
            this.lblCoreTrend_X400.bChanged = false;
            this.lblCoreTrend_X400.Location = new System.Drawing.Point(726, 37);
            this.lblCoreTrend_X400.Max = 0;
            this.lblCoreTrend_X400.Name = "lblCoreTrend_X400";
            this.lblCoreTrend_X400.Size = new System.Drawing.Size(32, 13);
            this.lblCoreTrend_X400.TabIndex = 77;
            this.lblCoreTrend_X400.Text = "X400";
            // 
            // lblCoreTrend_SMTP
            // 
            this.lblCoreTrend_SMTP.AutoSize = true;
            this.lblCoreTrend_SMTP.bChanged = false;
            this.lblCoreTrend_SMTP.Location = new System.Drawing.Point(644, 37);
            this.lblCoreTrend_SMTP.Max = 0;
            this.lblCoreTrend_SMTP.Name = "lblCoreTrend_SMTP";
            this.lblCoreTrend_SMTP.Size = new System.Drawing.Size(37, 13);
            this.lblCoreTrend_SMTP.TabIndex = 76;
            this.lblCoreTrend_SMTP.Text = "SMTP";
            // 
            // lbCoreQ_X400
            // 
            this.lbCoreQ_X400.bChanged = false;
            this.lbCoreQ_X400.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lbCoreQ_X400.FormattingEnabled = true;
            this.lbCoreQ_X400.intSeli = ((short)(0));
            this.lbCoreQ_X400.intTrend = 0;
            this.lbCoreQ_X400.Location = new System.Drawing.Point(726, 50);
            this.lbCoreQ_X400.Max_Occs = ((short)(60));
            this.lbCoreQ_X400.Name = "lbCoreQ_X400";
            this.lbCoreQ_X400.Size = new System.Drawing.Size(82, 160);
            this.lbCoreQ_X400.TabIndex = 74;
            // 
            // lblCoreQ
            // 
            this.lblCoreQ.AutoSize = true;
            this.lblCoreQ.Location = new System.Drawing.Point(704, 21);
            this.lblCoreQ.Name = "lblCoreQ";
            this.lblCoreQ.Size = new System.Drawing.Size(35, 13);
            this.lblCoreQ.TabIndex = 67;
            this.lblCoreQ.Text = "Trend";
            // 
            // lbCoreQ_SMTP
            // 
            this.lbCoreQ_SMTP.bChanged = false;
            this.lbCoreQ_SMTP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lbCoreQ_SMTP.FormattingEnabled = true;
            this.lbCoreQ_SMTP.intSeli = ((short)(0));
            this.lbCoreQ_SMTP.intTrend = 0;
            this.lbCoreQ_SMTP.Location = new System.Drawing.Point(644, 50);
            this.lbCoreQ_SMTP.Max_Occs = ((short)(60));
            this.lbCoreQ_SMTP.Name = "lbCoreQ_SMTP";
            this.lbCoreQ_SMTP.Size = new System.Drawing.Size(82, 160);
            this.lbCoreQ_SMTP.TabIndex = 64;
            // 
            // pnlCore2
            // 
            this.pnlCore2.BackColor = System.Drawing.Color.Teal;
            this.pnlCore2.Controls.Add(this.lblMsgs_Core_Age2);
            this.pnlCore2.Controls.Add(this.lblMsgs_Core_Total2);
            this.pnlCore2.Controls.Add(this.lblCoreOldest2);
            this.pnlCore2.Controls.Add(this.lblCoreTotal2);
            this.pnlCore2.ForeColor = System.Drawing.Color.Black;
            this.pnlCore2.Location = new System.Drawing.Point(341, 224);
            this.pnlCore2.Name = "pnlCore2";
            this.pnlCore2.Size = new System.Drawing.Size(303, 22);
            this.pnlCore2.TabIndex = 51;
            // 
            // lblMsgs_Core_Age2
            // 
            this.lblMsgs_Core_Age2.AutoSize = true;
            this.lblMsgs_Core_Age2.ForeColor = System.Drawing.Color.White;
            this.lblMsgs_Core_Age2.Location = new System.Drawing.Point(0, 5);
            this.lblMsgs_Core_Age2.Name = "lblMsgs_Core_Age2";
            this.lblMsgs_Core_Age2.Size = new System.Drawing.Size(40, 13);
            this.lblMsgs_Core_Age2.TabIndex = 51;
            this.lblMsgs_Core_Age2.Text = "Oldest:";
            // 
            // lblMsgs_Core_Total2
            // 
            this.lblMsgs_Core_Total2.AutoSize = true;
            this.lblMsgs_Core_Total2.ForeColor = System.Drawing.Color.White;
            this.lblMsgs_Core_Total2.Location = new System.Drawing.Point(237, 5);
            this.lblMsgs_Core_Total2.Name = "lblMsgs_Core_Total2";
            this.lblMsgs_Core_Total2.Size = new System.Drawing.Size(34, 13);
            this.lblMsgs_Core_Total2.TabIndex = 50;
            this.lblMsgs_Core_Total2.Text = "Total:";
            // 
            // lblCoreOldest2
            // 
            this.lblCoreOldest2.AutoSize = true;
            this.lblCoreOldest2.ForeColor = System.Drawing.Color.White;
            this.lblCoreOldest2.Location = new System.Drawing.Point(122, 5);
            this.lblCoreOldest2.Name = "lblCoreOldest2";
            this.lblCoreOldest2.Size = new System.Drawing.Size(75, 13);
            this.lblCoreOldest2.TabIndex = 47;
            this.lblCoreOldest2.Text = "lblCoreOldest2";
            // 
            // lblCoreTotal2
            // 
            this.lblCoreTotal2.AutoSize = true;
            this.lblCoreTotal2.ForeColor = System.Drawing.Color.White;
            this.lblCoreTotal2.Location = new System.Drawing.Point(269, 5);
            this.lblCoreTotal2.Name = "lblCoreTotal2";
            this.lblCoreTotal2.Size = new System.Drawing.Size(69, 13);
            this.lblCoreTotal2.TabIndex = 45;
            this.lblCoreTotal2.Text = "lblCoreTotal2";
            // 
            // pnlCore1
            // 
            this.pnlCore1.BackColor = System.Drawing.Color.Teal;
            this.pnlCore1.Controls.Add(this.lblCoreTotal1);
            this.pnlCore1.Controls.Add(this.lblMsgs_Core_Total1);
            this.pnlCore1.Controls.Add(this.lblCoreOldest1);
            this.pnlCore1.Controls.Add(this.lblMsgs_Core_Age1);
            this.pnlCore1.ForeColor = System.Drawing.Color.White;
            this.pnlCore1.Location = new System.Drawing.Point(10, 224);
            this.pnlCore1.Name = "pnlCore1";
            this.pnlCore1.Size = new System.Drawing.Size(331, 22);
            this.pnlCore1.TabIndex = 50;
            // 
            // lblCoreTotal1
            // 
            this.lblCoreTotal1.AutoSize = true;
            this.lblCoreTotal1.ForeColor = System.Drawing.Color.White;
            this.lblCoreTotal1.Location = new System.Drawing.Point(273, 5);
            this.lblCoreTotal1.Name = "lblCoreTotal1";
            this.lblCoreTotal1.Size = new System.Drawing.Size(69, 13);
            this.lblCoreTotal1.TabIndex = 42;
            this.lblCoreTotal1.Text = "lblCoreTotal1";
            // 
            // lblMsgs_Core_Total1
            // 
            this.lblMsgs_Core_Total1.AutoSize = true;
            this.lblMsgs_Core_Total1.ForeColor = System.Drawing.Color.White;
            this.lblMsgs_Core_Total1.Location = new System.Drawing.Point(241, 5);
            this.lblMsgs_Core_Total1.Name = "lblMsgs_Core_Total1";
            this.lblMsgs_Core_Total1.Size = new System.Drawing.Size(34, 13);
            this.lblMsgs_Core_Total1.TabIndex = 48;
            this.lblMsgs_Core_Total1.Text = "Total:";
            // 
            // lblCoreOldest1
            // 
            this.lblCoreOldest1.AutoSize = true;
            this.lblCoreOldest1.ForeColor = System.Drawing.Color.White;
            this.lblCoreOldest1.Location = new System.Drawing.Point(124, 5);
            this.lblCoreOldest1.Name = "lblCoreOldest1";
            this.lblCoreOldest1.Size = new System.Drawing.Size(75, 13);
            this.lblCoreOldest1.TabIndex = 46;
            this.lblCoreOldest1.Text = "lblCoreOldest1";
            // 
            // lblMsgs_Core_Age1
            // 
            this.lblMsgs_Core_Age1.AutoSize = true;
            this.lblMsgs_Core_Age1.ForeColor = System.Drawing.Color.White;
            this.lblMsgs_Core_Age1.Location = new System.Drawing.Point(3, 5);
            this.lblMsgs_Core_Age1.Name = "lblMsgs_Core_Age1";
            this.lblMsgs_Core_Age1.Size = new System.Drawing.Size(40, 13);
            this.lblMsgs_Core_Age1.TabIndex = 49;
            this.lblMsgs_Core_Age1.Text = "Oldest:";
            // 
            // dgCoreQ
            // 
            this.dgCoreQ.AllowUserToAddRows = false;
            this.dgCoreQ.AllowUserToDeleteRows = false;
            this.dgCoreQ.AllowUserToResizeColumns = false;
            this.dgCoreQ.AllowUserToResizeRows = false;
            this.dgCoreQ.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgCoreQ.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colCoreQ_Server,
            this.colCoreQ_Proto,
            this.colCoreQ_Queue,
            this.colCoreQ_CheckTime,
            this.colCoreQ_Oldest,
            this.colCoreQ_Newest});
            this.dgCoreQ.Location = new System.Drawing.Point(10, 30);
            this.dgCoreQ.MultiSelect = false;
            this.dgCoreQ.Name = "dgCoreQ";
            this.dgCoreQ.ReadOnly = true;
            this.dgCoreQ.RowHeadersVisible = false;
            this.dgCoreQ.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgCoreQ.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgCoreQ.Size = new System.Drawing.Size(634, 194);
            this.dgCoreQ.TabIndex = 0;
            this.dgCoreQ.SelectionChanged += new System.EventHandler(this.dgCoreQ_SelectionChanged);
            // 
            // colCoreQ_Server
            // 
            this.colCoreQ_Server.HeaderText = "Server";
            this.colCoreQ_Server.MaxInputLength = 8;
            this.colCoreQ_Server.MinimumWidth = 50;
            this.colCoreQ_Server.Name = "colCoreQ_Server";
            this.colCoreQ_Server.ReadOnly = true;
            this.colCoreQ_Server.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colCoreQ_Server.Width = 50;
            // 
            // colCoreQ_Proto
            // 
            this.colCoreQ_Proto.HeaderText = "Protocol";
            this.colCoreQ_Proto.MaxInputLength = 4;
            this.colCoreQ_Proto.MinimumWidth = 110;
            this.colCoreQ_Proto.Name = "colCoreQ_Proto";
            this.colCoreQ_Proto.ReadOnly = true;
            this.colCoreQ_Proto.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colCoreQ_Proto.Width = 110;
            // 
            // colCoreQ_Queue
            // 
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle4.Format = "N0";
            dataGridViewCellStyle4.NullValue = null;
            this.colCoreQ_Queue.DefaultCellStyle = dataGridViewCellStyle4;
            this.colCoreQ_Queue.HeaderText = "Queue";
            this.colCoreQ_Queue.MaxInputLength = 7;
            this.colCoreQ_Queue.MinimumWidth = 50;
            this.colCoreQ_Queue.Name = "colCoreQ_Queue";
            this.colCoreQ_Queue.ReadOnly = true;
            this.colCoreQ_Queue.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colCoreQ_Queue.Width = 50;
            // 
            // colCoreQ_CheckTime
            // 
            this.colCoreQ_CheckTime.HeaderText = "Checktime";
            this.colCoreQ_CheckTime.MinimumWidth = 120;
            this.colCoreQ_CheckTime.Name = "colCoreQ_CheckTime";
            this.colCoreQ_CheckTime.ReadOnly = true;
            this.colCoreQ_CheckTime.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colCoreQ_CheckTime.Width = 120;
            // 
            // colCoreQ_Oldest
            // 
            this.colCoreQ_Oldest.HeaderText = "Oldest";
            this.colCoreQ_Oldest.Name = "colCoreQ_Oldest";
            this.colCoreQ_Oldest.ReadOnly = true;
            this.colCoreQ_Oldest.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colCoreQ_Oldest.Width = 150;
            // 
            // colCoreQ_Newest
            // 
            this.colCoreQ_Newest.HeaderText = "Newest";
            this.colCoreQ_Newest.Name = "colCoreQ_Newest";
            this.colCoreQ_Newest.ReadOnly = true;
            this.colCoreQ_Newest.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colCoreQ_Newest.Width = 150;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "alarm.png");
            // 
            // lblNagios
            // 
            this.lblNagios.AutoSize = true;
            this.lblNagios.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNagios.Location = new System.Drawing.Point(3, -5);
            this.lblNagios.Name = "lblNagios";
            this.lblNagios.Size = new System.Drawing.Size(288, 24);
            this.lblNagios.TabIndex = 69;
            this.lblNagios.Text = "Nagios messages to Servicedesk";
            // 
            // grbOVH_Q
            // 
            this.grbOVH_Q.Controls.Add(this.pnlX400_OVH_Max);
            this.grbOVH_Q.Controls.Add(this.pnlSMTP_OVH_Max);
            this.grbOVH_Q.Controls.Add(this.lblX400Q_OVH);
            this.grbOVH_Q.Controls.Add(this.lbX400Q_OVH);
            this.grbOVH_Q.Controls.Add(this.lblSMTPQ_OVH);
            this.grbOVH_Q.Controls.Add(this.lbSMTPQ_OVH);
            this.grbOVH_Q.Controls.Add(this.lblSMTP_OVH);
            this.grbOVH_Q.Controls.Add(this.dgX400Q_OVH);
            this.grbOVH_Q.Controls.Add(this.lblX400_OVH);
            this.grbOVH_Q.Controls.Add(this.dgSMTPQ_OVH);
            this.grbOVH_Q.Controls.Add(this.lblMsgs_OVH);
            this.grbOVH_Q.Location = new System.Drawing.Point(660, 401);
            this.grbOVH_Q.Name = "grbOVH_Q";
            this.grbOVH_Q.Size = new System.Drawing.Size(730, 425);
            this.grbOVH_Q.TabIndex = 33;
            this.grbOVH_Q.TabStop = false;
            // 
            // pnlX400_OVH_Max
            // 
            this.pnlX400_OVH_Max.BackColor = System.Drawing.Color.White;
            this.pnlX400_OVH_Max.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlX400_OVH_Max.Controls.Add(this.lblX400Q_OVH_MAX);
            this.pnlX400_OVH_Max.Controls.Add(this.lblX400Q_OVH_MAXTime);
            this.pnlX400_OVH_Max.Location = new System.Drawing.Point(574, 381);
            this.pnlX400_OVH_Max.Name = "pnlX400_OVH_Max";
            this.pnlX400_OVH_Max.Size = new System.Drawing.Size(70, 40);
            this.pnlX400_OVH_Max.TabIndex = 77;
            // 
            // lblX400Q_OVH_MAX
            // 
            this.lblX400Q_OVH_MAX.AutoSize = true;
            this.lblX400Q_OVH_MAX.bChanged = false;
            this.lblX400Q_OVH_MAX.Location = new System.Drawing.Point(1, 3);
            this.lblX400Q_OVH_MAX.Max = 0;
            this.lblX400Q_OVH_MAX.Name = "lblX400Q_OVH_MAX";
            this.lblX400Q_OVH_MAX.Size = new System.Drawing.Size(39, 13);
            this.lblX400Q_OVH_MAX.TabIndex = 69;
            this.lblX400Q_OVH_MAX.Text = "Max: 0";
            // 
            // lblX400Q_OVH_MAXTime
            // 
            this.lblX400Q_OVH_MAXTime.AutoSize = true;
            this.lblX400Q_OVH_MAXTime.bChanged = false;
            this.lblX400Q_OVH_MAXTime.Location = new System.Drawing.Point(1, 19);
            this.lblX400Q_OVH_MAXTime.MaxTime = new System.DateTime(((long)(0)));
            this.lblX400Q_OVH_MAXTime.Name = "lblX400Q_OVH_MAXTime";
            this.lblX400Q_OVH_MAXTime.Size = new System.Drawing.Size(50, 13);
            this.lblX400Q_OVH_MAXTime.TabIndex = 73;
            this.lblX400Q_OVH_MAXTime.Text = "At:  --:--:--";
            // 
            // pnlSMTP_OVH_Max
            // 
            this.pnlSMTP_OVH_Max.BackColor = System.Drawing.Color.White;
            this.pnlSMTP_OVH_Max.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlSMTP_OVH_Max.Controls.Add(this.lblSMTPQ_OVH_MAX);
            this.pnlSMTP_OVH_Max.Controls.Add(this.lblSMTPQ_OVH_MAXTime);
            this.pnlSMTP_OVH_Max.Location = new System.Drawing.Point(643, 166);
            this.pnlSMTP_OVH_Max.Name = "pnlSMTP_OVH_Max";
            this.pnlSMTP_OVH_Max.Size = new System.Drawing.Size(77, 40);
            this.pnlSMTP_OVH_Max.TabIndex = 76;
            // 
            // lblSMTPQ_OVH_MAX
            // 
            this.lblSMTPQ_OVH_MAX.AutoSize = true;
            this.lblSMTPQ_OVH_MAX.bChanged = false;
            this.lblSMTPQ_OVH_MAX.Location = new System.Drawing.Point(1, 3);
            this.lblSMTPQ_OVH_MAX.Max = 0;
            this.lblSMTPQ_OVH_MAX.Name = "lblSMTPQ_OVH_MAX";
            this.lblSMTPQ_OVH_MAX.Size = new System.Drawing.Size(39, 13);
            this.lblSMTPQ_OVH_MAX.TabIndex = 69;
            this.lblSMTPQ_OVH_MAX.Text = "Max: 0";
            // 
            // lblSMTPQ_OVH_MAXTime
            // 
            this.lblSMTPQ_OVH_MAXTime.AutoSize = true;
            this.lblSMTPQ_OVH_MAXTime.bChanged = false;
            this.lblSMTPQ_OVH_MAXTime.Location = new System.Drawing.Point(1, 19);
            this.lblSMTPQ_OVH_MAXTime.MaxTime = new System.DateTime(((long)(0)));
            this.lblSMTPQ_OVH_MAXTime.Name = "lblSMTPQ_OVH_MAXTime";
            this.lblSMTPQ_OVH_MAXTime.Size = new System.Drawing.Size(50, 13);
            this.lblSMTPQ_OVH_MAXTime.TabIndex = 73;
            this.lblSMTPQ_OVH_MAXTime.Text = "At:  --:--:--";
            // 
            // lblX400Q_OVH
            // 
            this.lblX400Q_OVH.AutoSize = true;
            this.lblX400Q_OVH.Location = new System.Drawing.Point(640, 297);
            this.lblX400Q_OVH.Name = "lblX400Q_OVH";
            this.lblX400Q_OVH.Size = new System.Drawing.Size(35, 13);
            this.lblX400Q_OVH.TabIndex = 68;
            this.lblX400Q_OVH.Text = "Trend";
            // 
            // lbX400Q_OVH
            // 
            this.lbX400Q_OVH.bChanged = false;
            this.lbX400Q_OVH.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lbX400Q_OVH.FormattingEnabled = true;
            this.lbX400Q_OVH.intSeli = ((short)(0));
            this.lbX400Q_OVH.intTrend = 0;
            this.lbX400Q_OVH.Location = new System.Drawing.Point(643, 313);
            this.lbX400Q_OVH.Max_Occs = ((short)(60));
            this.lbX400Q_OVH.Name = "lbX400Q_OVH";
            this.lbX400Q_OVH.Size = new System.Drawing.Size(76, 108);
            this.lbX400Q_OVH.TabIndex = 67;
            // 
            // lblSMTPQ_OVH
            // 
            this.lblSMTPQ_OVH.AutoSize = true;
            this.lblSMTPQ_OVH.Location = new System.Drawing.Point(639, 30);
            this.lblSMTPQ_OVH.Name = "lblSMTPQ_OVH";
            this.lblSMTPQ_OVH.Size = new System.Drawing.Size(35, 13);
            this.lblSMTPQ_OVH.TabIndex = 66;
            this.lblSMTPQ_OVH.Text = "Trend";
            // 
            // lbSMTPQ_OVH
            // 
            this.lbSMTPQ_OVH.bChanged = false;
            this.lbSMTPQ_OVH.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lbSMTPQ_OVH.FormattingEnabled = true;
            this.lbSMTPQ_OVH.intSeli = ((short)(0));
            this.lbSMTPQ_OVH.intTrend = 0;
            this.lbSMTPQ_OVH.Location = new System.Drawing.Point(644, 46);
            this.lbSMTPQ_OVH.Max_Occs = ((short)(60));
            this.lbSMTPQ_OVH.Name = "lbSMTPQ_OVH";
            this.lbSMTPQ_OVH.Size = new System.Drawing.Size(76, 121);
            this.lbSMTPQ_OVH.TabIndex = 40;
            // 
            // lblSMTP_OVH
            // 
            this.lblSMTP_OVH.AutoSize = true;
            this.lblSMTP_OVH.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSMTP_OVH.Location = new System.Drawing.Point(6, 21);
            this.lblSMTP_OVH.Name = "lblSMTP_OVH";
            this.lblSMTP_OVH.Size = new System.Drawing.Size(62, 24);
            this.lblSMTP_OVH.TabIndex = 38;
            this.lblSMTP_OVH.Text = "SMTP";
            // 
            // dgX400Q_OVH
            // 
            this.dgX400Q_OVH.AllowUserToAddRows = false;
            this.dgX400Q_OVH.AllowUserToDeleteRows = false;
            this.dgX400Q_OVH.AllowUserToResizeColumns = false;
            this.dgX400Q_OVH.AllowUserToResizeRows = false;
            this.dgX400Q_OVH.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgX400Q_OVH.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colX400Q_OVH_Server,
            this.colX400Q_OVH_Queue,
            this.colX400Q_OVH_CheckTime,
            this.colX400Q_OVH_Oldest,
            this.colX400Q_OVH_Newest});
            this.dgX400Q_OVH.Location = new System.Drawing.Point(10, 313);
            this.dgX400Q_OVH.MultiSelect = false;
            this.dgX400Q_OVH.Name = "dgX400Q_OVH";
            this.dgX400Q_OVH.ReadOnly = true;
            this.dgX400Q_OVH.RowHeadersVisible = false;
            this.dgX400Q_OVH.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgX400Q_OVH.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgX400Q_OVH.Size = new System.Drawing.Size(634, 69);
            this.dgX400Q_OVH.TabIndex = 1;
            this.dgX400Q_OVH.SelectionChanged += new System.EventHandler(this.dgX400Q_OVH_SelectionChanged);
            // 
            // colX400Q_OVH_Server
            // 
            this.colX400Q_OVH_Server.HeaderText = "Server";
            this.colX400Q_OVH_Server.MaxInputLength = 8;
            this.colX400Q_OVH_Server.MinimumWidth = 65;
            this.colX400Q_OVH_Server.Name = "colX400Q_OVH_Server";
            this.colX400Q_OVH_Server.ReadOnly = true;
            this.colX400Q_OVH_Server.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colX400Q_OVH_Server.Width = 65;
            // 
            // colX400Q_OVH_Queue
            // 
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle5.Format = "N0";
            dataGridViewCellStyle5.NullValue = null;
            this.colX400Q_OVH_Queue.DefaultCellStyle = dataGridViewCellStyle5;
            this.colX400Q_OVH_Queue.HeaderText = "Queue";
            this.colX400Q_OVH_Queue.MaxInputLength = 7;
            this.colX400Q_OVH_Queue.MinimumWidth = 50;
            this.colX400Q_OVH_Queue.Name = "colX400Q_OVH_Queue";
            this.colX400Q_OVH_Queue.ReadOnly = true;
            this.colX400Q_OVH_Queue.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colX400Q_OVH_Queue.Width = 50;
            // 
            // colX400Q_OVH_CheckTime
            // 
            this.colX400Q_OVH_CheckTime.HeaderText = "Checktime";
            this.colX400Q_OVH_CheckTime.MaxInputLength = 100;
            this.colX400Q_OVH_CheckTime.MinimumWidth = 130;
            this.colX400Q_OVH_CheckTime.Name = "colX400Q_OVH_CheckTime";
            this.colX400Q_OVH_CheckTime.ReadOnly = true;
            this.colX400Q_OVH_CheckTime.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colX400Q_OVH_CheckTime.Width = 130;
            // 
            // colX400Q_OVH_Oldest
            // 
            this.colX400Q_OVH_Oldest.HeaderText = "Oldest";
            this.colX400Q_OVH_Oldest.Name = "colX400Q_OVH_Oldest";
            this.colX400Q_OVH_Oldest.ReadOnly = true;
            this.colX400Q_OVH_Oldest.Width = 185;
            // 
            // colX400Q_OVH_Newest
            // 
            this.colX400Q_OVH_Newest.HeaderText = "Newest";
            this.colX400Q_OVH_Newest.Name = "colX400Q_OVH_Newest";
            this.colX400Q_OVH_Newest.ReadOnly = true;
            this.colX400Q_OVH_Newest.Width = 200;
            // 
            // lblX400_OVH
            // 
            this.lblX400_OVH.AutoSize = true;
            this.lblX400_OVH.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblX400_OVH.Location = new System.Drawing.Point(8, 286);
            this.lblX400_OVH.Name = "lblX400_OVH";
            this.lblX400_OVH.Size = new System.Drawing.Size(54, 24);
            this.lblX400_OVH.TabIndex = 21;
            this.lblX400_OVH.Text = "X400";
            // 
            // grbBDR_Q
            // 
            this.grbBDR_Q.Controls.Add(this.pnlX400_BDR_Max);
            this.grbBDR_Q.Controls.Add(this.pnlSMTP_BDR_Max);
            this.grbBDR_Q.Controls.Add(this.lblX400Q_BDR);
            this.grbBDR_Q.Controls.Add(this.lbX400Q_BDR);
            this.grbBDR_Q.Controls.Add(this.lblSMTPQ_BDR);
            this.grbBDR_Q.Controls.Add(this.lbSMTPQ_BDR);
            this.grbBDR_Q.Controls.Add(this.pnSMTPQ_BDR);
            this.grbBDR_Q.Controls.Add(this.lblSMTP_BDR);
            this.grbBDR_Q.Controls.Add(this.lblX400_BDR);
            this.grbBDR_Q.Controls.Add(this.lblMsgs_BDR);
            this.grbBDR_Q.Controls.Add(this.dgX400Q_BDR);
            this.grbBDR_Q.Controls.Add(this.dgSMTPQ_BDR);
            this.grbBDR_Q.Location = new System.Drawing.Point(5, 401);
            this.grbBDR_Q.Name = "grbBDR_Q";
            this.grbBDR_Q.Size = new System.Drawing.Size(651, 425);
            this.grbBDR_Q.TabIndex = 34;
            this.grbBDR_Q.TabStop = false;
            // 
            // pnlX400_BDR_Max
            // 
            this.pnlX400_BDR_Max.BackColor = System.Drawing.Color.White;
            this.pnlX400_BDR_Max.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlX400_BDR_Max.Controls.Add(this.lblX400Q_BDR_MAX);
            this.pnlX400_BDR_Max.Controls.Add(this.lblX400Q_BDR_MAXTime);
            this.pnlX400_BDR_Max.Location = new System.Drawing.Point(480, 381);
            this.pnlX400_BDR_Max.Name = "pnlX400_BDR_Max";
            this.pnlX400_BDR_Max.Size = new System.Drawing.Size(70, 40);
            this.pnlX400_BDR_Max.TabIndex = 78;
            // 
            // lblX400Q_BDR_MAX
            // 
            this.lblX400Q_BDR_MAX.AutoSize = true;
            this.lblX400Q_BDR_MAX.bChanged = false;
            this.lblX400Q_BDR_MAX.Location = new System.Drawing.Point(1, 3);
            this.lblX400Q_BDR_MAX.Max = 0;
            this.lblX400Q_BDR_MAX.Name = "lblX400Q_BDR_MAX";
            this.lblX400Q_BDR_MAX.Size = new System.Drawing.Size(39, 13);
            this.lblX400Q_BDR_MAX.TabIndex = 69;
            this.lblX400Q_BDR_MAX.Text = "Max: 0";
            // 
            // lblX400Q_BDR_MAXTime
            // 
            this.lblX400Q_BDR_MAXTime.AutoSize = true;
            this.lblX400Q_BDR_MAXTime.bChanged = false;
            this.lblX400Q_BDR_MAXTime.Location = new System.Drawing.Point(1, 19);
            this.lblX400Q_BDR_MAXTime.MaxTime = new System.DateTime(((long)(0)));
            this.lblX400Q_BDR_MAXTime.Name = "lblX400Q_BDR_MAXTime";
            this.lblX400Q_BDR_MAXTime.Size = new System.Drawing.Size(50, 13);
            this.lblX400Q_BDR_MAXTime.TabIndex = 73;
            this.lblX400Q_BDR_MAXTime.Text = "At:  --:--:--";
            // 
            // pnlSMTP_BDR_Max
            // 
            this.pnlSMTP_BDR_Max.BackColor = System.Drawing.Color.White;
            this.pnlSMTP_BDR_Max.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlSMTP_BDR_Max.Controls.Add(this.lblSMTPQ_BDR_MAX);
            this.pnlSMTP_BDR_Max.Controls.Add(this.lblSMTPQ_BDR_MAXTime);
            this.pnlSMTP_BDR_Max.Location = new System.Drawing.Point(549, 167);
            this.pnlSMTP_BDR_Max.Name = "pnlSMTP_BDR_Max";
            this.pnlSMTP_BDR_Max.Size = new System.Drawing.Size(77, 41);
            this.pnlSMTP_BDR_Max.TabIndex = 77;
            // 
            // lblSMTPQ_BDR_MAX
            // 
            this.lblSMTPQ_BDR_MAX.AutoSize = true;
            this.lblSMTPQ_BDR_MAX.bChanged = false;
            this.lblSMTPQ_BDR_MAX.Location = new System.Drawing.Point(1, 3);
            this.lblSMTPQ_BDR_MAX.Max = 0;
            this.lblSMTPQ_BDR_MAX.Name = "lblSMTPQ_BDR_MAX";
            this.lblSMTPQ_BDR_MAX.Size = new System.Drawing.Size(39, 13);
            this.lblSMTPQ_BDR_MAX.TabIndex = 69;
            this.lblSMTPQ_BDR_MAX.Text = "Max: 0";
            // 
            // lblSMTPQ_BDR_MAXTime
            // 
            this.lblSMTPQ_BDR_MAXTime.AutoSize = true;
            this.lblSMTPQ_BDR_MAXTime.bChanged = false;
            this.lblSMTPQ_BDR_MAXTime.Location = new System.Drawing.Point(1, 19);
            this.lblSMTPQ_BDR_MAXTime.MaxTime = new System.DateTime(((long)(0)));
            this.lblSMTPQ_BDR_MAXTime.Name = "lblSMTPQ_BDR_MAXTime";
            this.lblSMTPQ_BDR_MAXTime.Size = new System.Drawing.Size(50, 13);
            this.lblSMTPQ_BDR_MAXTime.TabIndex = 73;
            this.lblSMTPQ_BDR_MAXTime.Text = "At:  --:--:--";
            // 
            // lblX400Q_BDR
            // 
            this.lblX400Q_BDR.AutoSize = true;
            this.lblX400Q_BDR.Location = new System.Drawing.Point(546, 297);
            this.lblX400Q_BDR.Name = "lblX400Q_BDR";
            this.lblX400Q_BDR.Size = new System.Drawing.Size(35, 13);
            this.lblX400Q_BDR.TabIndex = 69;
            this.lblX400Q_BDR.Text = "Trend";
            // 
            // lbX400Q_BDR
            // 
            this.lbX400Q_BDR.bChanged = false;
            this.lbX400Q_BDR.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lbX400Q_BDR.FormattingEnabled = true;
            this.lbX400Q_BDR.intSeli = ((short)(0));
            this.lbX400Q_BDR.intTrend = 0;
            this.lbX400Q_BDR.Location = new System.Drawing.Point(549, 313);
            this.lbX400Q_BDR.Max_Occs = ((short)(60));
            this.lbX400Q_BDR.Name = "lbX400Q_BDR";
            this.lbX400Q_BDR.Size = new System.Drawing.Size(76, 108);
            this.lbX400Q_BDR.TabIndex = 68;
            // 
            // lblSMTPQ_BDR
            // 
            this.lblSMTPQ_BDR.AutoSize = true;
            this.lblSMTPQ_BDR.Location = new System.Drawing.Point(546, 31);
            this.lblSMTPQ_BDR.Name = "lblSMTPQ_BDR";
            this.lblSMTPQ_BDR.Size = new System.Drawing.Size(35, 13);
            this.lblSMTPQ_BDR.TabIndex = 65;
            this.lblSMTPQ_BDR.Text = "Trend";
            // 
            // lbSMTPQ_BDR
            // 
            this.lbSMTPQ_BDR.bChanged = false;
            this.lbSMTPQ_BDR.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lbSMTPQ_BDR.FormattingEnabled = true;
            this.lbSMTPQ_BDR.intSeli = ((short)(0));
            this.lbSMTPQ_BDR.intTrend = 0;
            this.lbSMTPQ_BDR.Location = new System.Drawing.Point(550, 47);
            this.lbSMTPQ_BDR.Max_Occs = ((short)(60));
            this.lbSMTPQ_BDR.Name = "lbSMTPQ_BDR";
            this.lbSMTPQ_BDR.Size = new System.Drawing.Size(76, 121);
            this.lbSMTPQ_BDR.TabIndex = 64;
            // 
            // pnSMTPQ_BDR
            // 
            this.pnSMTPQ_BDR.Location = new System.Drawing.Point(12, 227);
            this.pnSMTPQ_BDR.Name = "pnSMTPQ_BDR";
            this.pnSMTPQ_BDR.Size = new System.Drawing.Size(610, 48);
            this.pnSMTPQ_BDR.TabIndex = 62;
            // 
            // lblSMTP_BDR
            // 
            this.lblSMTP_BDR.AutoSize = true;
            this.lblSMTP_BDR.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSMTP_BDR.Location = new System.Drawing.Point(6, 21);
            this.lblSMTP_BDR.Name = "lblSMTP_BDR";
            this.lblSMTP_BDR.Size = new System.Drawing.Size(62, 24);
            this.lblSMTP_BDR.TabIndex = 37;
            this.lblSMTP_BDR.Text = "SMTP";
            // 
            // lblX400_BDR
            // 
            this.lblX400_BDR.AutoSize = true;
            this.lblX400_BDR.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblX400_BDR.Location = new System.Drawing.Point(8, 286);
            this.lblX400_BDR.Name = "lblX400_BDR";
            this.lblX400_BDR.Size = new System.Drawing.Size(54, 24);
            this.lblX400_BDR.TabIndex = 36;
            this.lblX400_BDR.Text = "X400";
            // 
            // dgX400Q_BDR
            // 
            this.dgX400Q_BDR.AllowUserToAddRows = false;
            this.dgX400Q_BDR.AllowUserToDeleteRows = false;
            this.dgX400Q_BDR.AllowUserToResizeColumns = false;
            this.dgX400Q_BDR.AllowUserToResizeRows = false;
            this.dgX400Q_BDR.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgX400Q_BDR.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colX400Q_BDR_Server,
            this.colX400Q_BDR_Queue,
            this.colX400Q_BDR_CheckTime,
            this.colX400Q_BDR_Oldest,
            this.colX400Q_BDR_Newest});
            this.dgX400Q_BDR.Location = new System.Drawing.Point(10, 313);
            this.dgX400Q_BDR.MultiSelect = false;
            this.dgX400Q_BDR.Name = "dgX400Q_BDR";
            this.dgX400Q_BDR.ReadOnly = true;
            this.dgX400Q_BDR.RowHeadersVisible = false;
            this.dgX400Q_BDR.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgX400Q_BDR.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgX400Q_BDR.Size = new System.Drawing.Size(540, 69);
            this.dgX400Q_BDR.TabIndex = 1;
            this.dgX400Q_BDR.SelectionChanged += new System.EventHandler(this.dgX400Q_BDR_SelectionChanged);
            // 
            // colX400Q_BDR_Server
            // 
            this.colX400Q_BDR_Server.FillWeight = 65F;
            this.colX400Q_BDR_Server.HeaderText = "Server";
            this.colX400Q_BDR_Server.MaxInputLength = 8;
            this.colX400Q_BDR_Server.MinimumWidth = 65;
            this.colX400Q_BDR_Server.Name = "colX400Q_BDR_Server";
            this.colX400Q_BDR_Server.ReadOnly = true;
            this.colX400Q_BDR_Server.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colX400Q_BDR_Server.Width = 65;
            // 
            // colX400Q_BDR_Queue
            // 
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle6.Format = "N0";
            dataGridViewCellStyle6.NullValue = null;
            this.colX400Q_BDR_Queue.DefaultCellStyle = dataGridViewCellStyle6;
            this.colX400Q_BDR_Queue.HeaderText = "Queue";
            this.colX400Q_BDR_Queue.MaxInputLength = 7;
            this.colX400Q_BDR_Queue.MinimumWidth = 50;
            this.colX400Q_BDR_Queue.Name = "colX400Q_BDR_Queue";
            this.colX400Q_BDR_Queue.ReadOnly = true;
            this.colX400Q_BDR_Queue.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colX400Q_BDR_Queue.Width = 50;
            // 
            // colX400Q_BDR_CheckTime
            // 
            this.colX400Q_BDR_CheckTime.HeaderText = "Checktime";
            this.colX400Q_BDR_CheckTime.MaxInputLength = 100;
            this.colX400Q_BDR_CheckTime.MinimumWidth = 130;
            this.colX400Q_BDR_CheckTime.Name = "colX400Q_BDR_CheckTime";
            this.colX400Q_BDR_CheckTime.ReadOnly = true;
            this.colX400Q_BDR_CheckTime.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colX400Q_BDR_CheckTime.Width = 130;
            // 
            // colX400Q_BDR_Oldest
            // 
            this.colX400Q_BDR_Oldest.HeaderText = "Oldest";
            this.colX400Q_BDR_Oldest.Name = "colX400Q_BDR_Oldest";
            this.colX400Q_BDR_Oldest.ReadOnly = true;
            this.colX400Q_BDR_Oldest.Width = 182;
            // 
            // colX400Q_BDR_Newest
            // 
            this.colX400Q_BDR_Newest.HeaderText = "Newest";
            this.colX400Q_BDR_Newest.Name = "colX400Q_BDR_Newest";
            this.colX400Q_BDR_Newest.ReadOnly = true;
            this.colX400Q_BDR_Newest.Width = 182;
            // 
            // grbAllQueue
            // 
            this.grbAllQueue.Controls.Add(this.grbNagios);
            this.grbAllQueue.Controls.Add(this.lblNoDebug);
            this.grbAllQueue.Controls.Add(this.pnlNoDebug);
            this.grbAllQueue.Controls.Add(this.cbDebug);
            this.grbAllQueue.Controls.Add(this.cmdDebugLog_Toggle);
            this.grbAllQueue.Controls.Add(this.lblSettings);
            this.grbAllQueue.Controls.Add(this.lblCore);
            this.grbAllQueue.Controls.Add(this.grbDigipoort);
            this.grbAllQueue.Controls.Add(this.grbCore_Q);
            this.grbAllQueue.Controls.Add(this.lblOverheden);
            this.grbAllQueue.Controls.Add(this.grbLog);
            this.grbAllQueue.Controls.Add(this.lblBedrijven);
            this.grbAllQueue.Controls.Add(this.grbBDR_Q);
            this.grbAllQueue.Controls.Add(this.grbOVH_Q);
            this.grbAllQueue.Controls.Add(this.grpSettings);
            this.grbAllQueue.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.grbAllQueue.Location = new System.Drawing.Point(12, 19);
            this.grbAllQueue.Name = "grbAllQueue";
            this.grbAllQueue.Size = new System.Drawing.Size(1489, 838);
            this.grbAllQueue.TabIndex = 1;
            this.grbAllQueue.TabStop = false;
            // 
            // grbNagios
            // 
            this.grbNagios.Controls.Add(this.lblNagios);
            this.grbNagios.Controls.Add(this.txtNagios_Queue);
            this.grbNagios.Location = new System.Drawing.Point(8, 307);
            this.grbNagios.Name = "grbNagios";
            this.grbNagios.Size = new System.Drawing.Size(323, 83);
            this.grbNagios.TabIndex = 70;
            this.grbNagios.TabStop = false;
            // 
            // txtNagios_Queue
            // 
            this.txtNagios_Queue.Enabled = false;
            this.txtNagios_Queue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNagios_Queue.Location = new System.Drawing.Point(4, 44);
            this.txtNagios_Queue.Multiline = true;
            this.txtNagios_Queue.Name = "txtNagios_Queue";
            this.txtNagios_Queue.Size = new System.Drawing.Size(313, 19);
            this.txtNagios_Queue.TabIndex = 71;
            this.txtNagios_Queue.Text = "OK: No queue(s) on kslv114 or kslv115";
            this.txtNagios_Queue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblNoDebug
            // 
            this.lblNoDebug.AutoSize = true;
            this.lblNoDebug.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNoDebug.ForeColor = System.Drawing.Color.Black;
            this.lblNoDebug.Location = new System.Drawing.Point(91, 11);
            this.lblNoDebug.Name = "lblNoDebug";
            this.lblNoDebug.Size = new System.Drawing.Size(157, 33);
            this.lblNoDebug.TabIndex = 68;
            this.lblNoDebug.Text = "Dashboard";
            // 
            // pnlNoDebug
            // 
            this.pnlNoDebug.BackColor = System.Drawing.Color.White;
            this.pnlNoDebug.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlNoDebug.Location = new System.Drawing.Point(13, 32);
            this.pnlNoDebug.Name = "pnlNoDebug";
            this.pnlNoDebug.Size = new System.Drawing.Size(315, 5);
            this.pnlNoDebug.TabIndex = 67;
            // 
            // cbDebug
            // 
            this.cbDebug.AutoSize = true;
            this.cbDebug.Location = new System.Drawing.Point(17, 22);
            this.cbDebug.Name = "cbDebug";
            this.cbDebug.Size = new System.Drawing.Size(58, 17);
            this.cbDebug.TabIndex = 65;
            this.cbDebug.Text = "Debug";
            this.cbDebug.UseVisualStyleBackColor = true;
            this.cbDebug.Visible = false;
            // 
            // cmdDebugLog_Toggle
            // 
            this.cmdDebugLog_Toggle.Location = new System.Drawing.Point(80, 19);
            this.cmdDebugLog_Toggle.Name = "cmdDebugLog_Toggle";
            this.cmdDebugLog_Toggle.Size = new System.Drawing.Size(136, 23);
            this.cmdDebugLog_Toggle.TabIndex = 63;
            this.cmdDebugLog_Toggle.Text = "Show/Hide debug log";
            this.cmdDebugLog_Toggle.UseVisualStyleBackColor = true;
            this.cmdDebugLog_Toggle.Visible = false;
            this.cmdDebugLog_Toggle.Click += new System.EventHandler(this.cmdDebugLog_Toggle_Click);
            // 
            // lblSettings
            // 
            this.lblSettings.AutoSize = true;
            this.lblSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSettings.Location = new System.Drawing.Point(342, 17);
            this.lblSettings.Name = "lblSettings";
            this.lblSettings.Size = new System.Drawing.Size(90, 25);
            this.lblSettings.TabIndex = 56;
            this.lblSettings.Text = "Settings";
            // 
            // lblCore
            // 
            this.lblCore.AutoSize = true;
            this.lblCore.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCore.Location = new System.Drawing.Point(945, 12);
            this.lblCore.Name = "lblCore";
            this.lblCore.Size = new System.Drawing.Size(78, 33);
            this.lblCore.TabIndex = 57;
            this.lblCore.Text = "Core";
            // 
            // grbDigipoort
            // 
            this.grbDigipoort.Controls.Add(this.pbDigipoort);
            this.grbDigipoort.Location = new System.Drawing.Point(8, 52);
            this.grbDigipoort.Name = "grbDigipoort";
            this.grbDigipoort.Size = new System.Drawing.Size(323, 238);
            this.grbDigipoort.TabIndex = 64;
            this.grbDigipoort.TabStop = false;
            // 
            // pbDigipoort
            // 
            this.pbDigipoort.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pbDigipoort.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pbDigipoort.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbDigipoort.Image = ((System.Drawing.Image)(resources.GetObject("pbDigipoort.Image")));
            this.pbDigipoort.Location = new System.Drawing.Point(40, 20);
            this.pbDigipoort.Name = "pbDigipoort";
            this.pbDigipoort.Size = new System.Drawing.Size(244, 204);
            this.pbDigipoort.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbDigipoort.TabIndex = 65;
            this.pbDigipoort.TabStop = false;
            // 
            // lblOverheden
            // 
            this.lblOverheden.AutoSize = true;
            this.lblOverheden.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOverheden.Location = new System.Drawing.Point(907, 394);
            this.lblOverheden.Name = "lblOverheden";
            this.lblOverheden.Size = new System.Drawing.Size(159, 33);
            this.lblOverheden.TabIndex = 53;
            this.lblOverheden.Text = "Overheden";
            // 
            // grbLog
            // 
            this.grbLog.Controls.Add(this.lblLog);
            this.grbLog.Controls.Add(this.cmdDebugLog_Clear);
            this.grbLog.Controls.Add(this.lblDebugError_val);
            this.grbLog.Controls.Add(this.lbDebug);
            this.grbLog.Controls.Add(this.lblDebugError_text);
            this.grbLog.Location = new System.Drawing.Point(12, 52);
            this.grbLog.Name = "grbLog";
            this.grbLog.Size = new System.Drawing.Size(316, 235);
            this.grbLog.TabIndex = 62;
            this.grbLog.TabStop = false;
            // 
            // lblLog
            // 
            this.lblLog.AutoSize = true;
            this.lblLog.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLog.Location = new System.Drawing.Point(6, -8);
            this.lblLog.Name = "lblLog";
            this.lblLog.Size = new System.Drawing.Size(48, 25);
            this.lblLog.TabIndex = 61;
            this.lblLog.Text = "Log";
            // 
            // cmdDebugLog_Clear
            // 
            this.cmdDebugLog_Clear.Location = new System.Drawing.Point(4, 207);
            this.cmdDebugLog_Clear.Name = "cmdDebugLog_Clear";
            this.cmdDebugLog_Clear.Size = new System.Drawing.Size(75, 23);
            this.cmdDebugLog_Clear.TabIndex = 58;
            this.cmdDebugLog_Clear.Text = "Clear logbox";
            this.cmdDebugLog_Clear.UseVisualStyleBackColor = true;
            this.cmdDebugLog_Clear.Click += new System.EventHandler(this.cmdDebug_Click);
            // 
            // lblDebugError_val
            // 
            this.lblDebugError_val.AutoSize = true;
            this.lblDebugError_val.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDebugError_val.Location = new System.Drawing.Point(293, 273);
            this.lblDebugError_val.Name = "lblDebugError_val";
            this.lblDebugError_val.Size = new System.Drawing.Size(13, 13);
            this.lblDebugError_val.TabIndex = 60;
            this.lblDebugError_val.Text = "0";
            // 
            // lbDebug
            // 
            this.lbDebug.FormattingEnabled = true;
            this.lbDebug.HorizontalScrollbar = true;
            this.lbDebug.Location = new System.Drawing.Point(6, 18);
            this.lbDebug.Name = "lbDebug";
            this.lbDebug.ScrollAlwaysVisible = true;
            this.lbDebug.Size = new System.Drawing.Size(300, 186);
            this.lbDebug.TabIndex = 54;
            // 
            // lblDebugError_text
            // 
            this.lblDebugError_text.AutoSize = true;
            this.lblDebugError_text.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDebugError_text.Location = new System.Drawing.Point(217, 273);
            this.lblDebugError_text.Name = "lblDebugError_text";
            this.lblDebugError_text.Size = new System.Drawing.Size(77, 13);
            this.lblDebugError_text.TabIndex = 59;
            this.lblDebugError_text.Text = "# Error events:";
            // 
            // lblBedrijven
            // 
            this.lblBedrijven.AutoSize = true;
            this.lblBedrijven.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBedrijven.Location = new System.Drawing.Point(248, 394);
            this.lblBedrijven.Name = "lblBedrijven";
            this.lblBedrijven.Size = new System.Drawing.Size(137, 33);
            this.lblBedrijven.TabIndex = 38;
            this.lblBedrijven.Text = "Bedrijven";
            // 
            // grpSettings
            // 
            this.grpSettings.BackColor = System.Drawing.SystemColors.Control;
            this.grpSettings.Controls.Add(this.cmbEnv);
            this.grpSettings.Controls.Add(this.lblEnv);
            this.grpSettings.Controls.Add(this.grbOptions);
            this.grpSettings.Controls.Add(this.pnlSettings);
            this.grpSettings.Controls.Add(this.cmbGroupSMTP);
            this.grpSettings.Controls.Add(this.lblGroupSMTP);
            this.grpSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpSettings.Location = new System.Drawing.Point(340, 24);
            this.grpSettings.Name = "grpSettings";
            this.grpSettings.Size = new System.Drawing.Size(316, 366);
            this.grpSettings.TabIndex = 52;
            this.grpSettings.TabStop = false;
            // 
            // cmbEnv
            // 
            this.cmbEnv.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEnv.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.cmbEnv.FormattingEnabled = true;
            this.cmbEnv.Location = new System.Drawing.Point(120, 31);
            this.cmbEnv.Name = "cmbEnv";
            this.cmbEnv.Size = new System.Drawing.Size(140, 21);
            this.cmbEnv.TabIndex = 65;
            this.cmbEnv.SelectedIndexChanged += new System.EventHandler(this.cmbEnv_SelectedIndexChanged);
            // 
            // lblEnv
            // 
            this.lblEnv.AutoSize = true;
            this.lblEnv.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEnv.Location = new System.Drawing.Point(14, 32);
            this.lblEnv.Name = "lblEnv";
            this.lblEnv.Size = new System.Drawing.Size(97, 16);
            this.lblEnv.TabIndex = 64;
            this.lblEnv.Text = "Environment:";
            // 
            // grbOptions
            // 
            this.grbOptions.Controls.Add(this.lblSaveToOptions);
            this.grbOptions.Controls.Add(this.lblSaveFile);
            this.grbOptions.Controls.Add(this.cmdSaveToOptions);
            this.grbOptions.Location = new System.Drawing.Point(12, 283);
            this.grbOptions.Name = "grbOptions";
            this.grbOptions.Size = new System.Drawing.Size(295, 71);
            this.grbOptions.TabIndex = 63;
            this.grbOptions.TabStop = false;
            this.grbOptions.Text = "Options";
            // 
            // lblSaveToOptions
            // 
            this.lblSaveToOptions.AutoSize = true;
            this.lblSaveToOptions.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaveToOptions.Location = new System.Drawing.Point(7, 20);
            this.lblSaveToOptions.Name = "lblSaveToOptions";
            this.lblSaveToOptions.Size = new System.Drawing.Size(147, 16);
            this.lblSaveToOptions.TabIndex = 61;
            this.lblSaveToOptions.Text = "Preserve queue info";
            // 
            // lblSaveFile
            // 
            this.lblSaveFile.AutoSize = true;
            this.lblSaveFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaveFile.Location = new System.Drawing.Point(83, 47);
            this.lblSaveFile.Name = "lblSaveFile";
            this.lblSaveFile.Size = new System.Drawing.Size(58, 13);
            this.lblSaveFile.TabIndex = 13;
            this.lblSaveFile.Text = "lblSaveFile";
            // 
            // cmdSaveToOptions
            // 
            this.cmdSaveToOptions.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdSaveToOptions.Location = new System.Drawing.Point(10, 42);
            this.cmdSaveToOptions.Name = "cmdSaveToOptions";
            this.cmdSaveToOptions.Size = new System.Drawing.Size(64, 23);
            this.cmdSaveToOptions.TabIndex = 8;
            this.cmdSaveToOptions.Text = "Save to...";
            this.cmdSaveToOptions.UseVisualStyleBackColor = true;
            this.cmdSaveToOptions.Click += new System.EventHandler(this.cmdSaveToOptions_Click);
            // 
            // pnlSettings
            // 
            this.pnlSettings.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlSettings.Controls.Add(this.lblAutoUpdate);
            this.pnlSettings.Controls.Add(this.cmdManualUpdate);
            this.pnlSettings.Controls.Add(this.lblUpdte);
            this.pnlSettings.Controls.Add(this.lblRefresh_till_refresh);
            this.pnlSettings.Controls.Add(this.lblRefresh_last_refresh);
            this.pnlSettings.Controls.Add(this.rbAutoUpdateOn);
            this.pnlSettings.Controls.Add(this.rbAutoUpdateOff);
            this.pnlSettings.Location = new System.Drawing.Point(9, 68);
            this.pnlSettings.Name = "pnlSettings";
            this.pnlSettings.Size = new System.Drawing.Size(295, 129);
            this.pnlSettings.TabIndex = 62;
            // 
            // lblAutoUpdate
            // 
            this.lblAutoUpdate.AutoSize = true;
            this.lblAutoUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAutoUpdate.Location = new System.Drawing.Point(2, 55);
            this.lblAutoUpdate.Name = "lblAutoUpdate";
            this.lblAutoUpdate.Size = new System.Drawing.Size(237, 13);
            this.lblAutoUpdate.TabIndex = 58;
            this.lblAutoUpdate.Text = "Automatic                                                             ";
            // 
            // cmdManualUpdate
            // 
            this.cmdManualUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdManualUpdate.Location = new System.Drawing.Point(2, 24);
            this.cmdManualUpdate.Name = "cmdManualUpdate";
            this.cmdManualUpdate.Size = new System.Drawing.Size(75, 23);
            this.cmdManualUpdate.TabIndex = 57;
            this.cmdManualUpdate.Text = "Update now";
            this.cmdManualUpdate.UseVisualStyleBackColor = true;
            this.cmdManualUpdate.Click += new System.EventHandler(this.cmdManualUpdate_Click);
            // 
            // lblUpdte
            // 
            this.lblUpdte.AutoSize = true;
            this.lblUpdte.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUpdte.Location = new System.Drawing.Point(0, 2);
            this.lblUpdte.Name = "lblUpdte";
            this.lblUpdte.Size = new System.Drawing.Size(59, 16);
            this.lblUpdte.TabIndex = 56;
            this.lblUpdte.Text = "Update";
            // 
            // lblRefresh_till_refresh
            // 
            this.lblRefresh_till_refresh.AutoSize = true;
            this.lblRefresh_till_refresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRefresh_till_refresh.Location = new System.Drawing.Point(55, 71);
            this.lblRefresh_till_refresh.Name = "lblRefresh_till_refresh";
            this.lblRefresh_till_refresh.Size = new System.Drawing.Size(107, 13);
            this.lblRefresh_till_refresh.TabIndex = 6;
            this.lblRefresh_till_refresh.Text = "lblRefresh_till_refresh";
            this.lblRefresh_till_refresh.Visible = false;
            // 
            // lblRefresh_last_refresh
            // 
            this.lblRefresh_last_refresh.AutoSize = true;
            this.lblRefresh_last_refresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRefresh_last_refresh.Location = new System.Drawing.Point(55, 89);
            this.lblRefresh_last_refresh.Name = "lblRefresh_last_refresh";
            this.lblRefresh_last_refresh.Size = new System.Drawing.Size(114, 13);
            this.lblRefresh_last_refresh.TabIndex = 9;
            this.lblRefresh_last_refresh.Text = "lblRefresh_last_refresh";
            this.lblRefresh_last_refresh.Visible = false;
            // 
            // rbAutoUpdateOn
            // 
            this.rbAutoUpdateOn.AutoSize = true;
            this.rbAutoUpdateOn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbAutoUpdateOn.Location = new System.Drawing.Point(6, 72);
            this.rbAutoUpdateOn.Name = "rbAutoUpdateOn";
            this.rbAutoUpdateOn.Size = new System.Drawing.Size(39, 17);
            this.rbAutoUpdateOn.TabIndex = 53;
            this.rbAutoUpdateOn.TabStop = true;
            this.rbAutoUpdateOn.Text = "On";
            this.rbAutoUpdateOn.UseVisualStyleBackColor = true;
            this.rbAutoUpdateOn.CheckedChanged += new System.EventHandler(this.rbAutoUpdateOn_CheckedChanged);
            // 
            // rbAutoUpdateOff
            // 
            this.rbAutoUpdateOff.AutoSize = true;
            this.rbAutoUpdateOff.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbAutoUpdateOff.Location = new System.Drawing.Point(6, 106);
            this.rbAutoUpdateOff.Name = "rbAutoUpdateOff";
            this.rbAutoUpdateOff.Size = new System.Drawing.Size(39, 17);
            this.rbAutoUpdateOff.TabIndex = 52;
            this.rbAutoUpdateOff.TabStop = true;
            this.rbAutoUpdateOff.Text = "Off";
            this.rbAutoUpdateOff.UseVisualStyleBackColor = true;
            this.rbAutoUpdateOff.CheckedChanged += new System.EventHandler(this.rbAutoUpdateOff_CheckedChanged);
            // 
            // cmbGroupSMTP
            // 
            this.cmbGroupSMTP.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbGroupSMTP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbGroupSMTP.FormattingEnabled = true;
            this.cmbGroupSMTP.Items.AddRange(new object[] {
            "Domain",
            "Server"});
            this.cmbGroupSMTP.Location = new System.Drawing.Point(12, 229);
            this.cmbGroupSMTP.Name = "cmbGroupSMTP";
            this.cmbGroupSMTP.Size = new System.Drawing.Size(173, 21);
            this.cmbGroupSMTP.TabIndex = 61;
            this.cmbGroupSMTP.SelectedIndexChanged += new System.EventHandler(this.cmbGroupSMTP_SelectedIndexChanged);
            // 
            // lblGroupSMTP
            // 
            this.lblGroupSMTP.AutoSize = true;
            this.lblGroupSMTP.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGroupSMTP.Location = new System.Drawing.Point(12, 208);
            this.lblGroupSMTP.Name = "lblGroupSMTP";
            this.lblGroupSMTP.Size = new System.Drawing.Size(176, 16);
            this.lblGroupSMTP.TabIndex = 60;
            this.lblGroupSMTP.Text = "Group SMTP queues by:";
            // 
            // frmDashQueue
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1509, 908);
            this.Controls.Add(this.grbAllQueue);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Sizable;
            this.Name = "frmDashQueue";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmDashQueue - Digipoort overview Messagequeues";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmDashQueue_FormClosing);
            this.Load += new System.EventHandler(this.frmDashQueue_Load);
            this.Resize += new System.EventHandler(this.frmDashQueue_Resize);
            this.Controls.SetChildIndex(this.lblHostName, 0);
            this.Controls.SetChildIndex(this.grbAllQueue, 0);
            this.Controls.SetChildIndex(this.cmdAfsluiten, 0);
            this.Controls.SetChildIndex(this.grbConnect, 0);
            this.grbConnect.ResumeLayout(false);
            this.grbConnect.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgSMTPQ_OVH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgSMTPQ_BDR)).EndInit();
            this.grbCore_Q.ResumeLayout(false);
            this.grbCore_Q.PerformLayout();
            this.grbCoreAlarm.ResumeLayout(false);
            this.pnlCoreMax.ResumeLayout(false);
            this.pnlCoreMax.PerformLayout();
            this.pnlCore2.ResumeLayout(false);
            this.pnlCore2.PerformLayout();
            this.pnlCore1.ResumeLayout(false);
            this.pnlCore1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgCoreQ)).EndInit();
            this.grbOVH_Q.ResumeLayout(false);
            this.grbOVH_Q.PerformLayout();
            this.pnlX400_OVH_Max.ResumeLayout(false);
            this.pnlX400_OVH_Max.PerformLayout();
            this.pnlSMTP_OVH_Max.ResumeLayout(false);
            this.pnlSMTP_OVH_Max.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgX400Q_OVH)).EndInit();
            this.grbBDR_Q.ResumeLayout(false);
            this.grbBDR_Q.PerformLayout();
            this.pnlX400_BDR_Max.ResumeLayout(false);
            this.pnlX400_BDR_Max.PerformLayout();
            this.pnlSMTP_BDR_Max.ResumeLayout(false);
            this.pnlSMTP_BDR_Max.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgX400Q_BDR)).EndInit();
            this.grbAllQueue.ResumeLayout(false);
            this.grbAllQueue.PerformLayout();
            this.grbNagios.ResumeLayout(false);
            this.grbNagios.PerformLayout();
            this.grbDigipoort.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbDigipoort)).EndInit();
            this.grbLog.ResumeLayout(false);
            this.grbLog.PerformLayout();
            this.grpSettings.ResumeLayout(false);
            this.grpSettings.PerformLayout();
            this.grbOptions.ResumeLayout(false);
            this.grbOptions.PerformLayout();
            this.pnlSettings.ResumeLayout(false);
            this.pnlSettings.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer tmrSMTPQ;
        private System.Windows.Forms.Timer tmrCoreQ;
        private System.Windows.Forms.Timer tmrX400Q;
        private System.Windows.Forms.Timer tmrRefresh;
        private System.Windows.Forms.Timer tmrSeconds;
        private System.Windows.Forms.Label lblMsgs_BDR;
        private System.Windows.Forms.DataGridView dgSMTPQ_BDR;
        private System.Windows.Forms.GroupBox grbCore_Q;
        private System.Windows.Forms.Label lblCoreTotal2;
        private System.Windows.Forms.Label lblCoreTotal1;
        private System.Windows.Forms.DataGridView dgCoreQ;
        private System.Windows.Forms.Label lblMsgs_OVH;
        private System.Windows.Forms.DataGridView dgSMTPQ_OVH;
        private System.Windows.Forms.GroupBox grbOVH_Q;
        private System.Windows.Forms.DataGridView dgX400Q_OVH;
        private System.Windows.Forms.GroupBox grbBDR_Q;
        private System.Windows.Forms.DataGridView dgX400Q_BDR;
        private System.Windows.Forms.GroupBox grbAllQueue;
        private System.Windows.Forms.Label lblCoreOldest1;
        private System.Windows.Forms.Label lblCoreOldest2;
        private System.Windows.Forms.Label lblMsgs_Core_Total1;
        private System.Windows.Forms.Label lblMsgs_Core_Age1;
        private System.Windows.Forms.Panel pnlCore2;
        private System.Windows.Forms.Panel pnlCore1;
        private System.Windows.Forms.Label lblMsgs_Core_Age2;
        private System.Windows.Forms.Label lblMsgs_Core_Total2;
        private System.Windows.Forms.GroupBox grpSettings;
        private System.Windows.Forms.RadioButton rbAutoUpdateOn;
        private System.Windows.Forms.RadioButton rbAutoUpdateOff;
        private System.Windows.Forms.Label lblRefresh_last_refresh;
        private System.Windows.Forms.Label lblRefresh_till_refresh;
        private System.Windows.Forms.Label lblUpdte;
        private System.Windows.Forms.Button cmdSaveToOptions;
        private System.Windows.Forms.Label lblSaveFile;
        private System.Windows.Forms.Label lblGroupSMTP;
        private System.Windows.Forms.ComboBox cmbGroupSMTP;
        private System.Windows.Forms.Label lblX400_OVH;
        private System.Windows.Forms.Label lblX400_BDR;
        private System.Windows.Forms.Label lblSMTP_OVH;
        private System.Windows.Forms.Label lblSMTP_BDR;
        private System.Windows.Forms.Label lblOverheden;
        private System.Windows.Forms.Label lblBedrijven;
        private System.Windows.Forms.ListBox lbDebug;
        private System.Windows.Forms.Label lblSettings;
        private System.Windows.Forms.Panel pnlSettings;
        private System.Windows.Forms.Label lblCore;
        private System.Windows.Forms.Button cmdDebugLog_Clear;
        private System.Windows.Forms.DataGridViewTextBoxColumn colX400Q_BDR_Server;
        private System.Windows.Forms.DataGridViewTextBoxColumn colX400Q_BDR_Queue;
        private System.Windows.Forms.DataGridViewTextBoxColumn colX400Q_BDR_CheckTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn colX400Q_BDR_Oldest;
        private System.Windows.Forms.DataGridViewTextBoxColumn colX400Q_BDR_Newest;
        private System.Windows.Forms.Button cmdManualUpdate;
        private System.Windows.Forms.Label lblAutoUpdate;
        private System.Windows.Forms.Label lblDebugError_val;
        private System.Windows.Forms.Label lblDebugError_text;
        private System.Windows.Forms.Label lblLog;
        private System.Windows.Forms.Panel pnSMTPQ_BDR;
        private lbTrend lbSMTPQ_OVH;
        private lbTrend lbSMTPQ_BDR;
        private lbTrend lbCoreQ_SMTP;
        private System.Windows.Forms.Label lblSMTPQ_BDR;
        private System.Windows.Forms.Label lblCoreQ;
        private System.Windows.Forms.Label lblSMTPQ_OVH;
        private System.Windows.Forms.Label lblX400Q_OVH;
        private lbTrend lbX400Q_OVH;
        private System.Windows.Forms.Label lblX400Q_BDR;
        private lbTrend lbX400Q_BDR;
        private System.Windows.Forms.GroupBox grbLog;
        private System.Windows.Forms.GroupBox grbDigipoort;
        private System.Windows.Forms.PictureBox pbDigipoort;
        private lblMax lblCore_SMTP_MAX;
        private lblMax lblCore_X400_MAX;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSMTP_OVH_Server;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSMTP_OVH_Queue;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSMTPQ_OVH_checktime;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSMTP_OVH_Domain;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSMTP_OVH_Age;
        private System.Windows.Forms.DataGridViewTextBoxColumn colX400Q_OVH_Server;
        private System.Windows.Forms.DataGridViewTextBoxColumn colX400Q_OVH_Queue;
        private System.Windows.Forms.DataGridViewTextBoxColumn colX400Q_OVH_CheckTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn colX400Q_OVH_Oldest;
        private System.Windows.Forms.DataGridViewTextBoxColumn colX400Q_OVH_Newest;
        private lblMaxTime lblCore_SMTP_MaxTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCoreQ_Server;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCoreQ_Proto;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCoreQ_Queue;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCoreQ_CheckTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCoreQ_Oldest;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCoreQ_Newest;
        private lblMax lblCoreTrend_X400;
        private lblMax lblCoreTrend_SMTP;
        private lblMaxTime lblCore_X400_MaxTime;
        private lbTrend lbCoreQ_X400;
        private System.Windows.Forms.Panel pnlCoreMax;
        private System.Windows.Forms.Panel pnlCore_Split;
        private System.Windows.Forms.Panel pnlSMTP_OVH_Max;
        private lblMax lblSMTPQ_OVH_MAX;
        private lblMaxTime lblSMTPQ_OVH_MAXTime;
        private System.Windows.Forms.Panel pnlSMTP_BDR_Max;
        private lblMax lblSMTPQ_BDR_MAX;
        private lblMaxTime lblSMTPQ_BDR_MAXTime;
        private System.Windows.Forms.Panel pnlX400_OVH_Max;
        private lblMax lblX400Q_OVH_MAX;
        private lblMaxTime lblX400Q_OVH_MAXTime;
        private System.Windows.Forms.Panel pnlX400_BDR_Max;
        private lblMax lblX400Q_BDR_MAX;
        private lblMaxTime lblX400Q_BDR_MAXTime;
        private System.Windows.Forms.GroupBox grbOptions;
        private System.Windows.Forms.Label lblSaveToOptions;
        private System.Windows.Forms.CheckBox cbDebug;
        private System.Windows.Forms.Button cmdDebugLog_Toggle;
        private System.Windows.Forms.Label lblNoDebug;
        private System.Windows.Forms.Panel pnlNoDebug;
        private System.Windows.Forms.Label lblNagios;
        private System.Windows.Forms.GroupBox grbNagios;
        private System.Windows.Forms.TextBox txtNagios_Queue;
        private System.Windows.Forms.ComboBox cmbEnv;
        private System.Windows.Forms.Label lblEnv;
        private System.Windows.Forms.GroupBox grbCoreAlarm;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.FlowLayoutPanel flpCoreAlarm;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSMTPQ_BDR_server;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSMTPQ_BDR_Queue;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSMTPQ_BDR_checktime;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSMTPQ_BDR_Domain;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSMTP_BDR_Age;
    }
}