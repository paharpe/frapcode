﻿namespace dbDashboard
{
    partial class frmDashBase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDashBase));
            this.cmdAfsluiten = new System.Windows.Forms.Button();
            this.grbConnect = new System.Windows.Forms.GroupBox();
            this.cmdConnect = new System.Windows.Forms.Button();
            this.lblConnected = new System.Windows.Forms.Label();
            this.lblHostName = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsbMenu = new System.Windows.Forms.ToolStripButton();
            this.pnlTSBMasquee = new System.Windows.Forms.Panel();
            this.grbConnect.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmdAfsluiten
            // 
            this.cmdAfsluiten.Location = new System.Drawing.Point(12, 455);
            this.cmdAfsluiten.Name = "cmdAfsluiten";
            this.cmdAfsluiten.Size = new System.Drawing.Size(75, 23);
            this.cmdAfsluiten.TabIndex = 0;
            this.cmdAfsluiten.Text = "Cancel";
            this.cmdAfsluiten.UseVisualStyleBackColor = true;
            this.cmdAfsluiten.Click += new System.EventHandler(this.cmdAfsluiten_Click);
            // 
            // grbConnect
            // 
            this.grbConnect.Controls.Add(this.cmdConnect);
            this.grbConnect.Controls.Add(this.lblConnected);
            this.grbConnect.Location = new System.Drawing.Point(303, 507);
            this.grbConnect.Name = "grbConnect";
            this.grbConnect.Size = new System.Drawing.Size(505, 35);
            this.grbConnect.TabIndex = 19;
            this.grbConnect.TabStop = false;
            this.grbConnect.Text = "Connectie";
            // 
            // cmdConnect
            // 
            this.cmdConnect.Location = new System.Drawing.Point(366, 9);
            this.cmdConnect.Name = "cmdConnect";
            this.cmdConnect.Size = new System.Drawing.Size(126, 23);
            this.cmdConnect.TabIndex = 11;
            this.cmdConnect.Text = "Wijzig Unix connectie...";
            this.cmdConnect.UseVisualStyleBackColor = true;
            // 
            // lblConnected
            // 
            this.lblConnected.AutoSize = true;
            this.lblConnected.Location = new System.Drawing.Point(6, 15);
            this.lblConnected.Name = "lblConnected";
            this.lblConnected.Size = new System.Drawing.Size(69, 13);
            this.lblConnected.TabIndex = 14;
            this.lblConnected.Text = "lblConnected";
            // 
            // lblHostName
            // 
            this.lblHostName.AutoSize = true;
            this.lblHostName.Enabled = false;
            this.lblHostName.Location = new System.Drawing.Point(660, 465);
            this.lblHostName.Name = "lblHostName";
            this.lblHostName.Size = new System.Drawing.Size(150, 13);
            this.lblHostName.TabIndex = 20;
            this.lblHostName.Text = "KPNNL\\\\WLD4BED923B63C";
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbMenu});
            this.toolStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Table;
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.toolStrip1.Size = new System.Drawing.Size(820, 23);
            this.toolStrip1.TabIndex = 21;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tsbMenu
            // 
            this.tsbMenu.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbMenu.Image = ((System.Drawing.Image)(resources.GetObject("tsbMenu.Image")));
            this.tsbMenu.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbMenu.Name = "tsbMenu";
            this.tsbMenu.Size = new System.Drawing.Size(23, 20);
            this.tsbMenu.Text = "Menu";
            this.tsbMenu.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            this.tsbMenu.Click += new System.EventHandler(this.tsbMenu_Click);
            // 
            // pnlTSBMasquee
            // 
            this.pnlTSBMasquee.Location = new System.Drawing.Point(37, 62);
            this.pnlTSBMasquee.Name = "pnlTSBMasquee";
            this.pnlTSBMasquee.Size = new System.Drawing.Size(200, 29);
            this.pnlTSBMasquee.TabIndex = 22;
            // 
            // frmDashBase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(820, 672);
            this.Controls.Add(this.pnlTSBMasquee);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.lblHostName);
            this.Controls.Add(this.grbConnect);
            this.Controls.Add(this.cmdAfsluiten);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmDashBase";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "DB Dashboard; base form";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmDashBase_FormClosed);
            this.Load += new System.EventHandler(this.frmDashBase_Load);
            this.grbConnect.ResumeLayout(false);
            this.grbConnect.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Button cmdAfsluiten;
        protected System.Windows.Forms.GroupBox grbConnect;
        protected System.Windows.Forms.Button cmdConnect;
        protected System.Windows.Forms.Label lblConnected;
        protected System.Windows.Forms.Label lblHostName;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsbMenu;
        private System.Windows.Forms.Panel pnlTSBMasquee;
    }
}