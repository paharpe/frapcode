﻿namespace dbDashboard
{
    partial class frmDashRelMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDashRelMenu));
            this.grpMenu = new System.Windows.Forms.GroupBox();
            this.tvMenu = new System.Windows.Forms.TreeView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.functiesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.Verwijder = new System.Windows.Forms.ToolStripMenuItem();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.grpUgro = new System.Windows.Forms.GroupBox();
            this.lbUgro = new System.Windows.Forms.ListBox();
            this.grpMenuAlg = new System.Windows.Forms.GroupBox();
            this.lblUgro_label = new System.Windows.Forms.Label();
            this.lblUgro_value = new System.Windows.Forms.Label();
            this.lblFunc_Instruct = new System.Windows.Forms.Label();
            this.grp2subs = new System.Windows.Forms.GroupBox();
            this.cmdAllfromTV = new System.Windows.Forms.Button();
            this.cmd1fromTV = new System.Windows.Forms.Button();
            this.grp2menu = new System.Windows.Forms.GroupBox();
            this.cmdAlltoTV = new System.Windows.Forms.Button();
            this.cmd1toTV = new System.Windows.Forms.Button();
            this.GrpSubs = new System.Windows.Forms.GroupBox();
            this.lbSubs = new System.Windows.Forms.ListBox();
            this.cmdFuncties = new System.Windows.Forms.Button();
            this.cmdReset = new System.Windows.Forms.Button();
            this.cmdOpslaan = new System.Windows.Forms.Button();
            this.lblUgro_text = new System.Windows.Forms.Label();
            this.lblKies_ugro = new System.Windows.Forms.Label();
            this.grbConnectie.SuspendLayout();
            this.grpMenu.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.grpUgro.SuspendLayout();
            this.grpMenuAlg.SuspendLayout();
            this.grp2subs.SuspendLayout();
            this.grp2menu.SuspendLayout();
            this.GrpSubs.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmdAfsluiten
            // 
            this.cmdAfsluiten.Location = new System.Drawing.Point(8, 425);
            // 
            // grbConnectie
            // 
            this.grbConnectie.Location = new System.Drawing.Point(350, 458);
            // 
            // grpMenu
            // 
            this.grpMenu.Controls.Add(this.tvMenu);
            this.grpMenu.Location = new System.Drawing.Point(11, 37);
            this.grpMenu.Name = "grpMenu";
            this.grpMenu.Size = new System.Drawing.Size(260, 333);
            this.grpMenu.TabIndex = 7;
            this.grpMenu.TabStop = false;
            this.grpMenu.Text = "Huidige indeling";
            // 
            // tvMenu
            // 
            this.tvMenu.AllowDrop = true;
            this.tvMenu.ContextMenuStrip = this.contextMenuStrip1;
            this.tvMenu.ImageIndex = 0;
            this.tvMenu.ImageList = this.imageList1;
            this.tvMenu.ItemHeight = 25;
            this.tvMenu.Location = new System.Drawing.Point(14, 17);
            this.tvMenu.Name = "tvMenu";
            this.tvMenu.SelectedImageIndex = 0;
            this.tvMenu.Size = new System.Drawing.Size(229, 303);
            this.tvMenu.TabIndex = 8;
            this.tvMenu.DoubleClick += new System.EventHandler(this.tvMenu_DoubleClick);
            this.tvMenu.DragDrop += new System.Windows.Forms.DragEventHandler(this.tvMenu_DragDrop);
            this.tvMenu.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.tvMenu_AfterSelect);
            this.tvMenu.MouseMove += new System.Windows.Forms.MouseEventHandler(this.tvMenu_MouseMove);
            this.tvMenu.MouseDown += new System.Windows.Forms.MouseEventHandler(this.tvMenu_MouseDown);
            this.tvMenu.DragEnter += new System.Windows.Forms.DragEventHandler(this.tvMenu_DragEnter);
            this.tvMenu.DragOver += new System.Windows.Forms.DragEventHandler(this.tvMenu_DragOver);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.AllowMerge = false;
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.functiesToolStripMenuItem,
            this.toolStripMenuItem1,
            this.Verwijder});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(127, 54);
            this.contextMenuStrip1.Closed += new System.Windows.Forms.ToolStripDropDownClosedEventHandler(this.contextMenuStrip1_Closed);
            this.contextMenuStrip1.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStrip1_Opening);
            // 
            // functiesToolStripMenuItem
            // 
            this.functiesToolStripMenuItem.Name = "functiesToolStripMenuItem";
            this.functiesToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.functiesToolStripMenuItem.Text = "Functies...";
            this.functiesToolStripMenuItem.Click += new System.EventHandler(this.functiesToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(123, 6);
            // 
            // Verwijder
            // 
            this.Verwijder.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.Verwijder.Name = "Verwijder";
            this.Verwijder.Size = new System.Drawing.Size(126, 22);
            this.Verwijder.Text = "Verwijder";
            this.Verwijder.Click += new System.EventHandler(this.Verwijder_Click);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "Dashboard.ico");
            // 
            // grpUgro
            // 
            this.grpUgro.Controls.Add(this.lbUgro);
            this.grpUgro.Location = new System.Drawing.Point(9, 42);
            this.grpUgro.Name = "grpUgro";
            this.grpUgro.Size = new System.Drawing.Size(204, 334);
            this.grpUgro.TabIndex = 1;
            this.grpUgro.TabStop = false;
            this.grpUgro.Text = "Gebruikersgroepen";
            // 
            // lbUgro
            // 
            this.lbUgro.FormattingEnabled = true;
            this.lbUgro.Location = new System.Drawing.Point(11, 20);
            this.lbUgro.Name = "lbUgro";
            this.lbUgro.Size = new System.Drawing.Size(180, 303);
            this.lbUgro.TabIndex = 2;
            this.lbUgro.SelectedIndexChanged += new System.EventHandler(this.lbUgro_SelectedIndexChanged);
            // 
            // grpMenuAlg
            // 
            this.grpMenuAlg.BackColor = System.Drawing.SystemColors.Control;
            this.grpMenuAlg.Controls.Add(this.lblUgro_label);
            this.grpMenuAlg.Controls.Add(this.lblUgro_value);
            this.grpMenuAlg.Controls.Add(this.lblFunc_Instruct);
            this.grpMenuAlg.Controls.Add(this.grp2subs);
            this.grpMenuAlg.Controls.Add(this.grp2menu);
            this.grpMenuAlg.Controls.Add(this.GrpSubs);
            this.grpMenuAlg.Controls.Add(this.cmdFuncties);
            this.grpMenuAlg.Controls.Add(this.cmdReset);
            this.grpMenuAlg.Controls.Add(this.cmdOpslaan);
            this.grpMenuAlg.Controls.Add(this.lblUgro_text);
            this.grpMenuAlg.Controls.Add(this.grpMenu);
            this.grpMenuAlg.Location = new System.Drawing.Point(226, 9);
            this.grpMenuAlg.Name = "grpMenuAlg";
            this.grpMenuAlg.Size = new System.Drawing.Size(626, 435);
            this.grpMenuAlg.TabIndex = 3;
            this.grpMenuAlg.TabStop = false;
            // 
            // lblUgro_label
            // 
            this.lblUgro_label.AutoSize = true;
            this.lblUgro_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUgro_label.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.lblUgro_label.Location = new System.Drawing.Point(17, 16);
            this.lblUgro_label.Name = "lblUgro_label";
            this.lblUgro_label.Size = new System.Drawing.Size(109, 13);
            this.lblUgro_label.TabIndex = 26;
            this.lblUgro_label.Text = "Geselecteerde groep:";
            // 
            // lblUgro_value
            // 
            this.lblUgro_value.AutoSize = true;
            this.lblUgro_value.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUgro_value.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.lblUgro_value.Location = new System.Drawing.Point(128, 16);
            this.lblUgro_value.Name = "lblUgro_value";
            this.lblUgro_value.Size = new System.Drawing.Size(47, 13);
            this.lblUgro_value.TabIndex = 25;
            this.lblUgro_value.Text = "lblUgro";
            // 
            // lblFunc_Instruct
            // 
            this.lblFunc_Instruct.AutoSize = true;
            this.lblFunc_Instruct.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFunc_Instruct.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblFunc_Instruct.Location = new System.Drawing.Point(7, 382);
            this.lblFunc_Instruct.Name = "lblFunc_Instruct";
            this.lblFunc_Instruct.Size = new System.Drawing.Size(452, 13);
            this.lblFunc_Instruct.TabIndex = 23;
            this.lblFunc_Instruct.Text = "Voordat functies kunnen worden gekoppeld  moeten eerst de wijzigingen worden opge" +
                "slagen !";
            // 
            // grp2subs
            // 
            this.grp2subs.Controls.Add(this.cmdAllfromTV);
            this.grp2subs.Controls.Add(this.cmd1fromTV);
            this.grp2subs.Location = new System.Drawing.Point(280, 213);
            this.grp2subs.Name = "grp2subs";
            this.grp2subs.Size = new System.Drawing.Size(65, 120);
            this.grp2subs.TabIndex = 22;
            this.grp2subs.TabStop = false;
            this.grp2subs.Text = "Verwijder      uit indeling";
            // 
            // cmdAllfromTV
            // 
            this.cmdAllfromTV.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdAllfromTV.Location = new System.Drawing.Point(11, 80);
            this.cmdAllfromTV.Name = "cmdAllfromTV";
            this.cmdAllfromTV.Size = new System.Drawing.Size(44, 35);
            this.cmdAllfromTV.TabIndex = 14;
            this.cmdAllfromTV.Text = ">>";
            this.cmdAllfromTV.UseVisualStyleBackColor = true;
            this.cmdAllfromTV.Click += new System.EventHandler(this.cmdAllfromTV_Click);
            // 
            // cmd1fromTV
            // 
            this.cmd1fromTV.BackColor = System.Drawing.SystemColors.Control;
            this.cmd1fromTV.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmd1fromTV.Location = new System.Drawing.Point(11, 43);
            this.cmd1fromTV.Name = "cmd1fromTV";
            this.cmd1fromTV.Size = new System.Drawing.Size(44, 35);
            this.cmd1fromTV.TabIndex = 13;
            this.cmd1fromTV.Tag = "";
            this.cmd1fromTV.Text = ">";
            this.cmd1fromTV.UseVisualStyleBackColor = true;
            this.cmd1fromTV.Click += new System.EventHandler(this.cmd1fromTV_Click);
            // 
            // grp2menu
            // 
            this.grp2menu.BackColor = System.Drawing.SystemColors.Control;
            this.grp2menu.Controls.Add(this.cmdAlltoTV);
            this.grp2menu.Controls.Add(this.cmd1toTV);
            this.grp2menu.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grp2menu.Location = new System.Drawing.Point(280, 63);
            this.grp2menu.Name = "grp2menu";
            this.grp2menu.Size = new System.Drawing.Size(65, 120);
            this.grp2menu.TabIndex = 21;
            this.grp2menu.TabStop = false;
            this.grp2menu.Text = "Voeg toe    aan indeling";
            // 
            // cmdAlltoTV
            // 
            this.cmdAlltoTV.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdAlltoTV.Location = new System.Drawing.Point(11, 79);
            this.cmdAlltoTV.Name = "cmdAlltoTV";
            this.cmdAlltoTV.Size = new System.Drawing.Size(44, 35);
            this.cmdAlltoTV.TabIndex = 24;
            this.cmdAlltoTV.Text = "<<";
            this.cmdAlltoTV.UseVisualStyleBackColor = true;
            this.cmdAlltoTV.Click += new System.EventHandler(this.cmdAlltoTV_Click);
            // 
            // cmd1toTV
            // 
            this.cmd1toTV.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmd1toTV.Location = new System.Drawing.Point(11, 41);
            this.cmd1toTV.Name = "cmd1toTV";
            this.cmd1toTV.Size = new System.Drawing.Size(44, 35);
            this.cmd1toTV.TabIndex = 23;
            this.cmd1toTV.Text = "<";
            this.cmd1toTV.UseVisualStyleBackColor = true;
            this.cmd1toTV.Click += new System.EventHandler(this.cmd1toTV_Click);
            // 
            // GrpSubs
            // 
            this.GrpSubs.BackColor = System.Drawing.SystemColors.Control;
            this.GrpSubs.Controls.Add(this.lbSubs);
            this.GrpSubs.Location = new System.Drawing.Point(354, 37);
            this.GrpSubs.Name = "GrpSubs";
            this.GrpSubs.Size = new System.Drawing.Size(260, 333);
            this.GrpSubs.TabIndex = 18;
            this.GrpSubs.TabStop = false;
            this.GrpSubs.Text = "Overig aanwezige Subsystemen";
            // 
            // lbSubs
            // 
            this.lbSubs.AllowDrop = true;
            this.lbSubs.FormattingEnabled = true;
            this.lbSubs.Location = new System.Drawing.Point(11, 17);
            this.lbSubs.Name = "lbSubs";
            this.lbSubs.Size = new System.Drawing.Size(229, 303);
            this.lbSubs.Sorted = true;
            this.lbSubs.TabIndex = 6;
            this.lbSubs.DoubleClick += new System.EventHandler(this.lbSubs_DoubleClick);
            this.lbSubs.Click += new System.EventHandler(this.lbSubs_Click);
            // 
            // cmdFuncties
            // 
            this.cmdFuncties.Location = new System.Drawing.Point(196, 405);
            this.cmdFuncties.Name = "cmdFuncties";
            this.cmdFuncties.Size = new System.Drawing.Size(75, 23);
            this.cmdFuncties.TabIndex = 17;
            this.cmdFuncties.Text = "&Functies...";
            this.cmdFuncties.UseVisualStyleBackColor = true;
            this.cmdFuncties.Click += new System.EventHandler(this.cmdFuncties_Click);
            // 
            // cmdReset
            // 
            this.cmdReset.Location = new System.Drawing.Point(6, 405);
            this.cmdReset.Name = "cmdReset";
            this.cmdReset.Size = new System.Drawing.Size(75, 23);
            this.cmdReset.TabIndex = 15;
            this.cmdReset.Text = "Reset";
            this.cmdReset.UseVisualStyleBackColor = true;
            this.cmdReset.Click += new System.EventHandler(this.cmdReset_Click);
            // 
            // cmdOpslaan
            // 
            this.cmdOpslaan.Location = new System.Drawing.Point(85, 405);
            this.cmdOpslaan.Name = "cmdOpslaan";
            this.cmdOpslaan.Size = new System.Drawing.Size(75, 23);
            this.cmdOpslaan.TabIndex = 16;
            this.cmdOpslaan.Text = "&Opslaan";
            this.cmdOpslaan.UseVisualStyleBackColor = true;
            this.cmdOpslaan.Click += new System.EventHandler(this.cmdOpslaan_Click);
            // 
            // lblUgro_text
            // 
            this.lblUgro_text.AutoSize = true;
            this.lblUgro_text.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUgro_text.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.lblUgro_text.Location = new System.Drawing.Point(385, -3);
            this.lblUgro_text.Name = "lblUgro_text";
            this.lblUgro_text.Size = new System.Drawing.Size(223, 20);
            this.lblUgro_text.TabIndex = 4;
            this.lblUgro_text.Text = "* menu-indeling gewijzigd *";
            // 
            // lblKies_ugro
            // 
            this.lblKies_ugro.AutoSize = true;
            this.lblKies_ugro.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKies_ugro.ForeColor = System.Drawing.Color.Olive;
            this.lblKies_ugro.Location = new System.Drawing.Point(7, 19);
            this.lblKies_ugro.Name = "lblKies_ugro";
            this.lblKies_ugro.Size = new System.Drawing.Size(156, 13);
            this.lblKies_ugro.TabIndex = 0;
            this.lblKies_ugro.Text = "Selecteer gebruikersgroep";
            // 
            // frmDashRelMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(862, 454);
            this.Controls.Add(this.lblKies_ugro);
            this.Controls.Add(this.grpUgro);
            this.Controls.Add(this.grpMenuAlg);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmDashRelMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "DB Dashboard;Menu-indeling per gebruikersgroep";
            this.Load += new System.EventHandler(this.DashRelMenu_Load);
            this.Controls.SetChildIndex(this.grpMenuAlg, 0);
            this.Controls.SetChildIndex(this.cmdAfsluiten, 0);
            this.Controls.SetChildIndex(this.grpUgro, 0);
            this.Controls.SetChildIndex(this.lblKies_ugro, 0);
            this.Controls.SetChildIndex(this.grbConnectie, 0);
            this.grbConnectie.ResumeLayout(false);
            this.grbConnectie.PerformLayout();
            this.grpMenu.ResumeLayout(false);
            this.contextMenuStrip1.ResumeLayout(false);
            this.grpUgro.ResumeLayout(false);
            this.grpMenuAlg.ResumeLayout(false);
            this.grpMenuAlg.PerformLayout();
            this.grp2subs.ResumeLayout(false);
            this.grp2menu.ResumeLayout(false);
            this.GrpSubs.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpMenu;
        private System.Windows.Forms.TreeView tvMenu;
        private System.Windows.Forms.GroupBox grpUgro;
        private System.Windows.Forms.ListBox lbUgro;
        private System.Windows.Forms.ToolStripMenuItem Verwijder;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.GroupBox grpMenuAlg;
        private System.Windows.Forms.ToolStripMenuItem functiesToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.Label lblUgro_text;
        private System.Windows.Forms.Button cmdReset;
        private System.Windows.Forms.Button cmdOpslaan;
        private System.Windows.Forms.Label lblKies_ugro;
        private System.Windows.Forms.Button cmdFuncties;
        private System.Windows.Forms.GroupBox GrpSubs;
        private System.Windows.Forms.ListBox lbSubs;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.GroupBox grp2menu;
        private System.Windows.Forms.GroupBox grp2subs;
        private System.Windows.Forms.Button cmdAlltoTV;
        private System.Windows.Forms.Button cmd1toTV;
        private System.Windows.Forms.Button cmdAllfromTV;
        private System.Windows.Forms.Button cmd1fromTV;
        private System.Windows.Forms.Label lblFunc_Instruct;
        private System.Windows.Forms.Label lblUgro_label;
        private System.Windows.Forms.Label lblUgro_value;
    }
}