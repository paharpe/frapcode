﻿namespace dbDashboard
{
    partial class frmDashRelFunc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDashRelFunc));
            this.grpFuncties = new System.Windows.Forms.GroupBox();
            this.clbFunc = new System.Windows.Forms.CheckedListBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblSubs = new System.Windows.Forms.Label();
            this.lblText3 = new System.Windows.Forms.Label();
            this.lblText2 = new System.Windows.Forms.Label();
            this.lblUgro = new System.Windows.Forms.Label();
            this.grpText = new System.Windows.Forms.GroupBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblSelectedN_cnt = new System.Windows.Forms.Label();
            this.lblSelectedN = new System.Windows.Forms.Label();
            this.lblSelectedY = new System.Windows.Forms.Label();
            this.lblSelectedY_cnt = new System.Windows.Forms.Label();
            this.grpText2 = new System.Windows.Forms.GroupBox();
            this.cmdOk = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.grpText3 = new System.Windows.Forms.GroupBox();
            this.cbFilter = new System.Windows.Forms.ComboBox();
            this.cmdReset = new System.Windows.Forms.Button();
            this.grbConnectie.SuspendLayout();
            this.grpFuncties.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.grpText3.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmdAfsluiten
            // 
            this.cmdAfsluiten.Location = new System.Drawing.Point(338, 328);
            // 
            // grbConnectie
            // 
            this.grbConnectie.Location = new System.Drawing.Point(249, 383);
            this.grbConnectie.Size = new System.Drawing.Size(245, 24);
            // 
            // grpFuncties
            // 
            this.grpFuncties.Controls.Add(this.clbFunc);
            this.grpFuncties.Location = new System.Drawing.Point(10, 12);
            this.grpFuncties.Name = "grpFuncties";
            this.grpFuncties.Size = new System.Drawing.Size(241, 338);
            this.grpFuncties.TabIndex = 0;
            this.grpFuncties.TabStop = false;
            this.grpFuncties.Text = "Functies";
            // 
            // clbFunc
            // 
            this.clbFunc.CheckOnClick = true;
            this.clbFunc.FormattingEnabled = true;
            this.clbFunc.Location = new System.Drawing.Point(8, 19);
            this.clbFunc.Name = "clbFunc";
            this.clbFunc.Size = new System.Drawing.Size(220, 304);
            this.clbFunc.Sorted = true;
            this.clbFunc.TabIndex = 1;
            this.clbFunc.SelectedIndexChanged += new System.EventHandler(this.clbFunc_SelectedIndexChanged);
            this.clbFunc.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.clbFunc_ItemCheck);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Control;
            this.panel1.Controls.Add(this.lblSubs);
            this.panel1.Controls.Add(this.lblText3);
            this.panel1.Controls.Add(this.lblText2);
            this.panel1.Controls.Add(this.lblUgro);
            this.panel1.Controls.Add(this.grpText);
            this.panel1.Location = new System.Drawing.Point(268, 22);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(221, 93);
            this.panel1.TabIndex = 2;
            // 
            // lblSubs
            // 
            this.lblSubs.AutoSize = true;
            this.lblSubs.Location = new System.Drawing.Point(122, 72);
            this.lblSubs.Name = "lblSubs";
            this.lblSubs.Size = new System.Drawing.Size(41, 13);
            this.lblSubs.TabIndex = 7;
            this.lblSubs.Text = "lblSubs";
            // 
            // lblText3
            // 
            this.lblText3.AutoSize = true;
            this.lblText3.Location = new System.Drawing.Point(1, 72);
            this.lblText3.Name = "lblText3";
            this.lblText3.Size = new System.Drawing.Size(67, 13);
            this.lblText3.TabIndex = 6;
            this.lblText3.Text = "Subsysteem:";
            // 
            // lblText2
            // 
            this.lblText2.AutoSize = true;
            this.lblText2.Location = new System.Drawing.Point(1, 51);
            this.lblText2.Name = "lblText2";
            this.lblText2.Size = new System.Drawing.Size(88, 13);
            this.lblText2.TabIndex = 4;
            this.lblText2.Text = "Gebruikersgroep:";
            // 
            // lblUgro
            // 
            this.lblUgro.AutoSize = true;
            this.lblUgro.Location = new System.Drawing.Point(122, 51);
            this.lblUgro.Name = "lblUgro";
            this.lblUgro.Size = new System.Drawing.Size(40, 13);
            this.lblUgro.TabIndex = 5;
            this.lblUgro.Text = "lblUgro";
            // 
            // grpText
            // 
            this.grpText.Location = new System.Drawing.Point(-2, 33);
            this.grpText.Name = "grpText";
            this.grpText.Size = new System.Drawing.Size(226, 72);
            this.grpText.TabIndex = 3;
            this.grpText.TabStop = false;
            this.grpText.Text = "Functies selecteren";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Control;
            this.panel2.Controls.Add(this.lblSelectedN_cnt);
            this.panel2.Controls.Add(this.lblSelectedN);
            this.panel2.Controls.Add(this.lblSelectedY);
            this.panel2.Controls.Add(this.lblSelectedY_cnt);
            this.panel2.Controls.Add(this.grpText2);
            this.panel2.Location = new System.Drawing.Point(268, 121);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(221, 90);
            this.panel2.TabIndex = 11;
            // 
            // lblSelectedN_cnt
            // 
            this.lblSelectedN_cnt.AutoSize = true;
            this.lblSelectedN_cnt.Location = new System.Drawing.Point(122, 73);
            this.lblSelectedN_cnt.Name = "lblSelectedN_cnt";
            this.lblSelectedN_cnt.Size = new System.Drawing.Size(88, 13);
            this.lblSelectedN_cnt.TabIndex = 12;
            this.lblSelectedN_cnt.Text = "lblSelectedN_cnt";
            // 
            // lblSelectedN
            // 
            this.lblSelectedN.AutoSize = true;
            this.lblSelectedN.Location = new System.Drawing.Point(1, 73);
            this.lblSelectedN.Name = "lblSelectedN";
            this.lblSelectedN.Size = new System.Drawing.Size(124, 13);
            this.lblSelectedN.TabIndex = 11;
            this.lblSelectedN.Text = "Aantal niet geselecteerd:";
            // 
            // lblSelectedY
            // 
            this.lblSelectedY.AutoSize = true;
            this.lblSelectedY.Location = new System.Drawing.Point(1, 49);
            this.lblSelectedY.Name = "lblSelectedY";
            this.lblSelectedY.Size = new System.Drawing.Size(104, 13);
            this.lblSelectedY.TabIndex = 9;
            this.lblSelectedY.Text = "Aantal geselecteerd:";
            // 
            // lblSelectedY_cnt
            // 
            this.lblSelectedY_cnt.AllowDrop = true;
            this.lblSelectedY_cnt.AutoSize = true;
            this.lblSelectedY_cnt.Location = new System.Drawing.Point(122, 49);
            this.lblSelectedY_cnt.Name = "lblSelectedY_cnt";
            this.lblSelectedY_cnt.Size = new System.Drawing.Size(87, 13);
            this.lblSelectedY_cnt.TabIndex = 10;
            this.lblSelectedY_cnt.Text = "lblSelectedY_cnt";
            // 
            // grpText2
            // 
            this.grpText2.Location = new System.Drawing.Point(-4, 33);
            this.grpText2.Name = "grpText2";
            this.grpText2.Size = new System.Drawing.Size(228, 72);
            this.grpText2.TabIndex = 8;
            this.grpText2.TabStop = false;
            this.grpText2.Text = "Info";
            // 
            // cmdOk
            // 
            this.cmdOk.Location = new System.Drawing.Point(257, 328);
            this.cmdOk.Name = "cmdOk";
            this.cmdOk.Size = new System.Drawing.Size(75, 23);
            this.cmdOk.TabIndex = 13;
            this.cmdOk.Text = "&Ok";
            this.cmdOk.UseVisualStyleBackColor = true;
            this.cmdOk.Click += new System.EventHandler(this.cmdOk_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.Control;
            this.panel3.Controls.Add(this.grpText3);
            this.panel3.Location = new System.Drawing.Point(266, 217);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(223, 90);
            this.panel3.TabIndex = 15;
            // 
            // grpText3
            // 
            this.grpText3.Controls.Add(this.cbFilter);
            this.grpText3.Location = new System.Drawing.Point(-4, 33);
            this.grpText3.Name = "grpText3";
            this.grpText3.Size = new System.Drawing.Size(230, 72);
            this.grpText3.TabIndex = 8;
            this.grpText3.TabStop = false;
            this.grpText3.Text = "Filter op getoonde functies";
            // 
            // cbFilter
            // 
            this.cbFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbFilter.FormattingEnabled = true;
            this.cbFilter.Items.AddRange(new object[] {
            "Alles",
            "Alleen geselecteerd",
            "Alleen niet geselecteerd"});
            this.cbFilter.Location = new System.Drawing.Point(8, 19);
            this.cbFilter.Name = "cbFilter";
            this.cbFilter.Size = new System.Drawing.Size(192, 21);
            this.cbFilter.TabIndex = 16;
            this.cbFilter.SelectedIndexChanged += new System.EventHandler(this.cbFilter_SelectedIndexChanged);
            // 
            // cmdReset
            // 
            this.cmdReset.Location = new System.Drawing.Point(419, 328);
            this.cmdReset.Name = "cmdReset";
            this.cmdReset.Size = new System.Drawing.Size(75, 23);
            this.cmdReset.TabIndex = 16;
            this.cmdReset.Text = "&Reset";
            this.cmdReset.UseVisualStyleBackColor = true;
            this.cmdReset.Click += new System.EventHandler(this.cmdReset_Click);
            // 
            // frmDashRelFunc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(502, 363);
            this.Controls.Add(this.cmdReset);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.cmdOk);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.grpFuncties);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmDashRelFunc";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "DB Dashboard; Functies per gebruikersgroep/subsysteem";
            this.Load += new System.EventHandler(this.frmDashRelFunc_Load);
            this.Controls.SetChildIndex(this.lblVoortgang, 0);
            this.Controls.SetChildIndex(this.grpFuncties, 0);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.Controls.SetChildIndex(this.panel2, 0);
            this.Controls.SetChildIndex(this.cmdOk, 0);
            this.Controls.SetChildIndex(this.cmdAfsluiten, 0);
            this.Controls.SetChildIndex(this.panel3, 0);
            this.Controls.SetChildIndex(this.grbConnectie, 0);
            this.Controls.SetChildIndex(this.cmdReset, 0);
            this.grbConnectie.ResumeLayout(false);
            this.grbConnectie.PerformLayout();
            this.grpFuncties.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.grpText3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpFuncties;
        private System.Windows.Forms.CheckedListBox clbFunc;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblSubs;
        private System.Windows.Forms.Label lblText3;
        private System.Windows.Forms.Label lblText2;
        private System.Windows.Forms.Label lblUgro;
        private System.Windows.Forms.GroupBox grpText;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblSelectedN_cnt;
        private System.Windows.Forms.Label lblSelectedN;
        private System.Windows.Forms.Label lblSelectedY;
        private System.Windows.Forms.Label lblSelectedY_cnt;
        private System.Windows.Forms.GroupBox grpText2;
        private System.Windows.Forms.Button cmdOk;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.GroupBox grpText3;
        private System.Windows.Forms.ComboBox cbFilter;
        private System.Windows.Forms.Button cmdReset;
    }
}