using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text.RegularExpressions;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.IO;
using System.Diagnostics;

namespace dbDashboard
{

    public partial class frmDashMenu : frmDashBase
    {

        string[] strQueryArgs       = new string[] { "[0]", "[1] ", "[2] ", "[4]", "[5]" };
        string[] strFunctie_array   = new string [50];
        Control[] ctrlFunktie_klik  = new Control[50];
        int intFunktie_klik_max     = 0;
        int intFunktie_klik_volg    = 0;

        public ArrayList arrSubs;

        Font fntRegular = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular);
        Font fntBold = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold);

        private string strText = null;
        private string strTag = null;

        private TreeNode tnSysteem = null;

        Label[] lblFunktie = new Label[50];

        public frmDashMenu()
        {
            InitializeComponent();            
        }

        private void frmDashMenu_Load(object sender, EventArgs e)
        {
            this.Location = new System.Drawing.Point(1, 20);
            this.Cursor = Cursors.WaitCursor;
            frm_init();
            this.Cursor = Cursors.Default;
        }

        public void DoSqlQuery(string strFunctie, string[] strValue)
        {
            DoSql mysql = new DoSql();

            switch (strFunctie)
            {
                case "MENU":
                    {
                        mysql.vul_deze_treeview = this.tvMenu;

                        mysql.DoQuery(" SELECT DISTINCT E.SubsVolg, E.SubsLevl, E.SubsNaam " +
                                        " FROM DashUser A,DashUgro B, DashSfug C, DashSufu D, DashSubs E " +
                                        " WHERE  A.UserCode = '" + strUserCode + "'" +
                                        " AND    B.UgroCode = A.UserUgro " +
                                        " AND    C.SfugUgvo = B.UgroVolg " +
                                        " AND    D.SufuVolg = C.SfugSfvo " +
                                        " AND (  E.SubsVolg = D.SufuSuvo OR E.SubsLevl = 0 ) ");
                        break;
                    }
                case "GETFUNCTIE":
                    {
                        /*
                         * NIEUW INTERFACE
                        */
                        // Functies binnen het in geselecteerde Menuysteem ophalen... 
                        this.strFunctie_array[1] = "FTA";
                        mysql.vul_deze_text1_array = this.strFunctie_array;
                        mysql.DoQuery(" SELECT   B.FuncText,  "
                                     + "         B.FuncProg & '/' & B.FuncParm & '/' & B.FuncOmsc, "
                                     + "          B.FuncFuns"
                                     + " FROM     DashGsfu A,DashFunc B              "
                                     + " WHERE    A.GsFuUgro = '" + strValue[1] + "' "
                                     + " AND      A.GsFuSubs = '" + strValue[0] + "' "
                                     + " AND      B.FuncProg = A.GsFuFunc "
                                     + " AND      B.FuncParm = A.GsFuParm "
                                     + " ORDER BY A.GsFuVolg");

                        if (mysql.affected_rows < 1)
                        {
                            clDashFunction.Melding( "Geen functies binnen subsysteem!", 1, "I");
                            return;
                        }

                        // Dynamisch nieuwe "pushbuttons" maken....
                        for (int i = 1; i <= mysql.affected_rows; i++)
                        {
                            lblFunktie[i] = new Label();

                            lblFunktie[i].BackColor = Color.White;
                            lblFunktie[i].Text = mysql.vul_deze_text1_array[i];

                            // Let op: In de Tag property zitten zowel de programma/formnaam
                            //         als de eventuele parameter
                            //         als de eventuele omschrijving tbv tooltop 
                            // opgeslagen !
                            lblFunktie[i].Tag = mysql.vul_deze_text2_array[i];
                            lblFunktie[i].Height = 46;

                            Padding pdFunktie = new Padding();
                            pdFunktie.Top        = 10;
                            pdFunktie.Left       = 10;
                            pdFunktie.Right      = 10;
                            pdFunktie.Bottom     = 1;
                            lblFunktie[i].Margin = pdFunktie;

                            lblFunktie[i].Height = 80;
                            lblFunktie[i].Width  = 110;
                            lblFunktie[i].Text   = lblFunktie[i].Text;
                            
                            lblFunktie[i].ImageList = tvMenu.ImageList;

                            // Executables krijgen blauwe bitmap variant, "formloaders" de zwarte...
                            if (mysql.vul_deze_text3_array[i] == "I")
                            {
                                lblFunktie[i].ImageIndex = 0;
                            }
                            else
                            {
                                lblFunktie[i].ImageIndex = 1;
                            }

                            lblFunktie[i].FlatStyle  = FlatStyle.Standard;
                            lblFunktie[i].ImageAlign = ContentAlignment.TopCenter;
                            lblFunktie[i].TextAlign  = ContentAlignment.BottomCenter;
                            lblFunktie[i].TextAlign  = ContentAlignment.MiddleCenter;

                            lblFunktie[i].AutoEllipsis = true;
                            lblFunktie[i].AutoSize     = false;

                            lblFunktie[i].MouseHover  += new System.EventHandler(lblFunktie_MouseHover);
                            lblFunktie[i].Click       += new System.EventHandler(lblFunktie_Click);
                            lblFunktie[i].DoubleClick += new System.EventHandler(lblFunktie_DoubleClick);
                            lblFunktie[i].Paint       += new System.Windows.Forms.PaintEventHandler(lblFunktie_Paint);

                            // Toevoegen op panel
                            flwPanel.Controls.Add(lblFunktie[i]);

                            // Toevoegen aan control array om met TAB te kunne
                            // springen. Zie verder functie: <tab2funktie()>
                            ctrlFunktie_klik[i] = lblFunktie[i];
                            intFunktie_klik_max++;
                        }

                        // Selecteer 1e funktie v/h subsysteem by default..
                        tab2funktie("TAB", new object(), 1);

                    }
                    break;

                default:
                    {
                        clDashFunction.Melding("Param error (" + strFunctie + ") in DoSqlQuery()", 1, "E");
                        break;
                    }
            }
        }

        private string get_function_count(string strSubSys)
        {
            DoSql mysql = new DoSql();
            mysql.vul_deze_string = "";
            mysql.DoQuery(" SELECT    COUNT(*) "
                         + " FROM     DashGsfu A,DashFunc B              "
                         + " WHERE    A.GsFuUgro = '" + strUserUgro + "' "
                         + " AND      A.GsFuSubs = '" + strSubSys + "' "
                         + " AND      B.FuncProg = A.GsFuFunc "
                         + " AND      B.FuncParm = A.GsFuParm ");
            return mysql.vul_deze_string;
        }

        private void afsluitenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void lblFunktie_DoubleClick(object sender, EventArgs e)
        {
            if (strTag != null)
            {
                start_program(strText, strTag);
            }
        }

        private void lblFunktie_Click(object sender, EventArgs e)
        {
            foreach (Label lblKeuze in flwPanel.Controls)
            {
                lblKeuze.Font = fntRegular;
                lblKeuze.ForeColor = Color.Black;
                // lblKeuze.BorderStyle = BorderStyle.None;
            }

            Label lblClicked = (Label)sender;
            lblClicked.Font = fntBold;
            strText = lblClicked.Text;
            strTag = lblClicked.Tag.ToString();

            tab2funktie("POSITION", lblClicked, 0);
            // Experimenteel toneel
            // intFunktie_klik_volg++;
        }

        private void lblFunktie_MouseHover(object sender, EventArgs e)
        {
            Label lbl_Clicked = (Label)sender;
            string strTooltip;
            string[] strarTooltip = Regex.Split(lbl_Clicked.Tag.ToString(), "/");
            if (strarTooltip.Length == 3
            && strarTooltip[2] != "")
            {
                strTooltip = strarTooltip[2];
            }
            else
            {
                strTooltip = lbl_Clicked.Text;
            }

            toolTip1.Show(strTooltip, lbl_Clicked, 70, 50, 2000);

            // Om ook op <ENTER> te kunnen starten....
            // strText = lbl_Clicked.Text;
            // strTag  = lbl_Clicked.Tag.ToString();
            // MessageBox.Show(strTag);
        }

        private void MenuItemsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmDashMaintT DashMaintT = new frmDashMaintT();
            DashMaintT.ShowDialog();
        }

        private void frm_init()
        {

            tnSysteem = null;

            tvMenu.Nodes.Clear();
            flwPanel.Controls.Clear();

            DoSql mysql = new DoSql();
            mysql.vul_deze_text1_array[1] = "FTA";
            mysql.DoQuery("SELECT UgssVolg, UgssSubs, UgssUgro " +
                          "FROM DashUgss " +
                          "WHERE UgssUgro = '" + strUserUgro + "' " +
                          "ORDER BY UgssVolg ");
            if (mysql.affected_rows == 0)
            {
                clDashFunction.Melding( "Geen menustructuur gedefinieerd voor groep: " + strUserUgro + "!", 1, "E");
                return;
            }
            // Alle geselecteerde menuitems doorlopen van ( occ 0 = altijd null )
            for (int i = 1; i <= mysql.affected_rows; i++)
            {
                string strNodeVolg = mysql.vul_deze_text1_array[i];
                string strNodeNaam = mysql.vul_deze_text2_array[i];
                string strUgssPkey = mysql.vul_deze_text3_array[i];

                // Nodevolgnummer ( 1,0,0,0 ) in array[0-3] zetten
                string[] arNodeLvl = Regex.Split(strNodeVolg, ",");

                // Alle geselecteerde menuitems doorlopen van N naar 1 ( occ 0 = altijd null )
                for (int j = arNodeLvl.Length - 1; j >= 0; j--)
                {
                    int intNodeNivoMin1 = Convert.ToInt16(arNodeLvl[j]);
                    // ***************************
                    // AFHANDELING SUBSUBSUB NODES
                    // ***************************
                    // Als op de NIET 1e positie van het volgnummer een "getal" staat dat
                    // groter is dan 0, dan hebben we een te maken met een sub(sub(sub))
                    // We moeten nu zijn "parent" zoeken:
                    // Bijvoorbeeld volgnr = 5,1,0,0, dan gaan we zoeken naar 5,0,0,0 Dit nummer wordt
                    // gecomponeerd in strSearchNode
                    if (j > 0 && arNodeLvl[j] != "0")
                    {
                        arNodeLvl[j] = "0";
                        string strSearchNode = arNodeLvl[0] + "," +
                                               arNodeLvl[1] + "," +
                                               arNodeLvl[2] + "," +
                                               arNodeLvl[3];

                        // Doorzoek de hele boom, hij MOET gevonden worden, anders klopt de menutabel
                        // in de database niet.....
                        TreeNode[] tnFound = tvMenu.Nodes.Find(strSearchNode, true);
                        // Omdat we bij een gevonden geval de hele "tak" meekrijgen is dit een 
                        // array. De nieuwe node moet als subnode worden toegevoegd aan het laatste
                        // item uit de "tak" (de search was immers naar de "vader" die 1 niveau hoger
                        // in de boom zit) vandaar onderstaande index constructie.
                        TreeNode tnNew = tnFound[tnFound.Length - 1].
                                         Nodes.Add(strNodeVolg, strNodeNaam +
                                                            " (" + get_function_count(strNodeNaam).ToString() + ")");
                        tnNew.Tag = strUgssPkey;
                        break;
                    }

                    // ***************************************
                    // afhandeling rootnode SYSTEEM (0,0,0,0)
                    // EN DE NODES DAAR direct onder
                    // ****************************************
                    else
                    {
                        if (j == 0)
                        {
                            if (tnSysteem == null)
                            {
                                TreeNode tnNew = tvMenu.Nodes.Add(strNodeVolg, strNodeNaam);
                                tnNew.Tag = strUgssPkey;
                                if (strNodeVolg == "0,0,0,0")
                                {
                                    tnSysteem = tnNew;
                                }
                            }
                            else
                            {
                                TreeNode tnNew = tnSysteem.Nodes.Add(strNodeVolg, strNodeNaam +
                                                                     " (" + get_function_count(strNodeNaam).ToString() + ")");

                                tnNew.Tag = strUgssPkey;
                            }
                        }
                    }
                }
            }

            tvMenu.SelectedNode = tnSysteem;
            // tnSysteem.Expand();
            tnSysteem.ExpandAll();
        }

        private void tvMenu_AfterSelect(object sender, TreeViewEventArgs e)
        {
            // Oude pushbutton controls op panel opruimen...          
            flwPanel.Controls.Clear();

            tab2funktie("RESET", new object(), 0);

            // Opnieuw vullen....
            if (e.Node.Text != null && e.Node.Tag != null && e.Node.Text != "Systeem")
            {
                string[] strFunctie_zonder_aantal = e.Node.Text.Split(Convert.ToChar("("));
                strQueryArgs[0] = strFunctie_zonder_aantal[0]; //e.Node.Text;
                strQueryArgs[1] = e.Node.Tag.ToString();

                DoSqlQuery("GETFUNCTIE", strQueryArgs);
            }
        }

        private void afsluitenToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void start_selected_program(string strProgramma, string strArguments)
        {
            start_selected_program(strProgramma, strArguments, false);
        }

        private void start_selected_program(string strProgramma, string strArguments, Boolean bTalk)
        {
            DoSql mysql = new DoSql();
            mysql.vul_deze_string = " ";
            mysql.DoQuery(" SELECT FuncProg " +
                          " FROM   DashFunc " +
                          " WHERE  FuncProg = '" + strProgramma + "'");

            if (!File.Exists(strProgramma))
            {
                if ( bTalk )
                {
                    clDashFunction.Melding( "Programm(location) " +
                                            strProgramma + " " + "is not valid !", 1, "I");
                }
            }
            else
            {
                // Programmanaam bijv. abc.exe destilleren uit "mysql.vul_deze_string" om verderop
                // te kunnen controleren of proces "abc.exe" al aanwezig is.
                int inStart = 0;
                int i_old = 0;
                for (int i = 1; i > 0; i++)
                {
                    i_old = i;
                    i = strProgramma.IndexOf("\\", inStart); //Na de laatste slashes staat de exe file
                    inStart = i + 1;
                }

                string[] strTarget = Regex.Split(strProgramma.Substring(i_old - 0,
                                                 strProgramma.Length - (i_old + 0)),
                                                 ".exe");

                // Indien proces al bekend is, dan opnieuw starten niet toegestaan
                if (Process.GetProcessesByName(strTarget[0]).Length > 0)
                {
                    if (bTalk)
                    {
                        clDashFunction.Melding("Programm '" + strProgramma +
                                               "' already started. It is not allowed to start a second instance !", 1, "I");
                    }
                }
                else
                {
                    try
                    {
                        System.Diagnostics.Process.Start(strProgramma, strArguments);
                    }
                    catch
                    {
                        if (bTalk)
                        {
                            clDashFunction.Melding("An error has occurred during starting: " + strProgramma, 1, "E");
                        }
                        return;
                    }
                }
            }
        }

        private void start_selected_form(string strForm_name, string strArguments, string strSupplemental_title)
        {
            if (clDashFunction.is_form_active(strForm_name, MdiParent))
            {
                return;
            }

            switch (strForm_name)
            {

                case "frmDashBoks":
                    {
                        frmDashBoks DashBoks = new frmDashBoks();
                        DashBoks.MdiParent = this.MdiParent;
                        DashBoks.Show();
                    }
                    break;                
                
                case "frmDashMaintT":
                    {
                        frmDashMaintT DashMaintT         = new frmDashMaintT();
                        DashMaintT.strBeheer_tabel       = strArguments;
                        DashMaintT.strSupplemental_Title = strSupplemental_title;
                        DashMaintT.strUserCode           = this.strUserCode;
                        DashMaintT.strUserUgro           = this.strUserUgro;
                        DashMaintT.MdiParent             = this.MdiParent;
                        DashMaintT.Show();
                    }
                    break;

                case "frmDashScript":
                    {
                        frmDashMaintT DashScript = new frmDashMaintT();
                        DashScript.strBeheer_tabel = strArguments;
                        DashScript.strSupplemental_Title = strSupplemental_title;
                        DashScript.strTabel_nr = "15";
                        DashScript.strUserCode = this.strUserCode;
                        DashScript.strUserUgro = this.strUserUgro;
                        DashScript.MdiParent = this.MdiParent;
                        DashScript.Show();
                    }
                    break;

                 case "frmDashRelMenu":
                    {
                        frmDashRelMenu DashRelMenu  = new frmDashRelMenu();
                        DashRelMenu.strUserCode     = this.strUserCode;
                        DashRelMenu.strUserUgro     = this.strUserUgro;
                        // DashRelMenu.MdiParent       = this.MdiParent;
                        if (DashRelMenu.ShowDialog() == DialogResult.Yes)
                        {
                            clDashFunction.Melding( "Let op: i.v.m. wijzigingen wordt het menu opnieuw opgebouwd !", 1, "I");
                            frm_init();
                        }
                    }
                    break;

                 case "frmDashPOP3":
                    {
                        frmDashPOP3 DashPOP3 = new frmDashPOP3();
                        DashPOP3.strUserCode = this.strUserCode;
                        DashPOP3.strUserUgro = this.strUserUgro;
                        DashPOP3.MdiParent = this.MdiParent;
                        DashPOP3.Show();
                    }
                    break;

                 case "frmDashQueue":
                    {
                        frmDashQueue DashQueue = new frmDashQueue();
                        DashQueue.strUserCode = this.strUserCode;
                        DashQueue.strUserUgro = this.strUserUgro;
                        DashQueue.MdiParent = this.MdiParent;
                        DashQueue.Show();
                    }
                    break;

                 case "frmDashQueueView":
                    {
                        frmDashQueueView DashQueueView = new frmDashQueueView();
                        DashQueueView.strUserCode = this.strUserCode;
                        DashQueueView.strUserUgro = this.strUserUgro;
                        DashQueueView.MdiParent = this.MdiParent;
                        DashQueueView.Show();
                    }
                    break;

                 case "frmDashTrax":
                    {
                        frmDashTrax DashTrax = new frmDashTrax();
                        DashTrax.strUserCode = this.strUserCode;
                        DashTrax.strUserUgro = this.strUserUgro;
                        DashTrax.MdiParent = this.MdiParent;
                        DashTrax.Show();
                    }
                    break;
                 case "frmDashFTPSstats":
                    {
                        frmDashFTPSstats DashFTPSstats = new frmDashFTPSstats();
                        DashFTPSstats.strUserCode = this.strUserCode;
                        DashFTPSstats.strUserUgro = this.strUserUgro;
                        DashFTPSstats.MdiParent = this.MdiParent;
                        DashFTPSstats.Show();
                    }
                    break;
                 case "frmDashFTPSlog":
                    {
                        frmDashFTPSlog DashFTPSlog = new frmDashFTPSlog();
                        DashFTPSlog.strUserCode = this.strUserCode;
                        DashFTPSlog.strUserUgro = this.strUserUgro;
                        DashFTPSlog.MdiParent = this.MdiParent;
                        DashFTPSlog.Show();
                    }
                    break;
                 case "frmDashFTPSfull":
                    {
                        frmDashFTPSfull DashFTPSfull = new frmDashFTPSfull();
                        DashFTPSfull.strUserCode = this.strUserCode;
                        DashFTPSfull.strUserUgro = this.strUserUgro;
                        DashFTPSfull.MdiParent = this.MdiParent;
                        DashFTPSfull.Show();
                    }
                    break;
                 case "frmDashShell":
                    {
                        frmDashShell DashShell = new frmDashShell();
                        DashShell.strUserCode = this.strUserCode;
                        DashShell.strUserUgro = this.strUserUgro;
                        DashShell.MdiParent = this.MdiParent;
                        DashShell.Show();
                    }
                    break;
                default:
                    {
                        clDashFunction.Melding( "Het opgegeven scherm (" + strForm_name + ") kan niet worden geladen !", 1, "I");
                        break;
                    }
            }
        }
       
        private void start_program(string strFunctie_Text, string strFunctie_Tag)
        {
            //MessageBox.Show("Tag : " + strFunctie_Tag +
            //    "\n" +
            //    "Text : " + strFunctie_Text);

            string strProgramma = "";
            string strArguments = "";

            this.Cursor = Cursors.WaitCursor;
            // cmdClicked.Enabled = false;
            // Eerst splitsen op programmanaam en evt parameter
            // Daarna kijken of we een EXE moeten starten of een intern form moeten gaan laden.
            // Dit wordt gedaan door te kijken of er ".exe" in de tag van de geklikte button
            // voorkomt EN of het imageindex 0 is, exe's worden immers met het default icon
            // getoond....

            // tbv doorgeven functietekst voor title in algemeen beheerform
            string strSupplemental_title = strFunctie_Text;

            // Splits in formname, argument en de eventuele tooltiptext....
            string[] strForm_narg = Regex.Split(strFunctie_Tag.ToString(), "/");
            strProgramma = strForm_narg[0].ToString();
            if (strForm_narg.Length > 1)
            {
                strArguments = strForm_narg[1].ToString();
            }

            //
            if (strProgramma.ToString().ToUpper().IndexOf(".EXE") > 0)
            // && cmdClicked.ImageIndex == 1)
            {
                start_selected_program(strProgramma, strArguments); // Dus een EXE
            }
            else
            {
                start_selected_form(strProgramma, strArguments, strSupplemental_title);  // Dus een Form binnen deze solution           
            }
            this.Cursor = Cursors.Default;
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            switch (keyData.ToString().ToUpper())
            {
                case "TAB":
                    {
                        base.ProcessDialogKey(keyData);

                        intFunktie_klik_volg++;
                        tab2funktie("TAB", new object(), intFunktie_klik_volg);

                    }
                    break;
                case "TAB, SHIFT":
                    {
                        base.ProcessDialogKey(keyData);

                        intFunktie_klik_volg--;
                        tab2funktie("TAB", new object(), intFunktie_klik_volg);

                    }
                    break;
                case "RETURN":
                    {
                        base.ProcessDialogKey(keyData);
                        lblFunktie_DoubleClick(lblFunktie[intFunktie_klik_volg], new EventArgs());
                    }
                    break;
                default:
                    return base.ProcessCmdKey(ref msg, keyData);
            }
            return true;
        }

        private void tab2funktie(string strFunctie, object lblClicked, int intFunktie_index)
        {
            switch (strFunctie)
            {
                case "RESET":
                    {
                        // Wanneer opnieuw functies worden opgehaald, dan het tab-volgnummer
                        // resetten naar 0           
                        for (intFunktie_index = 0; intFunktie_index < intFunktie_klik_max; intFunktie_index++)
                        {
                            ctrlFunktie_klik[intFunktie_index] = null;
                        }
                        intFunktie_klik_volg = 0;
                        intFunktie_klik_max = 0;
                        break;
                    }
                case "TAB":
                    {
                        if (intFunktie_klik_max > 0)
                        {
                            if (intFunktie_index > intFunktie_klik_max)
                            {
                                intFunktie_klik_volg = 1;
                                intFunktie_index = 1;
                            }
                            if (intFunktie_index < 1)
                            {
                                intFunktie_klik_volg = intFunktie_klik_max;
                                intFunktie_index = intFunktie_klik_max;
                            }
                            if (ctrlFunktie_klik[intFunktie_index] != null)
                            {
                                lblFunktie_Click(lblFunktie[intFunktie_index], new EventArgs());
                                tvMenu.Focus();
                            }
                            else
                            {
                                clDashFunction.Melding("Functie index geeft null-waarde op: " + intFunktie_index.ToString(), 1, "E");
                            }
                        }
                        break;
                    }
                case "POSITION":
                    {

                        for (intFunktie_klik_volg = 0; intFunktie_klik_volg < intFunktie_klik_max; intFunktie_klik_volg++)
                        {
                            if (ctrlFunktie_klik[intFunktie_klik_volg] == lblClicked)
                            {
                                break;
                            }
                        }
                        break;
                    }
                default:
                    break;
            }
        }       

        private void lblFunktie_Paint(object sender, PaintEventArgs e)
        {           
            Label lbl2Format        = (Label)sender;
            string strMeasureString = lbl2Format.Text;
            Font fntMeaseFont       = lbl2Format.Font;
            SizeF stringSize        = e.Graphics.MeasureString(strMeasureString, fntMeaseFont);

            if (stringSize.Width <= 110)
            {
                lbl2Format.Height = 82;
                return;
            }

            if (stringSize.Width > 110)
            {
                lbl2Format.Height = 93;
                return;
            }
            if (stringSize.Width > 220)
            {
                lbl2Format.Height = 104;
                return;
            }
            if (stringSize.Width > 320)
            {
                lbl2Format.Height = 115;
                return;
            }          
        }

        private void frmDashMenu_FormClosing(object sender, FormClosingEventArgs e)
        {

            if (mdiDashboard.alForms_loaded.Count > 1)
            {
                DialogResult dlgRes=clDashFunction.Melding("Other form(s) still loaded !\n\nDo you whish to continue ?",4,"Q");
                if ( dlgRes != DialogResult.Yes )
                {                   
                    e.Cancel = true;
                }                
            }
        }        
    }
}

