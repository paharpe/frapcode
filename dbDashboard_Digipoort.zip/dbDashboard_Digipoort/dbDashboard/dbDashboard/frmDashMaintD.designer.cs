﻿namespace dbDashboard
{
    partial class frmDashMaintD
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDashMaintD));
            this.grbUsrMaintD = new System.Windows.Forms.GroupBox();
            this.cmbUsrGroep = new System.Windows.Forms.ComboBox();
            this.txtUsrId = new System.Windows.Forms.TextBox();
            this.lblUsrId = new System.Windows.Forms.Label();
            this.lblUsrPass_hint = new System.Windows.Forms.Label();
            this.txtUsrPass = new System.Windows.Forms.TextBox();
            this.lblUsrPass = new System.Windows.Forms.Label();
            this.txtUsrNaam = new System.Windows.Forms.TextBox();
            this.txtUsrCode = new System.Windows.Forms.TextBox();
            this.lblUsrGroep = new System.Windows.Forms.Label();
            this.lblUsrNaam = new System.Windows.Forms.Label();
            this.lblUsrCode = new System.Windows.Forms.Label();
            this.cmdOK = new System.Windows.Forms.Button();
            this.grbGrpMaintD = new System.Windows.Forms.GroupBox();
            this.txtGrpNaam = new System.Windows.Forms.TextBox();
            this.txtGrpCode = new System.Windows.Forms.TextBox();
            this.lblGrpNaam = new System.Windows.Forms.Label();
            this.lblGrpCode = new System.Windows.Forms.Label();
            this.grbElemMaintD = new System.Windows.Forms.GroupBox();
            this.txtElemOms2 = new System.Windows.Forms.TextBox();
            this.txtElemOms1 = new System.Windows.Forms.TextBox();
            this.txtElemElem = new System.Windows.Forms.TextBox();
            this.cmbElemTabn = new System.Windows.Forms.ComboBox();
            this.lblElemOms2 = new System.Windows.Forms.Label();
            this.lblElemOms1 = new System.Windows.Forms.Label();
            this.lblElemElem = new System.Windows.Forms.Label();
            this.lblElemTabn = new System.Windows.Forms.Label();
            this.grbSubMaintD = new System.Windows.Forms.GroupBox();
            this.txtSubOmsc = new System.Windows.Forms.TextBox();
            this.lblSubOmsc = new System.Windows.Forms.Label();
            this.txtSubNaam = new System.Windows.Forms.TextBox();
            this.lblSubNaam = new System.Windows.Forms.Label();
            this.grbTablMaintD = new System.Windows.Forms.GroupBox();
            this.txtTablO2om = new System.Windows.Forms.TextBox();
            this.txtTablO1om = new System.Windows.Forms.TextBox();
            this.txtTablElom = new System.Windows.Forms.TextBox();
            this.lblTablO2om = new System.Windows.Forms.Label();
            this.lblTablO1om = new System.Windows.Forms.Label();
            this.lblTablElom = new System.Windows.Forms.Label();
            this.lblTablOmsc = new System.Windows.Forms.Label();
            this.lblTablTabn = new System.Windows.Forms.Label();
            this.txtTablTabn = new System.Windows.Forms.TextBox();
            this.txtTablOmsc = new System.Windows.Forms.TextBox();
            this.grbConnMaintD = new System.Windows.Forms.GroupBox();
            this.lblTelp23 = new System.Windows.Forms.Label();
            this.lblFtp21 = new System.Windows.Forms.Label();
            this.txtConnTelp = new System.Windows.Forms.TextBox();
            this.txtConnFtpp = new System.Windows.Forms.TextBox();
            this.lblConnTelp = new System.Windows.Forms.Label();
            this.lblConnFtpp = new System.Windows.Forms.Label();
            this.txtConnSnam = new System.Windows.Forms.TextBox();
            this.lblConnSnam = new System.Windows.Forms.Label();
            this.txtConnPass = new System.Windows.Forms.TextBox();
            this.lblConnPass = new System.Windows.Forms.Label();
            this.txtConnUser = new System.Windows.Forms.TextBox();
            this.txtConnHost = new System.Windows.Forms.TextBox();
            this.lblConnUser = new System.Windows.Forms.Label();
            this.lblConnHost = new System.Windows.Forms.Label();
            this.grbProgfile = new System.Windows.Forms.GroupBox();
            this.lblFunType = new System.Windows.Forms.Label();
            this.cmdFunExfu_del = new System.Windows.Forms.Button();
            this.cmdFunExfu_add = new System.Windows.Forms.Button();
            this.lbFunExfu = new System.Windows.Forms.ListBox();
            this.dgFunExfu = new System.Windows.Forms.DataGridView();
            this.colExFuFunc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblFunExfu = new System.Windows.Forms.Label();
            this.txtFunOmsc = new System.Windows.Forms.TextBox();
            this.lblFunOmsc = new System.Windows.Forms.Label();
            this.txtFunParm = new System.Windows.Forms.TextBox();
            this.lblFunParm = new System.Windows.Forms.Label();
            this.cmdKies = new System.Windows.Forms.Button();
            this.lblFunProg = new System.Windows.Forms.Label();
            this.txtFunProg = new System.Windows.Forms.TextBox();
            this.lblSplit_instructie = new System.Windows.Forms.Label();
            this.txtFunText = new System.Windows.Forms.TextBox();
            this.lblFunText = new System.Windows.Forms.Label();
            this.rbInt = new System.Windows.Forms.RadioButton();
            this.rbExec = new System.Windows.Forms.RadioButton();
            this.grbFunMaintD = new System.Windows.Forms.GroupBox();
            this.grbBronMaintD = new System.Windows.Forms.GroupBox();
            this.txtBronCode = new System.Windows.Forms.TextBox();
            this.lblBronCode = new System.Windows.Forms.Label();
            this.txtBronOmsc = new System.Windows.Forms.TextBox();
            this.lblBronOmsc = new System.Windows.Forms.Label();
            this.grbUitgMaintD = new System.Windows.Forms.GroupBox();
            this.lblUitgPubl = new System.Windows.Forms.Label();
            this.cmbUitgPubl = new System.Windows.Forms.ComboBox();
            this.lblUitgBron = new System.Windows.Forms.Label();
            this.cmbUitgBron = new System.Windows.Forms.ComboBox();
            this.txtUitgCode = new System.Windows.Forms.TextBox();
            this.lblUitgCode = new System.Windows.Forms.Label();
            this.txtUitgOmsc = new System.Windows.Forms.TextBox();
            this.lblUitgOmsc = new System.Windows.Forms.Label();
            this.grbScriptMaintD = new System.Windows.Forms.GroupBox();
            this.txtScriptCmd = new System.Windows.Forms.TextBox();
            this.lblScriptCmd = new System.Windows.Forms.Label();
            this.txtScriptKey = new System.Windows.Forms.TextBox();
            this.lblScriptKey = new System.Windows.Forms.Label();
            this.txtScriptOmsc = new System.Windows.Forms.TextBox();
            this.lblScriptOmsc = new System.Windows.Forms.Label();
            this.grbServMaintD = new System.Windows.Forms.GroupBox();
            this.txtServPass = new System.Windows.Forms.TextBox();
            this.lblServPass = new System.Windows.Forms.Label();
            this.txtServUser = new System.Windows.Forms.TextBox();
            this.lblServUser = new System.Windows.Forms.Label();
            this.txtServBeip = new System.Windows.Forms.TextBox();
            this.lblServBeip = new System.Windows.Forms.Label();
            this.txtServSnam = new System.Windows.Forms.TextBox();
            this.txtServBuip = new System.Windows.Forms.TextBox();
            this.txtServFoip = new System.Windows.Forms.TextBox();
            this.txtServHost = new System.Windows.Forms.TextBox();
            this.lblServBuip = new System.Windows.Forms.Label();
            this.lblServFoip = new System.Windows.Forms.Label();
            this.lblServHost = new System.Windows.Forms.Label();
            this.lblServSnam = new System.Windows.Forms.Label();
            this.grbWiseMaintD = new System.Windows.Forms.GroupBox();
            this.txtWiseNaam = new System.Windows.Forms.TextBox();
            this.txtWiseOmsc = new System.Windows.Forms.TextBox();
            this.lblWiseOmsc = new System.Windows.Forms.Label();
            this.lblWiseNaam = new System.Windows.Forms.Label();
            this.grbConnect.SuspendLayout();
            this.grbUsrMaintD.SuspendLayout();
            this.grbGrpMaintD.SuspendLayout();
            this.grbElemMaintD.SuspendLayout();
            this.grbSubMaintD.SuspendLayout();
            this.grbTablMaintD.SuspendLayout();
            this.grbConnMaintD.SuspendLayout();
            this.grbProgfile.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgFunExfu)).BeginInit();
            this.grbFunMaintD.SuspendLayout();
            this.grbBronMaintD.SuspendLayout();
            this.grbUitgMaintD.SuspendLayout();
            this.grbScriptMaintD.SuspendLayout();
            this.grbServMaintD.SuspendLayout();
            this.grbWiseMaintD.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmdAfsluiten
            // 
            this.cmdAfsluiten.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.cmdAfsluiten.Location = new System.Drawing.Point(84, 268);
            this.cmdAfsluiten.Click += new System.EventHandler(this.cmdAfsluiten_Click_1);
            // 
            // grbConnect
            // 
            this.grbConnect.Location = new System.Drawing.Point(13, 328);
            // 
            // cmdConnect
            // 
            this.cmdConnect.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            // 
            // lblHostName
            // 
            this.lblHostName.Location = new System.Drawing.Point(380, 278);
            this.lblHostName.Size = new System.Drawing.Size(145, 13);
            this.lblHostName.Text = "KPNNL\\WLD4BED923B63C";
            // 
            // grbUsrMaintD
            // 
            this.grbUsrMaintD.Controls.Add(this.cmbUsrGroep);
            this.grbUsrMaintD.Controls.Add(this.txtUsrId);
            this.grbUsrMaintD.Controls.Add(this.lblUsrId);
            this.grbUsrMaintD.Controls.Add(this.lblUsrPass_hint);
            this.grbUsrMaintD.Controls.Add(this.txtUsrPass);
            this.grbUsrMaintD.Controls.Add(this.lblUsrPass);
            this.grbUsrMaintD.Controls.Add(this.txtUsrNaam);
            this.grbUsrMaintD.Controls.Add(this.txtUsrCode);
            this.grbUsrMaintD.Controls.Add(this.lblUsrGroep);
            this.grbUsrMaintD.Controls.Add(this.lblUsrNaam);
            this.grbUsrMaintD.Controls.Add(this.lblUsrCode);
            this.grbUsrMaintD.Location = new System.Drawing.Point(12, 26);
            this.grbUsrMaintD.Name = "grbUsrMaintD";
            this.grbUsrMaintD.Size = new System.Drawing.Size(507, 231);
            this.grbUsrMaintD.TabIndex = 0;
            this.grbUsrMaintD.TabStop = false;
            this.grbUsrMaintD.Text = "Detailgegevens";
            // 
            // cmbUsrGroep
            // 
            this.cmbUsrGroep.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbUsrGroep.FormattingEnabled = true;
            this.cmbUsrGroep.Location = new System.Drawing.Point(136, 159);
            this.cmbUsrGroep.Name = "cmbUsrGroep";
            this.cmbUsrGroep.Size = new System.Drawing.Size(220, 21);
            this.cmbUsrGroep.TabIndex = 11;
            this.cmbUsrGroep.Tag = "Groepcode";
            this.cmbUsrGroep.SelectedIndexChanged += new System.EventHandler(this.cmbUsrGroep_SelectedIndexChanged);
            // 
            // txtUsrId
            // 
            this.txtUsrId.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtUsrId.Enabled = false;
            this.txtUsrId.Location = new System.Drawing.Point(136, 19);
            this.txtUsrId.MaxLength = 12;
            this.txtUsrId.Name = "txtUsrId";
            this.txtUsrId.Size = new System.Drawing.Size(100, 20);
            this.txtUsrId.TabIndex = 2;
            this.txtUsrId.Tag = "Userid";
            this.txtUsrId.TextChanged += new System.EventHandler(this.txtUsrId_TextChanged);
            // 
            // lblUsrId
            // 
            this.lblUsrId.AutoSize = true;
            this.lblUsrId.Location = new System.Drawing.Point(34, 23);
            this.lblUsrId.Name = "lblUsrId";
            this.lblUsrId.Size = new System.Drawing.Size(19, 13);
            this.lblUsrId.TabIndex = 1;
            this.lblUsrId.Text = "Id:";
            // 
            // lblUsrPass_hint
            // 
            this.lblUsrPass_hint.AutoSize = true;
            this.lblUsrPass_hint.Location = new System.Drawing.Point(242, 99);
            this.lblUsrPass_hint.Name = "lblUsrPass_hint";
            this.lblUsrPass_hint.Size = new System.Drawing.Size(63, 13);
            this.lblUsrPass_hint.TabIndex = 9;
            this.lblUsrPass_hint.Text = "(5-8 tekens)";
            // 
            // txtUsrPass
            // 
            this.txtUsrPass.Location = new System.Drawing.Point(136, 96);
            this.txtUsrPass.MaxLength = 8;
            this.txtUsrPass.Name = "txtUsrPass";
            this.txtUsrPass.Size = new System.Drawing.Size(100, 20);
            this.txtUsrPass.TabIndex = 8;
            this.txtUsrPass.Tag = "Password";
            this.txtUsrPass.TextChanged += new System.EventHandler(this.txtUsrPass_TextChanged);
            // 
            // lblUsrPass
            // 
            this.lblUsrPass.AutoSize = true;
            this.lblUsrPass.Location = new System.Drawing.Point(34, 99);
            this.lblUsrPass.Name = "lblUsrPass";
            this.lblUsrPass.Size = new System.Drawing.Size(56, 13);
            this.lblUsrPass.TabIndex = 7;
            this.lblUsrPass.Text = "Password:";
            // 
            // txtUsrNaam
            // 
            this.txtUsrNaam.Location = new System.Drawing.Point(136, 70);
            this.txtUsrNaam.MaxLength = 50;
            this.txtUsrNaam.Name = "txtUsrNaam";
            this.txtUsrNaam.Size = new System.Drawing.Size(334, 20);
            this.txtUsrNaam.TabIndex = 6;
            this.txtUsrNaam.Tag = "Naam";
            this.txtUsrNaam.TextChanged += new System.EventHandler(this.txtNaam_TextChanged);
            // 
            // txtUsrCode
            // 
            this.txtUsrCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtUsrCode.Location = new System.Drawing.Point(136, 45);
            this.txtUsrCode.MaxLength = 10;
            this.txtUsrCode.Name = "txtUsrCode";
            this.txtUsrCode.Size = new System.Drawing.Size(100, 20);
            this.txtUsrCode.TabIndex = 4;
            this.txtUsrCode.Tag = "Usercode";
            this.txtUsrCode.TextChanged += new System.EventHandler(this.txtCode_TextChanged);
            // 
            // lblUsrGroep
            // 
            this.lblUsrGroep.AutoSize = true;
            this.lblUsrGroep.Location = new System.Drawing.Point(34, 160);
            this.lblUsrGroep.Name = "lblUsrGroep";
            this.lblUsrGroep.Size = new System.Drawing.Size(39, 13);
            this.lblUsrGroep.TabIndex = 10;
            this.lblUsrGroep.Text = "Groep:";
            // 
            // lblUsrNaam
            // 
            this.lblUsrNaam.AutoSize = true;
            this.lblUsrNaam.Location = new System.Drawing.Point(34, 74);
            this.lblUsrNaam.Name = "lblUsrNaam";
            this.lblUsrNaam.Size = new System.Drawing.Size(77, 13);
            this.lblUsrNaam.TabIndex = 5;
            this.lblUsrNaam.Text = "Naam volledig:";
            // 
            // lblUsrCode
            // 
            this.lblUsrCode.AutoSize = true;
            this.lblUsrCode.Location = new System.Drawing.Point(34, 49);
            this.lblUsrCode.Name = "lblUsrCode";
            this.lblUsrCode.Size = new System.Drawing.Size(35, 13);
            this.lblUsrCode.TabIndex = 3;
            this.lblUsrCode.Text = "Code:";
            // 
            // cmdOK
            // 
            this.cmdOK.Location = new System.Drawing.Point(7, 268);
            this.cmdOK.Name = "cmdOK";
            this.cmdOK.Size = new System.Drawing.Size(75, 23);
            this.cmdOK.TabIndex = 12;
            this.cmdOK.Text = "&OK";
            this.cmdOK.UseVisualStyleBackColor = true;
            this.cmdOK.Click += new System.EventHandler(this.cmdOK_Click);
            // 
            // grbGrpMaintD
            // 
            this.grbGrpMaintD.Controls.Add(this.txtGrpNaam);
            this.grbGrpMaintD.Controls.Add(this.txtGrpCode);
            this.grbGrpMaintD.Controls.Add(this.lblGrpNaam);
            this.grbGrpMaintD.Controls.Add(this.lblGrpCode);
            this.grbGrpMaintD.Location = new System.Drawing.Point(11, 28);
            this.grbGrpMaintD.Name = "grbGrpMaintD";
            this.grbGrpMaintD.Size = new System.Drawing.Size(507, 231);
            this.grbGrpMaintD.TabIndex = 14;
            this.grbGrpMaintD.TabStop = false;
            this.grbGrpMaintD.Text = "Detailgegevens";
            // 
            // txtGrpNaam
            // 
            this.txtGrpNaam.Location = new System.Drawing.Point(136, 70);
            this.txtGrpNaam.MaxLength = 50;
            this.txtGrpNaam.Name = "txtGrpNaam";
            this.txtGrpNaam.Size = new System.Drawing.Size(334, 20);
            this.txtGrpNaam.TabIndex = 6;
            this.txtGrpNaam.Tag = "Naam v/d groep";
            this.txtGrpNaam.TextChanged += new System.EventHandler(this.txtGrpNaam_TextChanged);
            // 
            // txtGrpCode
            // 
            this.txtGrpCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtGrpCode.Location = new System.Drawing.Point(136, 45);
            this.txtGrpCode.MaxLength = 12;
            this.txtGrpCode.Name = "txtGrpCode";
            this.txtGrpCode.Size = new System.Drawing.Size(100, 20);
            this.txtGrpCode.TabIndex = 4;
            this.txtGrpCode.Tag = "Code v/d groep";
            this.txtGrpCode.TextChanged += new System.EventHandler(this.txtGrpCode_TextChanged);
            // 
            // lblGrpNaam
            // 
            this.lblGrpNaam.AutoSize = true;
            this.lblGrpNaam.Location = new System.Drawing.Point(34, 74);
            this.lblGrpNaam.Name = "lblGrpNaam";
            this.lblGrpNaam.Size = new System.Drawing.Size(67, 13);
            this.lblGrpNaam.TabIndex = 5;
            this.lblGrpNaam.Text = "Omschrijving";
            // 
            // lblGrpCode
            // 
            this.lblGrpCode.AutoSize = true;
            this.lblGrpCode.Location = new System.Drawing.Point(34, 49);
            this.lblGrpCode.Name = "lblGrpCode";
            this.lblGrpCode.Size = new System.Drawing.Size(65, 13);
            this.lblGrpCode.TabIndex = 3;
            this.lblGrpCode.Text = "Groepscode";
            // 
            // grbElemMaintD
            // 
            this.grbElemMaintD.Controls.Add(this.txtElemOms2);
            this.grbElemMaintD.Controls.Add(this.txtElemOms1);
            this.grbElemMaintD.Controls.Add(this.txtElemElem);
            this.grbElemMaintD.Controls.Add(this.cmbElemTabn);
            this.grbElemMaintD.Controls.Add(this.lblElemOms2);
            this.grbElemMaintD.Controls.Add(this.lblElemOms1);
            this.grbElemMaintD.Controls.Add(this.lblElemElem);
            this.grbElemMaintD.Controls.Add(this.lblElemTabn);
            this.grbElemMaintD.Location = new System.Drawing.Point(11, 26);
            this.grbElemMaintD.Name = "grbElemMaintD";
            this.grbElemMaintD.Size = new System.Drawing.Size(507, 231);
            this.grbElemMaintD.TabIndex = 18;
            this.grbElemMaintD.TabStop = false;
            this.grbElemMaintD.Text = "Detailgegevens";
            // 
            // txtElemOms2
            // 
            this.txtElemOms2.Location = new System.Drawing.Point(136, 142);
            this.txtElemOms2.MaxLength = 250;
            this.txtElemOms2.Multiline = true;
            this.txtElemOms2.Name = "txtElemOms2";
            this.txtElemOms2.Size = new System.Drawing.Size(355, 54);
            this.txtElemOms2.TabIndex = 8;
            this.txtElemOms2.Tag = "Omschrijving 2";
            this.txtElemOms2.TextChanged += new System.EventHandler(this.txtElemOms2_TextChanged);
            // 
            // txtElemOms1
            // 
            this.txtElemOms1.Location = new System.Drawing.Point(136, 80);
            this.txtElemOms1.MaxLength = 250;
            this.txtElemOms1.Multiline = true;
            this.txtElemOms1.Name = "txtElemOms1";
            this.txtElemOms1.Size = new System.Drawing.Size(355, 54);
            this.txtElemOms1.TabIndex = 6;
            this.txtElemOms1.Tag = "Omschrijving 1";
            this.txtElemOms1.TextChanged += new System.EventHandler(this.txtElemOms1_TextChanged);
            // 
            // txtElemElem
            // 
            this.txtElemElem.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtElemElem.Location = new System.Drawing.Point(136, 52);
            this.txtElemElem.MaxLength = 20;
            this.txtElemElem.Name = "txtElemElem";
            this.txtElemElem.Size = new System.Drawing.Size(142, 20);
            this.txtElemElem.TabIndex = 4;
            this.txtElemElem.Tag = "Element";
            this.txtElemElem.TextChanged += new System.EventHandler(this.txtElemElem_TextChanged);
            // 
            // cmbElemTabn
            // 
            this.cmbElemTabn.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbElemTabn.FormattingEnabled = true;
            this.cmbElemTabn.Location = new System.Drawing.Point(136, 18);
            this.cmbElemTabn.Name = "cmbElemTabn";
            this.cmbElemTabn.Size = new System.Drawing.Size(275, 21);
            this.cmbElemTabn.TabIndex = 1;
            this.cmbElemTabn.SelectedIndexChanged += new System.EventHandler(this.cmbElemTabn_SelectedIndexChanged);
            // 
            // lblElemOms2
            // 
            this.lblElemOms2.AutoSize = true;
            this.lblElemOms2.Location = new System.Drawing.Point(34, 142);
            this.lblElemOms2.Name = "lblElemOms2";
            this.lblElemOms2.Size = new System.Drawing.Size(73, 13);
            this.lblElemOms2.TabIndex = 7;
            this.lblElemOms2.Text = "Omschrijving2";
            // 
            // lblElemOms1
            // 
            this.lblElemOms1.AutoSize = true;
            this.lblElemOms1.Location = new System.Drawing.Point(34, 87);
            this.lblElemOms1.Name = "lblElemOms1";
            this.lblElemOms1.Size = new System.Drawing.Size(73, 13);
            this.lblElemOms1.TabIndex = 5;
            this.lblElemOms1.Text = "Omschrijving1";
            // 
            // lblElemElem
            // 
            this.lblElemElem.AutoSize = true;
            this.lblElemElem.Location = new System.Drawing.Point(34, 55);
            this.lblElemElem.Name = "lblElemElem";
            this.lblElemElem.Size = new System.Drawing.Size(48, 13);
            this.lblElemElem.TabIndex = 3;
            this.lblElemElem.Text = "Element:";
            // 
            // lblElemTabn
            // 
            this.lblElemTabn.AutoSize = true;
            this.lblElemTabn.Location = new System.Drawing.Point(34, 22);
            this.lblElemTabn.Name = "lblElemTabn";
            this.lblElemTabn.Size = new System.Drawing.Size(74, 13);
            this.lblElemTabn.TabIndex = 0;
            this.lblElemTabn.Text = "Tabelnummer:";
            // 
            // grbSubMaintD
            // 
            this.grbSubMaintD.Controls.Add(this.txtSubOmsc);
            this.grbSubMaintD.Controls.Add(this.lblSubOmsc);
            this.grbSubMaintD.Controls.Add(this.txtSubNaam);
            this.grbSubMaintD.Controls.Add(this.lblSubNaam);
            this.grbSubMaintD.Location = new System.Drawing.Point(12, 27);
            this.grbSubMaintD.Name = "grbSubMaintD";
            this.grbSubMaintD.Size = new System.Drawing.Size(507, 231);
            this.grbSubMaintD.TabIndex = 16;
            this.grbSubMaintD.TabStop = false;
            this.grbSubMaintD.Text = "Detailgegevens";
            // 
            // txtSubOmsc
            // 
            this.txtSubOmsc.Location = new System.Drawing.Point(134, 87);
            this.txtSubOmsc.MaxLength = 50;
            this.txtSubOmsc.Name = "txtSubOmsc";
            this.txtSubOmsc.Size = new System.Drawing.Size(349, 20);
            this.txtSubOmsc.TabIndex = 6;
            this.txtSubOmsc.Tag = "Omschrijving";
            this.txtSubOmsc.TextChanged += new System.EventHandler(this.txtSubOmsc_TextChanged);
            // 
            // lblSubOmsc
            // 
            this.lblSubOmsc.AutoSize = true;
            this.lblSubOmsc.Location = new System.Drawing.Point(37, 94);
            this.lblSubOmsc.Name = "lblSubOmsc";
            this.lblSubOmsc.Size = new System.Drawing.Size(70, 13);
            this.lblSubOmsc.TabIndex = 5;
            this.lblSubOmsc.Text = "Omschrijving:";
            // 
            // txtSubNaam
            // 
            this.txtSubNaam.Location = new System.Drawing.Point(136, 45);
            this.txtSubNaam.MaxLength = 25;
            this.txtSubNaam.Name = "txtSubNaam";
            this.txtSubNaam.Size = new System.Drawing.Size(243, 20);
            this.txtSubNaam.TabIndex = 4;
            this.txtSubNaam.Tag = "Naam subsysteem";
            this.txtSubNaam.TextChanged += new System.EventHandler(this.txtSubNaam_TextChanged);
            // 
            // lblSubNaam
            // 
            this.lblSubNaam.AutoSize = true;
            this.lblSubNaam.Location = new System.Drawing.Point(34, 49);
            this.lblSubNaam.Name = "lblSubNaam";
            this.lblSubNaam.Size = new System.Drawing.Size(67, 13);
            this.lblSubNaam.TabIndex = 3;
            this.lblSubNaam.Text = "Subsysteem:";
            // 
            // grbTablMaintD
            // 
            this.grbTablMaintD.Controls.Add(this.txtTablO2om);
            this.grbTablMaintD.Controls.Add(this.txtTablO1om);
            this.grbTablMaintD.Controls.Add(this.txtTablElom);
            this.grbTablMaintD.Controls.Add(this.lblTablO2om);
            this.grbTablMaintD.Controls.Add(this.lblTablO1om);
            this.grbTablMaintD.Controls.Add(this.lblTablElom);
            this.grbTablMaintD.Controls.Add(this.lblTablOmsc);
            this.grbTablMaintD.Controls.Add(this.lblTablTabn);
            this.grbTablMaintD.Controls.Add(this.txtTablTabn);
            this.grbTablMaintD.Controls.Add(this.txtTablOmsc);
            this.grbTablMaintD.Location = new System.Drawing.Point(11, 27);
            this.grbTablMaintD.Name = "grbTablMaintD";
            this.grbTablMaintD.Size = new System.Drawing.Size(507, 231);
            this.grbTablMaintD.TabIndex = 17;
            this.grbTablMaintD.TabStop = false;
            this.grbTablMaintD.Text = "Detailgegevens";
            // 
            // txtTablO2om
            // 
            this.txtTablO2om.Location = new System.Drawing.Point(180, 159);
            this.txtTablO2om.MaxLength = 20;
            this.txtTablO2om.Name = "txtTablO2om";
            this.txtTablO2om.Size = new System.Drawing.Size(225, 20);
            this.txtTablO2om.TabIndex = 10;
            this.txtTablO2om.TextChanged += new System.EventHandler(this.txtTablO2om_TextChanged);
            // 
            // txtTablO1om
            // 
            this.txtTablO1om.Location = new System.Drawing.Point(180, 132);
            this.txtTablO1om.MaxLength = 20;
            this.txtTablO1om.Name = "txtTablO1om";
            this.txtTablO1om.Size = new System.Drawing.Size(225, 20);
            this.txtTablO1om.TabIndex = 8;
            this.txtTablO1om.TextChanged += new System.EventHandler(this.txtTablO1om_TextChanged);
            // 
            // txtTablElom
            // 
            this.txtTablElom.Location = new System.Drawing.Point(180, 106);
            this.txtTablElom.MaxLength = 20;
            this.txtTablElom.Name = "txtTablElom";
            this.txtTablElom.Size = new System.Drawing.Size(225, 20);
            this.txtTablElom.TabIndex = 6;
            this.txtTablElom.TextChanged += new System.EventHandler(this.txtTablElom_TextChanged);
            // 
            // lblTablO2om
            // 
            this.lblTablO2om.AutoSize = true;
            this.lblTablO2om.Location = new System.Drawing.Point(34, 163);
            this.lblTablO2om.Name = "lblTablO2om";
            this.lblTablO2om.Size = new System.Drawing.Size(137, 13);
            this.lblTablO2om.TabIndex = 9;
            this.lblTablO2om.Text = "Beschrijving omschrijving 2:";
            // 
            // lblTablO1om
            // 
            this.lblTablO1om.AutoSize = true;
            this.lblTablO1om.Location = new System.Drawing.Point(34, 136);
            this.lblTablO1om.Name = "lblTablO1om";
            this.lblTablO1om.Size = new System.Drawing.Size(137, 13);
            this.lblTablO1om.TabIndex = 7;
            this.lblTablO1om.Text = "Beschrijving omschrijving 1:";
            // 
            // lblTablElom
            // 
            this.lblTablElom.AutoSize = true;
            this.lblTablElom.Location = new System.Drawing.Point(34, 110);
            this.lblTablElom.Name = "lblTablElom";
            this.lblTablElom.Size = new System.Drawing.Size(107, 13);
            this.lblTablElom.TabIndex = 5;
            this.lblTablElom.Text = "Beschrijving element:";
            // 
            // lblTablOmsc
            // 
            this.lblTablOmsc.AutoSize = true;
            this.lblTablOmsc.Location = new System.Drawing.Point(34, 70);
            this.lblTablOmsc.Name = "lblTablOmsc";
            this.lblTablOmsc.Size = new System.Drawing.Size(70, 13);
            this.lblTablOmsc.TabIndex = 3;
            this.lblTablOmsc.Text = "Omschrijving:";
            // 
            // lblTablTabn
            // 
            this.lblTablTabn.AutoSize = true;
            this.lblTablTabn.Location = new System.Drawing.Point(34, 44);
            this.lblTablTabn.Name = "lblTablTabn";
            this.lblTablTabn.Size = new System.Drawing.Size(74, 13);
            this.lblTablTabn.TabIndex = 1;
            this.lblTablTabn.Text = "Tabelnummer:";
            // 
            // txtTablTabn
            // 
            this.txtTablTabn.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower;
            this.txtTablTabn.Location = new System.Drawing.Point(180, 40);
            this.txtTablTabn.MaxLength = 12;
            this.txtTablTabn.Name = "txtTablTabn";
            this.txtTablTabn.Size = new System.Drawing.Size(54, 20);
            this.txtTablTabn.TabIndex = 2;
            this.txtTablTabn.Tag = "Tabelnummer";
            this.txtTablTabn.TextChanged += new System.EventHandler(this.txtTablTabn_TextChanged);
            // 
            // txtTablOmsc
            // 
            this.txtTablOmsc.Location = new System.Drawing.Point(180, 66);
            this.txtTablOmsc.MaxLength = 50;
            this.txtTablOmsc.Name = "txtTablOmsc";
            this.txtTablOmsc.Size = new System.Drawing.Size(291, 20);
            this.txtTablOmsc.TabIndex = 4;
            this.txtTablOmsc.Tag = "Omschrijving";
            this.txtTablOmsc.TextChanged += new System.EventHandler(this.txtTablOmsc_TextChanged);
            // 
            // grbConnMaintD
            // 
            this.grbConnMaintD.Controls.Add(this.lblTelp23);
            this.grbConnMaintD.Controls.Add(this.lblFtp21);
            this.grbConnMaintD.Controls.Add(this.txtConnTelp);
            this.grbConnMaintD.Controls.Add(this.txtConnFtpp);
            this.grbConnMaintD.Controls.Add(this.lblConnTelp);
            this.grbConnMaintD.Controls.Add(this.lblConnFtpp);
            this.grbConnMaintD.Controls.Add(this.txtConnSnam);
            this.grbConnMaintD.Controls.Add(this.lblConnSnam);
            this.grbConnMaintD.Controls.Add(this.txtConnPass);
            this.grbConnMaintD.Controls.Add(this.lblConnPass);
            this.grbConnMaintD.Controls.Add(this.txtConnUser);
            this.grbConnMaintD.Controls.Add(this.txtConnHost);
            this.grbConnMaintD.Controls.Add(this.lblConnUser);
            this.grbConnMaintD.Controls.Add(this.lblConnHost);
            this.grbConnMaintD.Location = new System.Drawing.Point(11, 25);
            this.grbConnMaintD.Name = "grbConnMaintD";
            this.grbConnMaintD.Size = new System.Drawing.Size(509, 231);
            this.grbConnMaintD.TabIndex = 19;
            this.grbConnMaintD.TabStop = false;
            this.grbConnMaintD.Text = "Detailgegevens";
            // 
            // lblTelp23
            // 
            this.lblTelp23.AutoSize = true;
            this.lblTelp23.Location = new System.Drawing.Point(170, 153);
            this.lblTelp23.Name = "lblTelp23";
            this.lblTelp23.Size = new System.Drawing.Size(25, 13);
            this.lblTelp23.TabIndex = 14;
            this.lblTelp23.Text = "(23)";
            // 
            // lblFtp21
            // 
            this.lblFtp21.AutoSize = true;
            this.lblFtp21.Location = new System.Drawing.Point(170, 126);
            this.lblFtp21.Name = "lblFtp21";
            this.lblFtp21.Size = new System.Drawing.Size(25, 13);
            this.lblFtp21.TabIndex = 13;
            this.lblFtp21.Text = "(21)";
            // 
            // txtConnTelp
            // 
            this.txtConnTelp.Location = new System.Drawing.Point(136, 150);
            this.txtConnTelp.MaxLength = 2;
            this.txtConnTelp.Name = "txtConnTelp";
            this.txtConnTelp.Size = new System.Drawing.Size(25, 20);
            this.txtConnTelp.TabIndex = 12;
            this.txtConnTelp.Tag = "Telnet poort";
            this.txtConnTelp.TextChanged += new System.EventHandler(this.txtConnTelp_TextChanged);
            // 
            // txtConnFtpp
            // 
            this.txtConnFtpp.Location = new System.Drawing.Point(136, 124);
            this.txtConnFtpp.MaxLength = 2;
            this.txtConnFtpp.Name = "txtConnFtpp";
            this.txtConnFtpp.Size = new System.Drawing.Size(25, 20);
            this.txtConnFtpp.TabIndex = 10;
            this.txtConnFtpp.Tag = "FTP poort";
            this.txtConnFtpp.TextChanged += new System.EventHandler(this.txtConnFtpp_TextChanged);
            // 
            // lblConnTelp
            // 
            this.lblConnTelp.AutoSize = true;
            this.lblConnTelp.Location = new System.Drawing.Point(34, 153);
            this.lblConnTelp.Name = "lblConnTelp";
            this.lblConnTelp.Size = new System.Drawing.Size(67, 13);
            this.lblConnTelp.TabIndex = 11;
            this.lblConnTelp.Text = "Telnet poort:";
            // 
            // lblConnFtpp
            // 
            this.lblConnFtpp.AutoSize = true;
            this.lblConnFtpp.Location = new System.Drawing.Point(34, 126);
            this.lblConnFtpp.Name = "lblConnFtpp";
            this.lblConnFtpp.Size = new System.Drawing.Size(57, 13);
            this.lblConnFtpp.TabIndex = 9;
            this.lblConnFtpp.Text = "FTP poort:";
            // 
            // txtConnSnam
            // 
            this.txtConnSnam.Location = new System.Drawing.Point(136, 19);
            this.txtConnSnam.MaxLength = 50;
            this.txtConnSnam.Name = "txtConnSnam";
            this.txtConnSnam.Size = new System.Drawing.Size(280, 20);
            this.txtConnSnam.TabIndex = 2;
            this.txtConnSnam.Tag = "Omschrijving";
            this.txtConnSnam.TextChanged += new System.EventHandler(this.txtConnSnam_TextChanged);
            // 
            // lblConnSnam
            // 
            this.lblConnSnam.AutoSize = true;
            this.lblConnSnam.Location = new System.Drawing.Point(34, 23);
            this.lblConnSnam.Name = "lblConnSnam";
            this.lblConnSnam.Size = new System.Drawing.Size(70, 13);
            this.lblConnSnam.TabIndex = 1;
            this.lblConnSnam.Text = "Omschrijving:";
            // 
            // txtConnPass
            // 
            this.txtConnPass.Location = new System.Drawing.Point(136, 96);
            this.txtConnPass.MaxLength = 25;
            this.txtConnPass.Name = "txtConnPass";
            this.txtConnPass.Size = new System.Drawing.Size(181, 20);
            this.txtConnPass.TabIndex = 8;
            this.txtConnPass.Tag = "Password";
            this.txtConnPass.TextChanged += new System.EventHandler(this.txtConnPass_TextChanged);
            // 
            // lblConnPass
            // 
            this.lblConnPass.AutoSize = true;
            this.lblConnPass.Location = new System.Drawing.Point(34, 99);
            this.lblConnPass.Name = "lblConnPass";
            this.lblConnPass.Size = new System.Drawing.Size(56, 13);
            this.lblConnPass.TabIndex = 7;
            this.lblConnPass.Text = "Password:";
            // 
            // txtConnUser
            // 
            this.txtConnUser.Location = new System.Drawing.Point(136, 70);
            this.txtConnUser.MaxLength = 25;
            this.txtConnUser.Name = "txtConnUser";
            this.txtConnUser.Size = new System.Drawing.Size(181, 20);
            this.txtConnUser.TabIndex = 6;
            this.txtConnUser.Tag = "Gebruikersnaam";
            this.txtConnUser.TextChanged += new System.EventHandler(this.txtConnUser_TextChanged);
            // 
            // txtConnHost
            // 
            this.txtConnHost.Location = new System.Drawing.Point(136, 45);
            this.txtConnHost.MaxLength = 50;
            this.txtConnHost.Name = "txtConnHost";
            this.txtConnHost.Size = new System.Drawing.Size(280, 20);
            this.txtConnHost.TabIndex = 4;
            this.txtConnHost.Tag = "Host";
            this.txtConnHost.TextChanged += new System.EventHandler(this.txtConnHost_TextChanged);
            // 
            // lblConnUser
            // 
            this.lblConnUser.AutoSize = true;
            this.lblConnUser.Location = new System.Drawing.Point(34, 74);
            this.lblConnUser.Name = "lblConnUser";
            this.lblConnUser.Size = new System.Drawing.Size(87, 13);
            this.lblConnUser.TabIndex = 5;
            this.lblConnUser.Text = "Gebruikersnaam:";
            // 
            // lblConnHost
            // 
            this.lblConnHost.AutoSize = true;
            this.lblConnHost.Location = new System.Drawing.Point(34, 49);
            this.lblConnHost.Name = "lblConnHost";
            this.lblConnHost.Size = new System.Drawing.Size(32, 13);
            this.lblConnHost.TabIndex = 3;
            this.lblConnHost.Text = "Host:";
            // 
            // grbProgfile
            // 
            this.grbProgfile.Controls.Add(this.lblFunType);
            this.grbProgfile.Controls.Add(this.cmdFunExfu_del);
            this.grbProgfile.Controls.Add(this.cmdFunExfu_add);
            this.grbProgfile.Controls.Add(this.lbFunExfu);
            this.grbProgfile.Controls.Add(this.dgFunExfu);
            this.grbProgfile.Controls.Add(this.lblFunExfu);
            this.grbProgfile.Controls.Add(this.txtFunOmsc);
            this.grbProgfile.Controls.Add(this.lblFunOmsc);
            this.grbProgfile.Controls.Add(this.txtFunParm);
            this.grbProgfile.Controls.Add(this.lblFunParm);
            this.grbProgfile.Controls.Add(this.cmdKies);
            this.grbProgfile.Controls.Add(this.lblFunProg);
            this.grbProgfile.Controls.Add(this.txtFunProg);
            this.grbProgfile.Controls.Add(this.lblSplit_instructie);
            this.grbProgfile.Controls.Add(this.txtFunText);
            this.grbProgfile.Controls.Add(this.lblFunText);
            this.grbProgfile.Controls.Add(this.rbInt);
            this.grbProgfile.Controls.Add(this.rbExec);
            this.grbProgfile.Location = new System.Drawing.Point(11, 18);
            this.grbProgfile.Name = "grbProgfile";
            this.grbProgfile.Size = new System.Drawing.Size(483, 202);
            this.grbProgfile.TabIndex = 16;
            this.grbProgfile.TabStop = false;
            this.grbProgfile.Text = "Programma of formnaam";
            // 
            // lblFunType
            // 
            this.lblFunType.AutoSize = true;
            this.lblFunType.Location = new System.Drawing.Point(16, 22);
            this.lblFunType.Name = "lblFunType";
            this.lblFunType.Size = new System.Drawing.Size(34, 13);
            this.lblFunType.TabIndex = 34;
            this.lblFunType.Text = "Type:";
            // 
            // cmdFunExfu_del
            // 
            this.cmdFunExfu_del.Enabled = false;
            this.cmdFunExfu_del.Location = new System.Drawing.Point(400, 175);
            this.cmdFunExfu_del.Name = "cmdFunExfu_del";
            this.cmdFunExfu_del.Size = new System.Drawing.Size(75, 23);
            this.cmdFunExfu_del.TabIndex = 33;
            this.cmdFunExfu_del.Text = "Verwijder";
            this.cmdFunExfu_del.UseVisualStyleBackColor = true;
            this.cmdFunExfu_del.Click += new System.EventHandler(this.cmdFunExfu_del_Click_1);
            // 
            // cmdFunExfu_add
            // 
            this.cmdFunExfu_add.Location = new System.Drawing.Point(400, 151);
            this.cmdFunExfu_add.Name = "cmdFunExfu_add";
            this.cmdFunExfu_add.Size = new System.Drawing.Size(75, 23);
            this.cmdFunExfu_add.TabIndex = 32;
            this.cmdFunExfu_add.Text = "Voeg toe";
            this.cmdFunExfu_add.UseVisualStyleBackColor = true;
            this.cmdFunExfu_add.Click += new System.EventHandler(this.cmdFunExfu_add_Click);
            // 
            // lbFunExfu
            // 
            this.lbFunExfu.FormattingEnabled = true;
            this.lbFunExfu.Location = new System.Drawing.Point(20, 174);
            this.lbFunExfu.Name = "lbFunExfu";
            this.lbFunExfu.Size = new System.Drawing.Size(46, 17);
            this.lbFunExfu.TabIndex = 31;
            this.lbFunExfu.Visible = false;
            // 
            // dgFunExfu
            // 
            this.dgFunExfu.AllowUserToAddRows = false;
            this.dgFunExfu.AllowUserToDeleteRows = false;
            this.dgFunExfu.AllowUserToResizeColumns = false;
            this.dgFunExfu.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.NullValue = null;
            this.dgFunExfu.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgFunExfu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgFunExfu.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colExFuFunc});
            this.dgFunExfu.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgFunExfu.Location = new System.Drawing.Point(119, 125);
            this.dgFunExfu.MultiSelect = false;
            this.dgFunExfu.Name = "dgFunExfu";
            this.dgFunExfu.RowHeadersVisible = false;
            this.dgFunExfu.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgFunExfu.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgFunExfu.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgFunExfu.Size = new System.Drawing.Size(277, 72);
            this.dgFunExfu.TabIndex = 29;
            this.dgFunExfu.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgFunExfu_CellValueChanged);
            this.dgFunExfu.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgFunExfu_EditingControlShowing);
            this.dgFunExfu.SelectionChanged += new System.EventHandler(this.dgFunExfu_SelectionChanged);
            // 
            // colExFuFunc
            // 
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.NullValue = null;
            this.colExFuFunc.DefaultCellStyle = dataGridViewCellStyle2;
            this.colExFuFunc.HeaderText = "Functie";
            this.colExFuFunc.MaxInputLength = 30;
            this.colExFuFunc.Name = "colExFuFunc";
            this.colExFuFunc.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colExFuFunc.Width = 274;
            // 
            // lblFunExfu
            // 
            this.lblFunExfu.AutoSize = true;
            this.lblFunExfu.Location = new System.Drawing.Point(16, 152);
            this.lblFunExfu.Name = "lblFunExfu";
            this.lblFunExfu.Size = new System.Drawing.Size(101, 13);
            this.lblFunExfu.TabIndex = 28;
            this.lblFunExfu.Text = "Embedded functies:";
            // 
            // txtFunOmsc
            // 
            this.txtFunOmsc.Location = new System.Drawing.Point(119, 103);
            this.txtFunOmsc.MaxLength = 50;
            this.txtFunOmsc.Name = "txtFunOmsc";
            this.txtFunOmsc.Size = new System.Drawing.Size(353, 20);
            this.txtFunOmsc.TabIndex = 27;
            this.txtFunOmsc.Tag = "Programma of formnaam";
            // 
            // lblFunOmsc
            // 
            this.lblFunOmsc.AutoSize = true;
            this.lblFunOmsc.Location = new System.Drawing.Point(16, 107);
            this.lblFunOmsc.Name = "lblFunOmsc";
            this.lblFunOmsc.Size = new System.Drawing.Size(70, 13);
            this.lblFunOmsc.TabIndex = 26;
            this.lblFunOmsc.Text = "Omschrijving:";
            // 
            // txtFunParm
            // 
            this.txtFunParm.Location = new System.Drawing.Point(119, 60);
            this.txtFunParm.MaxLength = 255;
            this.txtFunParm.Name = "txtFunParm";
            this.txtFunParm.Size = new System.Drawing.Size(274, 20);
            this.txtFunParm.TabIndex = 23;
            this.txtFunParm.Tag = "Programma/formnaam";
            // 
            // lblFunParm
            // 
            this.lblFunParm.AutoSize = true;
            this.lblFunParm.Location = new System.Drawing.Point(16, 64);
            this.lblFunParm.Name = "lblFunParm";
            this.lblFunParm.Size = new System.Drawing.Size(69, 13);
            this.lblFunParm.TabIndex = 22;
            this.lblFunParm.Text = "Parameter(s):";
            // 
            // cmdKies
            // 
            this.cmdKies.Location = new System.Drawing.Point(453, 37);
            this.cmdKies.Name = "cmdKies";
            this.cmdKies.Size = new System.Drawing.Size(26, 23);
            this.cmdKies.TabIndex = 21;
            this.cmdKies.Text = "...";
            this.cmdKies.UseVisualStyleBackColor = true;
            this.cmdKies.Click += new System.EventHandler(this.cmdKies_Click);
            // 
            // lblFunProg
            // 
            this.lblFunProg.AutoSize = true;
            this.lblFunProg.Location = new System.Drawing.Point(16, 43);
            this.lblFunProg.Name = "lblFunProg";
            this.lblFunProg.Size = new System.Drawing.Size(38, 13);
            this.lblFunProg.TabIndex = 19;
            this.lblFunProg.Text = "Naam:";
            // 
            // txtFunProg
            // 
            this.txtFunProg.Location = new System.Drawing.Point(119, 39);
            this.txtFunProg.MaxLength = 255;
            this.txtFunProg.Name = "txtFunProg";
            this.txtFunProg.Size = new System.Drawing.Size(334, 20);
            this.txtFunProg.TabIndex = 20;
            this.txtFunProg.Tag = "Programma/formnaam";
            // 
            // lblSplit_instructie
            // 
            this.lblSplit_instructie.AutoSize = true;
            this.lblSplit_instructie.Location = new System.Drawing.Point(96, -15);
            this.lblSplit_instructie.Name = "lblSplit_instructie";
            this.lblSplit_instructie.Size = new System.Drawing.Size(331, 13);
            this.lblSplit_instructie.TabIndex = 17;
            this.lblSplit_instructie.Text = "Gebruik een / om het programma te scheiden van een evt parameter";
            // 
            // txtFunText
            // 
            this.txtFunText.Location = new System.Drawing.Point(119, 81);
            this.txtFunText.MaxLength = 50;
            this.txtFunText.Name = "txtFunText";
            this.txtFunText.Size = new System.Drawing.Size(274, 20);
            this.txtFunText.TabIndex = 25;
            this.txtFunText.Tag = "Programma of formnaam";
            this.txtFunText.TextChanged += new System.EventHandler(this.txtFunText_TextChanged);
            // 
            // lblFunText
            // 
            this.lblFunText.AutoSize = true;
            this.lblFunText.Location = new System.Drawing.Point(16, 85);
            this.lblFunText.Name = "lblFunText";
            this.lblFunText.Size = new System.Drawing.Size(37, 13);
            this.lblFunText.TabIndex = 24;
            this.lblFunText.Text = "Tekst:";
            // 
            // rbInt
            // 
            this.rbInt.AutoSize = true;
            this.rbInt.Location = new System.Drawing.Point(203, 19);
            this.rbInt.Name = "rbInt";
            this.rbInt.Size = new System.Drawing.Size(48, 17);
            this.rbInt.TabIndex = 18;
            this.rbInt.TabStop = true;
            this.rbInt.Text = "Form";
            this.rbInt.UseVisualStyleBackColor = true;
            this.rbInt.CheckedChanged += new System.EventHandler(this.rbInt_CheckedChanged);
            // 
            // rbExec
            // 
            this.rbExec.AutoSize = true;
            this.rbExec.Location = new System.Drawing.Point(120, 19);
            this.rbExec.Name = "rbExec";
            this.rbExec.Size = new System.Drawing.Size(78, 17);
            this.rbExec.TabIndex = 17;
            this.rbExec.TabStop = true;
            this.rbExec.Text = "Executable";
            this.rbExec.UseVisualStyleBackColor = true;
            this.rbExec.CheckedChanged += new System.EventHandler(this.rbExec_CheckedChanged);
            // 
            // grbFunMaintD
            // 
            this.grbFunMaintD.Controls.Add(this.grbProgfile);
            this.grbFunMaintD.Location = new System.Drawing.Point(11, 26);
            this.grbFunMaintD.Name = "grbFunMaintD";
            this.grbFunMaintD.Size = new System.Drawing.Size(507, 231);
            this.grbFunMaintD.TabIndex = 15;
            this.grbFunMaintD.TabStop = false;
            this.grbFunMaintD.Text = "Detailgegevens";
            // 
            // grbBronMaintD
            // 
            this.grbBronMaintD.Controls.Add(this.txtBronCode);
            this.grbBronMaintD.Controls.Add(this.lblBronCode);
            this.grbBronMaintD.Controls.Add(this.txtBronOmsc);
            this.grbBronMaintD.Controls.Add(this.lblBronOmsc);
            this.grbBronMaintD.Location = new System.Drawing.Point(12, 26);
            this.grbBronMaintD.Name = "grbBronMaintD";
            this.grbBronMaintD.Size = new System.Drawing.Size(509, 231);
            this.grbBronMaintD.TabIndex = 1;
            this.grbBronMaintD.TabStop = false;
            this.grbBronMaintD.Text = "Detailgegevens";
            // 
            // txtBronCode
            // 
            this.txtBronCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtBronCode.Location = new System.Drawing.Point(136, 19);
            this.txtBronCode.MaxLength = 3;
            this.txtBronCode.Name = "txtBronCode";
            this.txtBronCode.Size = new System.Drawing.Size(59, 20);
            this.txtBronCode.TabIndex = 3;
            this.txtBronCode.Tag = "Broncode";
            this.txtBronCode.TextChanged += new System.EventHandler(this.txtBronCode_TextChanged);
            // 
            // lblBronCode
            // 
            this.lblBronCode.AutoSize = true;
            this.lblBronCode.Location = new System.Drawing.Point(34, 23);
            this.lblBronCode.Name = "lblBronCode";
            this.lblBronCode.Size = new System.Drawing.Size(56, 13);
            this.lblBronCode.TabIndex = 2;
            this.lblBronCode.Text = "Broncode:";
            // 
            // txtBronOmsc
            // 
            this.txtBronOmsc.Location = new System.Drawing.Point(136, 45);
            this.txtBronOmsc.MaxLength = 50;
            this.txtBronOmsc.Name = "txtBronOmsc";
            this.txtBronOmsc.Size = new System.Drawing.Size(280, 20);
            this.txtBronOmsc.TabIndex = 5;
            this.txtBronOmsc.Tag = "Omschrijving";
            this.txtBronOmsc.TextChanged += new System.EventHandler(this.txtBronOmsc_TextChanged);
            // 
            // lblBronOmsc
            // 
            this.lblBronOmsc.AutoSize = true;
            this.lblBronOmsc.Location = new System.Drawing.Point(34, 49);
            this.lblBronOmsc.Name = "lblBronOmsc";
            this.lblBronOmsc.Size = new System.Drawing.Size(70, 13);
            this.lblBronOmsc.TabIndex = 4;
            this.lblBronOmsc.Text = "Omschrijving:";
            // 
            // grbUitgMaintD
            // 
            this.grbUitgMaintD.Controls.Add(this.lblUitgPubl);
            this.grbUitgMaintD.Controls.Add(this.cmbUitgPubl);
            this.grbUitgMaintD.Controls.Add(this.lblUitgBron);
            this.grbUitgMaintD.Controls.Add(this.cmbUitgBron);
            this.grbUitgMaintD.Controls.Add(this.txtUitgCode);
            this.grbUitgMaintD.Controls.Add(this.lblUitgCode);
            this.grbUitgMaintD.Controls.Add(this.txtUitgOmsc);
            this.grbUitgMaintD.Controls.Add(this.lblUitgOmsc);
            this.grbUitgMaintD.Location = new System.Drawing.Point(11, 25);
            this.grbUitgMaintD.Name = "grbUitgMaintD";
            this.grbUitgMaintD.Size = new System.Drawing.Size(509, 231);
            this.grbUitgMaintD.TabIndex = 1;
            this.grbUitgMaintD.TabStop = false;
            this.grbUitgMaintD.Text = "Detailgegevens";
            // 
            // lblUitgPubl
            // 
            this.lblUitgPubl.AutoSize = true;
            this.lblUitgPubl.Location = new System.Drawing.Point(34, 77);
            this.lblUitgPubl.Name = "lblUitgPubl";
            this.lblUitgPubl.Size = new System.Drawing.Size(50, 13);
            this.lblUitgPubl.TabIndex = 6;
            this.lblUitgPubl.Text = "Uitgever:";
            // 
            // cmbUitgPubl
            // 
            this.cmbUitgPubl.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbUitgPubl.FormattingEnabled = true;
            this.cmbUitgPubl.Location = new System.Drawing.Point(136, 71);
            this.cmbUitgPubl.Name = "cmbUitgPubl";
            this.cmbUitgPubl.Size = new System.Drawing.Size(101, 21);
            this.cmbUitgPubl.TabIndex = 7;
            this.cmbUitgPubl.Tag = "Code uitgever";
            this.cmbUitgPubl.SelectedIndexChanged += new System.EventHandler(this.cmbUitgPubl_SelectedIndexChanged);
            // 
            // lblUitgBron
            // 
            this.lblUitgBron.AutoSize = true;
            this.lblUitgBron.Location = new System.Drawing.Point(248, 77);
            this.lblUitgBron.Name = "lblUitgBron";
            this.lblUitgBron.Size = new System.Drawing.Size(56, 13);
            this.lblUitgBron.TabIndex = 8;
            this.lblUitgBron.Text = "Broncode:";
            // 
            // cmbUitgBron
            // 
            this.cmbUitgBron.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbUitgBron.FormattingEnabled = true;
            this.cmbUitgBron.Location = new System.Drawing.Point(315, 71);
            this.cmbUitgBron.Name = "cmbUitgBron";
            this.cmbUitgBron.Size = new System.Drawing.Size(101, 21);
            this.cmbUitgBron.TabIndex = 9;
            this.cmbUitgBron.Tag = "Broncode";
            this.cmbUitgBron.SelectedIndexChanged += new System.EventHandler(this.cmbUitgBron_SelectedIndexChanged);
            // 
            // txtUitgCode
            // 
            this.txtUitgCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtUitgCode.Location = new System.Drawing.Point(136, 19);
            this.txtUitgCode.MaxLength = 4;
            this.txtUitgCode.Name = "txtUitgCode";
            this.txtUitgCode.Size = new System.Drawing.Size(59, 20);
            this.txtUitgCode.TabIndex = 3;
            this.txtUitgCode.Tag = "Uitgavecode";
            this.txtUitgCode.TextChanged += new System.EventHandler(this.txtUitgCode_TextChanged);
            // 
            // lblUitgCode
            // 
            this.lblUitgCode.AutoSize = true;
            this.lblUitgCode.Location = new System.Drawing.Point(34, 23);
            this.lblUitgCode.Name = "lblUitgCode";
            this.lblUitgCode.Size = new System.Drawing.Size(47, 13);
            this.lblUitgCode.TabIndex = 2;
            this.lblUitgCode.Text = "Uitgave:";
            // 
            // txtUitgOmsc
            // 
            this.txtUitgOmsc.Location = new System.Drawing.Point(136, 45);
            this.txtUitgOmsc.MaxLength = 50;
            this.txtUitgOmsc.Name = "txtUitgOmsc";
            this.txtUitgOmsc.Size = new System.Drawing.Size(280, 20);
            this.txtUitgOmsc.TabIndex = 5;
            this.txtUitgOmsc.Tag = "Omschrijving";
            this.txtUitgOmsc.TextChanged += new System.EventHandler(this.txtUitgOmsc_TextChanged);
            // 
            // lblUitgOmsc
            // 
            this.lblUitgOmsc.AutoSize = true;
            this.lblUitgOmsc.Location = new System.Drawing.Point(34, 49);
            this.lblUitgOmsc.Name = "lblUitgOmsc";
            this.lblUitgOmsc.Size = new System.Drawing.Size(70, 13);
            this.lblUitgOmsc.TabIndex = 4;
            this.lblUitgOmsc.Text = "Omschrijving:";
            // 
            // grbScriptMaintD
            // 
            this.grbScriptMaintD.Controls.Add(this.txtScriptCmd);
            this.grbScriptMaintD.Controls.Add(this.lblScriptCmd);
            this.grbScriptMaintD.Controls.Add(this.txtScriptKey);
            this.grbScriptMaintD.Controls.Add(this.lblScriptKey);
            this.grbScriptMaintD.Controls.Add(this.txtScriptOmsc);
            this.grbScriptMaintD.Controls.Add(this.lblScriptOmsc);
            this.grbScriptMaintD.Location = new System.Drawing.Point(8, 43);
            this.grbScriptMaintD.Name = "grbScriptMaintD";
            this.grbScriptMaintD.Size = new System.Drawing.Size(509, 212);
            this.grbScriptMaintD.TabIndex = 20;
            this.grbScriptMaintD.TabStop = false;
            this.grbScriptMaintD.Text = "Detailgegevens";
            // 
            // txtScriptCmd
            // 
            this.txtScriptCmd.Location = new System.Drawing.Point(136, 115);
            this.txtScriptCmd.MaxLength = 50;
            this.txtScriptCmd.Name = "txtScriptCmd";
            this.txtScriptCmd.Size = new System.Drawing.Size(359, 20);
            this.txtScriptCmd.TabIndex = 7;
            this.txtScriptCmd.Tag = "Unix directory";
            // 
            // lblScriptCmd
            // 
            this.lblScriptCmd.AutoSize = true;
            this.lblScriptCmd.Location = new System.Drawing.Point(11, 118);
            this.lblScriptCmd.Name = "lblScriptCmd";
            this.lblScriptCmd.Size = new System.Drawing.Size(114, 13);
            this.lblScriptCmd.TabIndex = 6;
            this.lblScriptCmd.Text = "<Server>:<Path+Cmd>";
            // 
            // txtScriptKey
            // 
            this.txtScriptKey.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtScriptKey.Location = new System.Drawing.Point(136, 55);
            this.txtScriptKey.MaxLength = 12;
            this.txtScriptKey.Name = "txtScriptKey";
            this.txtScriptKey.Size = new System.Drawing.Size(100, 20);
            this.txtScriptKey.TabIndex = 3;
            this.txtScriptKey.Tag = "Uitgever";
            this.txtScriptKey.TextChanged += new System.EventHandler(this.txtScriptKey_TextChanged);
            // 
            // lblScriptKey
            // 
            this.lblScriptKey.AutoSize = true;
            this.lblScriptKey.Location = new System.Drawing.Point(11, 58);
            this.lblScriptKey.Name = "lblScriptKey";
            this.lblScriptKey.Size = new System.Drawing.Size(28, 13);
            this.lblScriptKey.TabIndex = 2;
            this.lblScriptKey.Text = "Key:";
            // 
            // txtScriptOmsc
            // 
            this.txtScriptOmsc.Location = new System.Drawing.Point(136, 85);
            this.txtScriptOmsc.MaxLength = 50;
            this.txtScriptOmsc.Name = "txtScriptOmsc";
            this.txtScriptOmsc.Size = new System.Drawing.Size(294, 20);
            this.txtScriptOmsc.TabIndex = 5;
            this.txtScriptOmsc.Tag = "Omschrijving";
            this.txtScriptOmsc.TextChanged += new System.EventHandler(this.txtScriptOmsc_TextChanged);
            // 
            // lblScriptOmsc
            // 
            this.lblScriptOmsc.AutoSize = true;
            this.lblScriptOmsc.Location = new System.Drawing.Point(11, 88);
            this.lblScriptOmsc.Name = "lblScriptOmsc";
            this.lblScriptOmsc.Size = new System.Drawing.Size(70, 13);
            this.lblScriptOmsc.TabIndex = 4;
            this.lblScriptOmsc.Text = "Omschrijving:";
            // 
            // grbServMaintD
            // 
            this.grbServMaintD.Controls.Add(this.txtServPass);
            this.grbServMaintD.Controls.Add(this.lblServPass);
            this.grbServMaintD.Controls.Add(this.txtServUser);
            this.grbServMaintD.Controls.Add(this.lblServUser);
            this.grbServMaintD.Controls.Add(this.txtServBeip);
            this.grbServMaintD.Controls.Add(this.lblServBeip);
            this.grbServMaintD.Controls.Add(this.txtServSnam);
            this.grbServMaintD.Controls.Add(this.txtServBuip);
            this.grbServMaintD.Controls.Add(this.txtServFoip);
            this.grbServMaintD.Controls.Add(this.txtServHost);
            this.grbServMaintD.Controls.Add(this.lblServBuip);
            this.grbServMaintD.Controls.Add(this.lblServFoip);
            this.grbServMaintD.Controls.Add(this.lblServHost);
            this.grbServMaintD.Controls.Add(this.lblServSnam);
            this.grbServMaintD.Location = new System.Drawing.Point(11, 28);
            this.grbServMaintD.Name = "grbServMaintD";
            this.grbServMaintD.Size = new System.Drawing.Size(507, 231);
            this.grbServMaintD.TabIndex = 19;
            this.grbServMaintD.TabStop = false;
            this.grbServMaintD.Text = "Detailgegevens";
            this.grbServMaintD.Visible = false;
            // 
            // txtServPass
            // 
            this.txtServPass.Location = new System.Drawing.Point(135, 101);
            this.txtServPass.MaxLength = 50;
            this.txtServPass.Name = "txtServPass";
            this.txtServPass.PasswordChar = '*';
            this.txtServPass.Size = new System.Drawing.Size(164, 20);
            this.txtServPass.TabIndex = 7;
            this.txtServPass.Tag = "Wachtwoord";
            this.txtServPass.TextChanged += new System.EventHandler(this.txtServPass_TextChanged);
            // 
            // lblServPass
            // 
            this.lblServPass.AutoSize = true;
            this.lblServPass.Location = new System.Drawing.Point(34, 101);
            this.lblServPass.Name = "lblServPass";
            this.lblServPass.Size = new System.Drawing.Size(71, 13);
            this.lblServPass.TabIndex = 6;
            this.lblServPass.Text = "Wachtwoord:";
            // 
            // txtServUser
            // 
            this.txtServUser.Location = new System.Drawing.Point(135, 78);
            this.txtServUser.MaxLength = 50;
            this.txtServUser.Name = "txtServUser";
            this.txtServUser.PasswordChar = '*';
            this.txtServUser.Size = new System.Drawing.Size(164, 20);
            this.txtServUser.TabIndex = 5;
            this.txtServUser.Tag = "Gebruikersnaam";
            this.txtServUser.TextChanged += new System.EventHandler(this.txtServUser_TextChanged);
            // 
            // lblServUser
            // 
            this.lblServUser.AutoSize = true;
            this.lblServUser.Location = new System.Drawing.Point(34, 78);
            this.lblServUser.Name = "lblServUser";
            this.lblServUser.Size = new System.Drawing.Size(87, 13);
            this.lblServUser.TabIndex = 4;
            this.lblServUser.Text = "Gebruikersnaam:";
            // 
            // txtServBeip
            // 
            this.txtServBeip.Location = new System.Drawing.Point(135, 155);
            this.txtServBeip.MaxLength = 15;
            this.txtServBeip.Name = "txtServBeip";
            this.txtServBeip.Size = new System.Drawing.Size(219, 20);
            this.txtServBeip.TabIndex = 11;
            this.txtServBeip.Tag = "Back-End IP";
            this.txtServBeip.TextChanged += new System.EventHandler(this.txtServBeip_TextChanged);
            // 
            // lblServBeip
            // 
            this.lblServBeip.AutoSize = true;
            this.lblServBeip.Location = new System.Drawing.Point(34, 159);
            this.lblServBeip.Name = "lblServBeip";
            this.lblServBeip.Size = new System.Drawing.Size(70, 13);
            this.lblServBeip.TabIndex = 10;
            this.lblServBeip.Text = "Back-End IP:";
            // 
            // txtServSnam
            // 
            this.txtServSnam.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtServSnam.Location = new System.Drawing.Point(135, 24);
            this.txtServSnam.MaxLength = 25;
            this.txtServSnam.Name = "txtServSnam";
            this.txtServSnam.Size = new System.Drawing.Size(193, 20);
            this.txtServSnam.TabIndex = 1;
            this.txtServSnam.Tag = "Naam";
            this.txtServSnam.TextChanged += new System.EventHandler(this.txtServSnam_TextChanged);
            // 
            // txtServBuip
            // 
            this.txtServBuip.Location = new System.Drawing.Point(135, 178);
            this.txtServBuip.MaxLength = 15;
            this.txtServBuip.Name = "txtServBuip";
            this.txtServBuip.Size = new System.Drawing.Size(219, 20);
            this.txtServBuip.TabIndex = 13;
            this.txtServBuip.Tag = "Backup-IP";
            this.txtServBuip.TextChanged += new System.EventHandler(this.txtServBuip_TextChanged);
            // 
            // txtServFoip
            // 
            this.txtServFoip.Location = new System.Drawing.Point(135, 132);
            this.txtServFoip.MaxLength = 15;
            this.txtServFoip.Name = "txtServFoip";
            this.txtServFoip.Size = new System.Drawing.Size(219, 20);
            this.txtServFoip.TabIndex = 9;
            this.txtServFoip.Tag = "Front-End IP";
            this.txtServFoip.TextChanged += new System.EventHandler(this.txtServFoip_TextChanged);
            // 
            // txtServHost
            // 
            this.txtServHost.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtServHost.Location = new System.Drawing.Point(135, 48);
            this.txtServHost.MaxLength = 50;
            this.txtServHost.Name = "txtServHost";
            this.txtServHost.Size = new System.Drawing.Size(301, 20);
            this.txtServHost.TabIndex = 3;
            this.txtServHost.Tag = "Hostnaam";
            this.txtServHost.TextChanged += new System.EventHandler(this.txtServHost_TextChanged);
            // 
            // lblServBuip
            // 
            this.lblServBuip.AutoSize = true;
            this.lblServBuip.Location = new System.Drawing.Point(34, 182);
            this.lblServBuip.Name = "lblServBuip";
            this.lblServBuip.Size = new System.Drawing.Size(60, 13);
            this.lblServBuip.TabIndex = 12;
            this.lblServBuip.Text = "Backup-IP:";
            // 
            // lblServFoip
            // 
            this.lblServFoip.AutoSize = true;
            this.lblServFoip.Location = new System.Drawing.Point(34, 136);
            this.lblServFoip.Name = "lblServFoip";
            this.lblServFoip.Size = new System.Drawing.Size(69, 13);
            this.lblServFoip.TabIndex = 8;
            this.lblServFoip.Text = "Front-End IP:";
            // 
            // lblServHost
            // 
            this.lblServHost.AutoSize = true;
            this.lblServHost.Location = new System.Drawing.Point(34, 51);
            this.lblServHost.Name = "lblServHost";
            this.lblServHost.Size = new System.Drawing.Size(58, 13);
            this.lblServHost.TabIndex = 2;
            this.lblServHost.Text = "Hostnaam:";
            // 
            // lblServSnam
            // 
            this.lblServSnam.AutoSize = true;
            this.lblServSnam.Location = new System.Drawing.Point(34, 31);
            this.lblServSnam.Name = "lblServSnam";
            this.lblServSnam.Size = new System.Drawing.Size(35, 13);
            this.lblServSnam.TabIndex = 0;
            this.lblServSnam.Text = "Naam";
            // 
            // grbWiseMaintD
            // 
            this.grbWiseMaintD.Controls.Add(this.txtWiseNaam);
            this.grbWiseMaintD.Controls.Add(this.txtWiseOmsc);
            this.grbWiseMaintD.Controls.Add(this.lblWiseOmsc);
            this.grbWiseMaintD.Controls.Add(this.lblWiseNaam);
            this.grbWiseMaintD.Location = new System.Drawing.Point(10, 26);
            this.grbWiseMaintD.Name = "grbWiseMaintD";
            this.grbWiseMaintD.Size = new System.Drawing.Size(507, 231);
            this.grbWiseMaintD.TabIndex = 20;
            this.grbWiseMaintD.TabStop = false;
            this.grbWiseMaintD.Text = "Detailgegevens";
            // 
            // txtWiseNaam
            // 
            this.txtWiseNaam.Location = new System.Drawing.Point(135, 45);
            this.txtWiseNaam.MaxLength = 25;
            this.txtWiseNaam.Name = "txtWiseNaam";
            this.txtWiseNaam.Size = new System.Drawing.Size(193, 20);
            this.txtWiseNaam.TabIndex = 1;
            this.txtWiseNaam.Tag = "Naam service";
            this.txtWiseNaam.TextChanged += new System.EventHandler(this.txtWiseNaam_TextChanged);
            // 
            // txtWiseOmsc
            // 
            this.txtWiseOmsc.Location = new System.Drawing.Point(135, 90);
            this.txtWiseOmsc.MaxLength = 50;
            this.txtWiseOmsc.Multiline = true;
            this.txtWiseOmsc.Name = "txtWiseOmsc";
            this.txtWiseOmsc.Size = new System.Drawing.Size(301, 54);
            this.txtWiseOmsc.TabIndex = 3;
            this.txtWiseOmsc.Tag = "Omschrijving";
            this.txtWiseOmsc.TextChanged += new System.EventHandler(this.txtWiseOmsc_TextChanged);
            // 
            // lblWiseOmsc
            // 
            this.lblWiseOmsc.AutoSize = true;
            this.lblWiseOmsc.Location = new System.Drawing.Point(34, 90);
            this.lblWiseOmsc.Name = "lblWiseOmsc";
            this.lblWiseOmsc.Size = new System.Drawing.Size(67, 13);
            this.lblWiseOmsc.TabIndex = 2;
            this.lblWiseOmsc.Text = "Omschrijving";
            // 
            // lblWiseNaam
            // 
            this.lblWiseNaam.AutoSize = true;
            this.lblWiseNaam.Location = new System.Drawing.Point(34, 48);
            this.lblWiseNaam.Name = "lblWiseNaam";
            this.lblWiseNaam.Size = new System.Drawing.Size(75, 13);
            this.lblWiseNaam.TabIndex = 0;
            this.lblWiseNaam.Text = "Naam service:";
            // 
            // frmDashMaintD
            // 
            this.AcceptButton = this.cmdAfsluiten;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(526, 305);
            this.Controls.Add(this.grbFunMaintD);
            this.Controls.Add(this.grbServMaintD);
            this.Controls.Add(this.grbElemMaintD);
            this.Controls.Add(this.grbScriptMaintD);
            this.Controls.Add(this.grbUitgMaintD);
            this.Controls.Add(this.grbWiseMaintD);
            this.Controls.Add(this.grbConnMaintD);
            this.Controls.Add(this.grbSubMaintD);
            this.Controls.Add(this.grbBronMaintD);
            this.Controls.Add(this.grbGrpMaintD);
            this.Controls.Add(this.cmdOK);
            this.Controls.Add(this.grbTablMaintD);
            this.Controls.Add(this.grbUsrMaintD);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmDashMaintD";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "DB Dashboard onderhoud";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmDashMaintD_FormClosed);
            this.Load += new System.EventHandler(this.frmDashMaintD_Load);
            this.Shown += new System.EventHandler(this.frmDashMaintD_Shown);
            this.Controls.SetChildIndex(this.lblHostName, 0);
            this.Controls.SetChildIndex(this.grbUsrMaintD, 0);
            this.Controls.SetChildIndex(this.grbTablMaintD, 0);
            this.Controls.SetChildIndex(this.cmdOK, 0);
            this.Controls.SetChildIndex(this.grbGrpMaintD, 0);
            this.Controls.SetChildIndex(this.grbBronMaintD, 0);
            this.Controls.SetChildIndex(this.grbSubMaintD, 0);
            this.Controls.SetChildIndex(this.grbConnMaintD, 0);
            this.Controls.SetChildIndex(this.grbWiseMaintD, 0);
            this.Controls.SetChildIndex(this.grbUitgMaintD, 0);
            this.Controls.SetChildIndex(this.grbScriptMaintD, 0);
            this.Controls.SetChildIndex(this.grbElemMaintD, 0);
            this.Controls.SetChildIndex(this.grbServMaintD, 0);
            this.Controls.SetChildIndex(this.cmdAfsluiten, 0);
            this.Controls.SetChildIndex(this.grbConnect, 0);
            this.Controls.SetChildIndex(this.grbFunMaintD, 0);
            this.grbConnect.ResumeLayout(false);
            this.grbConnect.PerformLayout();
            this.grbUsrMaintD.ResumeLayout(false);
            this.grbUsrMaintD.PerformLayout();
            this.grbGrpMaintD.ResumeLayout(false);
            this.grbGrpMaintD.PerformLayout();
            this.grbElemMaintD.ResumeLayout(false);
            this.grbElemMaintD.PerformLayout();
            this.grbSubMaintD.ResumeLayout(false);
            this.grbSubMaintD.PerformLayout();
            this.grbTablMaintD.ResumeLayout(false);
            this.grbTablMaintD.PerformLayout();
            this.grbConnMaintD.ResumeLayout(false);
            this.grbConnMaintD.PerformLayout();
            this.grbProgfile.ResumeLayout(false);
            this.grbProgfile.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgFunExfu)).EndInit();
            this.grbFunMaintD.ResumeLayout(false);
            this.grbBronMaintD.ResumeLayout(false);
            this.grbBronMaintD.PerformLayout();
            this.grbUitgMaintD.ResumeLayout(false);
            this.grbUitgMaintD.PerformLayout();
            this.grbScriptMaintD.ResumeLayout(false);
            this.grbScriptMaintD.PerformLayout();
            this.grbServMaintD.ResumeLayout(false);
            this.grbServMaintD.PerformLayout();
            this.grbWiseMaintD.ResumeLayout(false);
            this.grbWiseMaintD.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grbUsrMaintD;
        private System.Windows.Forms.Label lblUsrGroep;
        private System.Windows.Forms.Label lblUsrNaam;
        private System.Windows.Forms.Label lblUsrCode;
        private System.Windows.Forms.TextBox txtUsrNaam;
        private System.Windows.Forms.TextBox txtUsrCode;
        private System.Windows.Forms.Button cmdOK;
        private System.Windows.Forms.TextBox txtUsrPass;
        private System.Windows.Forms.Label lblUsrPass;
        private System.Windows.Forms.Label lblUsrPass_hint;
        private System.Windows.Forms.TextBox txtUsrId;
        private System.Windows.Forms.Label lblUsrId;
        private System.Windows.Forms.GroupBox grbGrpMaintD;
        private System.Windows.Forms.TextBox txtGrpNaam;
        private System.Windows.Forms.TextBox txtGrpCode;
        private System.Windows.Forms.Label lblGrpNaam;
        private System.Windows.Forms.Label lblGrpCode;
        private System.Windows.Forms.ComboBox cmbUsrGroep;
        private System.Windows.Forms.GroupBox grbSubMaintD;
        private System.Windows.Forms.TextBox txtSubNaam;
        private System.Windows.Forms.Label lblSubNaam;
        private System.Windows.Forms.GroupBox grbTablMaintD;
        private System.Windows.Forms.TextBox txtTablTabn;
        private System.Windows.Forms.TextBox txtTablOmsc;
        private System.Windows.Forms.Label lblTablOmsc;
        private System.Windows.Forms.Label lblTablTabn;
        private System.Windows.Forms.GroupBox grbElemMaintD;
        private System.Windows.Forms.Label lblElemOms1;
        private System.Windows.Forms.Label lblElemElem;
        private System.Windows.Forms.Label lblElemTabn;
        private System.Windows.Forms.TextBox txtElemOms2;
        private System.Windows.Forms.TextBox txtElemOms1;
        private System.Windows.Forms.TextBox txtElemElem;
        private System.Windows.Forms.ComboBox cmbElemTabn;
        private System.Windows.Forms.Label lblElemOms2;
        private System.Windows.Forms.Label lblTablO2om;
        private System.Windows.Forms.Label lblTablO1om;
        private System.Windows.Forms.Label lblTablElom;
        private System.Windows.Forms.TextBox txtTablO2om;
        private System.Windows.Forms.TextBox txtTablO1om;
        private System.Windows.Forms.TextBox txtTablElom;
        private System.Windows.Forms.GroupBox grbConnMaintD;
        private System.Windows.Forms.TextBox txtConnSnam;
        private System.Windows.Forms.Label lblConnSnam;
        private System.Windows.Forms.TextBox txtConnPass;
        private System.Windows.Forms.Label lblConnPass;
        private System.Windows.Forms.TextBox txtConnUser;
        private System.Windows.Forms.TextBox txtConnHost;
        private System.Windows.Forms.Label lblConnUser;
        private System.Windows.Forms.Label lblConnHost;
        private System.Windows.Forms.TextBox txtConnTelp;
        private System.Windows.Forms.TextBox txtConnFtpp;
        private System.Windows.Forms.Label lblConnTelp;
        private System.Windows.Forms.Label lblConnFtpp;
        private System.Windows.Forms.Label lblTelp23;
        private System.Windows.Forms.Label lblFtp21;
        private System.Windows.Forms.GroupBox grbProgfile;
        private System.Windows.Forms.Button cmdKies;
        private System.Windows.Forms.Label lblFunProg;
        private System.Windows.Forms.TextBox txtFunProg;
        private System.Windows.Forms.Label lblSplit_instructie;
        private System.Windows.Forms.TextBox txtFunText;
        private System.Windows.Forms.Label lblFunText;
        private System.Windows.Forms.RadioButton rbInt;
        private System.Windows.Forms.RadioButton rbExec;
        private System.Windows.Forms.GroupBox grbFunMaintD;
        private System.Windows.Forms.TextBox txtSubOmsc;
        private System.Windows.Forms.Label lblSubOmsc;
        private System.Windows.Forms.TextBox txtFunParm;
        private System.Windows.Forms.Label lblFunParm;
        private System.Windows.Forms.GroupBox grbBronMaintD;
        private System.Windows.Forms.TextBox txtBronCode;
        private System.Windows.Forms.Label lblBronCode;
        private System.Windows.Forms.TextBox txtBronOmsc;
        private System.Windows.Forms.Label lblBronOmsc;
        private System.Windows.Forms.GroupBox grbUitgMaintD;
        private System.Windows.Forms.Label lblUitgBron;
        private System.Windows.Forms.ComboBox cmbUitgBron;
        private System.Windows.Forms.TextBox txtUitgCode;
        private System.Windows.Forms.Label lblUitgCode;
        private System.Windows.Forms.TextBox txtUitgOmsc;
        private System.Windows.Forms.Label lblUitgOmsc;
        private System.Windows.Forms.Label lblUitgPubl;
        private System.Windows.Forms.ComboBox cmbUitgPubl;
        private System.Windows.Forms.GroupBox grbScriptMaintD;
        private System.Windows.Forms.TextBox txtScriptCmd;
        private System.Windows.Forms.Label lblScriptCmd;
        private System.Windows.Forms.TextBox txtScriptKey;
        private System.Windows.Forms.Label lblScriptKey;
        private System.Windows.Forms.TextBox txtScriptOmsc;
        private System.Windows.Forms.Label lblScriptOmsc;
        private System.Windows.Forms.TextBox txtFunOmsc;
        private System.Windows.Forms.Label lblFunOmsc;
        private System.Windows.Forms.GroupBox grbServMaintD;
        private System.Windows.Forms.TextBox txtServSnam;
        private System.Windows.Forms.TextBox txtServBuip;
        private System.Windows.Forms.TextBox txtServFoip;
        private System.Windows.Forms.TextBox txtServHost;
        private System.Windows.Forms.Label lblServBuip;
        private System.Windows.Forms.Label lblServFoip;
        private System.Windows.Forms.Label lblServHost;
        private System.Windows.Forms.Label lblServSnam;
        private System.Windows.Forms.TextBox txtServBeip;
        private System.Windows.Forms.Label lblServBeip;
        private System.Windows.Forms.TextBox txtServPass;
        private System.Windows.Forms.Label lblServPass;
        private System.Windows.Forms.TextBox txtServUser;
        private System.Windows.Forms.Label lblServUser;
        private System.Windows.Forms.GroupBox grbWiseMaintD;
        private System.Windows.Forms.TextBox txtWiseNaam;
        private System.Windows.Forms.TextBox txtWiseOmsc;
        private System.Windows.Forms.Label lblWiseOmsc;
        private System.Windows.Forms.Label lblWiseNaam;
        private System.Windows.Forms.DataGridView dgFunExfu;
        private System.Windows.Forms.Label lblFunExfu;
        private System.Windows.Forms.ListBox lbFunExfu;
        private System.Windows.Forms.Button cmdFunExfu_del;
        private System.Windows.Forms.Button cmdFunExfu_add;
        private System.Windows.Forms.Label lblFunType;
        private System.Windows.Forms.DataGridViewTextBoxColumn colExFuFunc;
    }
}