﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;

namespace dbDashboard
{
    public partial class frmDashTran : frmDashBase
    {
        public string strCore;
        public string strPlink;
        public string strSSH;
        public string strTranx;
        public string strSelectedAddressType;
        public string strSelectedAddress;

        public frmDashTran()
        {
            InitializeComponent();
        }

        private void cmdOTP_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            get_logrecords(txtFysical.Text, txtLogical.Text, cbOTPCase.Checked);
            this.Cursor = Cursors.Default;
        }

        private void get_logrecords(string strFysical, string strLogical, Boolean bMatchCase)
        {

            lblOTPStatus.Text = "";
            lblOTPStatus.Visible = false;

            string strServer = strCore;             // "kslv048";
            string strCmd = strPlink;               // "c:\\Program Files\\WinSCP\\Putty\\plink.exe";
            string strCredit = mdiDashboard.strPW;  // "-l pe029017 -pw Fblcb44$";
            string strGrep = "";

            int intRowNo = -1;

            if (strLogical != "")
            {
                if (strGrep == "")
                {
                    strGrep = "LA=" + strLogical;
                }
                else
                {
                    strGrep = strGrep + ",LA=" + strLogical;
                }
            }
            if (strFysical != "")
            {
                if (strGrep == "")
                {
                    strGrep = "FA=" + strFysical;
                }
                else
                {
                    strGrep = strGrep + ",FA=" + strFysical;
                }
            }
            if (strGrep == "")
            {
                if (bMatchCase)
                {
                    strGrep = "CS=MR";
                }
                else
                {
                    strGrep = "CS=MI";
                }
            }
            else
            {
                if (bMatchCase)
                {
                    strGrep = strGrep + ",CS=MR";
                }
                else
                {
                    strGrep = strGrep + ",CS=MI";
                }
            }

            //clDashFunction.Melding(strGrep);

            string strTrans = strTranx + " " + strGrep;
            //strTranx: zoiets als: /home/pe029017/scripts/gettrans.sh"; 

            dgTranslations.Rows.Clear();
            this.Refresh();

            if (mdiDashboard.Talk)
            {
                clDashFunction.Melding("Query Parms: strServer: " + strServer + "\n strTrans:" + strTrans,1,"I");
            }

            StreamReader myStreamReader = clDashFunction.get_linux_data(strServer, strTrans);
            if (myStreamReader != null)
            {
                string[] strTransRecord = new string[8];

                while (!myStreamReader.EndOfStream)
                {
                    // *********************************************************************************************************
                    //  1    ~   2    ~   3     ~   4                      ~   5     ~    6   ~  7     ~     8
                    // Role:~bedrijven~Physical:~OTPPROD@A-1-expediteurs.nl~PeerRole:~overheid~Logical:~a1de1162@mail.otpnet.nl
                    // **********************************************************************************************************

                    strTransRecord = Regex.Split(myStreamReader.ReadLine(), "~");
                    // MessageBox.Show("Lengte: "+strTransRecord.Length.ToString());

                    if (strTransRecord.Length == 8)
                    {
                        intRowNo = dgTranslations.Rows.Add();
                        dgTranslations[0, intRowNo].Value = strTransRecord[1];
                        dgTranslations[1, intRowNo].Value = strTransRecord[3];
                        dgTranslations[2, intRowNo].Value = strTransRecord[7];
                    }                    
                }
            }
            if (intRowNo < 0)
            {
                dgTranslations.Enabled = false;
                clDashFunction.Melding("No translations selected", 1, "I");
            }
            else
            {
                dgTranslations.Enabled = true;
            }

            lblOTPStatus.Text = (1 + intRowNo).ToString() + " translations selected";
            lblOTPStatus.Visible = true;
        }

        private void frmDashTrans_Load(object sender, EventArgs e)
        {
            frm_init();
        }

        private void dgTranslations_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            process_selection(e.ColumnIndex,e.RowIndex);
        }

        private void dgTranslations_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            process_selection(e.ColumnIndex, e.RowIndex);
        }

        private void frm_init()
        {
            // **********************************************
            // Remove bepaalde controls vanuit het base form
            // **********************************************
            clDashFunction.remove_inherited_control(this, "toolstrip1");
            
            
            cmdOTP.Enabled = false;
            switch ( strSelectedAddressType )
            {
                  case "P":
                    txtFysical.Text = strSelectedAddress;
                    cmdOTP_Click(new object(), new EventArgs());
                    break;
                case "L":
                    txtLogical.Text = strSelectedAddress;
                    cmdOTP_Click(new object(), new EventArgs());
                    break;  
                default:
                    // Do nothing ( should not be possible ) 
                    txtFysical.Text = strSelectedAddress;
                    txtSelectedAddressType.Text = strSelectedAddressType;                   
                    break;
            }
            
            /*
            if (cmdOTP.Enabled)
            {
                
            }
             * */

        }

        private void txtFysical_TextChanged(object sender, EventArgs e)
        {
            able_otp();
        }

        private void txtLogical_TextChanged(object sender, EventArgs e)
        {
            able_otp();
        }

        private void able_otp()
        {
            cmdOTP.Enabled = false;
            if (txtFysical.Text.Trim() != "" || txtLogical.Text.Trim() != "")
            {
                cmdOTP.Enabled = true;
            }
        }

        private void process_selection(int intColIndex, int intRowIndex)
        {
            if (intColIndex > 0)
            {
                strSelectedAddress = dgTranslations[intColIndex, intRowIndex].Value.ToString();
                strSelectedAddressType = dgTranslations.Columns[intColIndex].HeaderText.Substring(0, 1).ToString();
                this.Close();
            }
        }

        private void frmDashTrans_Activated(object sender, EventArgs e)
        {
            txtFysical.Focus();
        }
    }
}