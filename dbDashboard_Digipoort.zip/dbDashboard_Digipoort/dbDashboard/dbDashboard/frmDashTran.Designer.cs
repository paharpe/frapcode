﻿namespace dbDashboard
{
    partial class frmDashTran
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grbTran = new System.Windows.Forms.GroupBox();
            this.lblOTPStatus = new System.Windows.Forms.Label();
            this.dgTranslations = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grbTranSelect = new System.Windows.Forms.GroupBox();
            this.txtSelectedAddressType = new System.Windows.Forms.TextBox();
            this.cbOTPCase = new System.Windows.Forms.CheckBox();
            this.txtFysical = new System.Windows.Forms.TextBox();
            this.txtLogical = new System.Windows.Forms.TextBox();
            this.lblFysical = new System.Windows.Forms.Label();
            this.lblLogical = new System.Windows.Forms.Label();
            this.cmdOTP = new System.Windows.Forms.Button();
            this.grbConnect.SuspendLayout();
            this.grbTran.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgTranslations)).BeginInit();
            this.grbTranSelect.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmdAfsluiten
            // 
            this.cmdAfsluiten.Location = new System.Drawing.Point(10, 478);
            // 
            // grbConnect
            // 
            this.grbConnect.Location = new System.Drawing.Point(286, 722);
            this.grbConnect.Size = new System.Drawing.Size(505, 10);
            // 
            // lblHostName
            // 
            this.lblHostName.Location = new System.Drawing.Point(623, 493);
            this.lblHostName.Size = new System.Drawing.Size(145, 13);
            this.lblHostName.Text = "KPNNL\\WLD4BED923B63C";
            // 
            // grbTran
            // 
            this.grbTran.Controls.Add(this.lblOTPStatus);
            this.grbTran.Controls.Add(this.dgTranslations);
            this.grbTran.Controls.Add(this.grbTranSelect);
            this.grbTran.Location = new System.Drawing.Point(10, 27);
            this.grbTran.Name = "grbTran";
            this.grbTran.Size = new System.Drawing.Size(744, 438);
            this.grbTran.TabIndex = 21;
            this.grbTran.TabStop = false;
            this.grbTran.Text = "Digipoort translations";
            // 
            // lblOTPStatus
            // 
            this.lblOTPStatus.AutoSize = true;
            this.lblOTPStatus.Location = new System.Drawing.Point(16, 412);
            this.lblOTPStatus.Name = "lblOTPStatus";
            this.lblOTPStatus.Size = new System.Drawing.Size(37, 13);
            this.lblOTPStatus.TabIndex = 5;
            this.lblOTPStatus.Text = "Status";
            this.lblOTPStatus.Visible = false;
            // 
            // dgTranslations
            // 
            this.dgTranslations.AllowUserToAddRows = false;
            this.dgTranslations.AllowUserToDeleteRows = false;
            this.dgTranslations.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgTranslations.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3});
            this.dgTranslations.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgTranslations.Location = new System.Drawing.Point(19, 123);
            this.dgTranslations.MultiSelect = false;
            this.dgTranslations.Name = "dgTranslations";
            this.dgTranslations.ReadOnly = true;
            this.dgTranslations.RowHeadersVisible = false;
            this.dgTranslations.ShowCellErrors = false;
            this.dgTranslations.ShowCellToolTips = false;
            this.dgTranslations.ShowEditingIcon = false;
            this.dgTranslations.ShowRowErrors = false;
            this.dgTranslations.Size = new System.Drawing.Size(705, 277);
            this.dgTranslations.TabIndex = 3;
            this.dgTranslations.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgTranslations_CellContentClick);
            this.dgTranslations.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgTranslations_CellContentDoubleClick);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Role";
            this.dataGridViewTextBoxColumn1.MaxInputLength = 5;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.FillWeight = 300F;
            this.dataGridViewTextBoxColumn2.HeaderText = "Pysical address";
            this.dataGridViewTextBoxColumn2.MaxInputLength = 100;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 300;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.FillWeight = 300F;
            this.dataGridViewTextBoxColumn3.HeaderText = "Logical address";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 300;
            // 
            // grbTranSelect
            // 
            this.grbTranSelect.Controls.Add(this.txtSelectedAddressType);
            this.grbTranSelect.Controls.Add(this.cbOTPCase);
            this.grbTranSelect.Controls.Add(this.txtFysical);
            this.grbTranSelect.Controls.Add(this.txtLogical);
            this.grbTranSelect.Controls.Add(this.lblFysical);
            this.grbTranSelect.Controls.Add(this.lblLogical);
            this.grbTranSelect.Controls.Add(this.cmdOTP);
            this.grbTranSelect.Location = new System.Drawing.Point(19, 26);
            this.grbTranSelect.Name = "grbTranSelect";
            this.grbTranSelect.Size = new System.Drawing.Size(705, 81);
            this.grbTranSelect.TabIndex = 2;
            this.grbTranSelect.TabStop = false;
            this.grbTranSelect.Text = "Criteria";
            // 
            // txtSelectedAddressType
            // 
            this.txtSelectedAddressType.Location = new System.Drawing.Point(376, 34);
            this.txtSelectedAddressType.Name = "txtSelectedAddressType";
            this.txtSelectedAddressType.Size = new System.Drawing.Size(26, 20);
            this.txtSelectedAddressType.TabIndex = 6;
            this.txtSelectedAddressType.Visible = false;
            // 
            // cbOTPCase
            // 
            this.cbOTPCase.AutoSize = true;
            this.cbOTPCase.Location = new System.Drawing.Point(420, 22);
            this.cbOTPCase.Name = "cbOTPCase";
            this.cbOTPCase.Size = new System.Drawing.Size(82, 17);
            this.cbOTPCase.TabIndex = 4;
            this.cbOTPCase.Text = "Match case";
            this.cbOTPCase.UseVisualStyleBackColor = true;
            // 
            // txtFysical
            // 
            this.txtFysical.Location = new System.Drawing.Point(140, 20);
            this.txtFysical.Name = "txtFysical";
            this.txtFysical.Size = new System.Drawing.Size(230, 20);
            this.txtFysical.TabIndex = 1;
            this.txtFysical.TextChanged += new System.EventHandler(this.txtFysical_TextChanged);
            // 
            // txtLogical
            // 
            this.txtLogical.Location = new System.Drawing.Point(140, 48);
            this.txtLogical.Name = "txtLogical";
            this.txtLogical.Size = new System.Drawing.Size(230, 20);
            this.txtLogical.TabIndex = 3;
            this.txtLogical.TextChanged += new System.EventHandler(this.txtLogical_TextChanged);
            // 
            // lblFysical
            // 
            this.lblFysical.AutoSize = true;
            this.lblFysical.Location = new System.Drawing.Point(6, 24);
            this.lblFysical.Name = "lblFysical";
            this.lblFysical.Size = new System.Drawing.Size(132, 13);
            this.lblFysical.TabIndex = 0;
            this.lblFysical.Text = "Physical address contains:";
            // 
            // lblLogical
            // 
            this.lblLogical.AutoSize = true;
            this.lblLogical.Location = new System.Drawing.Point(6, 50);
            this.lblLogical.Name = "lblLogical";
            this.lblLogical.Size = new System.Drawing.Size(127, 13);
            this.lblLogical.TabIndex = 2;
            this.lblLogical.Text = "Logical address contains:";
            // 
            // cmdOTP
            // 
            this.cmdOTP.Location = new System.Drawing.Point(420, 46);
            this.cmdOTP.Name = "cmdOTP";
            this.cmdOTP.Size = new System.Drawing.Size(75, 23);
            this.cmdOTP.TabIndex = 7;
            this.cmdOTP.Text = "Select";
            this.cmdOTP.UseVisualStyleBackColor = true;
            this.cmdOTP.Click += new System.EventHandler(this.cmdOTP_Click);
            // 
            // frmDashTran
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(765, 506);
            this.Controls.Add(this.grbTran);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "frmDashTran";
            this.Text = "frmDashTran: Selection on phyiscal and logical translations";
            this.Activated += new System.EventHandler(this.frmDashTrans_Activated);
            this.Load += new System.EventHandler(this.frmDashTrans_Load);
            this.Controls.SetChildIndex(this.grbConnect, 0);
            this.Controls.SetChildIndex(this.lblHostName, 0);
            this.Controls.SetChildIndex(this.cmdAfsluiten, 0);
            this.Controls.SetChildIndex(this.grbTran, 0);
            this.grbConnect.ResumeLayout(false);
            this.grbConnect.PerformLayout();
            this.grbTran.ResumeLayout(false);
            this.grbTran.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgTranslations)).EndInit();
            this.grbTranSelect.ResumeLayout(false);
            this.grbTranSelect.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grbTran;
        private System.Windows.Forms.DataGridView dgTranslations;
        private System.Windows.Forms.GroupBox grbTranSelect;
        private System.Windows.Forms.Label lblOTPStatus;
        private System.Windows.Forms.CheckBox cbOTPCase;
        private System.Windows.Forms.TextBox txtFysical;
        private System.Windows.Forms.TextBox txtLogical;
        private System.Windows.Forms.Label lblFysical;
        private System.Windows.Forms.Label lblLogical;
        private System.Windows.Forms.Button cmdOTP;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.TextBox txtSelectedAddressType;
    }
}