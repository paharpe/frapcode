﻿namespace dbDashboard
{
    partial class frmDashMaintD
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDashMaintD));
            this.grbUsrMaintD = new System.Windows.Forms.GroupBox();
            this.cmbUsrGroep = new System.Windows.Forms.ComboBox();
            this.txtUsrId = new System.Windows.Forms.TextBox();
            this.lblUsrId = new System.Windows.Forms.Label();
            this.lblUsrPass_hint = new System.Windows.Forms.Label();
            this.txtUsrPass = new System.Windows.Forms.TextBox();
            this.lblUsrPass = new System.Windows.Forms.Label();
            this.txtUsrNaam = new System.Windows.Forms.TextBox();
            this.txtUsrCode = new System.Windows.Forms.TextBox();
            this.lblUsrGroep = new System.Windows.Forms.Label();
            this.lblUsrNaam = new System.Windows.Forms.Label();
            this.lblUsrCode = new System.Windows.Forms.Label();
            this.cmdOK = new System.Windows.Forms.Button();
            this.grbGrpMaintD = new System.Windows.Forms.GroupBox();
            this.txtGrpNaam = new System.Windows.Forms.TextBox();
            this.txtGrpCode = new System.Windows.Forms.TextBox();
            this.lblGrpNaam = new System.Windows.Forms.Label();
            this.lblGrpCode = new System.Windows.Forms.Label();
            this.grbElemMaintD = new System.Windows.Forms.GroupBox();
            this.txtElemOms2 = new System.Windows.Forms.TextBox();
            this.txtElemOms1 = new System.Windows.Forms.TextBox();
            this.txtElemElem = new System.Windows.Forms.TextBox();
            this.cmbElemTabn = new System.Windows.Forms.ComboBox();
            this.lblElemOms2 = new System.Windows.Forms.Label();
            this.lblElemOms1 = new System.Windows.Forms.Label();
            this.lblElemElem = new System.Windows.Forms.Label();
            this.lblElemTabn = new System.Windows.Forms.Label();
            this.grbSubMaintD = new System.Windows.Forms.GroupBox();
            this.txtSubOmsc = new System.Windows.Forms.TextBox();
            this.lblSubOmsc = new System.Windows.Forms.Label();
            this.txtSubNaam = new System.Windows.Forms.TextBox();
            this.lblSubNaam = new System.Windows.Forms.Label();
            this.grbTablMaintD = new System.Windows.Forms.GroupBox();
            this.txtTablO2om = new System.Windows.Forms.TextBox();
            this.txtTablO1om = new System.Windows.Forms.TextBox();
            this.txtTablElom = new System.Windows.Forms.TextBox();
            this.lblTablO2om = new System.Windows.Forms.Label();
            this.lblTablO1om = new System.Windows.Forms.Label();
            this.lblTablElom = new System.Windows.Forms.Label();
            this.lblTablOmsc = new System.Windows.Forms.Label();
            this.lblTablTabn = new System.Windows.Forms.Label();
            this.txtTablTabn = new System.Windows.Forms.TextBox();
            this.txtTablOmsc = new System.Windows.Forms.TextBox();
            this.grbConnMaintD = new System.Windows.Forms.GroupBox();
            this.lblTelp23 = new System.Windows.Forms.Label();
            this.lblFtp21 = new System.Windows.Forms.Label();
            this.txtConnTelp = new System.Windows.Forms.TextBox();
            this.txtConnFtpp = new System.Windows.Forms.TextBox();
            this.lblConnTelp = new System.Windows.Forms.Label();
            this.lblConnFtpp = new System.Windows.Forms.Label();
            this.txtConnSnam = new System.Windows.Forms.TextBox();
            this.lblConnSnam = new System.Windows.Forms.Label();
            this.txtConnPass = new System.Windows.Forms.TextBox();
            this.lblConnPass = new System.Windows.Forms.Label();
            this.txtConnUser = new System.Windows.Forms.TextBox();
            this.txtConnHost = new System.Windows.Forms.TextBox();
            this.lblConnUser = new System.Windows.Forms.Label();
            this.lblConnHost = new System.Windows.Forms.Label();
            this.grbProgfile = new System.Windows.Forms.GroupBox();
            this.txtFunParm = new System.Windows.Forms.TextBox();
            this.lblFunParm = new System.Windows.Forms.Label();
            this.cmdKies = new System.Windows.Forms.Button();
            this.lblFunProg = new System.Windows.Forms.Label();
            this.txtFunProg = new System.Windows.Forms.TextBox();
            this.lblSplit_instructie = new System.Windows.Forms.Label();
            this.txtFunText = new System.Windows.Forms.TextBox();
            this.lblFunText = new System.Windows.Forms.Label();
            this.rbInt = new System.Windows.Forms.RadioButton();
            this.rbExec = new System.Windows.Forms.RadioButton();
            this.grbFunMaintD = new System.Windows.Forms.GroupBox();
            this.grbBronMaintD = new System.Windows.Forms.GroupBox();
            this.txtBronCode = new System.Windows.Forms.TextBox();
            this.lblBronCode = new System.Windows.Forms.Label();
            this.txtBronOmsc = new System.Windows.Forms.TextBox();
            this.lblBronOmsc = new System.Windows.Forms.Label();
            this.grbUitgMaintD = new System.Windows.Forms.GroupBox();
            this.lblUitgPubl = new System.Windows.Forms.Label();
            this.cmbUitgPubl = new System.Windows.Forms.ComboBox();
            this.lblUitgBron = new System.Windows.Forms.Label();
            this.cmbUitgBron = new System.Windows.Forms.ComboBox();
            this.txtUitgCode = new System.Windows.Forms.TextBox();
            this.lblUitgCode = new System.Windows.Forms.Label();
            this.txtUitgOmsc = new System.Windows.Forms.TextBox();
            this.lblUitgOmsc = new System.Windows.Forms.Label();
            this.grbPublMaintD = new System.Windows.Forms.GroupBox();
            this.txtPublUenv = new System.Windows.Forms.TextBox();
            this.lblPublUenv = new System.Windows.Forms.Label();
            this.txtPublUdir = new System.Windows.Forms.TextBox();
            this.lblPublUdir = new System.Windows.Forms.Label();
            this.txtPublCode = new System.Windows.Forms.TextBox();
            this.lblPublCode = new System.Windows.Forms.Label();
            this.txtPublOmsc = new System.Windows.Forms.TextBox();
            this.lblPublOmsc = new System.Windows.Forms.Label();
            this.grbConnectie.SuspendLayout();
            this.grbUsrMaintD.SuspendLayout();
            this.grbGrpMaintD.SuspendLayout();
            this.grbElemMaintD.SuspendLayout();
            this.grbSubMaintD.SuspendLayout();
            this.grbTablMaintD.SuspendLayout();
            this.grbConnMaintD.SuspendLayout();
            this.grbProgfile.SuspendLayout();
            this.grbFunMaintD.SuspendLayout();
            this.grbBronMaintD.SuspendLayout();
            this.grbUitgMaintD.SuspendLayout();
            this.grbPublMaintD.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmdAfsluiten
            // 
            this.cmdAfsluiten.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.cmdAfsluiten.Location = new System.Drawing.Point(96, 269);
            // 
            // grbConnectie
            // 
            this.grbConnectie.Location = new System.Drawing.Point(13, 317);
            // 
            // cmdConnect
            // 
            this.cmdConnect.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            // 
            // grbUsrMaintD
            // 
            this.grbUsrMaintD.Controls.Add(this.cmbUsrGroep);
            this.grbUsrMaintD.Controls.Add(this.txtUsrId);
            this.grbUsrMaintD.Controls.Add(this.lblUsrId);
            this.grbUsrMaintD.Controls.Add(this.lblUsrPass_hint);
            this.grbUsrMaintD.Controls.Add(this.txtUsrPass);
            this.grbUsrMaintD.Controls.Add(this.lblUsrPass);
            this.grbUsrMaintD.Controls.Add(this.txtUsrNaam);
            this.grbUsrMaintD.Controls.Add(this.txtUsrCode);
            this.grbUsrMaintD.Controls.Add(this.lblUsrGroep);
            this.grbUsrMaintD.Controls.Add(this.lblUsrNaam);
            this.grbUsrMaintD.Controls.Add(this.lblUsrCode);
            this.grbUsrMaintD.Location = new System.Drawing.Point(12, 15);
            this.grbUsrMaintD.Name = "grbUsrMaintD";
            this.grbUsrMaintD.Size = new System.Drawing.Size(507, 231);
            this.grbUsrMaintD.TabIndex = 0;
            this.grbUsrMaintD.TabStop = false;
            this.grbUsrMaintD.Text = "Detailgegevens";
            // 
            // cmbUsrGroep
            // 
            this.cmbUsrGroep.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbUsrGroep.FormattingEnabled = true;
            this.cmbUsrGroep.Location = new System.Drawing.Point(136, 159);
            this.cmbUsrGroep.Name = "cmbUsrGroep";
            this.cmbUsrGroep.Size = new System.Drawing.Size(220, 21);
            this.cmbUsrGroep.TabIndex = 11;
            this.cmbUsrGroep.Tag = "Groepcode";
            this.cmbUsrGroep.SelectedIndexChanged += new System.EventHandler(this.cmbUsrGroep_SelectedIndexChanged);
            // 
            // txtUsrId
            // 
            this.txtUsrId.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtUsrId.Enabled = false;
            this.txtUsrId.Location = new System.Drawing.Point(136, 19);
            this.txtUsrId.MaxLength = 12;
            this.txtUsrId.Name = "txtUsrId";
            this.txtUsrId.Size = new System.Drawing.Size(100, 20);
            this.txtUsrId.TabIndex = 2;
            this.txtUsrId.Tag = "Userid";
            this.txtUsrId.TextChanged += new System.EventHandler(this.txtUsrId_TextChanged);
            // 
            // lblUsrId
            // 
            this.lblUsrId.AutoSize = true;
            this.lblUsrId.Location = new System.Drawing.Point(34, 23);
            this.lblUsrId.Name = "lblUsrId";
            this.lblUsrId.Size = new System.Drawing.Size(19, 13);
            this.lblUsrId.TabIndex = 1;
            this.lblUsrId.Text = "Id:";
            // 
            // lblUsrPass_hint
            // 
            this.lblUsrPass_hint.AutoSize = true;
            this.lblUsrPass_hint.Location = new System.Drawing.Point(242, 99);
            this.lblUsrPass_hint.Name = "lblUsrPass_hint";
            this.lblUsrPass_hint.Size = new System.Drawing.Size(63, 13);
            this.lblUsrPass_hint.TabIndex = 9;
            this.lblUsrPass_hint.Text = "(5-8 tekens)";
            // 
            // txtUsrPass
            // 
            this.txtUsrPass.Location = new System.Drawing.Point(136, 96);
            this.txtUsrPass.MaxLength = 8;
            this.txtUsrPass.Name = "txtUsrPass";
            this.txtUsrPass.Size = new System.Drawing.Size(100, 20);
            this.txtUsrPass.TabIndex = 8;
            this.txtUsrPass.Tag = "Password";
            this.txtUsrPass.TextChanged += new System.EventHandler(this.txtUsrPass_TextChanged);
            // 
            // lblUsrPass
            // 
            this.lblUsrPass.AutoSize = true;
            this.lblUsrPass.Location = new System.Drawing.Point(34, 99);
            this.lblUsrPass.Name = "lblUsrPass";
            this.lblUsrPass.Size = new System.Drawing.Size(56, 13);
            this.lblUsrPass.TabIndex = 7;
            this.lblUsrPass.Text = "Password:";
            // 
            // txtUsrNaam
            // 
            this.txtUsrNaam.Location = new System.Drawing.Point(136, 70);
            this.txtUsrNaam.MaxLength = 50;
            this.txtUsrNaam.Name = "txtUsrNaam";
            this.txtUsrNaam.Size = new System.Drawing.Size(334, 20);
            this.txtUsrNaam.TabIndex = 6;
            this.txtUsrNaam.Tag = "Naam";
            this.txtUsrNaam.TextChanged += new System.EventHandler(this.txtNaam_TextChanged);
            // 
            // txtUsrCode
            // 
            this.txtUsrCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtUsrCode.Location = new System.Drawing.Point(136, 45);
            this.txtUsrCode.MaxLength = 10;
            this.txtUsrCode.Name = "txtUsrCode";
            this.txtUsrCode.Size = new System.Drawing.Size(100, 20);
            this.txtUsrCode.TabIndex = 4;
            this.txtUsrCode.Tag = "Usercode";
            this.txtUsrCode.TextChanged += new System.EventHandler(this.txtCode_TextChanged);
            // 
            // lblUsrGroep
            // 
            this.lblUsrGroep.AutoSize = true;
            this.lblUsrGroep.Location = new System.Drawing.Point(34, 160);
            this.lblUsrGroep.Name = "lblUsrGroep";
            this.lblUsrGroep.Size = new System.Drawing.Size(39, 13);
            this.lblUsrGroep.TabIndex = 10;
            this.lblUsrGroep.Text = "Groep:";
            // 
            // lblUsrNaam
            // 
            this.lblUsrNaam.AutoSize = true;
            this.lblUsrNaam.Location = new System.Drawing.Point(34, 74);
            this.lblUsrNaam.Name = "lblUsrNaam";
            this.lblUsrNaam.Size = new System.Drawing.Size(77, 13);
            this.lblUsrNaam.TabIndex = 5;
            this.lblUsrNaam.Text = "Naam volledig:";
            // 
            // lblUsrCode
            // 
            this.lblUsrCode.AutoSize = true;
            this.lblUsrCode.Location = new System.Drawing.Point(34, 49);
            this.lblUsrCode.Name = "lblUsrCode";
            this.lblUsrCode.Size = new System.Drawing.Size(35, 13);
            this.lblUsrCode.TabIndex = 3;
            this.lblUsrCode.Text = "Code:";
            // 
            // cmdOK
            // 
            this.cmdOK.Location = new System.Drawing.Point(10, 269);
            this.cmdOK.Name = "cmdOK";
            this.cmdOK.Size = new System.Drawing.Size(75, 23);
            this.cmdOK.TabIndex = 12;
            this.cmdOK.Text = "&OK";
            this.cmdOK.UseVisualStyleBackColor = true;
            this.cmdOK.Click += new System.EventHandler(this.cmdOK_Click);
            // 
            // grbGrpMaintD
            // 
            this.grbGrpMaintD.Controls.Add(this.txtGrpNaam);
            this.grbGrpMaintD.Controls.Add(this.txtGrpCode);
            this.grbGrpMaintD.Controls.Add(this.lblGrpNaam);
            this.grbGrpMaintD.Controls.Add(this.lblGrpCode);
            this.grbGrpMaintD.Location = new System.Drawing.Point(11, 17);
            this.grbGrpMaintD.Name = "grbGrpMaintD";
            this.grbGrpMaintD.Size = new System.Drawing.Size(507, 231);
            this.grbGrpMaintD.TabIndex = 14;
            this.grbGrpMaintD.TabStop = false;
            this.grbGrpMaintD.Text = "Detailgegevens";
            // 
            // txtGrpNaam
            // 
            this.txtGrpNaam.Location = new System.Drawing.Point(136, 70);
            this.txtGrpNaam.MaxLength = 50;
            this.txtGrpNaam.Name = "txtGrpNaam";
            this.txtGrpNaam.Size = new System.Drawing.Size(334, 20);
            this.txtGrpNaam.TabIndex = 6;
            this.txtGrpNaam.Tag = "Naam v/d groep";
            this.txtGrpNaam.TextChanged += new System.EventHandler(this.txtGrpNaam_TextChanged);
            // 
            // txtGrpCode
            // 
            this.txtGrpCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtGrpCode.Location = new System.Drawing.Point(136, 45);
            this.txtGrpCode.MaxLength = 12;
            this.txtGrpCode.Name = "txtGrpCode";
            this.txtGrpCode.Size = new System.Drawing.Size(100, 20);
            this.txtGrpCode.TabIndex = 4;
            this.txtGrpCode.Tag = "Code v/d groep";
            this.txtGrpCode.TextChanged += new System.EventHandler(this.txtGrpCode_TextChanged);
            // 
            // lblGrpNaam
            // 
            this.lblGrpNaam.AutoSize = true;
            this.lblGrpNaam.Location = new System.Drawing.Point(34, 74);
            this.lblGrpNaam.Name = "lblGrpNaam";
            this.lblGrpNaam.Size = new System.Drawing.Size(67, 13);
            this.lblGrpNaam.TabIndex = 5;
            this.lblGrpNaam.Text = "Omschrijving";
            // 
            // lblGrpCode
            // 
            this.lblGrpCode.AutoSize = true;
            this.lblGrpCode.Location = new System.Drawing.Point(34, 49);
            this.lblGrpCode.Name = "lblGrpCode";
            this.lblGrpCode.Size = new System.Drawing.Size(65, 13);
            this.lblGrpCode.TabIndex = 3;
            this.lblGrpCode.Text = "Groepscode";
            // 
            // grbElemMaintD
            // 
            this.grbElemMaintD.Controls.Add(this.txtElemOms2);
            this.grbElemMaintD.Controls.Add(this.txtElemOms1);
            this.grbElemMaintD.Controls.Add(this.txtElemElem);
            this.grbElemMaintD.Controls.Add(this.cmbElemTabn);
            this.grbElemMaintD.Controls.Add(this.lblElemOms2);
            this.grbElemMaintD.Controls.Add(this.lblElemOms1);
            this.grbElemMaintD.Controls.Add(this.lblElemElem);
            this.grbElemMaintD.Controls.Add(this.lblElemTabn);
            this.grbElemMaintD.Location = new System.Drawing.Point(11, 15);
            this.grbElemMaintD.Name = "grbElemMaintD";
            this.grbElemMaintD.Size = new System.Drawing.Size(507, 231);
            this.grbElemMaintD.TabIndex = 18;
            this.grbElemMaintD.TabStop = false;
            this.grbElemMaintD.Text = "Detailgegevens";
            // 
            // txtElemOms2
            // 
            this.txtElemOms2.Location = new System.Drawing.Point(136, 142);
            this.txtElemOms2.MaxLength = 250;
            this.txtElemOms2.Multiline = true;
            this.txtElemOms2.Name = "txtElemOms2";
            this.txtElemOms2.Size = new System.Drawing.Size(355, 54);
            this.txtElemOms2.TabIndex = 8;
            this.txtElemOms2.Tag = "Omschrijving 2";
            this.txtElemOms2.TextChanged += new System.EventHandler(this.txtElemOms2_TextChanged);
            // 
            // txtElemOms1
            // 
            this.txtElemOms1.Location = new System.Drawing.Point(136, 80);
            this.txtElemOms1.MaxLength = 250;
            this.txtElemOms1.Multiline = true;
            this.txtElemOms1.Name = "txtElemOms1";
            this.txtElemOms1.Size = new System.Drawing.Size(355, 54);
            this.txtElemOms1.TabIndex = 6;
            this.txtElemOms1.Tag = "Omschrijving 1";
            this.txtElemOms1.TextChanged += new System.EventHandler(this.txtElemOms1_TextChanged);
            // 
            // txtElemElem
            // 
            this.txtElemElem.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtElemElem.Location = new System.Drawing.Point(136, 52);
            this.txtElemElem.MaxLength = 20;
            this.txtElemElem.Name = "txtElemElem";
            this.txtElemElem.Size = new System.Drawing.Size(142, 20);
            this.txtElemElem.TabIndex = 4;
            this.txtElemElem.Tag = "Element";
            this.txtElemElem.TextChanged += new System.EventHandler(this.txtElemElem_TextChanged);
            // 
            // cmbElemTabn
            // 
            this.cmbElemTabn.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbElemTabn.FormattingEnabled = true;
            this.cmbElemTabn.Location = new System.Drawing.Point(136, 18);
            this.cmbElemTabn.Name = "cmbElemTabn";
            this.cmbElemTabn.Size = new System.Drawing.Size(275, 21);
            this.cmbElemTabn.TabIndex = 1;
            this.cmbElemTabn.SelectedIndexChanged += new System.EventHandler(this.cmbElemTabn_SelectedIndexChanged);
            // 
            // lblElemOms2
            // 
            this.lblElemOms2.AutoSize = true;
            this.lblElemOms2.Location = new System.Drawing.Point(34, 142);
            this.lblElemOms2.Name = "lblElemOms2";
            this.lblElemOms2.Size = new System.Drawing.Size(73, 13);
            this.lblElemOms2.TabIndex = 7;
            this.lblElemOms2.Text = "Omschrijving2";
            // 
            // lblElemOms1
            // 
            this.lblElemOms1.AutoSize = true;
            this.lblElemOms1.Location = new System.Drawing.Point(34, 87);
            this.lblElemOms1.Name = "lblElemOms1";
            this.lblElemOms1.Size = new System.Drawing.Size(73, 13);
            this.lblElemOms1.TabIndex = 5;
            this.lblElemOms1.Text = "Omschrijving1";
            // 
            // lblElemElem
            // 
            this.lblElemElem.AutoSize = true;
            this.lblElemElem.Location = new System.Drawing.Point(34, 55);
            this.lblElemElem.Name = "lblElemElem";
            this.lblElemElem.Size = new System.Drawing.Size(48, 13);
            this.lblElemElem.TabIndex = 3;
            this.lblElemElem.Text = "Element:";
            // 
            // lblElemTabn
            // 
            this.lblElemTabn.AutoSize = true;
            this.lblElemTabn.Location = new System.Drawing.Point(34, 22);
            this.lblElemTabn.Name = "lblElemTabn";
            this.lblElemTabn.Size = new System.Drawing.Size(74, 13);
            this.lblElemTabn.TabIndex = 0;
            this.lblElemTabn.Text = "Tabelnummer:";
            // 
            // grbSubMaintD
            // 
            this.grbSubMaintD.Controls.Add(this.txtSubOmsc);
            this.grbSubMaintD.Controls.Add(this.lblSubOmsc);
            this.grbSubMaintD.Controls.Add(this.txtSubNaam);
            this.grbSubMaintD.Controls.Add(this.lblSubNaam);
            this.grbSubMaintD.Location = new System.Drawing.Point(12, 16);
            this.grbSubMaintD.Name = "grbSubMaintD";
            this.grbSubMaintD.Size = new System.Drawing.Size(507, 231);
            this.grbSubMaintD.TabIndex = 16;
            this.grbSubMaintD.TabStop = false;
            this.grbSubMaintD.Text = "Detailgegevens";
            // 
            // txtSubOmsc
            // 
            this.txtSubOmsc.Location = new System.Drawing.Point(134, 87);
            this.txtSubOmsc.MaxLength = 50;
            this.txtSubOmsc.Name = "txtSubOmsc";
            this.txtSubOmsc.Size = new System.Drawing.Size(349, 20);
            this.txtSubOmsc.TabIndex = 6;
            this.txtSubOmsc.Tag = "Omschrijving";
            this.txtSubOmsc.TextChanged += new System.EventHandler(this.txtSubOmsc_TextChanged);
            // 
            // lblSubOmsc
            // 
            this.lblSubOmsc.AutoSize = true;
            this.lblSubOmsc.Location = new System.Drawing.Point(37, 94);
            this.lblSubOmsc.Name = "lblSubOmsc";
            this.lblSubOmsc.Size = new System.Drawing.Size(70, 13);
            this.lblSubOmsc.TabIndex = 5;
            this.lblSubOmsc.Text = "Omschrijving:";
            // 
            // txtSubNaam
            // 
            this.txtSubNaam.Location = new System.Drawing.Point(136, 45);
            this.txtSubNaam.MaxLength = 25;
            this.txtSubNaam.Name = "txtSubNaam";
            this.txtSubNaam.Size = new System.Drawing.Size(243, 20);
            this.txtSubNaam.TabIndex = 4;
            this.txtSubNaam.Tag = "Naam subsysteem";
            this.txtSubNaam.TextChanged += new System.EventHandler(this.txtSubNaam_TextChanged);
            // 
            // lblSubNaam
            // 
            this.lblSubNaam.AutoSize = true;
            this.lblSubNaam.Location = new System.Drawing.Point(34, 49);
            this.lblSubNaam.Name = "lblSubNaam";
            this.lblSubNaam.Size = new System.Drawing.Size(67, 13);
            this.lblSubNaam.TabIndex = 3;
            this.lblSubNaam.Text = "Subsysteem:";
            // 
            // grbTablMaintD
            // 
            this.grbTablMaintD.Controls.Add(this.txtTablO2om);
            this.grbTablMaintD.Controls.Add(this.txtTablO1om);
            this.grbTablMaintD.Controls.Add(this.txtTablElom);
            this.grbTablMaintD.Controls.Add(this.lblTablO2om);
            this.grbTablMaintD.Controls.Add(this.lblTablO1om);
            this.grbTablMaintD.Controls.Add(this.lblTablElom);
            this.grbTablMaintD.Controls.Add(this.lblTablOmsc);
            this.grbTablMaintD.Controls.Add(this.lblTablTabn);
            this.grbTablMaintD.Controls.Add(this.txtTablTabn);
            this.grbTablMaintD.Controls.Add(this.txtTablOmsc);
            this.grbTablMaintD.Location = new System.Drawing.Point(11, 16);
            this.grbTablMaintD.Name = "grbTablMaintD";
            this.grbTablMaintD.Size = new System.Drawing.Size(507, 231);
            this.grbTablMaintD.TabIndex = 17;
            this.grbTablMaintD.TabStop = false;
            this.grbTablMaintD.Text = "Detailgegevens";
            // 
            // txtTablO2om
            // 
            this.txtTablO2om.Location = new System.Drawing.Point(180, 159);
            this.txtTablO2om.MaxLength = 20;
            this.txtTablO2om.Name = "txtTablO2om";
            this.txtTablO2om.Size = new System.Drawing.Size(225, 20);
            this.txtTablO2om.TabIndex = 10;
            this.txtTablO2om.TextChanged += new System.EventHandler(this.txtTablO2om_TextChanged);
            // 
            // txtTablO1om
            // 
            this.txtTablO1om.Location = new System.Drawing.Point(180, 132);
            this.txtTablO1om.MaxLength = 20;
            this.txtTablO1om.Name = "txtTablO1om";
            this.txtTablO1om.Size = new System.Drawing.Size(225, 20);
            this.txtTablO1om.TabIndex = 8;
            this.txtTablO1om.TextChanged += new System.EventHandler(this.txtTablO1om_TextChanged);
            // 
            // txtTablElom
            // 
            this.txtTablElom.Location = new System.Drawing.Point(180, 106);
            this.txtTablElom.MaxLength = 20;
            this.txtTablElom.Name = "txtTablElom";
            this.txtTablElom.Size = new System.Drawing.Size(225, 20);
            this.txtTablElom.TabIndex = 6;
            this.txtTablElom.TextChanged += new System.EventHandler(this.txtTablElom_TextChanged);
            // 
            // lblTablO2om
            // 
            this.lblTablO2om.AutoSize = true;
            this.lblTablO2om.Location = new System.Drawing.Point(34, 163);
            this.lblTablO2om.Name = "lblTablO2om";
            this.lblTablO2om.Size = new System.Drawing.Size(137, 13);
            this.lblTablO2om.TabIndex = 9;
            this.lblTablO2om.Text = "Beschrijving omschrijving 2:";
            // 
            // lblTablO1om
            // 
            this.lblTablO1om.AutoSize = true;
            this.lblTablO1om.Location = new System.Drawing.Point(34, 136);
            this.lblTablO1om.Name = "lblTablO1om";
            this.lblTablO1om.Size = new System.Drawing.Size(137, 13);
            this.lblTablO1om.TabIndex = 7;
            this.lblTablO1om.Text = "Beschrijving omschrijving 1:";
            // 
            // lblTablElom
            // 
            this.lblTablElom.AutoSize = true;
            this.lblTablElom.Location = new System.Drawing.Point(34, 110);
            this.lblTablElom.Name = "lblTablElom";
            this.lblTablElom.Size = new System.Drawing.Size(107, 13);
            this.lblTablElom.TabIndex = 5;
            this.lblTablElom.Text = "Beschrijving element:";
            // 
            // lblTablOmsc
            // 
            this.lblTablOmsc.AutoSize = true;
            this.lblTablOmsc.Location = new System.Drawing.Point(34, 70);
            this.lblTablOmsc.Name = "lblTablOmsc";
            this.lblTablOmsc.Size = new System.Drawing.Size(70, 13);
            this.lblTablOmsc.TabIndex = 3;
            this.lblTablOmsc.Text = "Omschrijving:";
            // 
            // lblTablTabn
            // 
            this.lblTablTabn.AutoSize = true;
            this.lblTablTabn.Location = new System.Drawing.Point(34, 44);
            this.lblTablTabn.Name = "lblTablTabn";
            this.lblTablTabn.Size = new System.Drawing.Size(74, 13);
            this.lblTablTabn.TabIndex = 1;
            this.lblTablTabn.Text = "Tabelnummer:";
            // 
            // txtTablTabn
            // 
            this.txtTablTabn.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower;
            this.txtTablTabn.Location = new System.Drawing.Point(180, 40);
            this.txtTablTabn.MaxLength = 12;
            this.txtTablTabn.Name = "txtTablTabn";
            this.txtTablTabn.Size = new System.Drawing.Size(54, 20);
            this.txtTablTabn.TabIndex = 2;
            this.txtTablTabn.Tag = "Tabelnummer";
            this.txtTablTabn.TextChanged += new System.EventHandler(this.txtTablTabn_TextChanged);
            // 
            // txtTablOmsc
            // 
            this.txtTablOmsc.Location = new System.Drawing.Point(180, 66);
            this.txtTablOmsc.MaxLength = 50;
            this.txtTablOmsc.Name = "txtTablOmsc";
            this.txtTablOmsc.Size = new System.Drawing.Size(291, 20);
            this.txtTablOmsc.TabIndex = 4;
            this.txtTablOmsc.Tag = "Omschrijving";
            this.txtTablOmsc.TextChanged += new System.EventHandler(this.txtTablOmsc_TextChanged);
            // 
            // grbConnMaintD
            // 
            this.grbConnMaintD.Controls.Add(this.lblTelp23);
            this.grbConnMaintD.Controls.Add(this.lblFtp21);
            this.grbConnMaintD.Controls.Add(this.txtConnTelp);
            this.grbConnMaintD.Controls.Add(this.txtConnFtpp);
            this.grbConnMaintD.Controls.Add(this.lblConnTelp);
            this.grbConnMaintD.Controls.Add(this.lblConnFtpp);
            this.grbConnMaintD.Controls.Add(this.txtConnSnam);
            this.grbConnMaintD.Controls.Add(this.lblConnSnam);
            this.grbConnMaintD.Controls.Add(this.txtConnPass);
            this.grbConnMaintD.Controls.Add(this.lblConnPass);
            this.grbConnMaintD.Controls.Add(this.txtConnUser);
            this.grbConnMaintD.Controls.Add(this.txtConnHost);
            this.grbConnMaintD.Controls.Add(this.lblConnUser);
            this.grbConnMaintD.Controls.Add(this.lblConnHost);
            this.grbConnMaintD.Location = new System.Drawing.Point(11, 14);
            this.grbConnMaintD.Name = "grbConnMaintD";
            this.grbConnMaintD.Size = new System.Drawing.Size(509, 231);
            this.grbConnMaintD.TabIndex = 19;
            this.grbConnMaintD.TabStop = false;
            this.grbConnMaintD.Text = "Detailgegevens";
            // 
            // lblTelp23
            // 
            this.lblTelp23.AutoSize = true;
            this.lblTelp23.Location = new System.Drawing.Point(170, 153);
            this.lblTelp23.Name = "lblTelp23";
            this.lblTelp23.Size = new System.Drawing.Size(25, 13);
            this.lblTelp23.TabIndex = 14;
            this.lblTelp23.Text = "(23)";
            // 
            // lblFtp21
            // 
            this.lblFtp21.AutoSize = true;
            this.lblFtp21.Location = new System.Drawing.Point(170, 126);
            this.lblFtp21.Name = "lblFtp21";
            this.lblFtp21.Size = new System.Drawing.Size(25, 13);
            this.lblFtp21.TabIndex = 13;
            this.lblFtp21.Text = "(21)";
            // 
            // txtConnTelp
            // 
            this.txtConnTelp.Location = new System.Drawing.Point(136, 150);
            this.txtConnTelp.MaxLength = 2;
            this.txtConnTelp.Name = "txtConnTelp";
            this.txtConnTelp.Size = new System.Drawing.Size(25, 20);
            this.txtConnTelp.TabIndex = 12;
            this.txtConnTelp.Tag = "Telnet poort";
            this.txtConnTelp.TextChanged += new System.EventHandler(this.txtConnTelp_TextChanged);
            // 
            // txtConnFtpp
            // 
            this.txtConnFtpp.Location = new System.Drawing.Point(136, 124);
            this.txtConnFtpp.MaxLength = 2;
            this.txtConnFtpp.Name = "txtConnFtpp";
            this.txtConnFtpp.Size = new System.Drawing.Size(25, 20);
            this.txtConnFtpp.TabIndex = 10;
            this.txtConnFtpp.Tag = "FTP poort";
            this.txtConnFtpp.TextChanged += new System.EventHandler(this.txtConnFtpp_TextChanged);
            // 
            // lblConnTelp
            // 
            this.lblConnTelp.AutoSize = true;
            this.lblConnTelp.Location = new System.Drawing.Point(34, 153);
            this.lblConnTelp.Name = "lblConnTelp";
            this.lblConnTelp.Size = new System.Drawing.Size(67, 13);
            this.lblConnTelp.TabIndex = 11;
            this.lblConnTelp.Text = "Telnet poort:";
            // 
            // lblConnFtpp
            // 
            this.lblConnFtpp.AutoSize = true;
            this.lblConnFtpp.Location = new System.Drawing.Point(34, 126);
            this.lblConnFtpp.Name = "lblConnFtpp";
            this.lblConnFtpp.Size = new System.Drawing.Size(57, 13);
            this.lblConnFtpp.TabIndex = 9;
            this.lblConnFtpp.Text = "FTP poort:";
            // 
            // txtConnSnam
            // 
            this.txtConnSnam.Location = new System.Drawing.Point(136, 19);
            this.txtConnSnam.MaxLength = 50;
            this.txtConnSnam.Name = "txtConnSnam";
            this.txtConnSnam.Size = new System.Drawing.Size(280, 20);
            this.txtConnSnam.TabIndex = 2;
            this.txtConnSnam.Tag = "Omschrijving";
            this.txtConnSnam.TextChanged += new System.EventHandler(this.txtConnSnam_TextChanged);
            // 
            // lblConnSnam
            // 
            this.lblConnSnam.AutoSize = true;
            this.lblConnSnam.Location = new System.Drawing.Point(34, 23);
            this.lblConnSnam.Name = "lblConnSnam";
            this.lblConnSnam.Size = new System.Drawing.Size(70, 13);
            this.lblConnSnam.TabIndex = 1;
            this.lblConnSnam.Text = "Omschrijving:";
            // 
            // txtConnPass
            // 
            this.txtConnPass.Location = new System.Drawing.Point(136, 96);
            this.txtConnPass.MaxLength = 25;
            this.txtConnPass.Name = "txtConnPass";
            this.txtConnPass.Size = new System.Drawing.Size(181, 20);
            this.txtConnPass.TabIndex = 8;
            this.txtConnPass.Tag = "Password";
            this.txtConnPass.TextChanged += new System.EventHandler(this.txtConnPass_TextChanged);
            // 
            // lblConnPass
            // 
            this.lblConnPass.AutoSize = true;
            this.lblConnPass.Location = new System.Drawing.Point(34, 99);
            this.lblConnPass.Name = "lblConnPass";
            this.lblConnPass.Size = new System.Drawing.Size(56, 13);
            this.lblConnPass.TabIndex = 7;
            this.lblConnPass.Text = "Password:";
            // 
            // txtConnUser
            // 
            this.txtConnUser.Location = new System.Drawing.Point(136, 70);
            this.txtConnUser.MaxLength = 25;
            this.txtConnUser.Name = "txtConnUser";
            this.txtConnUser.Size = new System.Drawing.Size(181, 20);
            this.txtConnUser.TabIndex = 6;
            this.txtConnUser.Tag = "Gebruikersnaam";
            this.txtConnUser.TextChanged += new System.EventHandler(this.txtConnUser_TextChanged);
            // 
            // txtConnHost
            // 
            this.txtConnHost.Location = new System.Drawing.Point(136, 45);
            this.txtConnHost.MaxLength = 50;
            this.txtConnHost.Name = "txtConnHost";
            this.txtConnHost.Size = new System.Drawing.Size(280, 20);
            this.txtConnHost.TabIndex = 4;
            this.txtConnHost.Tag = "Host";
            this.txtConnHost.TextChanged += new System.EventHandler(this.txtConnHost_TextChanged);
            // 
            // lblConnUser
            // 
            this.lblConnUser.AutoSize = true;
            this.lblConnUser.Location = new System.Drawing.Point(34, 74);
            this.lblConnUser.Name = "lblConnUser";
            this.lblConnUser.Size = new System.Drawing.Size(87, 13);
            this.lblConnUser.TabIndex = 5;
            this.lblConnUser.Text = "Gebruikersnaam:";
            // 
            // lblConnHost
            // 
            this.lblConnHost.AutoSize = true;
            this.lblConnHost.Location = new System.Drawing.Point(34, 49);
            this.lblConnHost.Name = "lblConnHost";
            this.lblConnHost.Size = new System.Drawing.Size(32, 13);
            this.lblConnHost.TabIndex = 3;
            this.lblConnHost.Text = "Host:";
            // 
            // grbProgfile
            // 
            this.grbProgfile.Controls.Add(this.txtFunParm);
            this.grbProgfile.Controls.Add(this.lblFunParm);
            this.grbProgfile.Controls.Add(this.cmdKies);
            this.grbProgfile.Controls.Add(this.lblFunProg);
            this.grbProgfile.Controls.Add(this.txtFunProg);
            this.grbProgfile.Controls.Add(this.lblSplit_instructie);
            this.grbProgfile.Controls.Add(this.txtFunText);
            this.grbProgfile.Controls.Add(this.lblFunText);
            this.grbProgfile.Controls.Add(this.rbInt);
            this.grbProgfile.Controls.Add(this.rbExec);
            this.grbProgfile.Location = new System.Drawing.Point(16, 41);
            this.grbProgfile.Name = "grbProgfile";
            this.grbProgfile.Size = new System.Drawing.Size(475, 167);
            this.grbProgfile.TabIndex = 16;
            this.grbProgfile.TabStop = false;
            this.grbProgfile.Text = "Programma of formnaam";
            // 
            // txtFunParm
            // 
            this.txtFunParm.Location = new System.Drawing.Point(101, 82);
            this.txtFunParm.MaxLength = 255;
            this.txtFunParm.Name = "txtFunParm";
            this.txtFunParm.Size = new System.Drawing.Size(334, 20);
            this.txtFunParm.TabIndex = 23;
            this.txtFunParm.Tag = "Programma/formnaam";
            // 
            // lblFunParm
            // 
            this.lblFunParm.AutoSize = true;
            this.lblFunParm.Location = new System.Drawing.Point(16, 84);
            this.lblFunParm.Name = "lblFunParm";
            this.lblFunParm.Size = new System.Drawing.Size(69, 13);
            this.lblFunParm.TabIndex = 22;
            this.lblFunParm.Text = "Parameter(s):";
            // 
            // cmdKies
            // 
            this.cmdKies.Location = new System.Drawing.Point(436, 52);
            this.cmdKies.Name = "cmdKies";
            this.cmdKies.Size = new System.Drawing.Size(21, 23);
            this.cmdKies.TabIndex = 21;
            this.cmdKies.Text = "...";
            this.cmdKies.UseVisualStyleBackColor = true;
            this.cmdKies.Click += new System.EventHandler(this.cmdKies_Click);
            // 
            // lblFunProg
            // 
            this.lblFunProg.AutoSize = true;
            this.lblFunProg.Location = new System.Drawing.Point(16, 58);
            this.lblFunProg.Name = "lblFunProg";
            this.lblFunProg.Size = new System.Drawing.Size(38, 13);
            this.lblFunProg.TabIndex = 19;
            this.lblFunProg.Text = "Naam:";
            // 
            // txtFunProg
            // 
            this.txtFunProg.Location = new System.Drawing.Point(101, 54);
            this.txtFunProg.MaxLength = 255;
            this.txtFunProg.Name = "txtFunProg";
            this.txtFunProg.Size = new System.Drawing.Size(334, 20);
            this.txtFunProg.TabIndex = 20;
            this.txtFunProg.Tag = "Programma/formnaam";
            // 
            // lblSplit_instructie
            // 
            this.lblSplit_instructie.AutoSize = true;
            this.lblSplit_instructie.Location = new System.Drawing.Point(96, -15);
            this.lblSplit_instructie.Name = "lblSplit_instructie";
            this.lblSplit_instructie.Size = new System.Drawing.Size(331, 13);
            this.lblSplit_instructie.TabIndex = 17;
            this.lblSplit_instructie.Text = "Gebruik een / om het programma te scheiden van een evt parameter";
            // 
            // txtFunText
            // 
            this.txtFunText.Location = new System.Drawing.Point(101, 111);
            this.txtFunText.MaxLength = 50;
            this.txtFunText.Name = "txtFunText";
            this.txtFunText.Size = new System.Drawing.Size(334, 20);
            this.txtFunText.TabIndex = 25;
            this.txtFunText.Tag = "Programma of formnaam";
            this.txtFunText.TextChanged += new System.EventHandler(this.txtFunText_TextChanged);
            // 
            // lblFunText
            // 
            this.lblFunText.AutoSize = true;
            this.lblFunText.Location = new System.Drawing.Point(16, 115);
            this.lblFunText.Name = "lblFunText";
            this.lblFunText.Size = new System.Drawing.Size(70, 13);
            this.lblFunText.TabIndex = 24;
            this.lblFunText.Text = "Omschrijving:";
            // 
            // rbInt
            // 
            this.rbInt.AutoSize = true;
            this.rbInt.Location = new System.Drawing.Point(95, 25);
            this.rbInt.Name = "rbInt";
            this.rbInt.Size = new System.Drawing.Size(93, 17);
            this.rbInt.TabIndex = 18;
            this.rbInt.TabStop = true;
            this.rbInt.Text = "Interne functie";
            this.rbInt.UseVisualStyleBackColor = true;
            this.rbInt.CheckedChanged += new System.EventHandler(this.rbInt_CheckedChanged);
            // 
            // rbExec
            // 
            this.rbExec.AutoSize = true;
            this.rbExec.Location = new System.Drawing.Point(12, 25);
            this.rbExec.Name = "rbExec";
            this.rbExec.Size = new System.Drawing.Size(78, 17);
            this.rbExec.TabIndex = 17;
            this.rbExec.TabStop = true;
            this.rbExec.Text = "Executable";
            this.rbExec.UseVisualStyleBackColor = true;
            this.rbExec.CheckedChanged += new System.EventHandler(this.rbExec_CheckedChanged);
            // 
            // grbFunMaintD
            // 
            this.grbFunMaintD.Controls.Add(this.grbProgfile);
            this.grbFunMaintD.Location = new System.Drawing.Point(11, 15);
            this.grbFunMaintD.Name = "grbFunMaintD";
            this.grbFunMaintD.Size = new System.Drawing.Size(507, 231);
            this.grbFunMaintD.TabIndex = 15;
            this.grbFunMaintD.TabStop = false;
            this.grbFunMaintD.Text = "Detailgegevens";
            // 
            // grbBronMaintD
            // 
            this.grbBronMaintD.Controls.Add(this.txtBronCode);
            this.grbBronMaintD.Controls.Add(this.lblBronCode);
            this.grbBronMaintD.Controls.Add(this.txtBronOmsc);
            this.grbBronMaintD.Controls.Add(this.lblBronOmsc);
            this.grbBronMaintD.Location = new System.Drawing.Point(12, 15);
            this.grbBronMaintD.Name = "grbBronMaintD";
            this.grbBronMaintD.Size = new System.Drawing.Size(509, 231);
            this.grbBronMaintD.TabIndex = 1;
            this.grbBronMaintD.TabStop = false;
            this.grbBronMaintD.Text = "Detailgegevens";
            // 
            // txtBronCode
            // 
            this.txtBronCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtBronCode.Location = new System.Drawing.Point(136, 19);
            this.txtBronCode.MaxLength = 3;
            this.txtBronCode.Name = "txtBronCode";
            this.txtBronCode.Size = new System.Drawing.Size(59, 20);
            this.txtBronCode.TabIndex = 3;
            this.txtBronCode.Tag = "Broncode";
            this.txtBronCode.TextChanged += new System.EventHandler(this.txtBronCode_TextChanged);
            // 
            // lblBronCode
            // 
            this.lblBronCode.AutoSize = true;
            this.lblBronCode.Location = new System.Drawing.Point(34, 23);
            this.lblBronCode.Name = "lblBronCode";
            this.lblBronCode.Size = new System.Drawing.Size(56, 13);
            this.lblBronCode.TabIndex = 2;
            this.lblBronCode.Text = "Broncode:";
            // 
            // txtBronOmsc
            // 
            this.txtBronOmsc.Location = new System.Drawing.Point(136, 45);
            this.txtBronOmsc.MaxLength = 50;
            this.txtBronOmsc.Name = "txtBronOmsc";
            this.txtBronOmsc.Size = new System.Drawing.Size(280, 20);
            this.txtBronOmsc.TabIndex = 5;
            this.txtBronOmsc.Tag = "Omschrijving";
            this.txtBronOmsc.TextChanged += new System.EventHandler(this.txtBronOmsc_TextChanged);
            // 
            // lblBronOmsc
            // 
            this.lblBronOmsc.AutoSize = true;
            this.lblBronOmsc.Location = new System.Drawing.Point(34, 49);
            this.lblBronOmsc.Name = "lblBronOmsc";
            this.lblBronOmsc.Size = new System.Drawing.Size(70, 13);
            this.lblBronOmsc.TabIndex = 4;
            this.lblBronOmsc.Text = "Omschrijving:";
            // 
            // grbUitgMaintD
            // 
            this.grbUitgMaintD.Controls.Add(this.lblUitgPubl);
            this.grbUitgMaintD.Controls.Add(this.cmbUitgPubl);
            this.grbUitgMaintD.Controls.Add(this.lblUitgBron);
            this.grbUitgMaintD.Controls.Add(this.cmbUitgBron);
            this.grbUitgMaintD.Controls.Add(this.txtUitgCode);
            this.grbUitgMaintD.Controls.Add(this.lblUitgCode);
            this.grbUitgMaintD.Controls.Add(this.txtUitgOmsc);
            this.grbUitgMaintD.Controls.Add(this.lblUitgOmsc);
            this.grbUitgMaintD.Location = new System.Drawing.Point(11, 14);
            this.grbUitgMaintD.Name = "grbUitgMaintD";
            this.grbUitgMaintD.Size = new System.Drawing.Size(509, 231);
            this.grbUitgMaintD.TabIndex = 1;
            this.grbUitgMaintD.TabStop = false;
            this.grbUitgMaintD.Text = "Detailgegevens";
            // 
            // lblUitgPubl
            // 
            this.lblUitgPubl.AutoSize = true;
            this.lblUitgPubl.Location = new System.Drawing.Point(34, 77);
            this.lblUitgPubl.Name = "lblUitgPubl";
            this.lblUitgPubl.Size = new System.Drawing.Size(50, 13);
            this.lblUitgPubl.TabIndex = 6;
            this.lblUitgPubl.Text = "Uitgever:";
            // 
            // cmbUitgPubl
            // 
            this.cmbUitgPubl.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbUitgPubl.FormattingEnabled = true;
            this.cmbUitgPubl.Location = new System.Drawing.Point(136, 71);
            this.cmbUitgPubl.Name = "cmbUitgPubl";
            this.cmbUitgPubl.Size = new System.Drawing.Size(101, 21);
            this.cmbUitgPubl.TabIndex = 7;
            this.cmbUitgPubl.Tag = "Code uitgever";
            this.cmbUitgPubl.SelectedIndexChanged += new System.EventHandler(this.cmbUitgPubl_SelectedIndexChanged);
            // 
            // lblUitgBron
            // 
            this.lblUitgBron.AutoSize = true;
            this.lblUitgBron.Location = new System.Drawing.Point(248, 77);
            this.lblUitgBron.Name = "lblUitgBron";
            this.lblUitgBron.Size = new System.Drawing.Size(56, 13);
            this.lblUitgBron.TabIndex = 8;
            this.lblUitgBron.Text = "Broncode:";
            // 
            // cmbUitgBron
            // 
            this.cmbUitgBron.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbUitgBron.FormattingEnabled = true;
            this.cmbUitgBron.Location = new System.Drawing.Point(315, 71);
            this.cmbUitgBron.Name = "cmbUitgBron";
            this.cmbUitgBron.Size = new System.Drawing.Size(101, 21);
            this.cmbUitgBron.TabIndex = 9;
            this.cmbUitgBron.Tag = "Broncode";
            this.cmbUitgBron.SelectedIndexChanged += new System.EventHandler(this.cmbUitgBron_SelectedIndexChanged);
            // 
            // txtUitgCode
            // 
            this.txtUitgCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtUitgCode.Location = new System.Drawing.Point(136, 19);
            this.txtUitgCode.MaxLength = 4;
            this.txtUitgCode.Name = "txtUitgCode";
            this.txtUitgCode.Size = new System.Drawing.Size(59, 20);
            this.txtUitgCode.TabIndex = 3;
            this.txtUitgCode.Tag = "Uitgavecode";
            this.txtUitgCode.TextChanged += new System.EventHandler(this.txtUitgCode_TextChanged);
            // 
            // lblUitgCode
            // 
            this.lblUitgCode.AutoSize = true;
            this.lblUitgCode.Location = new System.Drawing.Point(34, 23);
            this.lblUitgCode.Name = "lblUitgCode";
            this.lblUitgCode.Size = new System.Drawing.Size(47, 13);
            this.lblUitgCode.TabIndex = 2;
            this.lblUitgCode.Text = "Uitgave:";
            // 
            // txtUitgOmsc
            // 
            this.txtUitgOmsc.Location = new System.Drawing.Point(136, 45);
            this.txtUitgOmsc.MaxLength = 50;
            this.txtUitgOmsc.Name = "txtUitgOmsc";
            this.txtUitgOmsc.Size = new System.Drawing.Size(280, 20);
            this.txtUitgOmsc.TabIndex = 5;
            this.txtUitgOmsc.Tag = "Omschrijving";
            this.txtUitgOmsc.TextChanged += new System.EventHandler(this.txtUitgOmsc_TextChanged);
            // 
            // lblUitgOmsc
            // 
            this.lblUitgOmsc.AutoSize = true;
            this.lblUitgOmsc.Location = new System.Drawing.Point(34, 49);
            this.lblUitgOmsc.Name = "lblUitgOmsc";
            this.lblUitgOmsc.Size = new System.Drawing.Size(70, 13);
            this.lblUitgOmsc.TabIndex = 4;
            this.lblUitgOmsc.Text = "Omschrijving:";
            // 
            // grbPublMaintD
            // 
            this.grbPublMaintD.Controls.Add(this.txtPublUenv);
            this.grbPublMaintD.Controls.Add(this.lblPublUenv);
            this.grbPublMaintD.Controls.Add(this.txtPublUdir);
            this.grbPublMaintD.Controls.Add(this.lblPublUdir);
            this.grbPublMaintD.Controls.Add(this.txtPublCode);
            this.grbPublMaintD.Controls.Add(this.lblPublCode);
            this.grbPublMaintD.Controls.Add(this.txtPublOmsc);
            this.grbPublMaintD.Controls.Add(this.lblPublOmsc);
            this.grbPublMaintD.Location = new System.Drawing.Point(11, 34);
            this.grbPublMaintD.Name = "grbPublMaintD";
            this.grbPublMaintD.Size = new System.Drawing.Size(509, 212);
            this.grbPublMaintD.TabIndex = 20;
            this.grbPublMaintD.TabStop = false;
            this.grbPublMaintD.Text = "Detailgegevens";
            // 
            // txtPublUenv
            // 
            this.txtPublUenv.Location = new System.Drawing.Point(136, 102);
            this.txtPublUenv.MaxLength = 50;
            this.txtPublUenv.Name = "txtPublUenv";
            this.txtPublUenv.Size = new System.Drawing.Size(160, 20);
            this.txtPublUenv.TabIndex = 9;
            this.txtPublUenv.Tag = "Unix environment";
            this.txtPublUenv.TextChanged += new System.EventHandler(this.txtPublUenv_TextChanged);
            // 
            // lblPublUenv
            // 
            this.lblPublUenv.AutoSize = true;
            this.lblPublUenv.Location = new System.Drawing.Point(24, 105);
            this.lblPublUenv.Name = "lblPublUenv";
            this.lblPublUenv.Size = new System.Drawing.Size(105, 13);
            this.lblPublUenv.TabIndex = 8;
            this.lblPublUenv.Text = "Unix environmentfile:";
            // 
            // txtPublUdir
            // 
            this.txtPublUdir.Location = new System.Drawing.Point(136, 73);
            this.txtPublUdir.MaxLength = 50;
            this.txtPublUdir.Name = "txtPublUdir";
            this.txtPublUdir.Size = new System.Drawing.Size(359, 20);
            this.txtPublUdir.TabIndex = 7;
            this.txtPublUdir.Tag = "Unix directory";
            this.txtPublUdir.TextChanged += new System.EventHandler(this.txtPublUdir_TextChanged);
            // 
            // lblPublUdir
            // 
            this.lblPublUdir.AutoSize = true;
            this.lblPublUdir.Location = new System.Drawing.Point(24, 77);
            this.lblPublUdir.Name = "lblPublUdir";
            this.lblPublUdir.Size = new System.Drawing.Size(74, 13);
            this.lblPublUdir.TabIndex = 6;
            this.lblPublUdir.Text = "Unix directory:";
            // 
            // txtPublCode
            // 
            this.txtPublCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtPublCode.Location = new System.Drawing.Point(136, 19);
            this.txtPublCode.MaxLength = 8;
            this.txtPublCode.Name = "txtPublCode";
            this.txtPublCode.Size = new System.Drawing.Size(100, 20);
            this.txtPublCode.TabIndex = 3;
            this.txtPublCode.Tag = "Uitgever";
            this.txtPublCode.TextChanged += new System.EventHandler(this.txtPublCode_TextChanged);
            // 
            // lblPublCode
            // 
            this.lblPublCode.AutoSize = true;
            this.lblPublCode.Location = new System.Drawing.Point(24, 23);
            this.lblPublCode.Name = "lblPublCode";
            this.lblPublCode.Size = new System.Drawing.Size(50, 13);
            this.lblPublCode.TabIndex = 2;
            this.lblPublCode.Text = "Uitgever:";
            // 
            // txtPublOmsc
            // 
            this.txtPublOmsc.Location = new System.Drawing.Point(136, 45);
            this.txtPublOmsc.MaxLength = 50;
            this.txtPublOmsc.Name = "txtPublOmsc";
            this.txtPublOmsc.Size = new System.Drawing.Size(294, 20);
            this.txtPublOmsc.TabIndex = 5;
            this.txtPublOmsc.Tag = "Omschrijving";
            this.txtPublOmsc.TextChanged += new System.EventHandler(this.txtPublOmsc_TextChanged);
            // 
            // lblPublOmsc
            // 
            this.lblPublOmsc.AutoSize = true;
            this.lblPublOmsc.Location = new System.Drawing.Point(24, 49);
            this.lblPublOmsc.Name = "lblPublOmsc";
            this.lblPublOmsc.Size = new System.Drawing.Size(70, 13);
            this.lblPublOmsc.TabIndex = 4;
            this.lblPublOmsc.Text = "Omschrijving:";
            // 
            // frmDashMaintD
            // 
            this.AcceptButton = this.cmdAfsluiten;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(530, 297);
            this.Controls.Add(this.grbElemMaintD);
            this.Controls.Add(this.grbPublMaintD);
            this.Controls.Add(this.grbUitgMaintD);
            this.Controls.Add(this.grbConnMaintD);
            this.Controls.Add(this.grbSubMaintD);
            this.Controls.Add(this.grbBronMaintD);
            this.Controls.Add(this.grbGrpMaintD);
            this.Controls.Add(this.cmdOK);
            this.Controls.Add(this.grbTablMaintD);
            this.Controls.Add(this.grbFunMaintD);
            this.Controls.Add(this.grbUsrMaintD);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmDashMaintD";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "DB Dashboard onderhoud";
            this.Load += new System.EventHandler(this.frmDashMaintD_Load);
            this.Shown += new System.EventHandler(this.frmDashMaintD_Shown);
            this.Controls.SetChildIndex(this.lblVoortgang, 0);
            this.Controls.SetChildIndex(this.grbUsrMaintD, 0);
            this.Controls.SetChildIndex(this.grbFunMaintD, 0);
            this.Controls.SetChildIndex(this.grbTablMaintD, 0);
            this.Controls.SetChildIndex(this.cmdOK, 0);
            this.Controls.SetChildIndex(this.grbGrpMaintD, 0);
            this.Controls.SetChildIndex(this.grbBronMaintD, 0);
            this.Controls.SetChildIndex(this.grbSubMaintD, 0);
            this.Controls.SetChildIndex(this.grbConnMaintD, 0);
            this.Controls.SetChildIndex(this.grbUitgMaintD, 0);
            this.Controls.SetChildIndex(this.grbPublMaintD, 0);
            this.Controls.SetChildIndex(this.grbElemMaintD, 0);
            this.Controls.SetChildIndex(this.cmdAfsluiten, 0);
            this.Controls.SetChildIndex(this.grbConnectie, 0);
            this.grbConnectie.ResumeLayout(false);
            this.grbConnectie.PerformLayout();
            this.grbUsrMaintD.ResumeLayout(false);
            this.grbUsrMaintD.PerformLayout();
            this.grbGrpMaintD.ResumeLayout(false);
            this.grbGrpMaintD.PerformLayout();
            this.grbElemMaintD.ResumeLayout(false);
            this.grbElemMaintD.PerformLayout();
            this.grbSubMaintD.ResumeLayout(false);
            this.grbSubMaintD.PerformLayout();
            this.grbTablMaintD.ResumeLayout(false);
            this.grbTablMaintD.PerformLayout();
            this.grbConnMaintD.ResumeLayout(false);
            this.grbConnMaintD.PerformLayout();
            this.grbProgfile.ResumeLayout(false);
            this.grbProgfile.PerformLayout();
            this.grbFunMaintD.ResumeLayout(false);
            this.grbBronMaintD.ResumeLayout(false);
            this.grbBronMaintD.PerformLayout();
            this.grbUitgMaintD.ResumeLayout(false);
            this.grbUitgMaintD.PerformLayout();
            this.grbPublMaintD.ResumeLayout(false);
            this.grbPublMaintD.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grbUsrMaintD;
        private System.Windows.Forms.Label lblUsrGroep;
        private System.Windows.Forms.Label lblUsrNaam;
        private System.Windows.Forms.Label lblUsrCode;
        private System.Windows.Forms.TextBox txtUsrNaam;
        private System.Windows.Forms.TextBox txtUsrCode;
        private System.Windows.Forms.Button cmdOK;
        private System.Windows.Forms.TextBox txtUsrPass;
        private System.Windows.Forms.Label lblUsrPass;
        private System.Windows.Forms.Label lblUsrPass_hint;
        private System.Windows.Forms.TextBox txtUsrId;
        private System.Windows.Forms.Label lblUsrId;
        private System.Windows.Forms.GroupBox grbGrpMaintD;
        private System.Windows.Forms.TextBox txtGrpNaam;
        private System.Windows.Forms.TextBox txtGrpCode;
        private System.Windows.Forms.Label lblGrpNaam;
        private System.Windows.Forms.Label lblGrpCode;
        private System.Windows.Forms.ComboBox cmbUsrGroep;
        private System.Windows.Forms.GroupBox grbSubMaintD;
        private System.Windows.Forms.TextBox txtSubNaam;
        private System.Windows.Forms.Label lblSubNaam;
        private System.Windows.Forms.GroupBox grbTablMaintD;
        private System.Windows.Forms.TextBox txtTablTabn;
        private System.Windows.Forms.TextBox txtTablOmsc;
        private System.Windows.Forms.Label lblTablOmsc;
        private System.Windows.Forms.Label lblTablTabn;
        private System.Windows.Forms.GroupBox grbElemMaintD;
        private System.Windows.Forms.Label lblElemOms1;
        private System.Windows.Forms.Label lblElemElem;
        private System.Windows.Forms.Label lblElemTabn;
        private System.Windows.Forms.TextBox txtElemOms2;
        private System.Windows.Forms.TextBox txtElemOms1;
        private System.Windows.Forms.TextBox txtElemElem;
        private System.Windows.Forms.ComboBox cmbElemTabn;
        private System.Windows.Forms.Label lblElemOms2;
        private System.Windows.Forms.Label lblTablO2om;
        private System.Windows.Forms.Label lblTablO1om;
        private System.Windows.Forms.Label lblTablElom;
        private System.Windows.Forms.TextBox txtTablO2om;
        private System.Windows.Forms.TextBox txtTablO1om;
        private System.Windows.Forms.TextBox txtTablElom;
        private System.Windows.Forms.GroupBox grbConnMaintD;
        private System.Windows.Forms.TextBox txtConnSnam;
        private System.Windows.Forms.Label lblConnSnam;
        private System.Windows.Forms.TextBox txtConnPass;
        private System.Windows.Forms.Label lblConnPass;
        private System.Windows.Forms.TextBox txtConnUser;
        private System.Windows.Forms.TextBox txtConnHost;
        private System.Windows.Forms.Label lblConnUser;
        private System.Windows.Forms.Label lblConnHost;
        private System.Windows.Forms.TextBox txtConnTelp;
        private System.Windows.Forms.TextBox txtConnFtpp;
        private System.Windows.Forms.Label lblConnTelp;
        private System.Windows.Forms.Label lblConnFtpp;
        private System.Windows.Forms.Label lblTelp23;
        private System.Windows.Forms.Label lblFtp21;
        private System.Windows.Forms.GroupBox grbProgfile;
        private System.Windows.Forms.Button cmdKies;
        private System.Windows.Forms.Label lblFunProg;
        private System.Windows.Forms.TextBox txtFunProg;
        private System.Windows.Forms.Label lblSplit_instructie;
        private System.Windows.Forms.TextBox txtFunText;
        private System.Windows.Forms.Label lblFunText;
        private System.Windows.Forms.RadioButton rbInt;
        private System.Windows.Forms.RadioButton rbExec;
        private System.Windows.Forms.GroupBox grbFunMaintD;
        private System.Windows.Forms.TextBox txtSubOmsc;
        private System.Windows.Forms.Label lblSubOmsc;
        private System.Windows.Forms.TextBox txtFunParm;
        private System.Windows.Forms.Label lblFunParm;
        private System.Windows.Forms.GroupBox grbBronMaintD;
        private System.Windows.Forms.TextBox txtBronCode;
        private System.Windows.Forms.Label lblBronCode;
        private System.Windows.Forms.TextBox txtBronOmsc;
        private System.Windows.Forms.Label lblBronOmsc;
        private System.Windows.Forms.GroupBox grbUitgMaintD;
        private System.Windows.Forms.Label lblUitgBron;
        private System.Windows.Forms.ComboBox cmbUitgBron;
        private System.Windows.Forms.TextBox txtUitgCode;
        private System.Windows.Forms.Label lblUitgCode;
        private System.Windows.Forms.TextBox txtUitgOmsc;
        private System.Windows.Forms.Label lblUitgOmsc;
        private System.Windows.Forms.Label lblUitgPubl;
        private System.Windows.Forms.ComboBox cmbUitgPubl;
        private System.Windows.Forms.GroupBox grbPublMaintD;
        private System.Windows.Forms.TextBox txtPublUenv;
        private System.Windows.Forms.Label lblPublUenv;
        private System.Windows.Forms.TextBox txtPublUdir;
        private System.Windows.Forms.Label lblPublUdir;
        private System.Windows.Forms.TextBox txtPublCode;
        private System.Windows.Forms.Label lblPublCode;
        private System.Windows.Forms.TextBox txtPublOmsc;
        private System.Windows.Forms.Label lblPublOmsc;
    }
}