﻿namespace dbDashboard
{
    partial class frmDashQueueView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.grbQueuView = new System.Windows.Forms.GroupBox();
            this.dgQueue = new System.Windows.Forms.DataGridView();
            this.colResponse = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colKind = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colServer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDomain = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colQueueSize = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colQueueAgeOldest = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colQueueAgeNewest = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCheckTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colQueueAgeDateOld = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colQueueAgeDateNew = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblQueueRecCount = new System.Windows.Forms.Label();
            this.cmdOpenLogFile = new System.Windows.Forms.Button();
            this.ofdOpenLogFile = new System.Windows.Forms.OpenFileDialog();
            this.cmbView = new System.Windows.Forms.ComboBox();
            this.lblView = new System.Windows.Forms.Label();
            this.cbZeroes = new System.Windows.Forms.CheckBox();
            this.grpData = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.grpFilter = new System.Windows.Forms.GroupBox();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.grbConnectie.SuspendLayout();
            this.grbQueuView.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgQueue)).BeginInit();
            this.grpData.SuspendLayout();
            this.grpFilter.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmdAfsluiten
            // 
            this.cmdAfsluiten.Location = new System.Drawing.Point(12, 680);
            // 
            // grbConnectie
            // 
            this.grbConnectie.Location = new System.Drawing.Point(319, 746);
            // 
            // lblVoortgang
            // 
            this.lblVoortgang.Location = new System.Drawing.Point(325, 730);
            // 
            // grbQueuView
            // 
            this.grbQueuView.Controls.Add(this.dgQueue);
            this.grbQueuView.Controls.Add(this.lblQueueRecCount);
            this.grbQueuView.Location = new System.Drawing.Point(12, 97);
            this.grbQueuView.Name = "grbQueuView";
            this.grbQueuView.Size = new System.Drawing.Size(883, 577);
            this.grbQueuView.TabIndex = 21;
            this.grbQueuView.TabStop = false;
            this.grbQueuView.Text = "Logline(s)";
            // 
            // dgQueue
            // 
            this.dgQueue.AllowUserToAddRows = false;
            this.dgQueue.AllowUserToDeleteRows = false;
            this.dgQueue.AllowUserToOrderColumns = true;
            this.dgQueue.AllowUserToResizeColumns = false;
            this.dgQueue.AllowUserToResizeRows = false;
            this.dgQueue.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgQueue.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colResponse,
            this.colKind,
            this.colServer,
            this.colDomain,
            this.colQueueSize,
            this.colQueueAgeOldest,
            this.colQueueAgeNewest,
            this.colCheckTime,
            this.colQueueAgeDateOld,
            this.colQueueAgeDateNew});
            this.dgQueue.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgQueue.Location = new System.Drawing.Point(7, 39);
            this.dgQueue.Name = "dgQueue";
            this.dgQueue.RowHeadersVisible = false;
            this.dgQueue.Size = new System.Drawing.Size(863, 471);
            this.dgQueue.TabIndex = 0;
            // 
            // colResponse
            // 
            this.colResponse.HeaderText = "Response";
            this.colResponse.Name = "colResponse";
            this.colResponse.Visible = false;
            // 
            // colKind
            // 
            this.colKind.HeaderText = "Kind";
            this.colKind.MinimumWidth = 100;
            this.colKind.Name = "colKind";
            // 
            // colServer
            // 
            this.colServer.HeaderText = "Server";
            this.colServer.Name = "colServer";
            this.colServer.Width = 50;
            // 
            // colDomain
            // 
            this.colDomain.HeaderText = "Domain";
            this.colDomain.Name = "colDomain";
            this.colDomain.Width = 150;
            // 
            // colQueueSize
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle1.Format = "N0";
            dataGridViewCellStyle1.NullValue = null;
            this.colQueueSize.DefaultCellStyle = dataGridViewCellStyle1;
            this.colQueueSize.HeaderText = "QueueSize";
            this.colQueueSize.Name = "colQueueSize";
            this.colQueueSize.Width = 75;
            // 
            // colQueueAgeOldest
            // 
            this.colQueueAgeOldest.HeaderText = "Age Oldest";
            this.colQueueAgeOldest.MinimumWidth = 180;
            this.colQueueAgeOldest.Name = "colQueueAgeOldest";
            this.colQueueAgeOldest.Width = 180;
            // 
            // colQueueAgeNewest
            // 
            this.colQueueAgeNewest.HeaderText = "Age Newest";
            this.colQueueAgeNewest.MinimumWidth = 180;
            this.colQueueAgeNewest.Name = "colQueueAgeNewest";
            this.colQueueAgeNewest.Width = 180;
            // 
            // colCheckTime
            // 
            this.colCheckTime.HeaderText = "CheckTime";
            this.colCheckTime.Name = "colCheckTime";
            this.colCheckTime.Width = 125;
            // 
            // colQueueAgeDateOld
            // 
            this.colQueueAgeDateOld.HeaderText = "QueueAgeOldDT";
            this.colQueueAgeDateOld.Name = "colQueueAgeDateOld";
            this.colQueueAgeDateOld.Visible = false;
            // 
            // colQueueAgeDateNew
            // 
            this.colQueueAgeDateNew.HeaderText = "QueueAgeNewDT";
            this.colQueueAgeDateNew.Name = "colQueueAgeDateNew";
            this.colQueueAgeDateNew.Visible = false;
            // 
            // lblQueueRecCount
            // 
            this.lblQueueRecCount.AutoSize = true;
            this.lblQueueRecCount.Location = new System.Drawing.Point(772, 538);
            this.lblQueueRecCount.Name = "lblQueueRecCount";
            this.lblQueueRecCount.Size = new System.Drawing.Size(97, 13);
            this.lblQueueRecCount.TabIndex = 25;
            this.lblQueueRecCount.Text = "lblQueueRecCount";
            // 
            // cmdOpenLogFile
            // 
            this.cmdOpenLogFile.Location = new System.Drawing.Point(7, 37);
            this.cmdOpenLogFile.Name = "cmdOpenLogFile";
            this.cmdOpenLogFile.Size = new System.Drawing.Size(75, 23);
            this.cmdOpenLogFile.TabIndex = 22;
            this.cmdOpenLogFile.Text = "Open...";
            this.cmdOpenLogFile.UseVisualStyleBackColor = true;
            this.cmdOpenLogFile.Click += new System.EventHandler(this.cmdOpenLogFile_Click);
            // 
            // ofdOpenLogFile
            // 
            this.ofdOpenLogFile.FileName = "dp*";
            this.ofdOpenLogFile.Filter = "\"Logfile|*.csv|All files|*.*\"";
            this.ofdOpenLogFile.Multiselect = true;
            // 
            // cmbView
            // 
            this.cmbView.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbView.FormattingEnabled = true;
            this.cmbView.Location = new System.Drawing.Point(44, 18);
            this.cmbView.Name = "cmbView";
            this.cmbView.Size = new System.Drawing.Size(212, 21);
            this.cmbView.TabIndex = 26;
            this.cmbView.SelectedIndexChanged += new System.EventHandler(this.cmbView_SelectedIndexChanged);
            // 
            // lblView
            // 
            this.lblView.AutoSize = true;
            this.lblView.Location = new System.Drawing.Point(7, 22);
            this.lblView.Name = "lblView";
            this.lblView.Size = new System.Drawing.Size(33, 13);
            this.lblView.TabIndex = 27;
            this.lblView.Text = "View:";
            // 
            // cbZeroes
            // 
            this.cbZeroes.AutoSize = true;
            this.cbZeroes.Location = new System.Drawing.Point(321, 20);
            this.cbZeroes.Name = "cbZeroes";
            this.cbZeroes.Size = new System.Drawing.Size(127, 17);
            this.cbZeroes.TabIndex = 28;
            this.cbZeroes.Text = "Suppress zero values";
            this.cbZeroes.UseVisualStyleBackColor = true;
            this.cbZeroes.CheckedChanged += new System.EventHandler(this.cbZeroes_CheckedChanged);
            // 
            // grpData
            // 
            this.grpData.Controls.Add(this.button1);
            this.grpData.Controls.Add(this.grpFilter);
            this.grpData.Controls.Add(this.cmdOpenLogFile);
            this.grpData.Location = new System.Drawing.Point(12, 11);
            this.grpData.Name = "grpData";
            this.grpData.Size = new System.Drawing.Size(883, 80);
            this.grpData.TabIndex = 29;
            this.grpData.TabStop = false;
            this.grpData.Text = "Data";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(214, 28);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(119, 32);
            this.button1.TabIndex = 30;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // grpFilter
            // 
            this.grpFilter.Controls.Add(this.cmbView);
            this.grpFilter.Controls.Add(this.cbZeroes);
            this.grpFilter.Controls.Add(this.lblView);
            this.grpFilter.Location = new System.Drawing.Point(365, 23);
            this.grpFilter.Name = "grpFilter";
            this.grpFilter.Size = new System.Drawing.Size(506, 50);
            this.grpFilter.TabIndex = 29;
            this.grpFilter.TabStop = false;
            this.grpFilter.Text = "Filter";
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(549, 698);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(100, 23);
            this.progressBar1.TabIndex = 30;
            // 
            // frmDashQueueView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(907, 709);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.grpData);
            this.Controls.Add(this.grbQueuView);
            this.Name = "frmDashQueueView";
            this.Text = "frmDashQueueView";
            this.Load += new System.EventHandler(this.frmDashQueueView_Load);
            this.Controls.SetChildIndex(this.grbConnectie, 0);
            this.Controls.SetChildIndex(this.lblVoortgang, 0);
            this.Controls.SetChildIndex(this.cmdAfsluiten, 0);
            this.Controls.SetChildIndex(this.grbQueuView, 0);
            this.Controls.SetChildIndex(this.grpData, 0);
            this.Controls.SetChildIndex(this.progressBar1, 0);
            this.grbConnectie.ResumeLayout(false);
            this.grbConnectie.PerformLayout();
            this.grbQueuView.ResumeLayout(false);
            this.grbQueuView.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgQueue)).EndInit();
            this.grpData.ResumeLayout(false);
            this.grpFilter.ResumeLayout(false);
            this.grpFilter.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grbQueuView;
        private System.Windows.Forms.DataGridView dgQueue;
        private System.Windows.Forms.Button cmdOpenLogFile;
        private System.Windows.Forms.OpenFileDialog ofdOpenLogFile;
        private System.Windows.Forms.DataGridViewTextBoxColumn colResponse;
        private System.Windows.Forms.DataGridViewTextBoxColumn colKind;
        private System.Windows.Forms.DataGridViewTextBoxColumn colServer;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDomain;
        private System.Windows.Forms.DataGridViewTextBoxColumn colQueueSize;
        private System.Windows.Forms.DataGridViewTextBoxColumn colQueueAgeOldest;
        private System.Windows.Forms.DataGridViewTextBoxColumn colQueueAgeNewest;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCheckTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn colQueueAgeDateOld;
        private System.Windows.Forms.DataGridViewTextBoxColumn colQueueAgeDateNew;
        private System.Windows.Forms.Label lblQueueRecCount;
        private System.Windows.Forms.ComboBox cmbView;
        private System.Windows.Forms.Label lblView;
        private System.Windows.Forms.CheckBox cbZeroes;
        private System.Windows.Forms.GroupBox grpData;
        private System.Windows.Forms.GroupBox grpFilter;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ProgressBar progressBar1;
    }
}