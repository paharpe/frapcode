﻿namespace Stocks
{
    partial class frmFonds
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmFonds));
            this.grbFonds = new System.Windows.Forms.GroupBox();
            this.grbStats = new System.Windows.Forms.GroupBox();
            this.lblFonds_Totaal_lbl = new System.Windows.Forms.Label();
            this.lblFonds_AMX_lbl = new System.Windows.Forms.Label();
            this.lblFonds_Lokaal_lbl = new System.Windows.Forms.Label();
            this.lblFonds_Lokaal_val = new System.Windows.Forms.Label();
            this.lblFonds_AScX_lbl = new System.Windows.Forms.Label();
            this.lblFonds_Amsterdam_val = new System.Windows.Forms.Label();
            this.lblFonds_Amsterdam_lbl = new System.Windows.Forms.Label();
            this.lblFonds_AScX_val = new System.Windows.Forms.Label();
            this.lblFonds_count_val = new System.Windows.Forms.Label();
            this.lblFonds_AMX_val = new System.Windows.Forms.Label();
            this.lblSelect = new System.Windows.Forms.Label();
            this.cmdHighLowAnalyze = new System.Windows.Forms.Button();
            this.lblDoubleClick = new System.Windows.Forms.Label();
            this.grbAnalyse = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.lblLow_val = new System.Windows.Forms.Label();
            this.lblLow_lbl = new System.Windows.Forms.Label();
            this.lblHigh_val = new System.Windows.Forms.Label();
            this.lblMacPerc = new System.Windows.Forms.Label();
            this.lblHigh_lbl = new System.Windows.Forms.Label();
            this.cbHighLowShow = new System.Windows.Forms.CheckBox();
            this.pgMax = new System.Windows.Forms.ProgressBar();
            this.cmbSelect = new System.Windows.Forms.ComboBox();
            this.dgFonds = new System.Windows.Forms.DataGridView();
            this.cmdStockNames = new System.Windows.Forms.Button();
            this.cmdCancel = new System.Windows.Forms.Button();
            this.grbKoers = new System.Windows.Forms.GroupBox();
            this.lblKoers = new System.Windows.Forms.Label();
            this.lblKoers_count = new System.Windows.Forms.Label();
            this.dgKoers = new System.Windows.Forms.DataGridView();
            this.grbDetail = new System.Windows.Forms.GroupBox();
            this.cmdChoose = new System.Windows.Forms.Button();
            this.lblChoose = new System.Windows.Forms.Label();
            this.txtChoose = new System.Windows.Forms.TextBox();
            this.cmbChoose = new System.Windows.Forms.ComboBox();
            this.grbShort = new System.Windows.Forms.GroupBox();
            this.txtShortMax = new System.Windows.Forms.TextBox();
            this.lblShortRecent_lbl = new System.Windows.Forms.Label();
            this.lblShortMax_lbl = new System.Windows.Forms.Label();
            this.txtShortRecent = new System.Windows.Forms.TextBox();
            this.lblAgo = new System.Windows.Forms.Label();
            this.txtDiff_high = new System.Windows.Forms.TextBox();
            this.txtDiff_low = new System.Windows.Forms.TextBox();
            this.lblHowMuch = new System.Windows.Forms.Label();
            this.lblWhen = new System.Windows.Forms.Label();
            this.txtDate_now = new System.Windows.Forms.TextBox();
            this.txtKoers_now = new System.Windows.Forms.TextBox();
            this.lblNow = new System.Windows.Forms.Label();
            this.txtDate_high = new System.Windows.Forms.TextBox();
            this.txtDate_low = new System.Windows.Forms.TextBox();
            this.txtKoers_high = new System.Windows.Forms.TextBox();
            this.txtKoers_low = new System.Windows.Forms.TextBox();
            this.lblHigh = new System.Windows.Forms.Label();
            this.lblLow = new System.Windows.Forms.Label();
            this.grbToday = new System.Windows.Forms.GroupBox();
            this.lblToday = new System.Windows.Forms.Label();
            this.grbMin = new System.Windows.Forms.GroupBox();
            this.lbMin = new System.Windows.Forms.ListBox();
            this.grbMax = new System.Windows.Forms.GroupBox();
            this.lbMax = new System.Windows.Forms.ListBox();
            this.txtProperty = new System.Windows.Forms.TextBox();
            this.cmdPropdate = new System.Windows.Forms.Button();
            this.grbProperties = new System.Windows.Forms.GroupBox();
            this.lblProperty = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.grbFonds.SuspendLayout();
            this.grbStats.SuspendLayout();
            this.grbAnalyse.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgFonds)).BeginInit();
            this.grbKoers.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgKoers)).BeginInit();
            this.grbDetail.SuspendLayout();
            this.grbShort.SuspendLayout();
            this.grbToday.SuspendLayout();
            this.grbMin.SuspendLayout();
            this.grbMax.SuspendLayout();
            this.grbProperties.SuspendLayout();
            this.SuspendLayout();
            // 
            // grbFonds
            // 
            this.grbFonds.Controls.Add(this.grbStats);
            this.grbFonds.Controls.Add(this.lblSelect);
            this.grbFonds.Controls.Add(this.cmdHighLowAnalyze);
            this.grbFonds.Controls.Add(this.lblDoubleClick);
            this.grbFonds.Controls.Add(this.grbAnalyse);
            this.grbFonds.Controls.Add(this.cmbSelect);
            this.grbFonds.Controls.Add(this.dgFonds);
            this.grbFonds.Location = new System.Drawing.Point(10, 104);
            this.grbFonds.Name = "grbFonds";
            this.grbFonds.Size = new System.Drawing.Size(627, 483);
            this.grbFonds.TabIndex = 0;
            this.grbFonds.TabStop = false;
            this.grbFonds.Text = "Stock";
            // 
            // grbStats
            // 
            this.grbStats.Controls.Add(this.lblFonds_Totaal_lbl);
            this.grbStats.Controls.Add(this.lblFonds_AMX_lbl);
            this.grbStats.Controls.Add(this.lblFonds_Lokaal_lbl);
            this.grbStats.Controls.Add(this.lblFonds_Lokaal_val);
            this.grbStats.Controls.Add(this.lblFonds_AScX_lbl);
            this.grbStats.Controls.Add(this.lblFonds_Amsterdam_val);
            this.grbStats.Controls.Add(this.lblFonds_Amsterdam_lbl);
            this.grbStats.Controls.Add(this.lblFonds_AScX_val);
            this.grbStats.Controls.Add(this.lblFonds_count_val);
            this.grbStats.Controls.Add(this.lblFonds_AMX_val);
            this.grbStats.Location = new System.Drawing.Point(428, 66);
            this.grbStats.Name = "grbStats";
            this.grbStats.Size = new System.Drawing.Size(175, 95);
            this.grbStats.TabIndex = 18;
            this.grbStats.TabStop = false;
            this.grbStats.Text = "Stats";
            // 
            // lblFonds_Totaal_lbl
            // 
            this.lblFonds_Totaal_lbl.AutoSize = true;
            this.lblFonds_Totaal_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFonds_Totaal_lbl.Location = new System.Drawing.Point(4, 74);
            this.lblFonds_Totaal_lbl.Name = "lblFonds_Totaal_lbl";
            this.lblFonds_Totaal_lbl.Size = new System.Drawing.Size(40, 13);
            this.lblFonds_Totaal_lbl.TabIndex = 18;
            this.lblFonds_Totaal_lbl.Text = "Total:";
            // 
            // lblFonds_AMX_lbl
            // 
            this.lblFonds_AMX_lbl.AutoSize = true;
            this.lblFonds_AMX_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFonds_AMX_lbl.Location = new System.Drawing.Point(4, 30);
            this.lblFonds_AMX_lbl.Name = "lblFonds_AMX_lbl";
            this.lblFonds_AMX_lbl.Size = new System.Drawing.Size(33, 13);
            this.lblFonds_AMX_lbl.TabIndex = 11;
            this.lblFonds_AMX_lbl.Text = "AMX:";
            // 
            // lblFonds_Lokaal_lbl
            // 
            this.lblFonds_Lokaal_lbl.AutoSize = true;
            this.lblFonds_Lokaal_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFonds_Lokaal_lbl.Location = new System.Drawing.Point(4, 58);
            this.lblFonds_Lokaal_lbl.Name = "lblFonds_Lokaal_lbl";
            this.lblFonds_Lokaal_lbl.Size = new System.Drawing.Size(42, 13);
            this.lblFonds_Lokaal_lbl.TabIndex = 13;
            this.lblFonds_Lokaal_lbl.Text = "Lokaal:";
            // 
            // lblFonds_Lokaal_val
            // 
            this.lblFonds_Lokaal_val.AutoSize = true;
            this.lblFonds_Lokaal_val.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFonds_Lokaal_val.Location = new System.Drawing.Point(73, 58);
            this.lblFonds_Lokaal_val.Name = "lblFonds_Lokaal_val";
            this.lblFonds_Lokaal_val.Size = new System.Drawing.Size(19, 13);
            this.lblFonds_Lokaal_val.TabIndex = 17;
            this.lblFonds_Lokaal_val.Text = "90";
            this.lblFonds_Lokaal_val.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblFonds_AScX_lbl
            // 
            this.lblFonds_AScX_lbl.AutoSize = true;
            this.lblFonds_AScX_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFonds_AScX_lbl.Location = new System.Drawing.Point(4, 44);
            this.lblFonds_AScX_lbl.Name = "lblFonds_AScX_lbl";
            this.lblFonds_AScX_lbl.Size = new System.Drawing.Size(37, 13);
            this.lblFonds_AScX_lbl.TabIndex = 12;
            this.lblFonds_AScX_lbl.Text = "AScX:";
            // 
            // lblFonds_Amsterdam_val
            // 
            this.lblFonds_Amsterdam_val.AutoSize = true;
            this.lblFonds_Amsterdam_val.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFonds_Amsterdam_val.Location = new System.Drawing.Point(73, 16);
            this.lblFonds_Amsterdam_val.Name = "lblFonds_Amsterdam_val";
            this.lblFonds_Amsterdam_val.Size = new System.Drawing.Size(25, 13);
            this.lblFonds_Amsterdam_val.TabIndex = 14;
            this.lblFonds_Amsterdam_val.Text = "123";
            this.lblFonds_Amsterdam_val.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblFonds_Amsterdam_lbl
            // 
            this.lblFonds_Amsterdam_lbl.AutoSize = true;
            this.lblFonds_Amsterdam_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFonds_Amsterdam_lbl.Location = new System.Drawing.Point(4, 16);
            this.lblFonds_Amsterdam_lbl.Name = "lblFonds_Amsterdam_lbl";
            this.lblFonds_Amsterdam_lbl.Size = new System.Drawing.Size(62, 13);
            this.lblFonds_Amsterdam_lbl.TabIndex = 10;
            this.lblFonds_Amsterdam_lbl.Text = "Amsterdam:";
            // 
            // lblFonds_AScX_val
            // 
            this.lblFonds_AScX_val.AutoSize = true;
            this.lblFonds_AScX_val.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFonds_AScX_val.Location = new System.Drawing.Point(73, 44);
            this.lblFonds_AScX_val.Name = "lblFonds_AScX_val";
            this.lblFonds_AScX_val.Size = new System.Drawing.Size(19, 13);
            this.lblFonds_AScX_val.TabIndex = 16;
            this.lblFonds_AScX_val.Text = "78";
            this.lblFonds_AScX_val.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblFonds_count_val
            // 
            this.lblFonds_count_val.AutoSize = true;
            this.lblFonds_count_val.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFonds_count_val.Location = new System.Drawing.Point(64, 74);
            this.lblFonds_count_val.Name = "lblFonds_count_val";
            this.lblFonds_count_val.Size = new System.Drawing.Size(31, 13);
            this.lblFonds_count_val.TabIndex = 1;
            this.lblFonds_count_val.Text = "1234";
            this.lblFonds_count_val.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblFonds_AMX_val
            // 
            this.lblFonds_AMX_val.AutoSize = true;
            this.lblFonds_AMX_val.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFonds_AMX_val.Location = new System.Drawing.Point(73, 30);
            this.lblFonds_AMX_val.Name = "lblFonds_AMX_val";
            this.lblFonds_AMX_val.Size = new System.Drawing.Size(25, 13);
            this.lblFonds_AMX_val.TabIndex = 15;
            this.lblFonds_AMX_val.Text = "123";
            this.lblFonds_AMX_val.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblSelect
            // 
            this.lblSelect.AutoSize = true;
            this.lblSelect.Location = new System.Drawing.Point(15, 31);
            this.lblSelect.Name = "lblSelect";
            this.lblSelect.Size = new System.Drawing.Size(54, 13);
            this.lblSelect.TabIndex = 9;
            this.lblSelect.Text = "Selection:";
            // 
            // cmdHighLowAnalyze
            // 
            this.cmdHighLowAnalyze.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdHighLowAnalyze.Location = new System.Drawing.Point(313, 453);
            this.cmdHighLowAnalyze.Name = "cmdHighLowAnalyze";
            this.cmdHighLowAnalyze.Size = new System.Drawing.Size(102, 23);
            this.cmdHighLowAnalyze.TabIndex = 3;
            this.cmdHighLowAnalyze.Text = "Analyse";
            this.cmdHighLowAnalyze.UseVisualStyleBackColor = true;
            this.cmdHighLowAnalyze.Click += new System.EventHandler(this.cmdHighLowAnalyze_Click);
            // 
            // lblDoubleClick
            // 
            this.lblDoubleClick.AutoSize = true;
            this.lblDoubleClick.Location = new System.Drawing.Point(17, 59);
            this.lblDoubleClick.Name = "lblDoubleClick";
            this.lblDoubleClick.Size = new System.Drawing.Size(98, 13);
            this.lblDoubleClick.TabIndex = 0;
            this.lblDoubleClick.Text = "Double click row to";
            // 
            // grbAnalyse
            // 
            this.grbAnalyse.Controls.Add(this.button1);
            this.grbAnalyse.Controls.Add(this.lblLow_val);
            this.grbAnalyse.Controls.Add(this.lblLow_lbl);
            this.grbAnalyse.Controls.Add(this.lblHigh_val);
            this.grbAnalyse.Controls.Add(this.lblMacPerc);
            this.grbAnalyse.Controls.Add(this.lblHigh_lbl);
            this.grbAnalyse.Controls.Add(this.cbHighLowShow);
            this.grbAnalyse.Controls.Add(this.pgMax);
            this.grbAnalyse.Location = new System.Drawing.Point(428, 318);
            this.grbAnalyse.Name = "grbAnalyse";
            this.grbAnalyse.Size = new System.Drawing.Size(173, 125);
            this.grbAnalyse.TabIndex = 2;
            this.grbAnalyse.TabStop = false;
            this.grbAnalyse.Text = "Analysis results";
            this.grbAnalyse.Visible = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(43, 230);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(155, 32);
            this.button1.TabIndex = 23;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // lblLow_val
            // 
            this.lblLow_val.AutoSize = true;
            this.lblLow_val.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLow_val.Location = new System.Drawing.Point(50, 72);
            this.lblLow_val.Name = "lblLow_val";
            this.lblLow_val.Size = new System.Drawing.Size(57, 13);
            this.lblLow_val.TabIndex = 22;
            this.lblLow_val.Text = "lblLow_val";
            // 
            // lblLow_lbl
            // 
            this.lblLow_lbl.AutoSize = true;
            this.lblLow_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLow_lbl.Location = new System.Drawing.Point(10, 72);
            this.lblLow_lbl.Name = "lblLow_lbl";
            this.lblLow_lbl.Size = new System.Drawing.Size(40, 13);
            this.lblLow_lbl.TabIndex = 21;
            this.lblLow_lbl.Text = "# Low:";
            // 
            // lblHigh_val
            // 
            this.lblHigh_val.AutoSize = true;
            this.lblHigh_val.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHigh_val.Location = new System.Drawing.Point(50, 53);
            this.lblHigh_val.Name = "lblHigh_val";
            this.lblHigh_val.Size = new System.Drawing.Size(59, 13);
            this.lblHigh_val.TabIndex = 20;
            this.lblHigh_val.Text = "lblHigh_val";
            // 
            // lblMacPerc
            // 
            this.lblMacPerc.AutoSize = true;
            this.lblMacPerc.BackColor = System.Drawing.SystemColors.Control;
            this.lblMacPerc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMacPerc.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblMacPerc.Location = new System.Drawing.Point(6, 29);
            this.lblMacPerc.Name = "lblMacPerc";
            this.lblMacPerc.Size = new System.Drawing.Size(24, 13);
            this.lblMacPerc.TabIndex = 2;
            this.lblMacPerc.Text = "0 %";
            this.lblMacPerc.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblHigh_lbl
            // 
            this.lblHigh_lbl.AutoSize = true;
            this.lblHigh_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHigh_lbl.Location = new System.Drawing.Point(10, 53);
            this.lblHigh_lbl.Name = "lblHigh_lbl";
            this.lblHigh_lbl.Size = new System.Drawing.Size(42, 13);
            this.lblHigh_lbl.TabIndex = 19;
            this.lblHigh_lbl.Text = "# High:";
            // 
            // cbHighLowShow
            // 
            this.cbHighLowShow.AutoSize = true;
            this.cbHighLowShow.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbHighLowShow.Location = new System.Drawing.Point(13, 97);
            this.cbHighLowShow.Name = "cbHighLowShow";
            this.cbHighLowShow.Size = new System.Drawing.Size(136, 17);
            this.cbHighLowShow.TabIndex = 4;
            this.cbHighLowShow.Text = "Show highs && lows only";
            this.cbHighLowShow.UseVisualStyleBackColor = true;
            this.cbHighLowShow.CheckedChanged += new System.EventHandler(this.cbHighLowShow_CheckedChanged);
            // 
            // pgMax
            // 
            this.pgMax.Location = new System.Drawing.Point(9, 22);
            this.pgMax.Name = "pgMax";
            this.pgMax.Size = new System.Drawing.Size(150, 3);
            this.pgMax.Step = 2;
            this.pgMax.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.pgMax.TabIndex = 1;
            // 
            // cmbSelect
            // 
            this.cmbSelect.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSelect.FormattingEnabled = true;
            this.cmbSelect.Items.AddRange(new object[] {
            "All stocks",
            "My stocks"});
            this.cmbSelect.Location = new System.Drawing.Point(75, 27);
            this.cmbSelect.Name = "cmbSelect";
            this.cmbSelect.Size = new System.Drawing.Size(144, 21);
            this.cmbSelect.TabIndex = 8;
            this.cmbSelect.SelectedIndexChanged += new System.EventHandler(this.cmbSelect_SelectedIndexChanged);
            // 
            // dgFonds
            // 
            this.dgFonds.AllowUserToAddRows = false;
            this.dgFonds.AllowUserToDeleteRows = false;
            this.dgFonds.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgFonds.Location = new System.Drawing.Point(20, 75);
            this.dgFonds.MultiSelect = false;
            this.dgFonds.Name = "dgFonds";
            this.dgFonds.ReadOnly = true;
            this.dgFonds.RowHeadersVisible = false;
            this.dgFonds.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgFonds.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgFonds.Size = new System.Drawing.Size(395, 368);
            this.dgFonds.TabIndex = 1;
            this.dgFonds.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgFonds_CellClick);
            this.dgFonds.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgFonds_CellContentClick);
            this.dgFonds.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgFonds_RowEnter);
            this.dgFonds.DoubleClick += new System.EventHandler(this.dgFonds_DoubleClick);
            // 
            // cmdStockNames
            // 
            this.cmdStockNames.Location = new System.Drawing.Point(6, 49);
            this.cmdStockNames.Name = "cmdStockNames";
            this.cmdStockNames.Size = new System.Drawing.Size(187, 25);
            this.cmdStockNames.TabIndex = 7;
            this.cmdStockNames.Text = "Manage Stock and Shortnames...";
            this.cmdStockNames.UseVisualStyleBackColor = true;
            this.cmdStockNames.Click += new System.EventHandler(this.cmdStockNames_Click);
            // 
            // cmdCancel
            // 
            this.cmdCancel.Location = new System.Drawing.Point(10, 787);
            this.cmdCancel.Name = "cmdCancel";
            this.cmdCancel.Size = new System.Drawing.Size(81, 25);
            this.cmdCancel.TabIndex = 3;
            this.cmdCancel.Text = "Cancel";
            this.cmdCancel.UseVisualStyleBackColor = true;
            this.cmdCancel.Click += new System.EventHandler(this.cmdCancel_Click);
            // 
            // grbKoers
            // 
            this.grbKoers.Controls.Add(this.lblKoers);
            this.grbKoers.Controls.Add(this.lblKoers_count);
            this.grbKoers.Controls.Add(this.dgKoers);
            this.grbKoers.Location = new System.Drawing.Point(643, 24);
            this.grbKoers.Name = "grbKoers";
            this.grbKoers.Size = new System.Drawing.Size(77, 51);
            this.grbKoers.TabIndex = 2;
            this.grbKoers.TabStop = false;
            this.grbKoers.Text = "Share details";
            // 
            // lblKoers
            // 
            this.lblKoers.AutoSize = true;
            this.lblKoers.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKoers.Location = new System.Drawing.Point(73, 0);
            this.lblKoers.Name = "lblKoers";
            this.lblKoers.Size = new System.Drawing.Size(44, 13);
            this.lblKoers.TabIndex = 9;
            this.lblKoers.Text = "lblKoers";
            // 
            // lblKoers_count
            // 
            this.lblKoers_count.AutoSize = true;
            this.lblKoers_count.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKoers_count.Location = new System.Drawing.Point(217, 267);
            this.lblKoers_count.Name = "lblKoers_count";
            this.lblKoers_count.Size = new System.Drawing.Size(91, 13);
            this.lblKoers_count.TabIndex = 2;
            this.lblKoers_count.Text = "lblKoers_count";
            // 
            // dgKoers
            // 
            this.dgKoers.AllowUserToAddRows = false;
            this.dgKoers.AllowUserToDeleteRows = false;
            this.dgKoers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgKoers.Location = new System.Drawing.Point(20, 30);
            this.dgKoers.Name = "dgKoers";
            this.dgKoers.ReadOnly = true;
            this.dgKoers.RowHeadersVisible = false;
            this.dgKoers.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgKoers.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgKoers.Size = new System.Drawing.Size(288, 234);
            this.dgKoers.TabIndex = 0;
            // 
            // grbDetail
            // 
            this.grbDetail.Controls.Add(this.cmdChoose);
            this.grbDetail.Controls.Add(this.lblChoose);
            this.grbDetail.Controls.Add(this.txtChoose);
            this.grbDetail.Controls.Add(this.cmbChoose);
            this.grbDetail.Controls.Add(this.grbShort);
            this.grbDetail.Controls.Add(this.lblAgo);
            this.grbDetail.Controls.Add(this.txtDiff_high);
            this.grbDetail.Controls.Add(this.txtDiff_low);
            this.grbDetail.Controls.Add(this.lblHowMuch);
            this.grbDetail.Controls.Add(this.lblWhen);
            this.grbDetail.Controls.Add(this.txtDate_now);
            this.grbDetail.Controls.Add(this.txtKoers_now);
            this.grbDetail.Controls.Add(this.lblNow);
            this.grbDetail.Controls.Add(this.txtDate_high);
            this.grbDetail.Controls.Add(this.txtDate_low);
            this.grbDetail.Controls.Add(this.txtKoers_high);
            this.grbDetail.Controls.Add(this.txtKoers_low);
            this.grbDetail.Controls.Add(this.lblHigh);
            this.grbDetail.Controls.Add(this.lblLow);
            this.grbDetail.Location = new System.Drawing.Point(10, 614);
            this.grbDetail.Name = "grbDetail";
            this.grbDetail.Size = new System.Drawing.Size(627, 167);
            this.grbDetail.TabIndex = 2;
            this.grbDetail.TabStop = false;
            this.grbDetail.Text = "Detail info";
            // 
            // cmdChoose
            // 
            this.cmdChoose.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdChoose.Location = new System.Drawing.Point(567, 132);
            this.cmdChoose.Name = "cmdChoose";
            this.cmdChoose.Size = new System.Drawing.Size(34, 23);
            this.cmdChoose.TabIndex = 21;
            this.cmdChoose.Text = "...";
            this.cmdChoose.UseVisualStyleBackColor = true;
            // 
            // lblChoose
            // 
            this.lblChoose.AutoSize = true;
            this.lblChoose.Location = new System.Drawing.Point(6, 137);
            this.lblChoose.Name = "lblChoose";
            this.lblChoose.Size = new System.Drawing.Size(46, 13);
            this.lblChoose.TabIndex = 20;
            this.lblChoose.Text = "Choose:";
            // 
            // txtChoose
            // 
            this.txtChoose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtChoose.Enabled = false;
            this.txtChoose.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtChoose.Location = new System.Drawing.Point(151, 133);
            this.txtChoose.Name = "txtChoose";
            this.txtChoose.ReadOnly = true;
            this.txtChoose.Size = new System.Drawing.Size(410, 20);
            this.txtChoose.TabIndex = 19;
            // 
            // cmbChoose
            // 
            this.cmbChoose.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbChoose.FormattingEnabled = true;
            this.cmbChoose.Location = new System.Drawing.Point(58, 133);
            this.cmbChoose.Name = "cmbChoose";
            this.cmbChoose.Size = new System.Drawing.Size(87, 21);
            this.cmbChoose.Sorted = true;
            this.cmbChoose.TabIndex = 18;
            this.cmbChoose.SelectedIndexChanged += new System.EventHandler(this.cmbChoose_SelectedIndexChanged);
            // 
            // grbShort
            // 
            this.grbShort.Controls.Add(this.txtShortMax);
            this.grbShort.Controls.Add(this.lblShortRecent_lbl);
            this.grbShort.Controls.Add(this.lblShortMax_lbl);
            this.grbShort.Controls.Add(this.txtShortRecent);
            this.grbShort.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbShort.Location = new System.Drawing.Point(406, 19);
            this.grbShort.Name = "grbShort";
            this.grbShort.Size = new System.Drawing.Size(195, 100);
            this.grbShort.TabIndex = 17;
            this.grbShort.TabStop = false;
            this.grbShort.Text = "Short data";
            // 
            // txtShortMax
            // 
            this.txtShortMax.BackColor = System.Drawing.SystemColors.Control;
            this.txtShortMax.Enabled = false;
            this.txtShortMax.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtShortMax.Location = new System.Drawing.Point(61, 30);
            this.txtShortMax.Name = "txtShortMax";
            this.txtShortMax.ReadOnly = true;
            this.txtShortMax.Size = new System.Drawing.Size(125, 20);
            this.txtShortMax.TabIndex = 19;
            // 
            // lblShortRecent_lbl
            // 
            this.lblShortRecent_lbl.AutoSize = true;
            this.lblShortRecent_lbl.Location = new System.Drawing.Point(6, 69);
            this.lblShortRecent_lbl.Name = "lblShortRecent_lbl";
            this.lblShortRecent_lbl.Size = new System.Drawing.Size(52, 13);
            this.lblShortRecent_lbl.TabIndex = 18;
            this.lblShortRecent_lbl.Text = "Recent:";
            // 
            // lblShortMax_lbl
            // 
            this.lblShortMax_lbl.AutoSize = true;
            this.lblShortMax_lbl.Location = new System.Drawing.Point(6, 32);
            this.lblShortMax_lbl.Name = "lblShortMax_lbl";
            this.lblShortMax_lbl.Size = new System.Drawing.Size(34, 13);
            this.lblShortMax_lbl.TabIndex = 17;
            this.lblShortMax_lbl.Text = "Max:";
            // 
            // txtShortRecent
            // 
            this.txtShortRecent.BackColor = System.Drawing.SystemColors.Control;
            this.txtShortRecent.Enabled = false;
            this.txtShortRecent.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtShortRecent.Location = new System.Drawing.Point(61, 67);
            this.txtShortRecent.Name = "txtShortRecent";
            this.txtShortRecent.ReadOnly = true;
            this.txtShortRecent.Size = new System.Drawing.Size(125, 20);
            this.txtShortRecent.TabIndex = 15;
            // 
            // lblAgo
            // 
            this.lblAgo.AutoSize = true;
            this.lblAgo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAgo.Location = new System.Drawing.Point(208, 22);
            this.lblAgo.Name = "lblAgo";
            this.lblAgo.Size = new System.Drawing.Size(70, 13);
            this.lblAgo.TabIndex = 2;
            this.lblAgo.Text = "# days ago";
            // 
            // txtDiff_high
            // 
            this.txtDiff_high.BackColor = System.Drawing.SystemColors.Control;
            this.txtDiff_high.Enabled = false;
            this.txtDiff_high.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtDiff_high.Location = new System.Drawing.Point(211, 70);
            this.txtDiff_high.Name = "txtDiff_high";
            this.txtDiff_high.ReadOnly = true;
            this.txtDiff_high.Size = new System.Drawing.Size(68, 20);
            this.txtDiff_high.TabIndex = 10;
            // 
            // txtDiff_low
            // 
            this.txtDiff_low.BackColor = System.Drawing.SystemColors.Control;
            this.txtDiff_low.Enabled = false;
            this.txtDiff_low.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtDiff_low.Location = new System.Drawing.Point(211, 39);
            this.txtDiff_low.Name = "txtDiff_low";
            this.txtDiff_low.ReadOnly = true;
            this.txtDiff_low.Size = new System.Drawing.Size(68, 20);
            this.txtDiff_low.TabIndex = 6;
            // 
            // lblHowMuch
            // 
            this.lblHowMuch.AutoSize = true;
            this.lblHowMuch.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHowMuch.Location = new System.Drawing.Point(50, 22);
            this.lblHowMuch.Name = "lblHowMuch";
            this.lblHowMuch.Size = new System.Drawing.Size(66, 13);
            this.lblHowMuch.TabIndex = 0;
            this.lblHowMuch.Text = "How much";
            // 
            // lblWhen
            // 
            this.lblWhen.AutoSize = true;
            this.lblWhen.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWhen.Location = new System.Drawing.Point(117, 22);
            this.lblWhen.Name = "lblWhen";
            this.lblWhen.Size = new System.Drawing.Size(40, 13);
            this.lblWhen.TabIndex = 1;
            this.lblWhen.Text = "When";
            // 
            // txtDate_now
            // 
            this.txtDate_now.Enabled = false;
            this.txtDate_now.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtDate_now.Location = new System.Drawing.Point(118, 101);
            this.txtDate_now.Name = "txtDate_now";
            this.txtDate_now.ReadOnly = true;
            this.txtDate_now.Size = new System.Drawing.Size(87, 20);
            this.txtDate_now.TabIndex = 13;
            // 
            // txtKoers_now
            // 
            this.txtKoers_now.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.txtKoers_now.Enabled = false;
            this.txtKoers_now.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtKoers_now.Location = new System.Drawing.Point(53, 102);
            this.txtKoers_now.Name = "txtKoers_now";
            this.txtKoers_now.ReadOnly = true;
            this.txtKoers_now.Size = new System.Drawing.Size(63, 20);
            this.txtKoers_now.TabIndex = 12;
            // 
            // lblNow
            // 
            this.lblNow.AutoSize = true;
            this.lblNow.Location = new System.Drawing.Point(6, 104);
            this.lblNow.Name = "lblNow";
            this.lblNow.Size = new System.Drawing.Size(32, 13);
            this.lblNow.TabIndex = 11;
            this.lblNow.Text = "Now:";
            // 
            // txtDate_high
            // 
            this.txtDate_high.Enabled = false;
            this.txtDate_high.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtDate_high.Location = new System.Drawing.Point(118, 70);
            this.txtDate_high.Name = "txtDate_high";
            this.txtDate_high.ReadOnly = true;
            this.txtDate_high.Size = new System.Drawing.Size(87, 20);
            this.txtDate_high.TabIndex = 9;
            // 
            // txtDate_low
            // 
            this.txtDate_low.BackColor = System.Drawing.SystemColors.Control;
            this.txtDate_low.Enabled = false;
            this.txtDate_low.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtDate_low.Location = new System.Drawing.Point(118, 39);
            this.txtDate_low.Name = "txtDate_low";
            this.txtDate_low.ReadOnly = true;
            this.txtDate_low.Size = new System.Drawing.Size(87, 20);
            this.txtDate_low.TabIndex = 5;
            // 
            // txtKoers_high
            // 
            this.txtKoers_high.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtKoers_high.Enabled = false;
            this.txtKoers_high.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtKoers_high.Location = new System.Drawing.Point(53, 70);
            this.txtKoers_high.Name = "txtKoers_high";
            this.txtKoers_high.ReadOnly = true;
            this.txtKoers_high.Size = new System.Drawing.Size(63, 20);
            this.txtKoers_high.TabIndex = 8;
            // 
            // txtKoers_low
            // 
            this.txtKoers_low.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.txtKoers_low.Enabled = false;
            this.txtKoers_low.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtKoers_low.Location = new System.Drawing.Point(53, 39);
            this.txtKoers_low.Name = "txtKoers_low";
            this.txtKoers_low.ReadOnly = true;
            this.txtKoers_low.Size = new System.Drawing.Size(63, 20);
            this.txtKoers_low.TabIndex = 4;
            // 
            // lblHigh
            // 
            this.lblHigh.AutoSize = true;
            this.lblHigh.Location = new System.Drawing.Point(6, 73);
            this.lblHigh.Name = "lblHigh";
            this.lblHigh.Size = new System.Drawing.Size(32, 13);
            this.lblHigh.TabIndex = 7;
            this.lblHigh.Text = "High:";
            // 
            // lblLow
            // 
            this.lblLow.AutoSize = true;
            this.lblLow.Location = new System.Drawing.Point(6, 42);
            this.lblLow.Name = "lblLow";
            this.lblLow.Size = new System.Drawing.Size(30, 13);
            this.lblLow.TabIndex = 3;
            this.lblLow.Text = "Low:";
            // 
            // grbToday
            // 
            this.grbToday.Controls.Add(this.lblToday);
            this.grbToday.Controls.Add(this.grbMin);
            this.grbToday.Controls.Add(this.grbMax);
            this.grbToday.Location = new System.Drawing.Point(736, 24);
            this.grbToday.Name = "grbToday";
            this.grbToday.Size = new System.Drawing.Size(49, 64);
            this.grbToday.TabIndex = 1;
            this.grbToday.TabStop = false;
            this.grbToday.Text = "Today:";
            // 
            // lblToday
            // 
            this.lblToday.AutoSize = true;
            this.lblToday.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblToday.Location = new System.Drawing.Point(50, -15);
            this.lblToday.Name = "lblToday";
            this.lblToday.Size = new System.Drawing.Size(47, 13);
            this.lblToday.TabIndex = 10;
            this.lblToday.Text = "lblToday";
            // 
            // grbMin
            // 
            this.grbMin.Controls.Add(this.lbMin);
            this.grbMin.Location = new System.Drawing.Point(254, 22);
            this.grbMin.Name = "grbMin";
            this.grbMin.Size = new System.Drawing.Size(230, 268);
            this.grbMin.TabIndex = 8;
            this.grbMin.TabStop = false;
            this.grbMin.Text = "All-time Low";
            // 
            // lbMin
            // 
            this.lbMin.BackColor = System.Drawing.SystemColors.Control;
            this.lbMin.FormattingEnabled = true;
            this.lbMin.Items.AddRange(new object[] {
            "Nothing to display"});
            this.lbMin.Location = new System.Drawing.Point(12, 25);
            this.lbMin.Name = "lbMin";
            this.lbMin.Size = new System.Drawing.Size(207, 225);
            this.lbMin.TabIndex = 0;
            this.lbMin.Click += new System.EventHandler(this.lbMin_Click);
            // 
            // grbMax
            // 
            this.grbMax.Controls.Add(this.lbMax);
            this.grbMax.Location = new System.Drawing.Point(12, 22);
            this.grbMax.Name = "grbMax";
            this.grbMax.Size = new System.Drawing.Size(230, 268);
            this.grbMax.TabIndex = 0;
            this.grbMax.TabStop = false;
            this.grbMax.Text = "All-time High";
            // 
            // lbMax
            // 
            this.lbMax.BackColor = System.Drawing.SystemColors.Control;
            this.lbMax.FormattingEnabled = true;
            this.lbMax.Items.AddRange(new object[] {
            "Nothing to display"});
            this.lbMax.Location = new System.Drawing.Point(17, 25);
            this.lbMax.Name = "lbMax";
            this.lbMax.Size = new System.Drawing.Size(207, 225);
            this.lbMax.TabIndex = 0;
            this.lbMax.Click += new System.EventHandler(this.lbMax_Click);
            this.lbMax.SelectedIndexChanged += new System.EventHandler(this.lbMax_SelectedIndexChanged);
            // 
            // txtProperty
            // 
            this.txtProperty.Location = new System.Drawing.Point(52, 19);
            this.txtProperty.Name = "txtProperty";
            this.txtProperty.Size = new System.Drawing.Size(455, 20);
            this.txtProperty.TabIndex = 4;
            this.txtProperty.TextChanged += new System.EventHandler(this.txtProperty_TextChanged);
            // 
            // cmdPropdate
            // 
            this.cmdPropdate.Location = new System.Drawing.Point(513, 18);
            this.cmdPropdate.Name = "cmdPropdate";
            this.cmdPropdate.Size = new System.Drawing.Size(81, 21);
            this.cmdPropdate.TabIndex = 5;
            this.cmdPropdate.Text = "Update";
            this.cmdPropdate.UseVisualStyleBackColor = true;
            this.cmdPropdate.Click += new System.EventHandler(this.cmdPropdate_Click);
            // 
            // grbProperties
            // 
            this.grbProperties.Controls.Add(this.lblProperty);
            this.grbProperties.Controls.Add(this.txtProperty);
            this.grbProperties.Controls.Add(this.cmdPropdate);
            this.grbProperties.Controls.Add(this.cmdStockNames);
            this.grbProperties.Location = new System.Drawing.Point(10, 15);
            this.grbProperties.Name = "grbProperties";
            this.grbProperties.Size = new System.Drawing.Size(627, 83);
            this.grbProperties.TabIndex = 6;
            this.grbProperties.TabStop = false;
            this.grbProperties.Text = "Stocks.Properties.Settings.Default.Database ";
            // 
            // lblProperty
            // 
            this.lblProperty.AutoSize = true;
            this.lblProperty.Location = new System.Drawing.Point(9, 22);
            this.lblProperty.Name = "lblProperty";
            this.lblProperty.Size = new System.Drawing.Size(37, 13);
            this.lblProperty.TabIndex = 8;
            this.lblProperty.Text = "Value:";
            // 
            // backgroundWorker1
            // 
            this.backgroundWorker1.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker1_DoWork);
            this.backgroundWorker1.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.backgroundWorker1_ProgressChanged);
            // 
            // frmFonds
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(644, 818);
            this.Controls.Add(this.grbProperties);
            this.Controls.Add(this.grbToday);
            this.Controls.Add(this.grbKoers);
            this.Controls.Add(this.grbDetail);
            this.Controls.Add(this.cmdCancel);
            this.Controls.Add(this.grbFonds);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmFonds";
            this.Text = "frmFonds";
            this.Load += new System.EventHandler(this.frmFonds_Load);
            this.grbFonds.ResumeLayout(false);
            this.grbFonds.PerformLayout();
            this.grbStats.ResumeLayout(false);
            this.grbStats.PerformLayout();
            this.grbAnalyse.ResumeLayout(false);
            this.grbAnalyse.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgFonds)).EndInit();
            this.grbKoers.ResumeLayout(false);
            this.grbKoers.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgKoers)).EndInit();
            this.grbDetail.ResumeLayout(false);
            this.grbDetail.PerformLayout();
            this.grbShort.ResumeLayout(false);
            this.grbShort.PerformLayout();
            this.grbToday.ResumeLayout(false);
            this.grbToday.PerformLayout();
            this.grbMin.ResumeLayout(false);
            this.grbMax.ResumeLayout(false);
            this.grbProperties.ResumeLayout(false);
            this.grbProperties.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grbFonds;
        private System.Windows.Forms.DataGridView dgFonds;
        private System.Windows.Forms.Button cmdCancel;
        private System.Windows.Forms.Label lblFonds_count_val;
        private System.Windows.Forms.GroupBox grbKoers;
        private System.Windows.Forms.DataGridView dgKoers;
        private System.Windows.Forms.GroupBox grbDetail;
        private System.Windows.Forms.TextBox txtKoers_low;
        private System.Windows.Forms.Label lblHigh;
        private System.Windows.Forms.Label lblLow;
        private System.Windows.Forms.TextBox txtKoers_high;
        private System.Windows.Forms.TextBox txtDate_high;
        private System.Windows.Forms.TextBox txtDate_low;
        private System.Windows.Forms.TextBox txtDate_now;
        private System.Windows.Forms.TextBox txtKoers_now;
        private System.Windows.Forms.Label lblNow;
        private System.Windows.Forms.Label lblKoers_count;
        private System.Windows.Forms.Label lblHowMuch;
        private System.Windows.Forms.Label lblWhen;
        private System.Windows.Forms.Label lblDoubleClick;
        private System.Windows.Forms.Button cmdHighLowAnalyze;
        private System.Windows.Forms.GroupBox grbToday;
        private System.Windows.Forms.Label lblMacPerc;
        private System.Windows.Forms.ProgressBar pgMax;
        private System.Windows.Forms.GroupBox grbMin;
        private System.Windows.Forms.ListBox lbMin;
        private System.Windows.Forms.GroupBox grbMax;
        private System.Windows.Forms.ListBox lbMax;
        private System.Windows.Forms.Label lblKoers;
        private System.Windows.Forms.Label lblToday;
        private System.Windows.Forms.TextBox txtDiff_low;
        private System.Windows.Forms.Label lblAgo;
        private System.Windows.Forms.TextBox txtDiff_high;
        private System.Windows.Forms.TextBox txtProperty;
        private System.Windows.Forms.Button cmdPropdate;
        private System.Windows.Forms.GroupBox grbProperties;
        private System.Windows.Forms.Label lblProperty;
        private System.Windows.Forms.CheckBox cbHighLowShow;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Button cmdStockNames;
        private System.Windows.Forms.TextBox txtShortRecent;
        private System.Windows.Forms.GroupBox grbShort;
        private System.Windows.Forms.Label lblShortRecent_lbl;
        private System.Windows.Forms.Label lblShortMax_lbl;
        private System.Windows.Forms.Label lblSelect;
        private System.Windows.Forms.ComboBox cmbSelect;
        private System.Windows.Forms.GroupBox grbAnalyse;
        private System.Windows.Forms.Label lblFonds_Lokaal_val;
        private System.Windows.Forms.Label lblFonds_AScX_val;
        private System.Windows.Forms.Label lblFonds_AMX_val;
        private System.Windows.Forms.Label lblFonds_Amsterdam_val;
        private System.Windows.Forms.Label lblFonds_Lokaal_lbl;
        private System.Windows.Forms.Label lblFonds_AScX_lbl;
        private System.Windows.Forms.Label lblFonds_AMX_lbl;
        private System.Windows.Forms.Label lblFonds_Amsterdam_lbl;
        private System.Windows.Forms.GroupBox grbStats;
        private System.Windows.Forms.Label lblFonds_Totaal_lbl;
        private System.Windows.Forms.Label lblChoose;
        private System.Windows.Forms.TextBox txtChoose;
        private System.Windows.Forms.ComboBox cmbChoose;
        private System.Windows.Forms.Button cmdChoose;
        private System.Windows.Forms.Label lblLow_val;
        private System.Windows.Forms.Label lblLow_lbl;
        private System.Windows.Forms.Label lblHigh_val;
        private System.Windows.Forms.Label lblHigh_lbl;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtShortMax;
    }
}