﻿namespace dbDashboard
{
    partial class frmDashPOP3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.grbBDR_Q = new System.Windows.Forms.GroupBox();
            this.lblPOP3_BDR = new System.Windows.Forms.Label();
            this.dgPOP3Q_BDR = new System.Windows.Forms.DataGridView();
            this.colPOP3Q_BDR_Customer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPOP3Q_BDR_Queue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPOP3_oldest = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPOP3_newest = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblCount = new System.Windows.Forms.Label();
            this.lblCustomers = new System.Windows.Forms.Label();
            this.cmdShow = new System.Windows.Forms.Button();
            this.cmbEnvironment = new System.Windows.Forms.ComboBox();
            this.grbSelect = new System.Windows.Forms.GroupBox();
            this.lbEnvironment = new System.Windows.Forms.ListBox();
            this.lblServer = new System.Windows.Forms.Label();
            this.lblServer_val = new System.Windows.Forms.Label();
            this.lblCheckTime = new System.Windows.Forms.Label();
            this.lblCheckTime_val = new System.Windows.Forms.Label();
            this.grbStats = new System.Windows.Forms.GroupBox();
            this.grbConnect.SuspendLayout();
            this.grbBDR_Q.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgPOP3Q_BDR)).BeginInit();
            this.grbSelect.SuspendLayout();
            this.grbStats.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmdAfsluiten
            // 
            this.cmdAfsluiten.Location = new System.Drawing.Point(12, 446);
            this.cmdAfsluiten.TabIndex = 4;
            // 
            // lblHostName
            // 
            this.lblHostName.Location = new System.Drawing.Point(527, 453);
            this.lblHostName.Size = new System.Drawing.Size(145, 13);
            this.lblHostName.TabIndex = 5;
            this.lblHostName.Text = "KPNNL\\WLD4BED923B63C";
            // 
            // grbBDR_Q
            // 
            this.grbBDR_Q.Controls.Add(this.lblPOP3_BDR);
            this.grbBDR_Q.Controls.Add(this.dgPOP3Q_BDR);
            this.grbBDR_Q.Location = new System.Drawing.Point(12, 41);
            this.grbBDR_Q.Name = "grbBDR_Q";
            this.grbBDR_Q.Size = new System.Drawing.Size(459, 390);
            this.grbBDR_Q.TabIndex = 0;
            this.grbBDR_Q.TabStop = false;
            // 
            // lblPOP3_BDR
            // 
            this.lblPOP3_BDR.AutoSize = true;
            this.lblPOP3_BDR.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPOP3_BDR.Location = new System.Drawing.Point(11, -5);
            this.lblPOP3_BDR.Name = "lblPOP3_BDR";
            this.lblPOP3_BDR.Size = new System.Drawing.Size(59, 24);
            this.lblPOP3_BDR.TabIndex = 38;
            this.lblPOP3_BDR.Text = "POP3";
            // 
            // dgPOP3Q_BDR
            // 
            this.dgPOP3Q_BDR.AllowUserToAddRows = false;
            this.dgPOP3Q_BDR.AllowUserToDeleteRows = false;
            this.dgPOP3Q_BDR.AllowUserToResizeColumns = false;
            this.dgPOP3Q_BDR.AllowUserToResizeRows = false;
            this.dgPOP3Q_BDR.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgPOP3Q_BDR.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colPOP3Q_BDR_Customer,
            this.colPOP3Q_BDR_Queue,
            this.colPOP3_oldest,
            this.colPOP3_newest});
            this.dgPOP3Q_BDR.Location = new System.Drawing.Point(10, 29);
            this.dgPOP3Q_BDR.MultiSelect = false;
            this.dgPOP3Q_BDR.Name = "dgPOP3Q_BDR";
            this.dgPOP3Q_BDR.ReadOnly = true;
            this.dgPOP3Q_BDR.RowHeadersVisible = false;
            this.dgPOP3Q_BDR.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgPOP3Q_BDR.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgPOP3Q_BDR.Size = new System.Drawing.Size(433, 343);
            this.dgPOP3Q_BDR.TabIndex = 0;
            // 
            // colPOP3Q_BDR_Customer
            // 
            this.colPOP3Q_BDR_Customer.HeaderText = "Customer";
            this.colPOP3Q_BDR_Customer.MaxInputLength = 100;
            this.colPOP3Q_BDR_Customer.MinimumWidth = 160;
            this.colPOP3Q_BDR_Customer.Name = "colPOP3Q_BDR_Customer";
            this.colPOP3Q_BDR_Customer.ReadOnly = true;
            this.colPOP3Q_BDR_Customer.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colPOP3Q_BDR_Customer.Width = 160;
            // 
            // colPOP3Q_BDR_Queue
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle1.Format = "N0";
            dataGridViewCellStyle1.NullValue = null;
            this.colPOP3Q_BDR_Queue.DefaultCellStyle = dataGridViewCellStyle1;
            this.colPOP3Q_BDR_Queue.HeaderText = "Queue";
            this.colPOP3Q_BDR_Queue.MaxInputLength = 7;
            this.colPOP3Q_BDR_Queue.MinimumWidth = 50;
            this.colPOP3Q_BDR_Queue.Name = "colPOP3Q_BDR_Queue";
            this.colPOP3Q_BDR_Queue.ReadOnly = true;
            this.colPOP3Q_BDR_Queue.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colPOP3Q_BDR_Queue.Width = 50;
            // 
            // colPOP3_oldest
            // 
            this.colPOP3_oldest.HeaderText = "Oldest";
            this.colPOP3_oldest.MaxInputLength = 80;
            this.colPOP3_oldest.Name = "colPOP3_oldest";
            this.colPOP3_oldest.ReadOnly = true;
            this.colPOP3_oldest.Width = 110;
            // 
            // colPOP3_newest
            // 
            this.colPOP3_newest.HeaderText = "Newest";
            this.colPOP3_newest.MaxInputLength = 80;
            this.colPOP3_newest.Name = "colPOP3_newest";
            this.colPOP3_newest.ReadOnly = true;
            this.colPOP3_newest.Width = 110;
            // 
            // lblCount
            // 
            this.lblCount.AutoSize = true;
            this.lblCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCount.Location = new System.Drawing.Point(9, 138);
            this.lblCount.Name = "lblCount";
            this.lblCount.Size = new System.Drawing.Size(21, 13);
            this.lblCount.TabIndex = 5;
            this.lblCount.Text = "99";
            // 
            // lblCustomers
            // 
            this.lblCustomers.AutoSize = true;
            this.lblCustomers.Location = new System.Drawing.Point(9, 125);
            this.lblCustomers.Name = "lblCustomers";
            this.lblCustomers.Size = new System.Drawing.Size(110, 13);
            this.lblCustomers.TabIndex = 4;
            this.lblCustomers.Text = "Number of customers:";
            // 
            // cmdShow
            // 
            this.cmdShow.Location = new System.Drawing.Point(10, 65);
            this.cmdShow.Name = "cmdShow";
            this.cmdShow.Size = new System.Drawing.Size(75, 23);
            this.cmdShow.TabIndex = 1;
            this.cmdShow.Text = "Show";
            this.cmdShow.UseVisualStyleBackColor = true;
            this.cmdShow.Click += new System.EventHandler(this.cmdShow_Click);
            // 
            // cmbEnvironment
            // 
            this.cmbEnvironment.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEnvironment.FormattingEnabled = true;
            this.cmbEnvironment.Location = new System.Drawing.Point(10, 19);
            this.cmbEnvironment.Name = "cmbEnvironment";
            this.cmbEnvironment.Size = new System.Drawing.Size(128, 21);
            this.cmbEnvironment.TabIndex = 0;
            this.cmbEnvironment.SelectedIndexChanged += new System.EventHandler(this.cmbEnvironment_SelectedIndexChanged);
            // 
            // grbSelect
            // 
            this.grbSelect.Controls.Add(this.cmbEnvironment);
            this.grbSelect.Controls.Add(this.cmdShow);
            this.grbSelect.Location = new System.Drawing.Point(510, 41);
            this.grbSelect.Name = "grbSelect";
            this.grbSelect.Size = new System.Drawing.Size(154, 94);
            this.grbSelect.TabIndex = 1;
            this.grbSelect.TabStop = false;
            this.grbSelect.Text = "Select";
            // 
            // lbEnvironment
            // 
            this.lbEnvironment.FormattingEnabled = true;
            this.lbEnvironment.Location = new System.Drawing.Point(510, 147);
            this.lbEnvironment.Name = "lbEnvironment";
            this.lbEnvironment.Size = new System.Drawing.Size(154, 56);
            this.lbEnvironment.TabIndex = 2;
            this.lbEnvironment.Visible = false;
            // 
            // lblServer
            // 
            this.lblServer.AutoSize = true;
            this.lblServer.Location = new System.Drawing.Point(7, 36);
            this.lblServer.Name = "lblServer";
            this.lblServer.Size = new System.Drawing.Size(41, 13);
            this.lblServer.TabIndex = 0;
            this.lblServer.Text = "Server:";
            // 
            // lblServer_val
            // 
            this.lblServer_val.AutoSize = true;
            this.lblServer_val.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblServer_val.Location = new System.Drawing.Point(9, 49);
            this.lblServer_val.Name = "lblServer_val";
            this.lblServer_val.Size = new System.Drawing.Size(51, 13);
            this.lblServer_val.TabIndex = 1;
            this.lblServer_val.Text = "kslv000";
            // 
            // lblCheckTime
            // 
            this.lblCheckTime.AutoSize = true;
            this.lblCheckTime.Location = new System.Drawing.Point(9, 79);
            this.lblCheckTime.Name = "lblCheckTime";
            this.lblCheckTime.Size = new System.Drawing.Size(60, 13);
            this.lblCheckTime.TabIndex = 2;
            this.lblCheckTime.Text = "Checktime:";
            // 
            // lblCheckTime_val
            // 
            this.lblCheckTime_val.AutoSize = true;
            this.lblCheckTime_val.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCheckTime_val.Location = new System.Drawing.Point(9, 92);
            this.lblCheckTime_val.Name = "lblCheckTime_val";
            this.lblCheckTime_val.Size = new System.Drawing.Size(125, 13);
            this.lblCheckTime_val.TabIndex = 3;
            this.lblCheckTime_val.Text = "9999-12-31 23:59:59";
            // 
            // grbStats
            // 
            this.grbStats.Controls.Add(this.lblCheckTime_val);
            this.grbStats.Controls.Add(this.lblCustomers);
            this.grbStats.Controls.Add(this.lblCheckTime);
            this.grbStats.Controls.Add(this.lblCount);
            this.grbStats.Controls.Add(this.lblServer_val);
            this.grbStats.Controls.Add(this.lblServer);
            this.grbStats.Location = new System.Drawing.Point(510, 244);
            this.grbStats.Name = "grbStats";
            this.grbStats.Size = new System.Drawing.Size(154, 187);
            this.grbStats.TabIndex = 3;
            this.grbStats.TabStop = false;
            // 
            // frmDashPOP3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(677, 475);
            this.Controls.Add(this.grbStats);
            this.Controls.Add(this.lbEnvironment);
            this.Controls.Add(this.grbSelect);
            this.Controls.Add(this.grbBDR_Q);
            this.Name = "frmDashPOP3";
            this.Text = "frmDashPOP3 - Digipoort overview number of messages  in POP3 mailboxes";
            this.Load += new System.EventHandler(this.frmDashPOP3_Load);
            this.Controls.SetChildIndex(this.cmdAfsluiten, 0);
            this.Controls.SetChildIndex(this.grbConnect, 0);
            this.Controls.SetChildIndex(this.lblHostName, 0);
            this.Controls.SetChildIndex(this.grbBDR_Q, 0);
            this.Controls.SetChildIndex(this.grbSelect, 0);
            this.Controls.SetChildIndex(this.lbEnvironment, 0);
            this.Controls.SetChildIndex(this.grbStats, 0);
            this.grbConnect.ResumeLayout(false);
            this.grbConnect.PerformLayout();
            this.grbBDR_Q.ResumeLayout(false);
            this.grbBDR_Q.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgPOP3Q_BDR)).EndInit();
            this.grbSelect.ResumeLayout(false);
            this.grbStats.ResumeLayout(false);
            this.grbStats.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grbBDR_Q;
        private System.Windows.Forms.Label lblCustomers;
        private System.Windows.Forms.DataGridView dgPOP3Q_BDR;
        private System.Windows.Forms.Button cmdShow;
        private System.Windows.Forms.Label lblCount;
        private System.Windows.Forms.Label lblPOP3_BDR;
        private System.Windows.Forms.ComboBox cmbEnvironment;
        private System.Windows.Forms.GroupBox grbSelect;
        private System.Windows.Forms.ListBox lbEnvironment;
        private System.Windows.Forms.Label lblServer;
        private System.Windows.Forms.Label lblServer_val;
        private System.Windows.Forms.Label lblCheckTime;
        private System.Windows.Forms.Label lblCheckTime_val;
        private System.Windows.Forms.GroupBox grbStats;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPOP3Q_BDR_Customer;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPOP3Q_BDR_Queue;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPOP3_oldest;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPOP3_newest;
    }
}