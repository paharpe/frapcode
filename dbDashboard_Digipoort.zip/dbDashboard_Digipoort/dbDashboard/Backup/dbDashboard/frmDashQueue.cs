﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.IO;
using System.Threading;
using System.Diagnostics.CodeAnalysis;
using System.Windows.Forms.DataVisualization.Charting;

// using System.Windows.Forms.
using Excel = Microsoft.Office.Interop.Excel.Chart;

namespace dbDashboard
{
    public partial class frmDashQueue : frmDashBase
    {
        Boolean bSaveStarted;

        const string strNoMessages = "No messages";

        // Identifiers in de diverse inputbestanden
        // SMTP
        const string strSMTP2Bedrijven = "SMTP_OUT_BDR";
        const string strSMTP2Overheden = "SMTP_OUT_OVH";
        // Cores
        const string strSMTP_from_bedrijven = "SMTP_IN_BDR";
        const string strX400_from_overheden = "X400_IN_OVH";
        // X400
        const string strX4002Bedrijven = "X400_OUT_BDR";
        const string strX4002Overheden = "X400_OUT_OVH";
        // Reponse is an important landmark in the processing;
        const string strResponse = "RESPONSE";

        private Color clQueue_yes = Color.Orange;
        private Color clQueue_no = Color.White;
        private Color clQueue_error = Color.YellowGreen;

        private string strUpdateScript;

        private string strQueueCMD_Path;
        private string strQueueCMD_SMTP;
        private string strQueueCMD_X400;
        private string strQueueCMD_Core;

        private string strQueueData_Path;
        private string strQueueData_SMTP;
        private string strQueueData_X400;
        private string strQueueData_Core;

        private Boolean b_tmrSMTPq_started;
        private Boolean b_tmrCoreq_started;
        private Boolean b_tmrX400q_started;

        private Boolean b_SMTPq_BDR_SaveStarted;
        private Boolean b_SMTPq_OVH_SaveStarted;
        private Boolean b_Coreq_SaveStarted;
        private Boolean b_X400q_OVH_SaveStarted;
        private Boolean b_X400q_BDR_SaveStarted;

        private string strSaveFile_Name;
        private StreamWriter swSaveFile;
        private Boolean bRecordErrors;
        private Boolean bRecordQueueOnly;

        private ArrayList alSMTP_Shadow_tab = new ArrayList();
        private ArrayList alCore_Shadow_tab = new ArrayList(6);
        private ArrayList alX400_Shadow_tab = new ArrayList(6);

        Boolean bRecordSMTP_OVH_Log_INIT = false;
        Boolean bRecordSMTP_BDR_Log_INIT = false;
        Boolean bRecordCoreLog_INIT = false;
        Boolean bRecordX400_OVH_Log_INIT = false;
        Boolean bRecordX400_BDR_Log_INIT = false;

        int     intDebugErrors = 0;

        public frmDashQueue()
        {
            InitializeComponent();
        }

        private void frmDashQueue_Load(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            init_form();
            this.Cursor = Cursors.Default;           
        }

        private void init_form()
        {            
            // path en cmd namen uit INI file ophalen
            strQueueCMD_Path = clDashFunction.get_TagValue("[QCMDPATH]", true);
            strQueueCMD_Core = strQueueCMD_Path + clDashFunction.get_TagValue("[QCMDCORE]", true);
            strQueueCMD_SMTP = strQueueCMD_Path + clDashFunction.get_TagValue("[QCMDSMTP]", true);
            strQueueCMD_X400 = strQueueCMD_Path + clDashFunction.get_TagValue("[QCMDX400]", true);

            // directory en filenamen om nieuwe data vandaag te halen.
            strQueueData_Path = clDashFunction.get_TagValue("[QDATAPATH]", true);
            strQueueData_Core = strQueueData_Path + clDashFunction.get_TagValue("[QDATACORE]", true);
            strQueueData_SMTP = strQueueData_Path + clDashFunction.get_TagValue("[QDATASMTP]", true);
            strQueueData_X400 = strQueueData_Path + clDashFunction.get_TagValue("[QDATAX400]", true);

            // Default keuze maken voor SMTP overzichten: per domein
            cmbGroupSMTP.SelectedIndex = 0;
            
            // Alles aanwezig ?
            if (strQueueCMD_Core != "" && strQueueCMD_SMTP != "" && strQueueCMD_X400 != "" &&
                strQueueData_Core != "" && strQueueData_SMTP != "" && strQueueData_X400 != "")
            {
                // refresh_queuedata();
            }
            else
            {
                // clDashFunction.Melding("Queuedata kan niet worden opgehaald of getoond in verband met INI file issues");
                clDashFunction.Melding("Unable to obtain queuedata due to INI file issues");
            }

            // Default keuzes invullen voor in DialogBox QueueRec, waar wordt aangegeven of, welke en waar
            // recoding van de queuelog data plaatsvindt.
            b_SMTPq_OVH_SaveStarted = true; // SMTPqueues naar Overheid    ( kslv042/92 )
            b_Coreq_SaveStarted = true;     // Queue(s) op de Cores        ( kslv048/kslv095/096 )
            b_X400q_OVH_SaveStarted = true; // Queue(s) naar X400 overheid ( kslv043 / kslv93 ) 
            bRecordQueueOnly = true;

            // Variabele strUpdateScript kan "SERVER" of "LOCAL" bevatten
            // via deze waarde wordt bepaald of de update scripts via deze
            // code moeten worden getriggered of niet.
            // LOCAL: script uitvoeren en resultaat inlezen
            // SERVER:  alleen resultaat inlezen, script draait dan elders
            // Voor gebruik in code
            strUpdateScript=clDashFunction.get_update_script();
            // Voor tonen op scherm
            lblUpdate_Script_val.Text = strUpdateScript;
            rbAutoUpdateOff.Checked = true;
            rbAutoUpdateOn.Checked = true;
            rbDGSMTPQ_BEDR.Checked = true;
        }


        private void refresh_queuedata()
        {
            debug("Start refresh: "+System.DateTime.Now,false);
            check_SMTP_OUT(strQueueData_SMTP);
            get_SMTP_OUT_queues(strQueueData_SMTP);
            get_Core_queues(strQueueData_Core);
            get_X400_queues(strQueueData_X400);
            debug("End refresh : " + System.DateTime.Now,false);
            debug(" ",false);
            
        }

        private void check_SMTP_OUT(string strQueueData)
        {
            // Deze functie zorgt ervoor dat de radiobutten rbDomain niet kan worden
            // geklikt als er een "No messages" record voorkomt hetzij in de "BDR" of "OVH" 
            // SMTP output.
            // Het gaf namelijk een vreemd beeld om bijvoorbeeld
            //   "All   No messages" 
            //   "All   Wissekerke Unions   393" 
            // te zien staan. Daarom, bij (ook al is er maar 1) "No messages" record,
            // ALTIJD ALLEEN op SERVER groeperen
            

            // We moeten dus een hybride situatie met NO MESSAGES binnen OFWEL OVERHEID ofwel BEDRIJVEN herkennen..

            lblGroupSMTP.Enabled = true;
            cmbGroupSMTP.Enabled = true;
            if (cmbGroupSMTP.SelectedIndex < 0)
            {
                cmbGroupSMTP.SelectedIndex = 1;
            }

            Boolean bNoMsg_BDR = false;
            Boolean bYesMsg_BDR = false;
            Boolean bNoMsg_OVH = false;
            Boolean bYesMsg_OVH = false;
                      
            StreamReader srQueue = clDashFunction.open4read(strQueueData);

            string strQueue_record;

            if (srQueue != null)
            {
                while (!srQueue.EndOfStream)
                {
                    strQueue_record = srQueue.ReadLine();

                    // Staat er "no messages" in het inputrecord ??
                    if (!strQueue_record.ToUpper().Contains(strNoMessages.ToUpper()))
                    {

                        if (strQueue_record.ToUpper().Contains(strSMTP2Bedrijven))
                        {
                            bNoMsg_BDR = true;
                        }
                        if (strQueue_record.ToUpper().Contains(strSMTP2Overheden))
                        {
                            bNoMsg_OVH = true;
                        }
                    }
                    // Er staat NIET "no messages in het inputrecord !!
                    else
                    {
                        if (strQueue_record.ToUpper().Contains(strSMTP2Bedrijven))
                        {
                            bYesMsg_BDR = true;
                        }
                        if (strQueue_record.ToUpper().Contains(strSMTP2Overheden))
                        {
                            bYesMsg_OVH = true;
                        }
                    }                   

                }
                srQueue.Close();
                /* *And now.... op basis van de bevindingen:
                de combobox moet disabled worden:
                 - Als er binnen OVerHeid een combinatie voorkomt van No Messages en Wel Messages
                 *                                 OF
                 - Als er binnen BeDRrijven een combinatie voorkomt van No Messages en Wel Messages
                 * */
                if ((bNoMsg_BDR && bYesMsg_BDR )|| (bNoMsg_OVH && bYesMsg_OVH))
                {
                    cmbGroupSMTP.SelectedIndex = -1;
                    lblGroupSMTP.Enabled = false;
                    cmbGroupSMTP.Enabled = false;                   
                }
            }
            else
            {
                // Als het goed is kan deze 'else' tak een keer worden weggegooid, zolang dat niet zo is:
                // Experimenteel einde ingebouwd om te voorkomen dat er 100 dezelfde 
                // foutboxes staan als een bestand niet in 10 keer kan worden geopend.
                debug("Fout bij openen: " + strQueueData + " (>10 tries?)",true); 
                // clDashFunction.Melding("Er is een fout opgetreden bij het openen van "+strQueueData +" (>10 tries nodig ?)",1,"I"); 
                // this.Close();
            }
        }

        private void get_SMTP_OUT_queues(string strQueueData)
        {
            int intAL_BDR;          
            int intAL_OVH;
           
            string strSMTP_OUT_rec;
            int intSMTPRowNo = 0;
            Boolean bRecordSMTPLog = false;

            ArrayList alServer_BDR = new ArrayList();
            ArrayList alBedrijf_BDR = new ArrayList();
            ArrayList alQueue_BDR = new ArrayList();
            ArrayList alCheckTime_BDR = new ArrayList();
            ArrayList alAge_BDR = new ArrayList();
            Boolean   bFound_BDR = false;

            ArrayList alServer_OVH = new ArrayList();
            ArrayList alBedrijf_OVH = new ArrayList();
            ArrayList alQueue_OVH = new ArrayList();
            ArrayList alCheckTime_OVH = new ArrayList();
            ArrayList alAge_OVH = new ArrayList();
            Boolean bFound_OVH = false;
            
            int intQueue_BDR = 0;
            int intQueue_OVH = 0;

            StreamReader srQueue = clDashFunction.open4read(strQueueData);
            if (srQueue != null)
            {
                // Inputfile met QUEUE info doorfietsen
                while (!srQueue.EndOfStream)
                {
                    strSMTP_OUT_rec = srQueue.ReadLine();

                    /////////////////////
                    //Shadowtabel prutsel 
                    ////////////////////
                    if (alSMTP_Shadow_tab.Count <= intSMTPRowNo)
                    {
                        alSMTP_Shadow_tab.Add("");
                    }
                    if (alSMTP_Shadow_tab[intSMTPRowNo].ToString() != strSMTP_OUT_rec)
                    {
                        bRecordSMTPLog = true;
                    }
                    alSMTP_Shadow_tab[intSMTPRowNo] = strSMTP_OUT_rec;
                    intSMTPRowNo++;
                    //////////////////////////
                    // End Shadowtabel prutsel
                    //////////////////////////

                    string[] alSMTP_OUT = Regex.Split(strSMTP_OUT_rec, "~");

                    if (alSMTP_OUT.Length > 4)
                    {
                        ///////////////////////////
                        // BEDRIJVEN
                        ///////////////////////////
                        if (alSMTP_OUT[2] == strSMTP2Bedrijven)
                        {
                            if (cmbGroupSMTP.Text.ToUpper() == "DOMAIN".ToUpper())
                            {
                                bFound_BDR = false;
                                intAL_BDR = 0;
                                while (intAL_BDR < alBedrijf_BDR.Count) // had ook intMAX_BDR kunnen zijn
                                {
                                    // Bestaand bedrijf/domain
                                    if (alBedrijf_BDR[intAL_BDR].ToString() == alSMTP_OUT[4])
                                    {
                                        if (alSMTP_OUT.Length > 5)
                                        {
                                            alQueue_BDR[intAL_BDR] = Convert.ToString(Convert.ToInt32(alQueue_BDR[intAL_BDR]) + Convert.ToInt32(alSMTP_OUT[5]));
                                            if (Convert.ToInt32(alAge_BDR[intAL_BDR]) < Convert.ToInt32(alSMTP_OUT[6]))
                                            {
                                                alAge_BDR[intAL_BDR] = alSMTP_OUT[6];
                                            }
                                            alCheckTime_BDR[intAL_BDR] = alSMTP_OUT[3];
                                        }
                                        bFound_BDR = true;
                                    }
                                    intAL_BDR++;
                                }
                                // Nieuw bedrijf/domain
                                if (!bFound_BDR)
                                {
                                    alServer_BDR.Add("All");
                                    alCheckTime_BDR.Add(alSMTP_OUT[3]);
                                    alBedrijf_BDR.Add(alSMTP_OUT[4]);
                                    if (alSMTP_OUT.Length > 5)
                                    {                                        
                                        alQueue_BDR.Add(alSMTP_OUT[5]);
                                        alAge_BDR.Add(alSMTP_OUT[6]);
                                    }
                                    else
                                    {
                                        // Nullen toevoegen om array's in sync te houden
                                        alQueue_BDR.Add(0);
                                        alAge_BDR.Add(0);
                                    }
                                }
                            }
                            else // de "gewone" recht op en neer weergave
                            {
                                alServer_BDR.Add(alSMTP_OUT[1]);
                                alCheckTime_BDR.Add(alSMTP_OUT[3]);
                                alBedrijf_BDR.Add(alSMTP_OUT[4]);
                                if (alSMTP_OUT.Length > 5)
                                {
                                    alQueue_BDR.Add(alSMTP_OUT[5]);
                                    alAge_BDR.Add(alSMTP_OUT[6]);
                                }
                                else
                                {
                                    // Nullen toevoegen om array's in sync te houden
                                    alQueue_BDR.Add(0);
                                    alAge_BDR.Add(0);
                                }
                            }
                        }

                        ///////////////////////////
                        // OVERHEDEN
                        ///////////////////////////
                        if (alSMTP_OUT[2] == strSMTP2Overheden)
                        {
                            if (cmbGroupSMTP.Text.ToUpper() == "DOMAIN".ToUpper())
                            {
                                bFound_OVH = false;
                                intAL_OVH = 0;
                                while (intAL_OVH < alBedrijf_OVH.Count) // had ook intMAX_OVH kunnen zijn
                                {
                                    // Bestaand bedrijf/domain
                                    if (alBedrijf_OVH[intAL_OVH].ToString() == alSMTP_OUT[4])
                                    {
                                        if (alSMTP_OUT.Length > 5)
                                        {
                                            alQueue_OVH[intAL_OVH] = Convert.ToString(Convert.ToInt32(alQueue_OVH[intAL_OVH]) + Convert.ToInt32(alSMTP_OUT[5]));
                                            if (Convert.ToInt32(alAge_OVH[intAL_OVH]) < Convert.ToInt32(alSMTP_OUT[6]))
                                            {
                                                alAge_OVH[intAL_OVH] = alSMTP_OUT[6];
                                            }
                                            alCheckTime_OVH[intAL_OVH] = alSMTP_OUT[3];
                                        }
                                        bFound_OVH = true;
                                    }
                                    intAL_OVH++;
                                }
                                // Nieuw bedrijf/domain
                                if (!bFound_OVH)
                                {
                                    alServer_OVH.Add("All");
                                    alCheckTime_OVH.Add(alSMTP_OUT[3]);
                                    alBedrijf_OVH.Add(alSMTP_OUT[4]);
                                    if (alSMTP_OUT.Length == 7)
                                    {                                      
                                        alQueue_OVH.Add(alSMTP_OUT[5]);
                                        alAge_OVH.Add(alSMTP_OUT[6]);
                                    }
                                    else
                                    {
                                        // Nullen toevoegen om array's in sync te houden
                                        alQueue_OVH.Add(0);
                                        alAge_OVH.Add(0);
                                    }
                                }
                            }
                            else // de "gewone" recht op en neer weergave
                            {
                                alServer_OVH.Add(alSMTP_OUT[1]);
                                alCheckTime_OVH.Add(alSMTP_OUT[3]);
                                alBedrijf_OVH.Add(alSMTP_OUT[4]);
                                if (alSMTP_OUT.Length == 7)
                                {                                    
                                    alQueue_OVH.Add(alSMTP_OUT[5]);
                                    alAge_OVH.Add(alSMTP_OUT[6]);
                                }
                                else
                                {
                                    // Nullen toevoegen om array's in sync te houden
                                    alQueue_OVH.Add(0);
                                    alAge_OVH.Add(0);
                                }
                            }
                        }
                    }
                    else
                    {
                        show_data_columns_error("SMTPQ", strQueueData);
                        return;
                    }
                }
                srQueue.Close();

                /////////////////////////////////////////////////////////////////////////////
                // Als de "Queuedata recording" aanstaat &
                // bRecordSMTPLog staat aan ( er is iets gewijzigd t.o.v. de vorige refresh )
                /////////////////////////////////////////////////////////////////////////////
                if (bRecordSMTPLog || bRecordSMTP_BDR_Log_INIT || bRecordSMTP_OVH_Log_INIT)
                {
                    bRecordSMTP_BDR_Log_INIT = false;
                    bRecordSMTP_OVH_Log_INIT = false;
                    foreach (string strSMTPLog_Record in alSMTP_Shadow_tab)
                    {
                        Save_Log_Record(strSMTPLog_Record.Split('~')[2], strSMTPLog_Record);
                    }
                }

                /////////////////////////////////////////////////////////////////////////////////
                // Datagrids vullen
                ////////////////////////////////////////////////////////////////////////////////

                // *********
                // BEDRIJVEN
                // *********
                intAL_BDR = 0;

                dgSMTPQ_BDR.Rows.Clear();
                while (intAL_BDR < alBedrijf_BDR.Count)
                {
                    int intNewRow = dgSMTPQ_BDR.Rows.Add();
                    dgSMTPQ_BDR[0, intNewRow].Value = alServer_BDR[intAL_BDR];
                    dgSMTPQ_BDR[3, intNewRow].Value = alBedrijf_BDR[intAL_BDR];
                    if (Convert.ToInt32(alQueue_BDR[intAL_BDR]) > 0)
                    {
                        dgSMTPQ_BDR[1, intNewRow].Value = Convert.ToInt32(alQueue_BDR[intAL_BDR]);
                        dgSMTPQ_BDR[2, intNewRow].Value = alCheckTime_BDR[intAL_BDR];
                        dgSMTPQ_BDR[4, intNewRow].Value = clDashFunction.fromS2DHMS(Convert.ToDouble(alAge_BDR[intAL_BDR]), false);
                    }
                    else
                    {
                        dgSMTPQ_BDR[1, intNewRow].Value = 0;
                        dgSMTPQ_BDR[2, intNewRow].Value = alCheckTime_BDR[intAL_BDR];
                        dgSMTPQ_BDR[4, intNewRow].Value = "";
                    }
                    intQueue_BDR = intQueue_BDR + Convert.ToInt32(dgSMTPQ_BDR[1, intNewRow].Value);

                    intAL_BDR++;
                }

                /////////////////////////////
                // TREND
                /////////////////////////////
                lbSMTPQ_BDR.Items.Add(intQueue_BDR); // hulpconstructie voor trendberekening


                if (lbSMTPQ_BDR.Items.Count > 5)
                {
                    lbSMTPQ_BDR.Items.RemoveAt(0);
                }

                    
                        int intSeli = 0;
                        int intTrend = 0;
                        while (intSeli < lbSMTPQ_BDR.Items.Count)
                        {
                            lbSMTPQ_BDR.SelectedIndex = intSeli;
                            intTrend = intTrend + Convert.ToInt32(lbSMTPQ_BDR.Text);
                            intSeli++;
                        }
                        intTrend = intTrend / lbSMTPQ_BDR.Items.Count;
                        debug("Gemiddeld: " + intTrend.ToString(),false);
                 
                // Als er geen messages gequeued zijn, dan de "aantal domains" variabele ook naar 0
                // anders worden de "No messages" regels wel als zodanig geteld.
                if (intQueue_BDR == 0)
                {
                    intAL_BDR = 0;
                }

                lblMsgs_BDR.Text = intQueue_BDR + " message(s), " + intAL_BDR + " domain(s)";
                
                // Trendgrafiek bijwerken
                pnSMTPQ_BDR.Controls.Add(Get_SMTPQ_BDR_Chart());

                // *********
                // OVERHEDEN
                // *********
                intAL_OVH = 0;

                dgSMTPQ_OVH.Rows.Clear();
                while (intAL_OVH < alBedrijf_OVH.Count)
                {
                    int intNewRow = dgSMTPQ_OVH.Rows.Add();
                    dgSMTPQ_OVH[0, intNewRow].Value = alServer_OVH[intAL_OVH];
                    dgSMTPQ_OVH[3, intNewRow].Value = alBedrijf_OVH[intAL_OVH];
                    if (Convert.ToInt32(alQueue_OVH[intAL_OVH]) > 0)
                    {
                        dgSMTPQ_OVH[1, intNewRow].Value = Convert.ToInt32(alQueue_OVH[intAL_OVH]);
                        dgSMTPQ_OVH[2, intNewRow].Value = alCheckTime_OVH[intAL_OVH];
                        dgSMTPQ_OVH[4, intNewRow].Value = clDashFunction.fromS2DHMS(Convert.ToDouble(alAge_OVH[intAL_OVH]), false);
                    }
                    else
                    {
                        dgSMTPQ_OVH[1, intNewRow].Value = 0;
                        dgSMTPQ_OVH[2, intNewRow].Value = alCheckTime_OVH[intAL_OVH];
                        dgSMTPQ_OVH[4, intNewRow].Value = "";
                    }
                    intQueue_OVH = intQueue_OVH + Convert.ToInt32(dgSMTPQ_OVH[1, intNewRow].Value);

                    intAL_OVH++;
                }

                //Als er geen messages gequeued zijn, dan de "aantal domains" variabele ook naar 0
                //anders worden de "No messages" regels wel als zodanig geteld.
                if (intQueue_OVH == 0)
                {
                    intAL_OVH = 0;
                }

                lblMsgs_OVH.Text = intQueue_OVH + " message(s), " + intAL_OVH + " domain(s)";
            }
            else
            {              
                debug("No update: fout bij openen SMTP inputfile",true);
                // clDashFunction.Melding("File " + strQueueData + " does not exist ");
            }
        }

        private void get_Core_queues(string strQueueData)
        {
            string strCore_OUT_rec;
            int intCoreRowNo = 0;
            int intNewRow = 0;
            int[] intCoreTotals = new int[2];
            int[] intCoreOldestRowNo = new int[2];
            string[] strCoreOldest = new string[2];
            Boolean bRecordCoreLog = false;
            pnlCore1.Visible = false;
            pnlCore2.Visible = false;

            intCoreOldestRowNo[0] = -1;
            intCoreOldestRowNo[1] = -1;
            strCoreOldest[0] = "9999-99-9999:99:99.999999999";
            strCoreOldest[1] = "9999-99-9999:99:99.999999999";

            StreamReader srQueue = clDashFunction.open4read(strQueueData);
            if (srQueue != null)
            {
                // Alleen datagrid opschonen als suc6 vol een file is geopend om het opnieuw
                // te vullen, anders zitten we misschien tegen een zwart datagrid aan te kijken
                dgCoreQ.Rows.Clear();
                
                while (!srQueue.EndOfStream)
                {
                    strCore_OUT_rec = srQueue.ReadLine();

                    /////////////////////
                    //Shadowtabel prutsel 
                    ////////////////////
                    if (alCore_Shadow_tab.Count <= intCoreRowNo)
                    {
                        alCore_Shadow_tab.Add("");
                    }
                    if (alCore_Shadow_tab[intCoreRowNo].ToString() != strCore_OUT_rec)
                    {
                        bRecordCoreLog = true;
                    }
                    alCore_Shadow_tab[intCoreRowNo] = strCore_OUT_rec;
                    intCoreRowNo++;
                    //////////////////////////
                    // End Shadowtabel prutsel
                    //////////////////////////

                    // Split inputrecord into separate fields
                    string[] alCore = Regex.Split(strCore_OUT_rec, "~");

                    if (alCore.Length > 3)
                    {
                        if (alCore[2] == strSMTP_from_bedrijven || alCore[2] == strX400_from_overheden)
                        {
                            intNewRow = dgCoreQ.Rows.Add();
                            dgCoreQ[0, intNewRow].Value = alCore[1]; // Server
                            dgCoreQ[1, intNewRow].Value = alCore[2]; // Protocol

                            // Als Queue aantal groter of gelijk is aan 0 handel dan 'normaal' af en
                            // ga dan het aantal in het grid zetten en kleuren
                            if (Convert.ToInt32(alCore[4]) >= 0)
                            {
                                dgCoreQ[2, intNewRow].Value = Convert.ToInt32(alCore[4]); // # Queue

                                if (Convert.ToInt32(alCore[4]) == 0)
                                {
                                    dgCoreQ.Rows[intNewRow].DefaultCellStyle.BackColor = clQueue_no;
                                }

                                if (Convert.ToInt32(alCore[4]) > 0)
                                {
                                    dgCoreQ.Rows[intNewRow].DefaultCellStyle.BackColor = clQueue_yes;
                                }
                               
                            }
                            // Als het Queue aantal kleiner is dan 0 dan is er een fout opgetreden in het
                            // onderliggende script op Linux bij het bepalen van grootte en ouderdom
                            // berichten in de queue ( ik heb wel ???'kens gezien in het resultaat van een ls
                            else
                            {
                                dgCoreQ[2, intNewRow].Value = "Error";
                                dgCoreQ.Rows[intNewRow].DefaultCellStyle.BackColor = clQueue_error;
                                debug("Error in Core inputdata",true);                                
                            }

                            dgCoreQ[3, intNewRow].Value = alCore[3]; // Age
                            if (alCore.Length > 7)
                            {
                                dgCoreQ[4, intNewRow].Value = clDashFunction.fromS2DHMS(Convert.ToDouble(alCore[6]), true); // Oldest
                                dgCoreQ[5, intNewRow].Value = clDashFunction.fromS2DHMS(Convert.ToDouble(alCore[8]), true); // Newest
                            }

                            switch (alCore[2])
                            {
                                case strSMTP_from_bedrijven:
                                    
                                    intCoreTotals[0] = intCoreTotals[0] + Convert.ToInt32(alCore[4]);
                                    
                                    if ( alCore[5].CompareTo(strCoreOldest[0]) < 0)
                                    {
                                        strCoreOldest[0] = alCore[5];    
                                        intCoreOldestRowNo[0] = intNewRow;
                                    }
                                    break;

                                case strX400_from_overheden:
                                    intCoreTotals[1] = intCoreTotals[1] + Convert.ToInt32(alCore[4]);
                                    if (alCore[5].CompareTo(strCoreOldest[1]) < 0)
                                    {
                                        strCoreOldest[1] = alCore[5];
                                        intCoreOldestRowNo[1] = intNewRow;
                                    }
                                    break;

                                default:
                                    clDashFunction.Melding("Onbekend protocol type: "+ alCore[2] + " in functie: get_Core_queues", 1, "I");
                                break;
                             }
                        }
                                               
                        if (intCoreTotals[0] > 0)
                        {
                            lblCoreTotal1.Text = intCoreTotals[0].ToString("#,#") + "  ( " + strSMTP_from_bedrijven + " )";
                            lblCoreOldest1.Text = dgCoreQ[4, intCoreOldestRowNo[0]].Value.ToString();
                            pnlCore1.Visible = true;
                        }
                        
                        if (intCoreTotals[1] > 0)
                        {
                            lblCoreTotal2.Text =  intCoreTotals[1].ToString("#,#") + "  ( "+strX400_from_overheden + " )";
                            lblCoreOldest2.Text = dgCoreQ[4, intCoreOldestRowNo[1]].Value.ToString();
                            pnlCore2.Visible = true;
                        }                        
                    }
                    else
                    {
                        show_data_columns_error("CoreQ", strQueueData);
                        return;
                    }
                }
                srQueue.Close();

                 /////////////////////////////////////////////////////////////////////////////
                // Als de "Queuedata recording" aanstaat &
                // bRecordCoreLog staat aan ( er is iets gewijzigd t.o.v. de vorige refresh )
                /////////////////////////////////////////////////////////////////////////////
                if (bRecordCoreLog || bRecordCoreLog_INIT)
                {
                    bRecordCoreLog_INIT = false;
                    foreach (string strCoreLog_Record in alCore_Shadow_tab)
                    {

                        Save_Log_Record(strCoreLog_Record.Split('~')[2], strCoreLog_Record);
                    }
                }
            }
            else
            {
                debug("No update: fout bij openen Core inputfile",true);
            }
        }
        
        private void get_X400_queues(string strQueueData)
        {
            string strX400_OUT_rec;
            int intX400RowNo = 0;
            Boolean bRecordX400Log = false;

            StreamReader srQueue = clDashFunction.open4read(strQueueData);
            if (srQueue != null)
            {
                // Alleen datagrid opschonen als suc6 vol een file is geopend om het opnieuw
                // te vullen, anders zitten we misschien tegen een zwart datagrid aan te kijken
                dgX400Q_OVH.Rows.Clear();
                dgX400Q_BDR.Rows.Clear();

                while (!srQueue.EndOfStream)
                {
                    strX400_OUT_rec = srQueue.ReadLine();

                    /////////////////////
                    //Shadowtabel prutsel 
                    ////////////////////
                    if (alX400_Shadow_tab.Count <= intX400RowNo)
                    {                        
                        alX400_Shadow_tab.Add("");
                    }
                    if (alX400_Shadow_tab[intX400RowNo].ToString() != strX400_OUT_rec)
                    {
                        bRecordX400Log = true;
                    }
                    alX400_Shadow_tab[intX400RowNo] = strX400_OUT_rec;
                    intX400RowNo++;
                    //////////////////////////
                    // End Shadowtabel prutsel
                    //////////////////////////


                    string[] alX400Q = Regex.Split(strX400_OUT_rec, "~");

                    if (alX400Q.Length > 3)
                    {
                        //////////////////
                        // Bedrijven X400
                        //////////////////
                        if (alX400Q[2] == strX4002Bedrijven)
                        {
                            Save_Log_Record(strX4002Bedrijven, strX400_OUT_rec);

                            int intNewRow = dgX400Q_BDR.Rows.Add();
                            dgX400Q_BDR[0, intNewRow].Value = alX400Q[1]; // Server
                            dgX400Q_BDR[1, intNewRow].Value = Convert.ToInt32(alX400Q[4]); // # Queue
                            if (Convert.ToInt32(alX400Q[4]) > 0)
                            {
                                dgX400Q_BDR.Rows[intNewRow].DefaultCellStyle.BackColor = clQueue_yes;
                            }
                            else
                            {
                                dgX400Q_BDR.Rows[intNewRow].DefaultCellStyle.BackColor = clQueue_no;
                            }
                            dgX400Q_BDR[2, intNewRow].Value = alX400Q[3]; // Time
                            if (alX400Q.Length > 6)
                            {
                                dgX400Q_BDR[3, intNewRow].Value = clDashFunction.fromS2DHMS(Convert.ToDouble(alX400Q[6]), true); // Oldest
                                dgX400Q_BDR[4, intNewRow].Value = clDashFunction.fromS2DHMS(Convert.ToDouble(alX400Q[8]), true); // Newest
                            }
                        }

                        //////////////////
                        // Overheden X400
                        //////////////////
                        if (alX400Q[2] == strX4002Overheden)
                        {
                            Save_Log_Record(strX4002Overheden, strX400_OUT_rec);

                            int intNewRow = dgX400Q_OVH.Rows.Add();
                            dgX400Q_OVH[0, intNewRow].Value = alX400Q[1]; // Server
                            dgX400Q_OVH[1, intNewRow].Value = Convert.ToInt32(alX400Q[4]); // # Queue
                            if (Convert.ToInt32(alX400Q[4]) > 0)
                            {
                                dgX400Q_OVH.Rows[intNewRow].DefaultCellStyle.BackColor = clQueue_yes;
                            }
                            else
                            {
                                dgX400Q_OVH.Rows[intNewRow].DefaultCellStyle.BackColor = clQueue_no;
                            }
                            dgX400Q_OVH[2, intNewRow].Value = alX400Q[3]; // Time
                            if (alX400Q.Length > 6)
                            {
                                dgX400Q_OVH[3, intNewRow].Value = clDashFunction.fromS2DHMS(Convert.ToDouble(alX400Q[6]), true); // Oldest
                                dgX400Q_OVH[4, intNewRow].Value = clDashFunction.fromS2DHMS(Convert.ToDouble(alX400Q[8]), true); // Newest
                            }
                        }
                    }
                    else
                    {
                        show_data_columns_error("X400Q", strQueueData);
                        return;
                    }
                }
                srQueue.Close();

                /////////////////////////////////////////////////////////////////////////////
                // Als de "Queuedata recording" aanstaat &
                // bRecordX400Log staat aan ( er is iets gewijzigd t.o.v. de vorige refresh )
                /////////////////////////////////////////////////////////////////////////////
                if (bRecordX400Log || bRecordX400_OVH_Log_INIT)
                {
                    bRecordX400_OVH_Log_INIT = false;
                    foreach (string strX400Log_Record in alX400_Shadow_tab)
                    {

                        Save_Log_Record(strX400Log_Record.Split('~')[2], strX400Log_Record);
                    }
                }
            }
            else
            {
                debug("No update: fout bij openen X400 inputfile",true);
            }
        }

        private void show_data_columns_error(string strKind, string strQueueData)
        {
            clDashFunction.Melding(strKind + " data record does not have the appropriate number of columns !" +
                      System.Environment.NewLine + System.Environment.NewLine +
                      "( " + strQueueData + ")" +
                       System.Environment.NewLine + System.Environment.NewLine +
                      "This file will NOT be processed !", 1, "E");
        }
                
        private void auto_update_start()
        {     
            
            // lblRefresh_till_refresh.Text = "(Started)";
            lblRefresh_till_refresh.Visible = true;
            lblRefresh_last_refresh.Visible = true;
            lblUpdate_Script_txt.Visible = true;
            lblUpdate_Script_val.Visible = true;           
           
            cmdConfigureSave.Enabled = true;

            // Eerst alles éénmalig uitvoeren om direct actuele data te zien..
            tmrSMTPQ_Tick(new object(), new EventArgs());
            tmrCoreQ_Tick(new object(), new EventArgs());
            tmrX400Q_Tick(new object(), new EventArgs());
            tmrRefresh_Tick(new object(), new EventArgs());

            // En daarna op het ritme van de timers      
            start_timers();
        }

        private void auto_update_stop()
        {
            Boolean bStopSave = false;

            if (bSaveStarted)
            {
                if (swSaveFile != null)
                {
                    if (clDashFunction.Melding("Queuedata recording is currently active and will be cancelled, Are you sure ?", 4, "Q") == DialogResult.Yes)
                    {
                        bStopSave = true;
                    }
                    else
                    {
                        // Toch maar niet..
                        rbAutoUpdateOn.Checked = true;
                    }
                }
            }
            else
            {
                bStopSave = true;
            }
            if (bStopSave)
            {
                stop_timers();
                // lblRefresh.Text = "(Stopped)";
                lblRefresh_till_refresh.Text = "";
                lblRefresh_last_refresh.Text = "";
                //lblUpdate_Script_txt.Text = "";
                //lblUpdate_Script_val.Text = "";
                
                lblRefresh_till_refresh.Visible = false;
                lblRefresh_last_refresh.Visible = false;
                lblUpdate_Script_txt.Visible = false;
                lblUpdate_Script_val.Visible = false;
              
                cmdSaveStop_Click(new object(), new EventArgs());
            }
        }

        private void start_timers()
        {
            tmrSeconds.Start();
            /////////////////////////////////////////////////////////////////////
            // LET OP:
            // de CoreQ 
            //    en
            // de X400 
            // timers worden "getrapt" gestart vanuit de SMTPQ timer !!!
            //////////////////////////////////////////////////////////////////////
            tmrSMTPQ.Start();
            b_tmrSMTPq_started = true;

            tmrRefresh.Start();
        }

        private void stop_timers()
        {
            tmrSeconds.Stop();
            tmrSMTPQ.Stop();
            b_tmrSMTPq_started = false;
            tmrCoreQ.Stop();
            b_tmrCoreq_started = false;
            tmrX400Q.Stop();
            b_tmrX400q_started = false;
            tmrRefresh.Stop();
            // cbAutoUpdateOff.Enabled = false;
            cmdConfigureSave.Enabled = false;
            // grbSaveData.Enabled = false;
            // cbAutoUpdateOn.Enabled = !cbAutoUpdateOff.Enabled;
            // cbAutoUpdateOn.Checked = !cbAutoUpdateOff.Checked;
        }

        private void tmrSMTPQ_Tick(object sender, EventArgs e)
        {
            // alleen script vanaf deze app zelf triggeren als strUpdateScript <> "SERVER"
            // Anders wordt verondersteld dat er wel ergens anders op een server een script draait
            // en hoeven we alleen daar de output van op te halen
            if (strUpdateScript.ToUpper() != mdiDashboard.strServer.ToUpper() ) 
            {
              clDashFunction.do_wincmd(strQueueCMD_SMTP, "", true);
            }
            if (!b_tmrCoreq_started) { tmrCoreQ.Start(); b_tmrCoreq_started = true; }
       }

        private void tmrCoreQ_Tick(object sender, EventArgs e)
        {
            // alleen script vanaf deze app zelf triggeren als strUpdateScript <> "SERVER"
            // Anders wordt verondersteld dat er wel ergens anders op een server een script draait
            // en hoeven we alleen daar de output van op te halen
            if (strUpdateScript.ToUpper() != "ServeR".ToUpper())
            {
                clDashFunction.do_wincmd(strQueueCMD_Core, "", true);
            }
            if (!b_tmrX400q_started) { tmrX400Q.Start(); b_tmrX400q_started = true; }
        }

        private void tmrX400Q_Tick(object sender, EventArgs e)
        {
            // alleen script vanaf deze app zelf triggeren als strUpdateScript <> "SERVER"
            // Anders wordt verondersteld dat er wel ergens anders op een server een script draait
            // en hoeven we alleen daar de output van op te halen
            if (strUpdateScript.ToUpper() != "ServeR".ToUpper())
            {
                clDashFunction.do_wincmd(strQueueCMD_X400, "", true);
            }
        }

        private void tmrRefresh_Tick(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
           
            lblRefresh_last_refresh.Text = LastRefresh();
            lblRefresh_till_refresh.Tag = (tmrRefresh.Interval / 1000).ToString();
            lblRefresh_till_refresh.Text = NextRefresh(lblRefresh_till_refresh, 0);

            debug("Timer triggered: " + System.DateTime.Now, false);
            refresh_queuedata();
            
            this.Cursor = Cursors.Default;
        }

        private void tmrSeconds_Tick(object sender, EventArgs e)
        {    
            lblRefresh_till_refresh.Text = NextRefresh(lblRefresh_till_refresh);

            doSaveInd();
        }

        private void doSaveInd( )
        {
            
        }

        private void cmdConfigureSave_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            frmDashQueueRec frmQueueRec = new frmDashQueueRec();
            frmQueueRec.strQueueData_Path = strQueueData_Path;
            frmQueueRec.strRecordFile_val = strSaveFile_Name;
            frmQueueRec.bLog_SMTPQ_BDR = b_SMTPq_BDR_SaveStarted;
            frmQueueRec.bLog_SMTPQ_OVH = b_SMTPq_OVH_SaveStarted;
            frmQueueRec.bLog_CoreQ = b_Coreq_SaveStarted;
            frmQueueRec.bLog_X400Q_OVH = b_X400q_OVH_SaveStarted;
            frmQueueRec.bLog_X400Q_BDR = b_X400q_BDR_SaveStarted;
            frmQueueRec.bRecordQueueOnly = bRecordQueueOnly;
            frmQueueRec.bRecordErrors = bRecordErrors;

            frmQueueRec.ShowDialog();
            if (!frmQueueRec.bCancelled)
            {
                bSaveStarted = true;

                // Gekozen logcriteria in variabelen frommelen.
                bRecordQueueOnly = frmQueueRec.bRecordQueueOnly;
                bRecordErrors = frmQueueRec.bRecordErrors;
                bRecordSMTP_BDR_Log_INIT = b_SMTPq_BDR_SaveStarted = frmQueueRec.bLog_SMTPQ_BDR;
                bRecordCoreLog_INIT = b_Coreq_SaveStarted = frmQueueRec.bLog_CoreQ;
                bRecordX400_OVH_Log_INIT = b_X400q_OVH_SaveStarted = frmQueueRec.bLog_X400Q_OVH;
                bRecordX400_BDR_Log_INIT = b_X400q_BDR_SaveStarted = frmQueueRec.bLog_X400Q_BDR;

                // Resume bestaande logfile ?
                if ((strSaveFile_Name != frmQueueRec.strRecordFile_val)
                || (strSaveFile_Name == "" && frmQueueRec.strRecordFile_val != ""))
                {
                    strSaveFile_Name = frmQueueRec.strRecordFile_val;
                    Start_save(strSaveFile_Name, true);
                }
                else
                {
                    // Begin met een nieuwe
                    Start_save(strSaveFile_Name, false);
                }
            }
            //else
            //{
            //     clDashFunction.Melding("Queuedata recording has been cancelled", 1, "I");
            //}
            this.Cursor = Cursors.Default;
        }

        private void Start_save(string strSaveFile_Name, Boolean bOpenNewSaveFile)
        {
            // Hier alleen de filename met wat punten ervoor. Als het path eraan is
            // vastgeplakt past de gehele waarde mogelijk niet op het form(deel)
            lblSaveFile.Text = "Saving to: ...../"+System.IO.Path.GetFileName(strSaveFile_Name);

            // Stoppen moet voortaan altijd kunnen als er een Save/Record actie actief is
            cmdSaveStop.Enabled = true;


            // Er moet een nieuwe file worden geopend
            if (bOpenNewSaveFile)
            {
                // Bestaande eerst sluiten
                if (swSaveFile != null)
                {
                    swSaveFile.Close();
                }

                // Open nieuwe
                swSaveFile = clDashFunction.open4write(strSaveFile_Name);
                swSaveFile.WriteLine("*** Start logging (" + System.DateTime.Now + ") ***");
            }
            else
            {
                swSaveFile.WriteLine("*** Resume logging (" + System.DateTime.Now + ") ***");
            }

        }

        private void cmdSaveStop_Click(object sender, EventArgs e)
        {
            Reset_Save_Vars();
            cmdSaveStop.Enabled = false;
        }


        // Aftellen van het aantal seconden voordat een
        // volgende refresh gaat plaatsvinden. Het control
        // waarover het gaat wordt als Parm meegegeven.
        // Note: we ge/mis/bruiken het Tag attribute om te tellen
        private string NextRefresh(Control cLabel, Int16 intSubtractSecs)
        {
            cLabel.Tag = Convert.ToInt32(cLabel.Tag) - intSubtractSecs;
            return "Next refresh within " + cLabel.Tag + " secs";
        }
        // Effe overloaden voor de default keuze ( = -1 seconden )
        private string NextRefresh(Control cLabel)
        {
            return NextRefresh(cLabel, 1);
        }

        // Teruggeven van een (STD) tekst string met daarin een timestamp
        private string LastRefresh()
        {
            return "Last refresh: " + System.DateTime.Now.ToLongTimeString();
        }

        private void dgSMTPQ_BDR_SelectionChanged(object sender, EventArgs e)
        {
            dgSMTPQ_BDR.CurrentRow.Selected = false;
        }

        private void dgSMTPQ_OVH_SelectionChanged(object sender, EventArgs e)
        {
            dgSMTPQ_OVH.CurrentRow.Selected = false;
        }

        private void dgCoreQ_SelectionChanged(object sender, EventArgs e)
        {
            dgCoreQ.CurrentRow.Selected = false;
        }

        private void dgX400Q_OVH_SelectionChanged(object sender, EventArgs e)
        {
            dgX400Q_OVH.CurrentRow.Selected = false;
        }

        private void cmdAfsluiten_Click_1(object sender, EventArgs e)
        {
            // Als de Queuedata recording nog actief is, dan deze beëindigen.
            if (bSaveStarted)
            {
                cmdSaveStop_Click(new object(), new EventArgs());
            }
        }

        private void Save_Log_Record(string strId, string strLogRecord)
        {
            if (swSaveFile != null)
            {
                switch (strId.ToUpper())
                {
                    case "SMTP_OUT_BDR":
                        {
                            if (b_SMTPq_BDR_SaveStarted)
                            {
                                Write_Log_Record(strLogRecord, 4);                               
                            }
                        }
                        break;

                    case "SMTP_OUT_OVH":
                        if (b_SMTPq_OVH_SaveStarted)
                        {
                            Write_Log_Record(strLogRecord, 4);  
                        }
                        break;

                    case "SMTP_IN_BDR":
                        if (b_Coreq_SaveStarted)
                        {
                            Write_Log_Record(strLogRecord, 3);  
                        }
                        break;

                    case "X400_IN_OVH":
                        if (b_Coreq_SaveStarted)
                        {
                            Write_Log_Record(strLogRecord, 3);  
                        }
                        break;

                    case "X400_OUT_OVH":
                        if (b_X400q_OVH_SaveStarted)
                        {
                            Write_Log_Record(strLogRecord, 3);  
                        }
                        break;
                    
                    case "X400_OUT_BDR":
                        if (b_X400q_BDR_SaveStarted)
                        {                           
                            Write_Log_Record(strLogRecord, 3);  
                        }
                        break;
                    default:
                        clDashFunction.Melding("Onbekend ID:" + strId, 1, "E");
                        break;
                }
            }
        }
        private void Write_Log_Record(string strLogRecord, int intFields)
        {
            int intQueueIndex = intFields+1;
            if ((strLogRecord.Split('~').Length - 1) > intFields)
                                {
                                    if (!bRecordQueueOnly || (bRecordQueueOnly && Convert.ToInt32(strLogRecord.Split('~')[intQueueIndex]) > 0))
                                    {
                                        swSaveFile.WriteLine(strLogRecord);
                                                        }
                                    if (bRecordErrors && Convert.ToInt32(strLogRecord.Split('~')[intQueueIndex]) == -1)
                                    {   
                                        swSaveFile.WriteLine(strLogRecord.Replace(strResponse,"Error"));
                                    }
                                }
        }

        private void Reset_Save_Vars()
        {
            if (File.Exists(strSaveFile_Name))
            {
                if (swSaveFile != null)
                {
                    swSaveFile.WriteLine("*** Stop logging (" + System.DateTime.Now + ") ***");
                    swSaveFile.Close();
                    swSaveFile = null;
                }
            }
            lblSaveFile.Text = "";
            strSaveFile_Name = "";
            b_SMTPq_BDR_SaveStarted = false;
            b_SMTPq_OVH_SaveStarted = true;
            b_Coreq_SaveStarted = true;
            b_X400q_OVH_SaveStarted = true;
            b_X400q_BDR_SaveStarted = false;
            bRecordQueueOnly = true;
            bRecordErrors = true;
            bSaveStarted = false;
        }

        private Boolean isDataChanged(string strAgeFirstRow, string strAgeLastRow, ArrayList alAge_BDR)
        {
            // Om overbodig werk en dubbele logrecords te voorkomen:
            // Controle of er wel refreshed en naar de externe logfile moet worden geschreven.
            // Dit wordt gedaan door te zien of 
            // - het aantal bestaande rijen gelijk is aan het aantal rows in de (nieuwe)Age array
            // - EN of de AGE van het eerste EN laatste record gelijk is tussen het datagrid en de Age array
            Boolean bRefresh = true;

            if (dgSMTPQ_BDR.Rows.Count == alAge_BDR.Count)
            {
                if (dgSMTPQ_BDR[4, 0].Value.ToString() == clDashFunction.fromS2DHMS(Convert.ToDouble(alAge_BDR[0]), false).ToString())
                {
                    if (dgSMTPQ_BDR[4, alAge_BDR.Count - 1].Value.ToString() == clDashFunction.fromS2DHMS(Convert.ToDouble(alAge_BDR[alAge_BDR.Count - 1]), false).ToString())
                    {
                        bRefresh = false;
                    }
                }
            }
            return bRefresh;
        }      

        private void dgX400Q_BDR_SelectionChanged(object sender, EventArgs e)
        {
            dgX400Q_BDR.CurrentRow.Selected = false;
        }
                
        private void rbAutoUpdateOff_CheckedChanged(object sender, EventArgs e)
        {
            if (rbAutoUpdateOff.Checked)
            {
                auto_update_stop();
            }
        }

        private void rbAutoUpdateOn_CheckedChanged(object sender, EventArgs e)
        {
            if (rbAutoUpdateOn.Checked)
            {
                auto_update_start();
            }
        }

        private void cmbGroupSMTP_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbGroupSMTP.SelectedIndex != -1)
            {
             check_SMTP_OUT(strQueueData_SMTP);
             get_SMTP_OUT_queues(strQueueData_SMTP);
            }
        }

        private void cmdDebug_Click(object sender, EventArgs e)
        {
            debug("RESET", false);            
        }

        private void cmdManualUpdate_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            debug("Manual triggered: " + System.DateTime.Now, false);
            refresh_queuedata();

            this.Cursor = Cursors.Default;
        }

        private void debug(string strMessage, Boolean bError)
        {
            if (strMessage.ToUpper() == "RESET".ToUpper())
            {
                lbDebug.Items.Clear();
                debug_error(true);
            }
            else
            {
                lbDebug.Items.Insert(0, strMessage);
                // lbDebug.Items.Add(strMessage);
                if (bError)
                {
                    debug_error(false);
                }
            }
        }

        private void debug_error(Boolean bReset)
        {
            if (bReset)
            {
                intDebugErrors = 0;
            }
            else
            {
                intDebugErrors++;
            }
            lblDebugError_val.Text = Convert.ToString(intDebugErrors);
        }
                
        private Chart Get_SMTPQ_BDR_Chart()
        {
            Chart chart = null;
            
            try
            {
                pnSMTPQ_BDR.Controls.Clear();

                DataTable dt = new DataTable();
                dt.Columns.Add("Queuesize", typeof(int));
                                
                int i = 0;
                while (i < lbSMTPQ_BDR.Items.Count)
                {
                    lbSMTPQ_BDR.SelectedIndex = i;

                    dt.Rows.Add(Convert.ToInt32(lbSMTPQ_BDR.Text));
                    i++;
                }
                WindowsCharting charting = new WindowsCharting();
                
                chart = charting.GenerateChart(dt, pnSMTPQ_BDR.Width, pnSMTPQ_BDR.Height, "FloralWhite", 3);
            }
            catch (Exception exp)
            {
                throw exp;
            }
            finally
            {
                //do nothing
            }
            return chart;
        }

        private void rbDGSMTPQ_BEDR_CheckedChanged(object sender, EventArgs e)
        {
            if (rbDGSMTPQ_BEDR.Checked)
            {
                pnSMTPQ_BDR.Visible = !rbDGSMTPQ_BEDR.Checked;
                dgSMTPQ_BDR.Visible = rbDGSMTPQ_BEDR.Checked;
            }
        }

        private void rbPNSMTPQ_BEDR_CheckedChanged(object sender, EventArgs e)
        {
            if (rbPNSMTPQ_BEDR.Checked)
            {
                pnSMTPQ_BDR.Visible = rbPNSMTPQ_BEDR.Checked;
                dgSMTPQ_BDR.Visible = !rbPNSMTPQ_BEDR.Checked;
            }
        }            
    }
}


