﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace dbDashboard
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] strStartup_parms)
        {
           // try
           // {
               Application.EnableVisualStyles();
               Application.SetCompatibleTextRenderingDefault(false);
               Application.Run(new mdiDashboard(strStartup_parms));
          /* }
           catch (Exception e)
           {               
               clDashFunction.Melding("De applicatie wordt beëindigd. (" + e.Message + ")", 1, "E");
           } */
        }        
    }
}
