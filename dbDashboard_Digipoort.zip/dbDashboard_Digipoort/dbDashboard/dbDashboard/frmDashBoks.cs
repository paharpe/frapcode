﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text.RegularExpressions;
using System.IO;
using System.Windows.Forms;

namespace dbDashboard
{
    public partial class frmDashBoks : Form
    {
        ArrayList alDirFile = new ArrayList(2);
        String strPuttyPlLoca_val;
        string strPuttyPlLoca_ts;
        Boolean bInitOk;

        public frmDashBoks()
        {
            InitializeComponent();
        }

        private void frmDashBoks_Load(object sender, EventArgs e)
        {
            bInitOk = frm_init();
            bInputCheck();
        }

        private Boolean frm_init()
        {

            Boolean bReturn = false;

            // **********************************************
            // Remove bepaalde controls vanuit het base form
            // **********************************************
            clDashFunction.remove_inherited_control(this, "toolstrip1");

            string strRef = "Ref: Tabel: 10 - Elm: PUTTYPLLOCA";
            
            if (mdiDashboard.strPutty_Plink_Loca != "")
            {

                alDirFile = clDashFunction.get_dir_file(mdiDashboard.strPutty_Plink_Loca);
                
                DoSql mySql = new DoSql();

                able_controls(false);

                /////////////////////////
                // Prepare 4 SQL version 
                /////////////////////////
                mySql.vul_deze_text1_array[1] = "FTA";

                mySql.DoQuery("SELECT ElemElem, ElemOms1,ElemMdat & ElemMtyd " +
                               "FROM   DashElem " +
                               "WHERE  ElemTabn = 10 " +
                               "AND    ElemElem = 'PUTTYPLCRED'");

                if (mySql.affected_rows < 1)
                {
                    clDashFunction.Melding("No 'Putty / Plink' settings found in table 10 " +
                    "\n\n " + strRef, 1, "E");
                }
                else
                {
                    strPuttyPlLoca_val = mySql.vul_deze_text2_array[1];
                    string[] strarPuttyPlLoca = Regex.Split(strPuttyPlLoca_val, " ");

                    if (strarPuttyPlLoca.Length == 4)
                    {
                        if (strarPuttyPlLoca[0] == "-l")
                        {
                            txtBoksSQLUser.Text = strarPuttyPlLoca[1].ToString();
                            txtNewUser.Text = strarPuttyPlLoca[1].ToString();

                            if (strarPuttyPlLoca[2] == "-pw")
                            {
                                txtBoksSQLPassword.Text = strarPuttyPlLoca[3].ToString();
                            }
                        }
                    }

                    strPuttyPlLoca_ts = mySql.vul_deze_text3_array[1];

                    ClearChangedStatus(grbNewVal);
                }


                //////////////////////////////
                // Prepare 4 TEXTfile version 
                //////////////////////////////
                if (!Directory.Exists(alDirFile[1].ToString()))
                {
                    clDashFunction.Melding("Boks passwordfile directory : " + alDirFile[1].ToString() +
                    "\n\n does not exist ! \n\n " + strRef, 1, "E");
                }
                else
                {
                    if (!File.Exists(mdiDashboard.strPutty_Plink_Loca))
                    {
                        clDashFunction.Melding("Boks passwordfile: " + mdiDashboard.strPutty_Plink_Loca +
                        "\n\n does not exist ! \n\n " + strRef, 1, "E");
                    }
                    else
                    {
                        StreamReader sr = clDashFunction.open4read(mdiDashboard.strPutty_Plink_Loca);
                        if (sr != null)
                        {
                            txtBoksText.Text = sr.ReadLine();
                            sr.Close();
                            bReturn = true;
                        }
                        else
                        {
                            clDashFunction.Melding("Unable to read from Boks passwordfile: " + mdiDashboard.strPutty_Plink_Loca, 1, "E");
                        }
                    }
                }
            }
            else
            {
                clDashFunction.Melding("Variabele bestaat niet " +
                "\n\n does not exist ! \n\n " + strRef, 1, "E");                
            }
            return bReturn;
        }

        private void cmdBoksWhere_Click(object sender, EventArgs e)
        {
            clDashFunction.Melding("Here's the Boks passwordfile location: \n\n " + mdiDashboard.strPutty_Plink_Loca, 1, "I");
        }

        private void able_controls(Boolean bEnabled)
        {
            txtBoksSQLUser.Enabled = bEnabled;
            txtBoksSQLPassword.Enabled = bEnabled;
            txtBoksText.Enabled = bEnabled;

            txtNewUser.Enabled = false;
        }


        private void cmdApply_Click(object sender, EventArgs e)
        {
            DoApply();           
        }

        private Boolean DoApply()
        {
            Boolean bReturn = false;

            if (txtNewUser.Text.Trim() != "")
            {
                if (txtNewPassword.Text.Trim() != "")
                {
                    if (DoSqlUpdate())
                    {
                        // Opnieuw schermvariabelen inlezen
                        frm_init();
                        txtNewPassword.Text = "";
                        bReturn = true;
                    }

                }
            }
            return bReturn;
        }

        private void txtNewPassword_TextChanged(object sender, EventArgs e)
        {
            bInputCheck();
        }

        private void bInputCheck()
        {
            Boolean bOk = false;

            if (txtNewUser.Text.Trim() != "" && txtNewPassword.Text.Trim() != "")
            {
                bOk = true;
            }

            cmdApply.Enabled = bOk;
            cmdOke.Enabled = bOk;  
        }

        private Boolean DoSqlUpdate()
        {

            Boolean bReturn = false;

            string strNewCred = "-l "+txtNewUser.Text+ " -pw "+txtNewPassword.Text;

            DoSql mySql = new DoSql();

            /////////////////////////
            // Prepare 4 SQL version 
            /////////////////////////
            mySql.vul_deze_string = "";

            mySql.DoQuery("SELECT  ElemMdat & ElemMtyd " +
                           "FROM   DashElem " +
                           "WHERE  ElemTabn = 10 " +
                           "AND    ElemElem = 'PUTTYPLCRED'");

            if (mySql.affected_rows == 1)
            {
                // Concurrent update check
                if (strPuttyPlLoca_ts == mySql.vul_deze_string)
                {
                    string strMutDatum = clDashFunction.get_mutdatum();
                    string strMutTijd = clDashFunction.get_muttijd();

                    strPuttyPlLoca_ts =  strMutDatum + strMutTijd;
                    
                    mySql.DoUpdate(" UPDATE DashElem " +
                                   " SET ElemOms1 = '" + strNewCred + "'" +
                                       ",ElemMdat = '" + strMutDatum + "'" +
                                       ",ElemMtyd = '" + strMutTijd + "'" +
                                       ",ElemMusr = 'SYSTEM'" +
                                   " WHERE ElemTabn = 10 " +
                                   " AND   ElemElem = 'PUTTYPLCRED'");

                    bReturn=clDashFunction.Write2File(strNewCred, mdiDashboard.strPutty_Plink_Loca);                    
                }
                else
                {
                    clDashFunction.Melding("Someone else has changed the Boks credentials in SQL in the mean time. \n\n "+ 
                    "Please close this function en try again",1,"E");
                }

            }

            return bReturn;
        }

        private void frmDashBoks_Paint(object sender, PaintEventArgs e)
        {
            if (!bInitOk)
            {
                this.Close();
            }
            txtNewPassword.Focus();
        }

        private void txtNewUser_TextChanged(object sender, EventArgs e)
        {
            bInputCheck();
        }

        /*
         * Uitvragen van het bChanged property van de controls van type txtMaint
        */
        private Boolean QueryChangedStatus(Control parent)
        {
            Boolean bReturn = false;

            foreach (Control C in parent.Controls)
            {   
                if (C.GetType() == typeof(txtMaint))
                {
                    txtMaint txtMaintC = (txtMaint)C;
                    if (txtMaintC.bChanged)
                    {
                        bReturn = true;
                        break;
                    }                    
                }
                else
                {
                    //nop
                }
            }
            return bReturn;
        }

        /*
         * Reset het bChanged proptery van de controls van type txtMaint
        */ 
        private void ClearChangedStatus(Control parent)
        {        
            foreach (Control C in parent.Controls)
            {                
                if (C.GetType() == typeof(txtMaint))
                {
                    txtMaint txtMaintC = (txtMaint)C;
                    txtMaintC.bChanged = false;                    
                }
                else
                {
                    //nop
                }
            }            
        }

        private void cmdNewUser_Click(object sender, EventArgs e)
        {
            txtNewUser.Enabled = true;
            cmdNewUser.Enabled = false;
        }       

        private void cmdKankel_Click(object sender, EventArgs e)
        {
            if (QueryChangedStatus(grbNewVal))
            {
                if (clDashFunction.Melding("Er is data gewijzigd !\nWeet u zeker dat u wilt stoppen zonder opslaan ? (wijzigen gaan verloren) ", 4, "Q") != DialogResult.Yes)
                {
                    return;
                }
            }
            this.Close();
        }

        private void cmdOke_Click(object sender, EventArgs e)
        {
            if (DoApply())
            {
                cmdKankel_Click(new object(), new EventArgs());
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Text = System.Environment.TickCount.ToString();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }              
    }
}

