﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace dbDashboard
{
    public partial class frmDashBase :Form
    {
        public Boolean bChanged;       
        
        // Global Unix connectie parms
        public string g_server;
        public string g_userid;
        public string g_password;
        public string g_pwd;
        public Int16  g_ftp_port;
        public Int16  g_telnet_port;

        public string strUserCode;
        public string strUserUgro;

        public string strRemote_file; 
        public string strRemote_dir;
        public string strLocal_file;

        public frmDashBase()
        {
            InitializeComponent();
        }

        protected void frmDashBase_Load(object sender, EventArgs e)
        {
            
            // Toevoegen aan arraylist ter voorkoming van dubbele opstart... 
            clDashFunction.block_form(mdiDashboard.alForms_loaded, this.Name);
            this.lblHostName.Text = System.Environment.UserDomainName + "\\" + System.Environment.MachineName;
            // Hier worden ALS ENIGE PLEK de inifile tags gedefinieerd!!!
            // we ontkomen nu eenmaal niet aan het ooit hard coded neerzetten 
           // alIniTags = new ArrayList(8);
           // alIniTags.Add("[MAX]");
           // alIniTags.Add("[MIN]");
           // alIniTags.Add("[CMDFILE]");

//            alIniVars = new ArrayList(8);
        }

        protected void frmDashBase_FormClosed(object sender, FormClosedEventArgs e)
        {
            // Toevoegen aan arraylist ter voorkoming van dubbele opstart... 
            clDashFunction.release_form(mdiDashboard.alForms_loaded, this.Name);
        }

        protected void cmdAfsluiten_Click(object sender, EventArgs e)
        {
            if (bChanged)
            {
                if (clDashFunction.Melding("Er is data gewijzigd !\nWeet u zeker dat u wilt stoppen zonder opslaan ? (wijzigen gaan verloren) ", 4, "Q") != DialogResult.Yes)
                {
                    return;
                }
            }
            this.Close();
        }

        private void tsbMenu_Click(object sender, EventArgs e)
        {
            clDashFunction.bring_form_to_front("frmDashMenu", MdiParent);
        }          
    }
}
