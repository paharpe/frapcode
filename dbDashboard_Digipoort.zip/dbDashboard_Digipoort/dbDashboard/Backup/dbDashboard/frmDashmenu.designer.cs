namespace dbDashboard
{
    partial class frmDashMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDashMenu));
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.lblToolTip = new System.Windows.Forms.Label();
            this.lblUser_data = new System.Windows.Forms.Label();
            this.lblAangemeld = new System.Windows.Forms.Label();
            this.gebruikersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groepenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.subsystemenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.funcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tvMenu = new System.Windows.Forms.TreeView();
            this.flwPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.grpLine = new System.Windows.Forms.GroupBox();
            this.grpLineVert = new System.Windows.Forms.GroupBox();
            this.txtPad = new System.Windows.Forms.TextBox();
            this.lblPad = new System.Windows.Forms.Label();
            this.grbConnectie.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmdAfsluiten
            // 
            this.cmdAfsluiten.Location = new System.Drawing.Point(761, 557);
            this.cmdAfsluiten.Size = new System.Drawing.Size(12, 10);
            this.cmdAfsluiten.Visible = false;
            // 
            // grbConnectie
            // 
            this.grbConnectie.Location = new System.Drawing.Point(775, 557);
            this.grbConnectie.Size = new System.Drawing.Size(68, 10);
            this.grbConnectie.Visible = false;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "Dashboard.bmp");
            this.imageList1.Images.SetKeyName(1, "Dashboard_blue.bmp");
            // 
            // lblToolTip
            // 
            this.lblToolTip.AutoSize = true;
            this.lblToolTip.Location = new System.Drawing.Point(7, 554);
            this.lblToolTip.Name = "lblToolTip";
            this.lblToolTip.Size = new System.Drawing.Size(53, 13);
            this.lblToolTip.TabIndex = 3;
            this.lblToolTip.Text = "lblToolTip";
            // 
            // lblUser_data
            // 
            this.lblUser_data.AutoSize = true;
            this.lblUser_data.Location = new System.Drawing.Point(349, 553);
            this.lblUser_data.Name = "lblUser_data";
            this.lblUser_data.Size = new System.Drawing.Size(66, 13);
            this.lblUser_data.TabIndex = 4;
            this.lblUser_data.Text = "lblUser_data";
            this.lblUser_data.UseMnemonic = false;
            // 
            // lblAangemeld
            // 
            this.lblAangemeld.AutoSize = true;
            this.lblAangemeld.Location = new System.Drawing.Point(283, 553);
            this.lblAangemeld.Name = "lblAangemeld";
            this.lblAangemeld.Size = new System.Drawing.Size(63, 13);
            this.lblAangemeld.TabIndex = 5;
            this.lblAangemeld.Text = "Aangemeld:";
            // 
            // gebruikersToolStripMenuItem
            // 
            this.gebruikersToolStripMenuItem.Name = "gebruikersToolStripMenuItem";
            this.gebruikersToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.gebruikersToolStripMenuItem.Text = "Gebruikers";
            // 
            // groepenToolStripMenuItem
            // 
            this.groepenToolStripMenuItem.Name = "groepenToolStripMenuItem";
            this.groepenToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.groepenToolStripMenuItem.Text = "Groepen";
            // 
            // subsystemenToolStripMenuItem
            // 
            this.subsystemenToolStripMenuItem.Name = "subsystemenToolStripMenuItem";
            this.subsystemenToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.subsystemenToolStripMenuItem.Text = "Subsystemen";
            // 
            // funcToolStripMenuItem
            // 
            this.funcToolStripMenuItem.Name = "funcToolStripMenuItem";
            this.funcToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.funcToolStripMenuItem.Text = "Functies";
            // 
            // tvMenu
            // 
            this.tvMenu.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.tvMenu.BackColor = System.Drawing.Color.White;
            this.tvMenu.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tvMenu.ImageIndex = 0;
            this.tvMenu.ImageList = this.imageList1;
            this.tvMenu.Location = new System.Drawing.Point(4, 29);
            this.tvMenu.Name = "tvMenu";
            this.tvMenu.SelectedImageIndex = 0;
            this.tvMenu.Size = new System.Drawing.Size(274, 517);
            this.tvMenu.TabIndex = 8;
            this.tvMenu.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.tvMenu_AfterSelect);
            // 
            // flwPanel
            // 
            this.flwPanel.BackColor = System.Drawing.Color.White;
            this.flwPanel.Location = new System.Drawing.Point(281, 29);
            this.flwPanel.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.flwPanel.Name = "flwPanel";
            this.flwPanel.Padding = new System.Windows.Forms.Padding(0, 20, 0, 0);
            this.flwPanel.Size = new System.Drawing.Size(574, 517);
            this.flwPanel.TabIndex = 9;
            this.flwPanel.MouseLeave += new System.EventHandler(this.flwPanel_MouseLeave);
            this.flwPanel.MouseHover += new System.EventHandler(this.flwPanel_MouseHover);
            // 
            // grpLine
            // 
            this.grpLine.Location = new System.Drawing.Point(4, 25);
            this.grpLine.Name = "grpLine";
            this.grpLine.Size = new System.Drawing.Size(852, 3);
            this.grpLine.TabIndex = 10;
            this.grpLine.TabStop = false;
            // 
            // grpLineVert
            // 
            this.grpLineVert.Location = new System.Drawing.Point(278, -7);
            this.grpLineVert.Name = "grpLineVert";
            this.grpLineVert.Size = new System.Drawing.Size(4, 553);
            this.grpLineVert.TabIndex = 11;
            this.grpLineVert.TabStop = false;
            // 
            // txtPad
            // 
            this.txtPad.Location = new System.Drawing.Point(322, 4);
            this.txtPad.Name = "txtPad";
            this.txtPad.Size = new System.Drawing.Size(531, 20);
            this.txtPad.TabIndex = 12;
            // 
            // lblPad
            // 
            this.lblPad.AutoSize = true;
            this.lblPad.Location = new System.Drawing.Point(289, 8);
            this.lblPad.Name = "lblPad";
            this.lblPad.Size = new System.Drawing.Size(29, 13);
            this.lblPad.TabIndex = 13;
            this.lblPad.Text = "Pad:";
            // 
            // frmDashMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(859, 570);
            this.Controls.Add(this.lblPad);
            this.Controls.Add(this.txtPad);
            this.Controls.Add(this.grpLineVert);
            this.Controls.Add(this.grpLine);
            this.Controls.Add(this.flwPanel);
            this.Controls.Add(this.tvMenu);
            this.Controls.Add(this.lblAangemeld);
            this.Controls.Add(this.lblUser_data);
            this.Controls.Add(this.lblToolTip);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmDashMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "DB Dashboard";
            this.Load += new System.EventHandler(this.frmDashMenu_Load);
            this.Controls.SetChildIndex(this.lblVoortgang, 0);
            this.Controls.SetChildIndex(this.lblToolTip, 0);
            this.Controls.SetChildIndex(this.lblUser_data, 0);
            this.Controls.SetChildIndex(this.lblAangemeld, 0);
            this.Controls.SetChildIndex(this.tvMenu, 0);
            this.Controls.SetChildIndex(this.flwPanel, 0);
            this.Controls.SetChildIndex(this.grpLine, 0);
            this.Controls.SetChildIndex(this.grpLineVert, 0);
            this.Controls.SetChildIndex(this.cmdAfsluiten, 0);
            this.Controls.SetChildIndex(this.txtPad, 0);
            this.Controls.SetChildIndex(this.grbConnectie, 0);
            this.Controls.SetChildIndex(this.lblPad, 0);
            this.grbConnectie.ResumeLayout(false);
            this.grbConnectie.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Label lblToolTip;
        private System.Windows.Forms.Label lblUser_data;
        private System.Windows.Forms.Label lblAangemeld;
        private System.Windows.Forms.ToolStripMenuItem gebruikersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem groepenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem subsystemenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem funcToolStripMenuItem;
        private System.Windows.Forms.TreeView tvMenu;
        private System.Windows.Forms.FlowLayoutPanel flwPanel;
        private System.Windows.Forms.GroupBox grpLine;
        private System.Windows.Forms.GroupBox grpLineVert;
        private System.Windows.Forms.TextBox txtPad;
        private System.Windows.Forms.Label lblPad;
    }
}

