﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.IO;

namespace dbDashboard
{
    public partial class frmDashEnvir : frmDashBase
    {
        private Int16       shAuto_close;
        public  string      strDownload_functie;
        public  ArrayList   alBericht;
       
        public frmDashEnvir()
        {
            InitializeComponent();
        }

        private void frmDashInit_Load(object sender, EventArgs e)
        {
            frm_init();   
        }

        private void frm_init()
        {
            lblInitFout.Visible = false;
            if (strDownload_functie == null)
            {
                lblInitFout.Visible = true;
                pgBar.Visible       = false;
                for (int i = 0; i < alBericht.Count; i++)
                {
                    vul_lbBericht(alBericht[i].ToString());                    
                }
            }        
        }

        private void frmDashInit_Shown(object sender, EventArgs e)
        {
            if (strDownload_functie != null)
            {
                switch (strDownload_functie)
                {
                         
                    default:
                        clDashFunction.Melding("Onbekende download functie: " + strDownload_functie, 1, "E");
                        break;
                }
            }
        }

             

        private void start_timer(Int16 shSeconden)
        {
            shAuto_close = clDashFunction.get_autoclose();
            this.Refresh();
            lblInitFout.Text    = "";
            lblInitFout.Visible = true;
            timer1.Interval     = shSeconden*1000;
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {            
            shAuto_close--;
            lblInitFout.Text = "AutoClose: " + shAuto_close.ToString() + " sec..";
            this.Refresh();
            if (shAuto_close < 1)
            {
                this.Close();
            }
        }

        private void vul_lbBericht(string strText)
        {
            lbBericht.Items.Add(strText);
            this.Refresh();
        }

        private void cmdSettings_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            frmDashSettings DashSettings = new frmDashSettings();
            DashSettings.MdiParent       = this.MdiParent;
            DashSettings.strUserCode     = this.strUserCode;
            DashSettings.strUserUgro     = this.strUserUgro;
            DashSettings.ShowDialog();
            DashSettings.Dispose();
            this.Close();
        }

        private void cmdAfsluiten_Click_1(object sender, EventArgs e)
        {

        }
    }    
}
