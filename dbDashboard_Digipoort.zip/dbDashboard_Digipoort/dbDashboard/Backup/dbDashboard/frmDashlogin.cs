﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace dbDashboard
{
    public partial class frmDashlogin : frmDashBase
    {
        public Boolean  bLogin_cancelled     = true;
        public string   strUsercode = " ";
        public string   strUsernaam = " ";
        public string   strUserugro = " ";

        public frmDashlogin()
        {
            InitializeComponent();           
        }

        private void frmDashlogin_Load(object sender, EventArgs e)
        {
            frm_init();
        }

        private void frm_init()
        {
            cmdOK.Enabled = true; //false;
            txtUser.Focus();
        }

        private void txtUser_TextChanged(object sender, EventArgs e)
        {
            Check_input();
        }
       

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            Check_input();
        }

        private void Check_input()
        {
            cmdOK.Enabled = false;
            if (txtUser.Text != "" && txtPassword.Text != "")
            {
                cmdOK.Enabled = true;               
            }
        }

        private void cmdCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public void cmdOK_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            DoSql mysql = new DoSql();
            // mysql.vul_deze_string = " ";
            mysql.vul_deze_text1_array[1] = "FTA";
            mysql.DoQuery(" SELECT UserNaam, UserUgro, 'DUMMY'" +
                          " FROM DashUser "+ 
                          " WHERE UserCode = '" + txtUser.Text      + "'" +
                          " AND   UserPass = '" + txtPassword.Text  + "'");
            if (mysql.affected_rows < 1)
            {
                clDashFunction.Melding("Aanmelden mislukt: naam e/o wachtwoord onbekend !", 1,"I");                 
                txtUser.Focus();
                this.Cursor = Cursors.Default;
                return;
            }
            else
            {
                this.strUsercode = txtUser.Text;
                this.strUsernaam = txtUser.Text + " - " + mysql.vul_deze_text1_array[1].ToString() + 
                                                 " - " + 
                                                 mysql.vul_deze_text2_array[1].ToString();
                this.strUserugro = mysql.vul_deze_text2_array[1].ToString();   
                
            }
            bLogin_cancelled = false;
            this.Cursor = Cursors.Default;
            this.Close();      
        }

        private void cmdDatabase_Click(object sender, EventArgs e)
        {
            string strDB_status = "Onderstaande database is NIET aanwezig: ";
            if (File.Exists(mdiDashboard.access_database))
            {
                strDB_status = "Onderstaande database is WEL aanwezig: ";
            }
            clDashFunction.Melding( strDB_status + 
                                    System.Environment.NewLine+
                                    mdiDashboard.access_database,1,"I" );
        }       
    }
}
