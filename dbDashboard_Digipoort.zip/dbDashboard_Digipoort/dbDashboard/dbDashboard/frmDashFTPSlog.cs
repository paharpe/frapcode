﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.IO;
// using Excel = Microsoft.Office.Interop.Excel;

namespace dbDashboard
{
    public partial class frmDashFTPSlog : frmDashBase
    {
        public frmDashFTPSlog()
        {
            InitializeComponent();
        }

        public string strPlink;
        public string strTranx;
        private string strOTP_logfile_path;

        private void cmdSelect_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            get_logrecords(txtLogical.Text);
            this.Cursor = Cursors.Default;
        }

        private void get_logrecords(string strLogical)
        {

            string strServer = lbServer.Text;       // "kslv072";
            string strGrep = "";
            string strTranferLogRecord;
            int intRowNo = 0;
            dgTransferLog.Rows.Clear();
            this.Refresh();

            strGrep = "grep " + txtLogical.Text + " "+ strOTP_logfile_path;
            // from OTP_transfer.log
            // to   OTP_transfer.log*
            // so all history will be included in the search as well
            if (cbCurrentLog.Checked)
            {
                strGrep = strGrep + "*";
            }

            if (!cbDelivered.Checked)
            {
                strGrep = strGrep + " | grep -v " + cbDelivered.Text;
            }
            
            if (!cbPut.Checked)
            {
                strGrep = strGrep + " | grep -v " + cbPut.Text;
            }
            
            if (!cbGet.Checked)
            {
                strGrep = strGrep + " | grep -v " + cbGet.Text;
            }

            if (!cbError.Checked)
            {
                strGrep = strGrep + " | grep -v " + cbError.Text;
            }

            if (!cbMeta.Checked)
            {
                strGrep = strGrep + " | grep -v " + cbMeta.Text;
            }

            if (!cbOK.Checked)
            {
                strGrep = strGrep + " | grep -v " + cbOK.Text;
            }

            if (!cbErrExt.Checked)
            {
                strGrep = strGrep + " | grep -v " + cbErrExt.Text;
            }


            if ( txtAdditional.Text.Trim() != "")
            {
                strGrep = strGrep + " | grep -i " + txtAdditional.Text.Trim();
            }

            // Ketenbewaking eraf slopen
            strGrep = strGrep + " | grep -v dpkb";

            if (mdiDashboard.Talk)
            {
                clDashFunction.Melding("QueryParms: strServer: " + strServer + "\n strTrans:" + strGrep,1,"I");
            }

            StreamReader myStreamReader = clDashFunction.get_linux_data(strServer, strGrep);
            if (myStreamReader != null)
            {             
                while (!myStreamReader.EndOfStream)
                {        
                    strTranferLogRecord = myStreamReader.ReadLine();
                    
                    intRowNo = dgTransferLog.Rows.Add();
                    dgTransferLog[0, intRowNo].Value = strTranferLogRecord;
                   
                }
            }
            if (intRowNo < 0)
            {
                dgTransferLog.Enabled = false;
                clDashFunction.Melding("No logrecords selected", 1, "I");
            }
            else
            {
                dgTransferLog.Enabled = true;
            }

            // nul = nul, maar anders komt de telling steevast 1 te laag uit.
            //            we beginnen immers te tellen bij rij 0 en die bevat record 1
            if (intRowNo > 0)
            { intRowNo++; }

            lblCount.Text = intRowNo.ToString();
        }

        private void frmDashFTPSlog_Load(object sender, EventArgs e)
        {
            frm_init();
        }

        private Boolean frm_init()
        {
            Boolean bInit_Ok = true;
            
            cmdSelect.Enabled = false;
            
            cbPut.Checked = true;
            cbGet.Checked = true;
            cbDelivered.Checked = true;
            cbError.Checked = true;
            cbMeta.Checked = true;
            cbOK.Checked = true;
            cbErrExt.Checked = true;

            //Vul Combobox met FTPs servers
            DoSql mySql = new DoSql();
            mySql.vul_deze_text1_array[1] = "FTA";

            mySql.DoQuery("SELECT   ElemElem, ElemOms1,ElemOms2 " +
                          "FROM     DashElem " +
                          "WHERE    ElemTabn = 12 " +
                          "AND      ElemOms1 like '%FTPS%' " +
                          "ORDER BY ElemOms2,ElemOms1,ElemElem");

            if (mySql.affected_rows < 1)
            {
                clDashFunction.Melding("Geen FTPS servers gedefinieerd in tabel 12", 1, "I");
                bInit_Ok = false;
            }
            else
            {
                int intAffected_rows_index = 1;
                while (intAffected_rows_index <= mySql.affected_rows)
                {
                    if (mySql.vul_deze_text1_array[intAffected_rows_index] != null)
                    {
                        lbServer.Items.Add(mySql.vul_deze_text1_array[intAffected_rows_index]);
                    }
                    intAffected_rows_index++;
                }
                lbServer.SelectedIndex = 0;
            }
            txtLogical.Enabled = bInit_Ok;

            strOTP_logfile_path = clDashFunction.get_path("FTPS_TRANS_PATH");

            if (strOTP_logfile_path.Trim() == "")
            {
                clDashFunction.Melding("Geen FPTS transferlog file(path) gedefinieerd in tabel nr:10 - elm:FTPS_TRANS_PATH", 1, "I");
                bInit_Ok = false;
            }

            return bInit_Ok;
        }

        private void txtLogical_TextChanged(object sender, EventArgs e)
        {
            dgTransferLog.Rows.Clear();
            is_selection_ok(txtLogical.Text, txtAdditional.Text,  lbServer.SelectedItem.ToString());
        }

        private void txtAdditional_TextChanged(object sender, EventArgs e)
        {
            is_selection_ok(txtLogical.Text, txtAdditional.Text, lbServer.SelectedItem.ToString());
        }

        private void is_selection_ok(string strLogical, string strAdditional, string strServer)
        {
            Boolean bReturn = false;

            if ( ( strLogical.Trim().Length >= 4 || strAdditional.Trim().Length >= 3) && strServer.Trim() != "" )
            {   
                bReturn = true;
            }
                        
            cmdSelect.Enabled = bReturn;            
        }

        private void cmdOTPTable_Click(object sender, EventArgs e)
        {
            
            string strELM = "FTPS_LOCAL_OTP";

            string strOTP_Path = openFileDlg.InitialDirectory = clDashFunction.get_path(strELM, true,false);
            if (strOTP_Path.Trim() != "")
            {
                openFileDlg.InitialDirectory = strOTP_Path;
            }

            openFileDlg.FileName = "otp-adrestabel.";
            
            openFileDlg.AddExtension = false;
            openFileDlg.Filter = "Excel 2003 files (*.xls)|*.xls|Excel 2010 files (*.xlsx)|*.xlsx";
            openFileDlg.DefaultExt = "txt";
            if (openFileDlg.ShowDialog() == DialogResult.OK)
            {
                show_excel(openFileDlg.FileName);
            }
        }

        private void show_excel(string strFile)
        {
            if (File.Exists(strFile))
            {
                try
                {
                    System.Diagnostics.Process.Start(strFile);
                }
                catch (Exception e)
                {
                    clDashFunction.Melding("Error \n" + e.Message + "\n while trying to open Excel file", 1, "E");
                }
            }
            else
            {
                clDashFunction.Melding("File: " + strFile + " does not exist !", 1, "E");
            }
        }     
    }
}
