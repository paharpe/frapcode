﻿namespace dbDashboard
{
    partial class frmDashlogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDashlogin));
            this.cmdOK = new System.Windows.Forms.Button();
            this.cmdCancel = new System.Windows.Forms.Button();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtUser = new System.Windows.Forms.TextBox();
            this.lblpassword = new System.Windows.Forms.Label();
            this.lblUserId = new System.Windows.Forms.Label();
            this.lbldbDashboard = new System.Windows.Forms.Label();
            this.lblVersion = new System.Windows.Forms.Label();
            this.pbDPLogo = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbDPLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // cmdOK
            // 
            this.cmdOK.BackColor = System.Drawing.SystemColors.Control;
            this.cmdOK.Location = new System.Drawing.Point(351, 69);
            this.cmdOK.Name = "cmdOK";
            this.cmdOK.Size = new System.Drawing.Size(99, 23);
            this.cmdOK.TabIndex = 3;
            this.cmdOK.Text = "Logon";
            this.cmdOK.UseVisualStyleBackColor = true;
            this.cmdOK.Click += new System.EventHandler(this.cmdOK_Click);
            // 
            // cmdCancel
            // 
            this.cmdCancel.BackColor = System.Drawing.SystemColors.Control;
            this.cmdCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cmdCancel.Location = new System.Drawing.Point(455, 69);
            this.cmdCancel.Name = "cmdCancel";
            this.cmdCancel.Size = new System.Drawing.Size(99, 23);
            this.cmdCancel.TabIndex = 4;
            this.cmdCancel.Text = "Cancel";
            this.cmdCancel.UseVisualStyleBackColor = true;
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(302, 41);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(250, 20);
            this.txtPassword.TabIndex = 2;
            this.txtPassword.Text = "Sdo$dar3";
            this.txtPassword.TextChanged += new System.EventHandler(this.txtPassword_TextChanged);
            // 
            // txtUser
            // 
            this.txtUser.Location = new System.Drawing.Point(302, 17);
            this.txtUser.MaxLength = 10;
            this.txtUser.Name = "txtUser";
            this.txtUser.Size = new System.Drawing.Size(250, 20);
            this.txtUser.TabIndex = 1;
            this.txtUser.Text = "SDO";
            this.txtUser.TextChanged += new System.EventHandler(this.txtUser_TextChanged);
            // 
            // lblpassword
            // 
            this.lblpassword.AutoSize = true;
            this.lblpassword.BackColor = System.Drawing.Color.Transparent;
            this.lblpassword.Location = new System.Drawing.Point(230, 45);
            this.lblpassword.Name = "lblpassword";
            this.lblpassword.Size = new System.Drawing.Size(56, 13);
            this.lblpassword.TabIndex = 13;
            this.lblpassword.Text = "Password:";
            // 
            // lblUserId
            // 
            this.lblUserId.AutoSize = true;
            this.lblUserId.BackColor = System.Drawing.Color.Transparent;
            this.lblUserId.Location = new System.Drawing.Point(230, 21);
            this.lblUserId.Name = "lblUserId";
            this.lblUserId.Size = new System.Drawing.Size(40, 13);
            this.lblUserId.TabIndex = 11;
            this.lblUserId.Text = "Userid:";
            // 
            // lbldbDashboard
            // 
            this.lbldbDashboard.AutoSize = true;
            this.lbldbDashboard.BackColor = System.Drawing.Color.Transparent;
            this.lbldbDashboard.Font = new System.Drawing.Font("Arial Narrow", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldbDashboard.ForeColor = System.Drawing.Color.Black;
            this.lbldbDashboard.Location = new System.Drawing.Point(14, 67);
            this.lbldbDashboard.Name = "lbldbDashboard";
            this.lbldbDashboard.Size = new System.Drawing.Size(105, 25);
            this.lbldbDashboard.TabIndex = 15;
            this.lbldbDashboard.Text = "Dashboard";
            // 
            // lblVersion
            // 
            this.lblVersion.AutoSize = true;
            this.lblVersion.BackColor = System.Drawing.Color.Transparent;
            this.lblVersion.Font = new System.Drawing.Font("Arial Narrow", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVersion.ForeColor = System.Drawing.Color.Black;
            this.lblVersion.Location = new System.Drawing.Point(125, 75);
            this.lblVersion.Name = "lblVersion";
            this.lblVersion.Size = new System.Drawing.Size(58, 15);
            this.lblVersion.TabIndex = 21;
            this.lblVersion.Text = "Version 1.2";
            // 
            // pbDPLogo
            // 
            this.pbDPLogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbDPLogo.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pbDPLogo.ErrorImage")));
            this.pbDPLogo.Image = ((System.Drawing.Image)(resources.GetObject("pbDPLogo.Image")));
            this.pbDPLogo.Location = new System.Drawing.Point(8, 6);
            this.pbDPLogo.Name = "pbDPLogo";
            this.pbDPLogo.Size = new System.Drawing.Size(197, 51);
            this.pbDPLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbDPLogo.TabIndex = 22;
            this.pbDPLogo.TabStop = false;
            this.pbDPLogo.Click += new System.EventHandler(this.pbDPLogo_Click);
            // 
            // frmDashlogin
            // 
            this.AcceptButton = this.cmdOK;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.CancelButton = this.cmdCancel;
            this.ClientSize = new System.Drawing.Size(563, 99);
            this.Controls.Add(this.txtUser);
            this.Controls.Add(this.cmdOK);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.lblUserId);
            this.Controls.Add(this.lblpassword);
            this.Controls.Add(this.lbldbDashboard);
            this.Controls.Add(this.cmdCancel);
            this.Controls.Add(this.pbDPLogo);
            this.Controls.Add(this.lblVersion);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmDashlogin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Digipoort Dashboard; logon";
            this.Load += new System.EventHandler(this.frmDashlogin_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbDPLogo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button cmdOK;
        private System.Windows.Forms.Button cmdCancel;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.TextBox txtUser;
        private System.Windows.Forms.Label lblpassword;
        private System.Windows.Forms.Label lblUserId;
        private System.Windows.Forms.Label lbldbDashboard;
        private System.Windows.Forms.Label lblVersion;
        private System.Windows.Forms.PictureBox pbDPLogo;
    }
}