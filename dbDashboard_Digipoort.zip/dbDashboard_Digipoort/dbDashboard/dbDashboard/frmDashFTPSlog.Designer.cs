﻿namespace dbDashboard
{
    partial class frmDashFTPSlog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grbTransferLog = new System.Windows.Forms.GroupBox();
            this.lblDPKB = new System.Windows.Forms.Label();
            this.lblCountTxt = new System.Windows.Forms.Label();
            this.lblCount = new System.Windows.Forms.Label();
            this.dgTransferLog = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grbTransferSelect = new System.Windows.Forms.GroupBox();
            this.grbIncludeExtensies = new System.Windows.Forms.GroupBox();
            this.cbMeta = new System.Windows.Forms.CheckBox();
            this.cbErrExt = new System.Windows.Forms.CheckBox();
            this.cbOK = new System.Windows.Forms.CheckBox();
            this.grbHist = new System.Windows.Forms.GroupBox();
            this.cbCurrentLog = new DBDashboard.cbMaint();
            this.cmdOTPTable = new System.Windows.Forms.Button();
            this.lblAdditional_min = new System.Windows.Forms.Label();
            this.lblLocigal_min = new System.Windows.Forms.Label();
            this.lblAndOr = new System.Windows.Forms.Label();
            this.cmdSelect = new System.Windows.Forms.Button();
            this.txtAdditional = new System.Windows.Forms.TextBox();
            this.lblAdditional = new System.Windows.Forms.Label();
            this.grbClude = new System.Windows.Forms.GroupBox();
            this.cbError = new System.Windows.Forms.CheckBox();
            this.cbDelivered = new System.Windows.Forms.CheckBox();
            this.cbGet = new System.Windows.Forms.CheckBox();
            this.cbPut = new System.Windows.Forms.CheckBox();
            this.lblServer = new System.Windows.Forms.Label();
            this.lbServer = new System.Windows.Forms.ListBox();
            this.txtLogical = new System.Windows.Forms.TextBox();
            this.lblLogical = new System.Windows.Forms.Label();
            this.openFileDlg = new System.Windows.Forms.OpenFileDialog();
            this.grbConnect.SuspendLayout();
            this.grbTransferLog.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgTransferLog)).BeginInit();
            this.grbTransferSelect.SuspendLayout();
            this.grbIncludeExtensies.SuspendLayout();
            this.grbHist.SuspendLayout();
            this.grbClude.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmdAfsluiten
            // 
            this.cmdAfsluiten.Location = new System.Drawing.Point(12, 603);
            this.cmdAfsluiten.TabIndex = 1;
            // 
            // grbConnect
            // 
            this.grbConnect.Location = new System.Drawing.Point(303, 693);
            // 
            // lblHostName
            // 
            this.lblHostName.Location = new System.Drawing.Point(965, 620);
            this.lblHostName.Size = new System.Drawing.Size(145, 13);
            this.lblHostName.TabIndex = 2;
            this.lblHostName.Text = "KPNNL\\WLD4BED923B63C";
            // 
            // grbTransferLog
            // 
            this.grbTransferLog.Controls.Add(this.lblDPKB);
            this.grbTransferLog.Controls.Add(this.lblCountTxt);
            this.grbTransferLog.Controls.Add(this.lblCount);
            this.grbTransferLog.Controls.Add(this.dgTransferLog);
            this.grbTransferLog.Controls.Add(this.grbTransferSelect);
            this.grbTransferLog.Location = new System.Drawing.Point(12, 22);
            this.grbTransferLog.Name = "grbTransferLog";
            this.grbTransferLog.Size = new System.Drawing.Size(1083, 573);
            this.grbTransferLog.TabIndex = 0;
            this.grbTransferLog.TabStop = false;
            this.grbTransferLog.Text = "Select / View Digipoort FTPs log records";
            // 
            // lblDPKB
            // 
            this.lblDPKB.AutoSize = true;
            this.lblDPKB.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDPKB.Location = new System.Drawing.Point(613, 552);
            this.lblDPKB.Name = "lblDPKB";
            this.lblDPKB.Size = new System.Drawing.Size(449, 13);
            this.lblDPKB.TabIndex = 4;
            this.lblDPKB.Text = "Note: \'ketenbewaking\' records are excluded from the selected row(s) implicitly";
            // 
            // lblCountTxt
            // 
            this.lblCountTxt.AutoSize = true;
            this.lblCountTxt.Location = new System.Drawing.Point(11, 550);
            this.lblCountTxt.Name = "lblCountTxt";
            this.lblCountTxt.Size = new System.Drawing.Size(163, 13);
            this.lblCountTxt.TabIndex = 2;
            this.lblCountTxt.Text = "Number of log record(s) selected:";
            // 
            // lblCount
            // 
            this.lblCount.AutoSize = true;
            this.lblCount.Location = new System.Drawing.Point(174, 550);
            this.lblCount.Name = "lblCount";
            this.lblCount.Size = new System.Drawing.Size(13, 13);
            this.lblCount.TabIndex = 3;
            this.lblCount.Text = "0";
            // 
            // dgTransferLog
            // 
            this.dgTransferLog.AllowUserToAddRows = false;
            this.dgTransferLog.AllowUserToDeleteRows = false;
            this.dgTransferLog.AllowUserToOrderColumns = true;
            this.dgTransferLog.AllowUserToResizeColumns = false;
            this.dgTransferLog.AllowUserToResizeRows = false;
            this.dgTransferLog.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgTransferLog.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1});
            this.dgTransferLog.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnF2;
            this.dgTransferLog.Location = new System.Drawing.Point(12, 212);
            this.dgTransferLog.Name = "dgTransferLog";
            this.dgTransferLog.RowHeadersVisible = false;
            this.dgTransferLog.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgTransferLog.ShowCellErrors = false;
            this.dgTransferLog.ShowCellToolTips = false;
            this.dgTransferLog.ShowEditingIcon = false;
            this.dgTransferLog.ShowRowErrors = false;
            this.dgTransferLog.Size = new System.Drawing.Size(1050, 335);
            this.dgTransferLog.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.FillWeight = 500F;
            this.dataGridViewTextBoxColumn1.HeaderText = "Log record";
            this.dataGridViewTextBoxColumn1.MaxInputLength = 250;
            this.dataGridViewTextBoxColumn1.MinimumWidth = 1050;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 1050;
            // 
            // grbTransferSelect
            // 
            this.grbTransferSelect.Controls.Add(this.grbIncludeExtensies);
            this.grbTransferSelect.Controls.Add(this.grbHist);
            this.grbTransferSelect.Controls.Add(this.cmdOTPTable);
            this.grbTransferSelect.Controls.Add(this.lblAdditional_min);
            this.grbTransferSelect.Controls.Add(this.lblLocigal_min);
            this.grbTransferSelect.Controls.Add(this.lblAndOr);
            this.grbTransferSelect.Controls.Add(this.cmdSelect);
            this.grbTransferSelect.Controls.Add(this.txtAdditional);
            this.grbTransferSelect.Controls.Add(this.lblAdditional);
            this.grbTransferSelect.Controls.Add(this.grbClude);
            this.grbTransferSelect.Controls.Add(this.lblServer);
            this.grbTransferSelect.Controls.Add(this.lbServer);
            this.grbTransferSelect.Controls.Add(this.txtLogical);
            this.grbTransferSelect.Controls.Add(this.lblLogical);
            this.grbTransferSelect.Location = new System.Drawing.Point(14, 38);
            this.grbTransferSelect.Name = "grbTransferSelect";
            this.grbTransferSelect.Size = new System.Drawing.Size(1048, 134);
            this.grbTransferSelect.TabIndex = 0;
            this.grbTransferSelect.TabStop = false;
            this.grbTransferSelect.Text = "Criteria";
            // 
            // grbIncludeExtensies
            // 
            this.grbIncludeExtensies.Controls.Add(this.cbMeta);
            this.grbIncludeExtensies.Controls.Add(this.cbErrExt);
            this.grbIncludeExtensies.Controls.Add(this.cbOK);
            this.grbIncludeExtensies.Location = new System.Drawing.Point(858, 20);
            this.grbIncludeExtensies.Name = "grbIncludeExtensies";
            this.grbIncludeExtensies.Size = new System.Drawing.Size(171, 102);
            this.grbIncludeExtensies.TabIndex = 13;
            this.grbIncludeExtensies.TabStop = false;
            this.grbIncludeExtensies.Text = "Include file extensions";
            // 
            // cbMeta
            // 
            this.cbMeta.AutoSize = true;
            this.cbMeta.Location = new System.Drawing.Point(10, 75);
            this.cbMeta.Name = "cbMeta";
            this.cbMeta.Size = new System.Drawing.Size(52, 17);
            this.cbMeta.TabIndex = 2;
            this.cbMeta.Text = ".meta";
            this.cbMeta.UseVisualStyleBackColor = true;
            // 
            // cbErrExt
            // 
            this.cbErrExt.AutoSize = true;
            this.cbErrExt.Location = new System.Drawing.Point(10, 17);
            this.cbErrExt.Name = "cbErrExt";
            this.cbErrExt.Size = new System.Drawing.Size(50, 17);
            this.cbErrExt.TabIndex = 0;
            this.cbErrExt.Text = ".error";
            this.cbErrExt.UseVisualStyleBackColor = true;
            // 
            // cbOK
            // 
            this.cbOK.AutoSize = true;
            this.cbOK.Location = new System.Drawing.Point(10, 46);
            this.cbOK.Name = "cbOK";
            this.cbOK.Size = new System.Drawing.Size(41, 17);
            this.cbOK.TabIndex = 1;
            this.cbOK.Text = ".ok";
            this.cbOK.UseVisualStyleBackColor = true;
            // 
            // grbHist
            // 
            this.grbHist.Controls.Add(this.cbCurrentLog);
            this.grbHist.Location = new System.Drawing.Point(512, 20);
            this.grbHist.Name = "grbHist";
            this.grbHist.Size = new System.Drawing.Size(330, 50);
            this.grbHist.TabIndex = 10;
            this.grbHist.TabStop = false;
            this.grbHist.Text = "History";
            // 
            // cbCurrentLog
            // 
            this.cbCurrentLog.AutoSize = true;
            this.cbCurrentLog.bChanged = false;
            this.cbCurrentLog.BitValue = ((short)(0));
            this.cbCurrentLog.Location = new System.Drawing.Point(13, 20);
            this.cbCurrentLog.Name = "cbCurrentLog";
            this.cbCurrentLog.OldValue = false;
            this.cbCurrentLog.Size = new System.Drawing.Size(254, 17);
            this.cbCurrentLog.TabIndex = 0;
            this.cbCurrentLog.Text = "Look in archived OTP_transfer.log* file(s) as well";
            this.cbCurrentLog.UseVisualStyleBackColor = true;
            // 
            // cmdOTPTable
            // 
            this.cmdOTPTable.Location = new System.Drawing.Point(254, 16);
            this.cmdOTPTable.Name = "cmdOTPTable";
            this.cmdOTPTable.Size = new System.Drawing.Size(24, 21);
            this.cmdOTPTable.TabIndex = 2;
            this.cmdOTPTable.Text = "...";
            this.cmdOTPTable.UseVisualStyleBackColor = true;
            this.cmdOTPTable.Click += new System.EventHandler(this.cmdOTPTable_Click);
            // 
            // lblAdditional_min
            // 
            this.lblAdditional_min.AutoSize = true;
            this.lblAdditional_min.Location = new System.Drawing.Point(281, 58);
            this.lblAdditional_min.Name = "lblAdditional_min";
            this.lblAdditional_min.Size = new System.Drawing.Size(70, 13);
            this.lblAdditional_min.TabIndex = 7;
            this.lblAdditional_min.Text = "(min. 3 chars)";
            // 
            // lblLocigal_min
            // 
            this.lblLocigal_min.AutoSize = true;
            this.lblLocigal_min.Location = new System.Drawing.Point(281, 20);
            this.lblLocigal_min.Name = "lblLocigal_min";
            this.lblLocigal_min.Size = new System.Drawing.Size(70, 13);
            this.lblLocigal_min.TabIndex = 3;
            this.lblLocigal_min.Text = "(min. 4 chars)";
            // 
            // lblAndOr
            // 
            this.lblAndOr.AutoSize = true;
            this.lblAndOr.Location = new System.Drawing.Point(49, 40);
            this.lblAndOr.Name = "lblAndOr";
            this.lblAndOr.Size = new System.Drawing.Size(42, 13);
            this.lblAndOr.TabIndex = 4;
            this.lblAndOr.Text = "And/Or";
            // 
            // cmdSelect
            // 
            this.cmdSelect.Location = new System.Drawing.Point(11, 100);
            this.cmdSelect.Name = "cmdSelect";
            this.cmdSelect.Size = new System.Drawing.Size(75, 23);
            this.cmdSelect.TabIndex = 11;
            this.cmdSelect.Text = "Select";
            this.cmdSelect.UseVisualStyleBackColor = true;
            this.cmdSelect.Click += new System.EventHandler(this.cmdSelect_Click);
            // 
            // txtAdditional
            // 
            this.txtAdditional.Location = new System.Drawing.Point(142, 54);
            this.txtAdditional.Name = "txtAdditional";
            this.txtAdditional.Size = new System.Drawing.Size(136, 20);
            this.txtAdditional.TabIndex = 6;
            this.txtAdditional.TextChanged += new System.EventHandler(this.txtAdditional_TextChanged);
            // 
            // lblAdditional
            // 
            this.lblAdditional.AutoSize = true;
            this.lblAdditional.Location = new System.Drawing.Point(9, 58);
            this.lblAdditional.Name = "lblAdditional";
            this.lblAdditional.Size = new System.Drawing.Size(124, 13);
            this.lblAdditional.TabIndex = 5;
            this.lblAdditional.Text = "Log record contains text:";
            // 
            // grbClude
            // 
            this.grbClude.Controls.Add(this.cbError);
            this.grbClude.Controls.Add(this.cbDelivered);
            this.grbClude.Controls.Add(this.cbGet);
            this.grbClude.Controls.Add(this.cbPut);
            this.grbClude.Location = new System.Drawing.Point(512, 74);
            this.grbClude.Name = "grbClude";
            this.grbClude.Size = new System.Drawing.Size(330, 49);
            this.grbClude.TabIndex = 11;
            this.grbClude.TabStop = false;
            this.grbClude.Text = "Include event(s)";
            // 
            // cbError
            // 
            this.cbError.AutoSize = true;
            this.cbError.Location = new System.Drawing.Point(196, 21);
            this.cbError.Name = "cbError";
            this.cbError.Size = new System.Drawing.Size(65, 17);
            this.cbError.TabIndex = 3;
            this.cbError.Text = "ERROR";
            this.cbError.UseVisualStyleBackColor = true;
            // 
            // cbDelivered
            // 
            this.cbDelivered.AutoSize = true;
            this.cbDelivered.Location = new System.Drawing.Point(109, 21);
            this.cbDelivered.Name = "cbDelivered";
            this.cbDelivered.Size = new System.Drawing.Size(87, 17);
            this.cbDelivered.TabIndex = 2;
            this.cbDelivered.Text = "DELIVERED";
            this.cbDelivered.UseVisualStyleBackColor = true;
            // 
            // cbGet
            // 
            this.cbGet.AutoSize = true;
            this.cbGet.Location = new System.Drawing.Point(61, 21);
            this.cbGet.Name = "cbGet";
            this.cbGet.Size = new System.Drawing.Size(48, 17);
            this.cbGet.TabIndex = 1;
            this.cbGet.Text = "GET";
            this.cbGet.UseVisualStyleBackColor = true;
            // 
            // cbPut
            // 
            this.cbPut.AutoSize = true;
            this.cbPut.Location = new System.Drawing.Point(13, 21);
            this.cbPut.Name = "cbPut";
            this.cbPut.Size = new System.Drawing.Size(48, 17);
            this.cbPut.TabIndex = 0;
            this.cbPut.Text = "PUT";
            this.cbPut.UseVisualStyleBackColor = true;
            // 
            // lblServer
            // 
            this.lblServer.AutoSize = true;
            this.lblServer.Location = new System.Drawing.Point(379, 12);
            this.lblServer.Name = "lblServer";
            this.lblServer.Size = new System.Drawing.Size(53, 13);
            this.lblServer.TabIndex = 8;
            this.lblServer.Text = "On server";
            // 
            // lbServer
            // 
            this.lbServer.FormattingEnabled = true;
            this.lbServer.Location = new System.Drawing.Point(380, 28);
            this.lbServer.Name = "lbServer";
            this.lbServer.Size = new System.Drawing.Size(120, 95);
            this.lbServer.TabIndex = 9;
            // 
            // txtLogical
            // 
            this.txtLogical.Location = new System.Drawing.Point(142, 16);
            this.txtLogical.Name = "txtLogical";
            this.txtLogical.Size = new System.Drawing.Size(112, 20);
            this.txtLogical.TabIndex = 1;
            this.txtLogical.TextChanged += new System.EventHandler(this.txtLogical_TextChanged);
            // 
            // lblLogical
            // 
            this.lblLogical.AutoSize = true;
            this.lblLogical.Location = new System.Drawing.Point(9, 20);
            this.lblLogical.Name = "lblLogical";
            this.lblLogical.Size = new System.Drawing.Size(127, 13);
            this.lblLogical.TabIndex = 0;
            this.lblLogical.Text = "Logical address contains:";
            // 
            // openFileDlg
            // 
            this.openFileDlg.FileName = "openFileDialog1";
            // 
            // frmDashFTPSlog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1107, 633);
            this.Controls.Add(this.grbTransferLog);
            this.Name = "frmDashFTPSlog";
            this.Text = "frmDashFTPSlog; Logging FTPs Accounts";
            this.Load += new System.EventHandler(this.frmDashFTPSlog_Load);
            this.Controls.SetChildIndex(this.cmdAfsluiten, 0);
            this.Controls.SetChildIndex(this.lblHostName, 0);
            this.Controls.SetChildIndex(this.grbConnect, 0);
            this.Controls.SetChildIndex(this.grbTransferLog, 0);
            this.grbConnect.ResumeLayout(false);
            this.grbConnect.PerformLayout();
            this.grbTransferLog.ResumeLayout(false);
            this.grbTransferLog.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgTransferLog)).EndInit();
            this.grbTransferSelect.ResumeLayout(false);
            this.grbTransferSelect.PerformLayout();
            this.grbIncludeExtensies.ResumeLayout(false);
            this.grbIncludeExtensies.PerformLayout();
            this.grbHist.ResumeLayout(false);
            this.grbHist.PerformLayout();
            this.grbClude.ResumeLayout(false);
            this.grbClude.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grbTransferLog;
        private System.Windows.Forms.DataGridView dgTransferLog;
        private System.Windows.Forms.GroupBox grbTransferSelect;
        private System.Windows.Forms.TextBox txtLogical;
        private System.Windows.Forms.Label lblLogical;
        private System.Windows.Forms.Button cmdSelect;
        private System.Windows.Forms.Label lblServer;
        private System.Windows.Forms.ListBox lbServer;
        private System.Windows.Forms.Label lblCountTxt;
        private System.Windows.Forms.Label lblCount;
        private System.Windows.Forms.GroupBox grbClude;
        private System.Windows.Forms.CheckBox cbMeta;
        private System.Windows.Forms.CheckBox cbDelivered;
        private System.Windows.Forms.CheckBox cbGet;
        private System.Windows.Forms.CheckBox cbPut;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.TextBox txtAdditional;
        private System.Windows.Forms.Label lblAdditional;
        private System.Windows.Forms.Label lblDPKB;
        private System.Windows.Forms.Label lblAndOr;
        private System.Windows.Forms.Label lblAdditional_min;
        private System.Windows.Forms.Label lblLocigal_min;
        private System.Windows.Forms.CheckBox cbError;
        private System.Windows.Forms.Button cmdOTPTable;
        private System.Windows.Forms.OpenFileDialog openFileDlg;
        private DBDashboard.cbMaint cbCurrentLog;
        private System.Windows.Forms.GroupBox grbHist;
        private System.Windows.Forms.GroupBox grbIncludeExtensies;
        private System.Windows.Forms.CheckBox cbErrExt;
        private System.Windows.Forms.CheckBox cbOK;
    }
}